/*     */ import processing.core.PApplet;
/*     */ import processing.core.PFont;
/*     */ 
/*     */ public class Directional_Derivative extends PApplet
/*     */ {
/*     */   float axes_centre_x;
/*     */   float axes_centre_y;
/*     */   float axes_centre_z;
/*     */   float x_axes_length;
/*     */   float y_axes_length;
/*     */   float z_axes_length;
/*     */   boolean rotate_cam_y;
/*     */   boolean rotate_cam_x;
/*     */   float rotate_y;
/*     */   float rotate_x;
/*     */   float rotate_speed;
/*     */   float surface_res;
/*     */   float stretchFactor;
/*     */   float transformx;
/*     */   float transformy;
/*     */   float transformz;
/*     */   float infinitesimal;
/*     */   float tangent_length;
/*     */   float speed;
/*     */   float scale_speed;
/*     */   float angle_scale_speed;
/*     */   float dotted_line_length;
/*     */   float r0_x;
/*     */   float r0_y;
/*     */   float u_theta;
/*     */   float u_a;
/*     */   float u_b;
/*     */   float s;
/*     */   float r_x;
/*     */   float r_y;
/*     */   boolean draw_overlay;
/*     */   float rect_size;
/*     */   float rect_angle_minus_pos_x;
/*     */   float rect_angle_minus_pos_y;
/*     */   float rect_angle_plus_pos_x;
/*     */   float rect_angle_plus_pos_y;
/*     */   boolean rect_angle_minus;
/*     */   boolean rect_angle_plus;
/*     */   float rect_s_minus_pos_x;
/*     */   float rect_s_minus_pos_y;
/*     */   float rect_s_plus_pos_x;
/*     */   float rect_s_plus_pos_y;
/*     */   boolean rect_s_minus;
/*     */   boolean rect_s_plus;
/*     */   boolean mouse_over_button;
/*     */   PFont font;
/*     */   Directional_Derivative.Slider sSlider;
/*     */   Directional_Derivative.Button btnXminus;
/*     */   Directional_Derivative.Button btnXplus;
/*     */   Directional_Derivative.Button btnYminus;
/*     */   Directional_Derivative.Button btnYplus;
/*     */   Directional_Derivative.ToggleButton tbCurve;
/*     */ 
/*     */   public void reset()
/*     */   {
/*  60 */     this.rotate_cam_y = false;
/*  61 */     this.rotate_cam_x = false;
/*  62 */     this.rotate_y = 0.0F;
/*  63 */     this.rotate_x = 0.0F;
/*  64 */     this.infinitesimal = 0.001F;
/*  65 */     this.tangent_length = 100.0F;
/*  66 */     this.r0_x = 100.0F;
/*  67 */     this.r0_y = 100.0F;
/*  68 */     this.u_theta = 0.7853982F;
/*  69 */     this.u_a = cos(this.u_theta);
/*  70 */     this.u_b = sin(this.u_theta);
/*  71 */     this.s = 50.0F;
/*  72 */     this.r_x = (this.r0_x + this.u_a * this.s);
/*  73 */     this.r_y = (this.r0_y + this.u_b * this.s);
/*  74 */     this.draw_overlay = false;
/*  75 */     this.sSlider.updatePosition(5);
/*  76 */     this.tbCurve.value = false;
/*     */   }
/*     */ 
/*     */   public void setup()
/*     */   {
/*  81 */     size(640, 480, "processing.core.PGraphics3");
/*  82 */     background(255.0F, 255.0F, 255.0F);
/*  83 */     stroke(0.0F, 0.0F, 0.0F);
/*  84 */     framerate(60.0F);
/*  85 */     this.font = loadFont("Arial-Black-20.vlw");
/*  86 */     textFont(this.font, 20.0F);
/*     */ 
/*  88 */     this.sSlider = new Directional_Derivative.Slider(500, 90, 100, 14, 1, 14, 5);
/*  89 */     this.btnXminus = new Directional_Derivative.Button(510, 370, 30, 30, "-x");
/*  90 */     this.btnXplus = new Directional_Derivative.Button(575, 370, 30, 30, "+x");
/*  91 */     this.btnYplus = new Directional_Derivative.Button(542, 330, 30, 30, "+y");
/*  92 */     this.btnYminus = new Directional_Derivative.Button(542, 410, 30, 30, "-y");
/*  93 */     this.tbCurve = new Directional_Derivative.ToggleButton(500, 130, 110, 20, "Draw Curve");
/*     */   }
/*     */ 
/*     */   public boolean mouseOverRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*     */   {
/* 100 */     return ((this.mouseX >= paramFloat1) && (this.mouseX <= paramFloat1 + paramFloat3) && (this.mouseY >= paramFloat2) && (this.mouseY <= paramFloat2 + paramFloat4));
/*     */   }
/*     */ 
/*     */   public void keyPressed()
/*     */   {
/* 108 */     if (this.key == 'r')
/*     */     {
/* 110 */       reset();
/*     */     }
/* 112 */     if (this.keyCode == 38)
/*     */     {
/* 114 */       this.r0_x += this.scale_speed;
/* 115 */       if (this.r0_x + this.u_a * this.s > this.x_axes_length) this.r0_x -= this.scale_speed;
/*     */     }
/* 117 */     if (this.keyCode == 40)
/*     */     {
/* 119 */       this.r0_x -= this.scale_speed;
/* 120 */       if (this.r0_x + this.u_a * this.s < 0.0F) this.r0_x += this.scale_speed;
/*     */     }
/* 122 */     if (this.keyCode == 39)
/*     */     {
/* 124 */       this.r0_y += this.scale_speed;
/* 125 */       if (this.r0_y + this.u_b * this.s > this.y_axes_length) this.r0_y -= this.scale_speed;
/*     */     }
/* 127 */     if (this.keyCode == 37)
/*     */     {
/* 129 */       this.r0_y -= this.scale_speed;
/* 130 */       if (this.r0_y + this.u_b * this.s < 0.0F) this.r0_y += this.scale_speed;
/*     */     }
/* 132 */     if (this.keyCode != 10)
/*     */       return;
/* 134 */     if (this.draw_overlay) this.draw_overlay = false; else this.draw_overlay = true;
/*     */   }
/*     */ 
/*     */   public void mousePressed()
/*     */   {
/* 140 */     if (this.mouseButton == 39)
/*     */     {
/* 142 */       this.rotate_cam_y = true;
/* 143 */       this.rotate_cam_x = true;
/*     */     }
/*     */ 
/* 146 */     if (this.mouseButton != 37)
/*     */       return;
/* 148 */     this.sSlider.processMouseDown();
/* 149 */     this.btnXminus.processMouseDown();
/* 150 */     this.btnXplus.processMouseDown();
/* 151 */     this.btnYplus.processMouseDown();
/* 152 */     this.btnYminus.processMouseDown();
/* 153 */     this.tbCurve.processMouseDown();
/*     */   }
/*     */ 
/*     */   public void mouseReleased()
/*     */   {
/* 159 */     if (this.mouseButton == 39)
/*     */     {
/* 161 */       this.rotate_cam_y = false;
/* 162 */       this.rotate_cam_x = false;
/*     */     }
/* 164 */     if (this.mouseButton != 37)
/*     */       return;
/* 166 */     this.sSlider.processMouseUp();
/* 167 */     this.btnXminus.processMouseUp();
/* 168 */     this.btnXplus.processMouseUp();
/* 169 */     this.btnYplus.processMouseUp();
/* 170 */     this.btnYminus.processMouseUp();
/*     */   }
/*     */ 
/*     */   public float actualFunction(float paramFloat1, float paramFloat2)
/*     */   {
/* 176 */     return (-paramFloat1 * paramFloat1 * 0.05F * paramFloat2 * paramFloat2);
/*     */   }
/*     */ 
/*     */   public float f(float paramFloat1, float paramFloat2)
/*     */   {
/* 182 */     return (this.stretchFactor * actualFunction(paramFloat1 + this.transformx, paramFloat2 + this.transformy) + this.transformz);
/*     */   }
/*     */ 
/*     */   public void checkMouse(float paramFloat1, float paramFloat2)
/*     */   {
/* 187 */     this.mouse_over_button = false;
/*     */ 
/* 189 */     if (mouseOverRect(this.rect_angle_minus_pos_x, this.rect_angle_minus_pos_y, this.rect_size, this.rect_size)) { this.rect_angle_minus = true; this.mouse_over_button = true; } else { this.rect_angle_minus = false; }
/* 190 */     if (mouseOverRect(this.rect_angle_plus_pos_x, this.rect_angle_plus_pos_y, this.rect_size, this.rect_size)) { this.rect_angle_plus = true; this.mouse_over_button = true; } else { this.rect_angle_plus = false;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void draw()
/*     */   {
/* 197 */     background(255.0F, 255.0F, 255.0F);
/* 198 */     checkMouse(this.mouseX, this.mouseY);
/*     */ 
/* 200 */     this.sSlider.draw();
/* 201 */     this.btnXminus.draw();
/* 202 */     this.btnXplus.draw();
/* 203 */     this.btnYminus.draw();
/* 204 */     this.btnYplus.draw();
/* 205 */     this.tbCurve.draw();
/*     */ 
/* 207 */     this.draw_overlay = this.tbCurve.value;
/*     */ 
/* 209 */     if (this.btnXplus.value)
/*     */     {
/* 211 */       this.r0_x += this.scale_speed;
/* 212 */       if (this.r0_x + this.u_a * this.s > this.x_axes_length) this.r0_x -= this.scale_speed;
/*     */     }
/* 214 */     if (this.btnXminus.value)
/*     */     {
/* 216 */       this.r0_x -= this.scale_speed;
/* 217 */       if (this.r0_x + this.u_a * this.s < 0.0F) this.r0_x += this.scale_speed;
/*     */     }
/* 219 */     if (this.btnYplus.value)
/*     */     {
/* 221 */       this.r0_y += this.scale_speed;
/* 222 */       if (this.r0_y + this.u_b * this.s > this.y_axes_length) this.r0_y -= this.scale_speed;
/*     */     }
/* 224 */     if (this.btnYminus.value)
/*     */     {
/* 226 */       this.r0_y -= this.scale_speed;
/* 227 */       if (this.r0_y + this.u_b * this.s < 0.0F) this.r0_y += this.scale_speed;
/*     */ 
/*     */     }
/*     */ 
/* 231 */     rectMode(0);
/* 232 */     stroke(0);
/* 233 */     if (this.rect_angle_minus) fill(255); else fill(200);
/* 234 */     rect(this.rect_angle_minus_pos_x, this.rect_angle_minus_pos_y, this.rect_size, this.rect_size);
/* 235 */     if (this.rect_angle_plus) fill(255); else fill(200);
/* 236 */     rect(this.rect_angle_plus_pos_x, this.rect_angle_plus_pos_y, this.rect_size, this.rect_size);
/* 237 */     fill(0);
/* 238 */     textSize(40.0F);
/* 239 */     text("-", this.rect_angle_minus_pos_x + 10.0F, this.rect_angle_minus_pos_y + this.rect_size - 4);
/* 240 */     text("+", this.rect_angle_plus_pos_x + 3.2F, this.rect_angle_plus_pos_y + this.rect_size);
/* 241 */     textSize(16.0F);
/* 242 */     text("rotate direction u", this.rect_angle_minus_pos_x - 40.0F, this.rect_angle_minus_pos_y + this.rect_size + 26.0F);
/*     */ 
/* 252 */     textSize(20.0F);
/* 253 */     text("s", this.rect_s_minus_pos_x + 30.0F, 110.0F);
/*     */ 
/* 256 */     if (this.mousePressed)
/*     */     {
/* 258 */       if (this.rect_angle_plus)
/*     */       {
/* 260 */         this.u_theta += this.angle_scale_speed;
/* 261 */         if (this.u_theta > 6.283186F) this.u_theta = 0.0F;
/*     */       }
/* 263 */       if (this.rect_angle_minus)
/*     */       {
/* 265 */         this.u_theta -= this.angle_scale_speed;
/*     */       }
/* 267 */       if (this.rect_s_minus)
/*     */       {
/* 269 */         this.s -= this.scale_speed;
/* 270 */         if (this.s < 0.1F) this.s = 0.1F;
/*     */       }
/* 272 */       if (this.rect_s_plus)
/*     */       {
/* 274 */         this.s += this.scale_speed;
/* 275 */         if ((this.r0_x + this.u_a * this.s > this.x_axes_length) || (this.r0_y + this.u_b * this.s > this.y_axes_length)) this.s -= this.scale_speed;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 280 */     stroke(0); fill(0);
/* 281 */     translate(this.axes_centre_x, this.axes_centre_y, this.axes_centre_z);
/* 282 */     translate(this.x_axes_length / 2.0F, -this.y_axes_length / 2.0F, this.z_axes_length / 2.0F);
/* 283 */     if (this.rotate_cam_y)
/*     */     {
/* 285 */       if (this.mouseX - this.pmouseX > 0.0F) this.rotate_y += this.rotate_speed;
/* 286 */       if (this.mouseX - this.pmouseX < 0.0F) this.rotate_y -= this.rotate_speed;
/* 287 */       if (this.rotate_y >= 6.283186F) this.rotate_y = 0.0F;
/*     */     }
/* 289 */     if (this.rotate_cam_x)
/*     */     {
/* 291 */       if (this.mouseY - this.pmouseY > 0.0F) this.rotate_x -= this.rotate_speed;
/* 292 */       if (this.mouseY - this.pmouseY < 0.0F) this.rotate_x += this.rotate_speed;
/* 293 */       if (this.rotate_x >= 6.283186F) this.rotate_x = 0.0F;
/*     */     }
/* 295 */     rotateX(this.rotate_x);
/* 296 */     rotateY(this.rotate_y);
/* 297 */     translate(-this.x_axes_length / 2.0F, this.y_axes_length / 2.0F, -this.z_axes_length / 2.0F);
/* 298 */     line(0.0F, 0.0F, 0.0F, this.x_axes_length, 0.0F, 0.0F);
/* 299 */     line(0.0F, 0.0F, 0.0F, 0.0F, -this.y_axes_length, 0.0F);
/* 300 */     line(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, this.z_axes_length);
/* 301 */     textSize(20.0F);
/* 302 */     text("z", 0.0F, -this.y_axes_length - 20.0F, 0.0F);
/* 303 */     text("x", this.x_axes_length + 20.0F, 0.0F, 0.0F);
/* 304 */     text("y", 0.0F, 0.0F, this.z_axes_length + 20.0F);
/*     */ 
/* 307 */     float f1 = 50.0F;
/* 308 */     if (this.draw_overlay) f1 = 20.0F;
/* 309 */     stroke(100.0F, 100.0F, 100.0F, f1);
/* 310 */     for (float f2 = 0.0F; f2 < this.x_axes_length; f2 += this.surface_res)
/*     */     {
/* 312 */       for (f3 = 0.0F; f3 < this.y_axes_length; f3 += this.surface_res)
/*     */       {
/* 315 */         line(f2, -f(f2, f3), f3, f2 + this.surface_res, -f(f2 + this.surface_res, f3), f3);
/* 316 */         line(f2, -f(f2, f3), f3, f2, -f(f2, f3 + this.surface_res), f3 + this.surface_res);
/* 317 */         line(f2 + this.surface_res, -f(f2 + this.surface_res, f3), f3, f2 + this.surface_res, -f(f2 + this.surface_res, f3 + this.surface_res), f3 + this.surface_res);
/* 318 */         line(f2, -f(f2, f3 + this.surface_res), f3 + this.surface_res, f2 + this.surface_res, -f(f2 + this.surface_res, f3 + this.surface_res), f3 + this.surface_res);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 325 */     stroke(0);
/* 326 */     line(0.0F, 0.0F, 0.0F, this.r0_x, -f(this.r0_x, this.r0_y), this.r0_y);
/* 327 */     this.u_a = cos(this.u_theta);
/* 328 */     this.u_b = sin(this.u_theta);
/* 329 */     this.r_x = (this.r0_x + this.u_a * this.s);
/* 330 */     this.r_y = (this.r0_y + this.u_b * this.s);
/* 331 */     stroke(0);
/* 332 */     line(0.0F, 0.0F, 0.0F, this.r_x, -f(this.r_x, this.r_y), this.r_y);
/* 333 */     stroke(0.0F, 0.0F, 255.0F);
/* 334 */     line(this.r0_x, -f(this.r0_x, this.r0_y), this.r0_y, this.r_x, -f(this.r_x, this.r_y), this.r_y);
/* 335 */     stroke(255.0F, 0.0F, 0.0F);
/* 336 */     line(this.r0_x, -f(this.r0_x, this.r0_y), this.r0_y, this.r_x, -f(this.r0_x, this.r0_y), this.r_y);
/* 337 */     stroke(0.0F, 255.0F, 0.0F);
/* 338 */     line(this.r_x, -f(this.r0_x, this.r0_y), this.r_y, this.r_x, -f(this.r_x, this.r_y), this.r_y);
/*     */ 
/* 341 */     stroke(0);
/* 342 */     f2 = atan((f(this.r_x, this.r_y) - f(this.r0_x, this.r0_y)) / this.s);
/* 343 */     float f3 = this.r0_x + this.u_a * (this.s + this.tangent_length);
/* 344 */     float f4 = this.r0_y + this.u_b * (this.s + this.tangent_length);
/* 345 */     float f5 = this.tangent_length * tan(f2);
/* 346 */     line(this.r_x, -f(this.r_x, this.r_y), this.r_y, f3, -f(this.r_x, this.r_y) - f5, f4);
/* 347 */     f3 = this.r0_x - (this.u_a * this.tangent_length);
/* 348 */     f4 = this.r0_y - (this.u_b * this.tangent_length);
/* 349 */     line(this.r0_x, -f(this.r0_x, this.r0_y), this.r0_y, f3, -f(this.r0_x, this.r0_y) + f5, f4);
/*     */ 
/* 352 */     if (!(this.draw_overlay))
/*     */       return;
/* 354 */     float f6 = 0.0F;
/* 355 */     while ((this.r0_x + this.u_a * f6 < this.x_axes_length) && (this.r0_y + this.u_b * f6 < this.y_axes_length) && (this.r0_x + this.u_a * f6 > 0.0F) && (this.r0_y + this.u_b * f6 > 0.0F))
/*     */     {
/* 357 */       line(this.r0_x + this.u_a * f6, -f(this.r0_x + this.u_a * f6, this.r0_y + this.u_b * f6), this.r0_y + this.u_b * f6, this.r0_x + this.u_a * (f6 + this.surface_res), -f(this.r0_x + this.u_a * (f6 + this.surface_res), this.r0_y + this.u_b * (f6 + this.surface_res)), this.r0_y + this.u_b * (f6 + this.surface_res));
/* 358 */       f6 += this.surface_res;
/*     */     }
/* 360 */     f6 = 0.0F;
/* 361 */     while ((this.r0_x + this.u_a * f6 < this.x_axes_length) && (this.r0_y + this.u_b * f6 < this.y_axes_length) && (this.r0_x + this.u_a * f6 > 0.0F) && (this.r0_y + this.u_b * f6 > 0.0F))
/*     */     {
/* 363 */       line(this.r0_x + this.u_a * f6, -f(this.r0_x + this.u_a * f6, this.r0_y + this.u_b * f6), this.r0_y + this.u_b * f6, this.r0_x + this.u_a * (f6 + this.surface_res), -f(this.r0_x + this.u_a * (f6 + this.surface_res), this.r0_y + this.u_b * (f6 + this.surface_res)), this.r0_y + this.u_b * (f6 + this.surface_res));
/* 364 */       f6 -= this.surface_res;
/*     */     }
/*     */   }
/*     */ 
/*     */   private final void jdMethod_this()
/*     */   {
/*   4 */     this.axes_centre_x = 150.0F;
/*   5 */     this.axes_centre_y = 400.0F;
/*   6 */     this.axes_centre_z = -300.0F;
/*   7 */     this.x_axes_length = 365.0F;
/*   8 */     this.y_axes_length = 365.0F;
/*   9 */     this.z_axes_length = 365.0F;
/*  10 */     this.rotate_cam_y = false;
/*  11 */     this.rotate_cam_x = false;
/*  12 */     this.rotate_y = 0.0F;
/*  13 */     this.rotate_x = 0.0F;
/*  14 */     this.rotate_speed = 0.05F;
/*  15 */     this.surface_res = 10.0F;
/*  16 */     this.stretchFactor = 7.E-06F;
/*  17 */     this.transformx = -150.0F;
/*  18 */     this.transformy = -140.0F;
/*  19 */     this.transformz = 150.0F;
/*  20 */     this.infinitesimal = 0.001F;
/*  21 */     this.tangent_length = 100.0F;
/*  22 */     this.speed = 10.1F;
/*  23 */     this.scale_speed = 2.0F;
/*  24 */     this.angle_scale_speed = 0.05F;
/*  25 */     this.dotted_line_length = 5;
/*  26 */     this.r0_x = 100.0F;
/*  27 */     this.r0_y = 100.0F;
/*  28 */     this.u_theta = 0.7853982F;
/*  29 */     this.u_a = cos(this.u_theta);
/*  30 */     this.u_b = sin(this.u_theta);
/*  31 */     this.s = 50.0F;
/*  32 */     this.r_x = (this.r0_x + this.u_a * this.s);
/*  33 */     this.r_y = (this.r0_y + this.u_b * this.s);
/*  34 */     this.draw_overlay = false;
/*  35 */     this.rect_size = 30.0F;
/*  36 */     this.rect_angle_minus_pos_x = 520.0F;
/*  37 */     this.rect_angle_minus_pos_y = 10.0F;
/*  38 */     this.rect_angle_plus_pos_x = (this.rect_angle_minus_pos_x + this.rect_size + 10.0F);
/*  39 */     this.rect_angle_plus_pos_y = this.rect_angle_minus_pos_y;
/*  40 */     this.rect_angle_minus = false;
/*  41 */     this.rect_angle_plus = false;
/*  42 */     this.rect_s_minus_pos_x = 520.0F;
/*  43 */     this.rect_s_minus_pos_y = 90.0F;
/*  44 */     this.rect_s_plus_pos_x = (this.rect_s_minus_pos_x + this.rect_size + 10.0F);
/*  45 */     this.rect_s_plus_pos_y = this.rect_s_minus_pos_y;
/*  46 */     this.rect_s_minus = false;
/*  47 */     this.rect_s_plus = false;
/*  48 */     this.mouse_over_button = false;
/*     */   }
/*     */ 
/*     */   public Directional_Derivative()
/*     */   {
/*   1 */     jdMethod_this();
/*     */   }
/*     */ 
/*     */   class Slider
/*     */   {
/*     */     private int _x;
/*     */     private int _y;
/*     */     private int _w;
/*     */     private int _h;
/*     */     private int _minValue;
/*     */     private int _maxValue;
/*     */     private int _pos;
/*     */     private float _frac;
/*     */     private boolean _dragging;
/*     */ 
/*     */     public void draw()
/*     */     {
/* 383 */       if (this._dragging) {
/* 384 */         int i = Directional_Derivative.this.mouseX - this._x;
/* 385 */         if (i < 0) {
/* 386 */           i = 0;
/*     */         }
/* 388 */         else if (i > this._w) {
/* 389 */           i = this._w;
/*     */         }
/* 391 */         this._frac = (i / this._w);
/* 392 */         updatePosition((int)(i / this._w * (this._maxValue - this._minValue)));
/*     */       }
/*     */ 
/* 395 */       Directional_Derivative.this.pushMatrix();
/* 396 */       Directional_Derivative.this.translate(this._x, this._y);
/* 397 */       Directional_Derivative.this.stroke(50.0F, 50.0F, 50.0F);
/* 398 */       Directional_Derivative.this.line(0.0F, 0.0F, this._w, 0.0F);
/* 399 */       Directional_Derivative.this.pushMatrix();
/* 400 */       Directional_Derivative.this.translate(this._w * this._pos / (this._maxValue - this._minValue), 0.0F);
/*     */ 
/* 402 */       Directional_Derivative.this.fill(0.0F, 0.0F, 255.0F);
/* 403 */       Directional_Derivative.this.rectMode(3);
/* 404 */       Directional_Derivative.this.rect(0.0F, 0.0F, this._h, this._h);
/* 405 */       Directional_Derivative.this.popMatrix();
/* 406 */       Directional_Derivative.this.popMatrix();
/*     */     }
/*     */ 
/*     */     public void updatePosition(int paramInt) {
/* 410 */       this._pos = paramInt;
/* 411 */       Directional_Derivative.this.s = (this._minValue + (this._maxValue - this._minValue) * paramInt);
/*     */     }
/*     */ 
/*     */     public void processMouseDown() {
/* 415 */       int i = Directional_Derivative.this.mouseX - this._x;
/* 416 */       int j = Directional_Derivative.this.mouseY - this._y;
/* 417 */       if (Directional_Derivative.mag(i - (this._w * this._pos / (this._maxValue - this._minValue)), j) <= this._h)
/* 418 */         this._dragging = true;
/*     */     }
/*     */ 
/*     */     public void processMouseUp()
/*     */     {
/* 423 */       this._dragging = false;
/*     */     }
/*     */ 
/*     */     private final void jdMethod_this()
/*     */     {
/* 435 */       this._dragging = false;
/*     */     }
/*     */ 
/*     */     public Slider(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7)
/*     */     {
/* 372 */       jdMethod_this();
/* 373 */       this._x = paramInt1;
/* 374 */       this._y = paramInt2;
/* 375 */       this._w = paramInt3;
/* 376 */       this._h = paramInt4;
/* 377 */       this._minValue = paramInt5;
/* 378 */       this._maxValue = paramInt6;
/* 379 */       updatePosition(paramInt7);
/*     */     }
/*     */   }
/*     */ 
/*     */   class ToggleButton
/*     */   {
/*     */     public boolean value;
/*     */     public String msg;
/*     */     public int x;
/*     */     public int y;
/*     */     public int w;
/*     */     public int h;
/*     */ 
/*     */     public void draw()
/*     */     {
/* 518 */       Directional_Derivative.this.pushMatrix();
/* 519 */       Directional_Derivative.this.translate(this.x, this.y);
/* 520 */       if (this.value) {
/* 521 */         Directional_Derivative.this.fill(250.0F, 130.0F, 20.0F);
/* 522 */         Directional_Derivative.this.stroke(0);
/* 523 */         Directional_Derivative.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/*     */       else
/*     */       {
/* 531 */         Directional_Derivative.this.fill(255.0F, 255.0F, 255.0F);
/* 532 */         Directional_Derivative.this.stroke(0);
/* 533 */         Directional_Derivative.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/* 535 */       Directional_Derivative.this.rect(0.0F, 0.0F, this.w, this.h);
/* 536 */       Directional_Derivative.this.noStroke();
/* 537 */       Directional_Derivative.this.fill(255.0F, 255.0F, 255.0F);
/* 538 */       Directional_Derivative.this.rect(2.0F, 2.0F, this.w - 4, this.h - 4);
/*     */ 
/* 540 */       Directional_Derivative.this.fill(0);
/*     */ 
/* 542 */       Directional_Derivative.this.textSize(16.0F);
/* 543 */       Directional_Derivative.this.text(this.msg, 5, this.h - 5);
/*     */ 
/* 545 */       Directional_Derivative.this.popMatrix();
/*     */     }
/*     */ 
/*     */     public void processMouseDown() {
/* 549 */       int i = Directional_Derivative.this.mouseX - this.x;
/* 550 */       int j = Directional_Derivative.this.mouseY - this.y;
/*     */ 
/* 552 */       if ((i < 0) || (i > this.w) || 
/* 553 */         (j < 0) || (j > this.h)) return;
/* 554 */       this.value ^= true;
/*     */     }
/*     */ 
/*     */     private final void jdMethod_this()
/*     */     {
/* 559 */       this.value = false;
/*     */     }
/*     */ 
/*     */     public ToggleButton(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString)
/*     */     {
/* 509 */       jdMethod_this();
/* 510 */       this.x = paramInt1;
/* 511 */       this.y = paramInt2;
/* 512 */       this.w = paramInt3;
/* 513 */       this.h = paramInt4;
/* 514 */       this.msg = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */   class Button
/*     */   {
/*     */     public boolean value;
/*     */     public String msg;
/*     */     public int x;
/*     */     public int y;
/*     */     public int w;
/*     */     public int h;
/*     */ 
/*     */     public void draw()
/*     */     {
/* 450 */       Directional_Derivative.this.rectMode(0);
/* 451 */       Directional_Derivative.this.pushMatrix();
/* 452 */       Directional_Derivative.this.translate(this.x, this.y);
/* 453 */       if (this.value) {
/* 454 */         Directional_Derivative.this.fill(250.0F, 130.0F, 20.0F);
/* 455 */         Directional_Derivative.this.stroke(0);
/* 456 */         Directional_Derivative.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/*     */       else
/*     */       {
/* 464 */         Directional_Derivative.this.fill(255.0F, 255.0F, 255.0F);
/* 465 */         Directional_Derivative.this.stroke(0);
/* 466 */         Directional_Derivative.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/* 468 */       Directional_Derivative.this.rect(0.0F, 0.0F, this.w, this.h);
/* 469 */       Directional_Derivative.this.noStroke();
/* 470 */       Directional_Derivative.this.fill(255.0F, 255.0F, 255.0F);
/* 471 */       Directional_Derivative.this.rect(2.0F, 2.0F, this.w - 4, this.h - 4);
/*     */ 
/* 473 */       Directional_Derivative.this.fill(0);
/*     */ 
/* 475 */       Directional_Derivative.this.textSize(19.0F);
/* 476 */       Directional_Derivative.this.text(this.msg, 5, this.h - 8);
/*     */ 
/* 478 */       Directional_Derivative.this.popMatrix();
/*     */     }
/*     */ 
/*     */     public void processMouseDown() {
/* 482 */       int i = Directional_Derivative.this.mouseX - this.x;
/* 483 */       int j = Directional_Derivative.this.mouseY - this.y;
/*     */ 
/* 485 */       if ((i < 0) || (i > this.w) || 
/* 486 */         (j < 0) || (j > this.h)) return;
/* 487 */       this.value = true;
/*     */     }
/*     */ 
/*     */     public void processMouseUp()
/*     */     {
/* 493 */       if (this.value)
/* 494 */         this.value = false;
/*     */     }
/*     */ 
/*     */     private final void jdMethod_this() {
/* 498 */       this.value = false;
/*     */     }
/*     */ 
/*     */     public Button(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString)
/*     */     {
/* 441 */       jdMethod_this();
/* 442 */       this.x = paramInt1;
/* 443 */       this.y = paramInt2;
/* 444 */       this.w = paramInt3;
/* 445 */       this.h = paramInt4;
/* 446 */       this.msg = paramString;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/mfeyereisen/applets-final/classes/
 * Qualified Name:     Directional_Derivative
 * JD-Core Version:    0.5.3
 */