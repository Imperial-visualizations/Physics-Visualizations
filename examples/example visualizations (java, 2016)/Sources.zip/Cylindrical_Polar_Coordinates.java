/*     */ import processing.core.PApplet;
/*     */ import processing.core.PFont;
/*     */ 
/*     */ public class Cylindrical_Polar_Coordinates extends PApplet
/*     */ {
/*     */   float axes_centre_x;
/*     */   float axes_centre_y;
/*     */   float axes_centre_z;
/*     */   float axes_length;
/*     */   float rotate_y;
/*     */   float rotate_x;
/*     */   float rotate_speed;
/*     */   float r;
/*     */   float angle;
/*     */   float z;
/*     */   float x;
/*     */   float y;
/*     */   float arc_size;
/*     */   float move_speed;
/*     */   float angle_speed;
/*     */   float dotted_line_length;
/*     */   float arrowhead_size;
/*     */   float rect_size;
/*     */   float rect_a_minus_pos_x;
/*     */   float rect_a_minus_pos_y;
/*     */   float rect_a_plus_pos_x;
/*     */   float rect_a_plus_pos_y;
/*     */   boolean rect_a_minus;
/*     */   boolean rect_a_plus;
/*     */   float rect_b_minus_pos_x;
/*     */   float rect_b_minus_pos_y;
/*     */   float rect_b_plus_pos_x;
/*     */   float rect_b_plus_pos_y;
/*     */   boolean rect_b_minus;
/*     */   boolean rect_b_plus;
/*     */   float rect_r_minus_pos_x;
/*     */   float rect_r_minus_pos_y;
/*     */   float rect_r_plus_pos_x;
/*     */   float rect_r_plus_pos_y;
/*     */   boolean rect_r_minus;
/*     */   boolean rect_r_plus;
/*     */   int rect_color;
/*     */   int rect_highlight_color;
/*     */   boolean mouse_over_button;
/*     */   PFont font;
/*     */ 
/*     */   public void reset()
/*     */   {
/*  47 */     this.rotate_y = 0.0F;
/*  48 */     this.rotate_x = 0.0F;
/*  49 */     this.r = sqrt(sq(this.axes_length / 2.0F) + sq(this.axes_length / 2.0F));
/*  50 */     this.angle = 0.7853982F;
/*  51 */     this.z = 0.0F;
/*  52 */     this.x = 0.0F;
/*  53 */     this.y = 0.0F;
/*  54 */     this.arc_size = 50.0F;
/*     */   }
/*     */ 
/*     */   public void setup()
/*     */   {
/*  60 */     size(640, 480, "processing.core.PGraphics3");
/*  61 */     background(255.0F, 255.0F, 255.0F);
/*  62 */     stroke(0.0F, 0.0F, 0.0F);
/*  63 */     framerate(60.0F);
/*  64 */     this.font = loadFont("Arial-Black-20.vlw");
/*  65 */     textFont(this.font, 20.0F);
/*     */   }
/*     */ 
/*     */   public boolean mouseOverRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*     */   {
/*  72 */     return ((this.mouseX >= paramFloat1) && (this.mouseX <= paramFloat1 + paramFloat3) && (this.mouseY >= paramFloat2) && (this.mouseY <= paramFloat2 + paramFloat4));
/*     */   }
/*     */ 
/*     */   public void checkMouse(float paramFloat1, float paramFloat2)
/*     */   {
/*  80 */     this.mouse_over_button = false;
/*     */ 
/*  82 */     if (mouseOverRect(this.rect_a_minus_pos_x, this.rect_a_minus_pos_y, this.rect_size, this.rect_size)) { this.rect_a_minus = true; this.mouse_over_button = true; } else { this.rect_a_minus = false; }
/*  83 */     if (mouseOverRect(this.rect_a_plus_pos_x, this.rect_a_plus_pos_y, this.rect_size, this.rect_size)) { this.rect_a_plus = true; this.mouse_over_button = true; } else { this.rect_a_plus = false; }
/*  84 */     if (mouseOverRect(this.rect_b_minus_pos_x, this.rect_b_minus_pos_y, this.rect_size, this.rect_size)) { this.rect_b_minus = true; this.mouse_over_button = true; } else { this.rect_b_minus = false; }
/*  85 */     if (mouseOverRect(this.rect_b_plus_pos_x, this.rect_b_plus_pos_y, this.rect_size, this.rect_size)) { this.rect_b_plus = true; this.mouse_over_button = true; } else { this.rect_b_plus = false; }
/*  86 */     if (mouseOverRect(this.rect_r_minus_pos_x, this.rect_r_minus_pos_y, this.rect_size, this.rect_size)) { this.rect_r_minus = true; this.mouse_over_button = true; } else { this.rect_r_minus = false; }
/*  87 */     if (mouseOverRect(this.rect_r_plus_pos_x, this.rect_r_plus_pos_y, this.rect_size, this.rect_size)) { this.rect_r_plus = true; this.mouse_over_button = true; } else { this.rect_r_plus = false;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void keyPressed() {
/*  92 */     if (this.key == 'r') reset();
/*     */ 
/*  94 */     if (this.keyCode == 16)
/*     */     {
/*  96 */       this.z += this.move_speed;
/*     */     }
/*  98 */     if (this.keyCode == 17)
/*     */     {
/* 100 */       this.z -= this.move_speed;
/*     */     }
/* 102 */     if (this.keyCode == 38)
/*     */     {
/* 104 */       this.angle += this.angle_speed;
/* 105 */       if (this.angle >= 6.283186F) this.angle = 0.0F;
/*     */     }
/* 107 */     if (this.keyCode == 40)
/*     */     {
/* 109 */       this.angle -= this.angle_speed;
/* 110 */       if (this.angle < 0.0F) this.angle = 6.283186F;
/*     */     }
/* 112 */     if (this.keyCode == 39)
/*     */     {
/* 114 */       this.r += this.move_speed;
/*     */     }
/* 116 */     if (this.keyCode != 37)
/*     */       return;
/* 118 */     this.r -= this.move_speed;
/* 119 */     if (this.r >= 0.0F) return; this.r = 0.0F;
/*     */   }
/*     */ 
/*     */   public void draw()
/*     */   {
/* 125 */     background(255);
/* 126 */     checkMouse(this.mouseX, this.mouseY);
/*     */ 
/* 129 */     stroke(0);
/* 130 */     if (this.rect_a_minus) fill(255.0F, 200.0F, 200.0F); else fill(255.0F, 0.0F, 0.0F);
/* 131 */     rect(this.rect_a_minus_pos_x, this.rect_a_minus_pos_y, this.rect_size, this.rect_size);
/* 132 */     if (this.rect_a_plus) fill(255.0F, 200.0F, 200.0F); else fill(255.0F, 0.0F, 0.0F);
/* 133 */     rect(this.rect_a_plus_pos_x, this.rect_a_plus_pos_y, this.rect_size, this.rect_size);
/* 134 */     if (this.rect_b_minus) fill(200.0F, 200.0F, 255.0F); else fill(0.0F, 0.0F, 255.0F);
/* 135 */     rect(this.rect_b_minus_pos_x, this.rect_b_minus_pos_y, this.rect_size, this.rect_size);
/* 136 */     if (this.rect_b_plus) fill(200.0F, 200.0F, 255.0F); else fill(0.0F, 0.0F, 255.0F);
/* 137 */     rect(this.rect_b_plus_pos_x, this.rect_b_plus_pos_y, this.rect_size, this.rect_size);
/* 138 */     if (this.rect_r_minus) fill(200.0F, 255.0F, 200.0F); else fill(0.0F, 255.0F, 0.0F);
/* 139 */     rect(this.rect_r_minus_pos_x, this.rect_r_minus_pos_y, this.rect_size, this.rect_size);
/* 140 */     if (this.rect_r_plus) fill(200.0F, 255.0F, 200.0F); else fill(0.0F, 255.0F, 0.0F);
/* 141 */     rect(this.rect_r_plus_pos_x, this.rect_r_plus_pos_y, this.rect_size, this.rect_size);
/* 142 */     fill(0);
/* 143 */     textSize(40.0F);
/* 144 */     text("-", this.rect_a_minus_pos_x + 10.0F, this.rect_a_minus_pos_y + this.rect_size - 4);
/* 145 */     text("+", this.rect_a_plus_pos_x + 3.2F, this.rect_a_plus_pos_y + this.rect_size);
/* 146 */     textSize(20.0F);
/* 147 */     text("angle = ", this.rect_a_minus_pos_x - 55.0F, this.rect_a_minus_pos_y + this.rect_size + 25.0F);
/* 148 */     text(this.angle, this.rect_a_minus_pos_x + 25.0F, this.rect_a_minus_pos_y + this.rect_size + 25.0F);
/* 149 */     textSize(40.0F);
/* 150 */     text("-", this.rect_b_minus_pos_x + 10.0F, this.rect_b_minus_pos_y + this.rect_size - 4);
/* 151 */     text("+", this.rect_b_plus_pos_x + 3.2F, this.rect_b_plus_pos_y + this.rect_size);
/* 152 */     textSize(20.0F);
/* 153 */     text("z = ", this.rect_b_minus_pos_x - 10.0F, this.rect_b_minus_pos_y + this.rect_size + 25.0F);
/* 154 */     text(this.z, this.rect_b_minus_pos_x + 25.0F, this.rect_b_minus_pos_y + this.rect_size + 25.0F);
/* 155 */     textSize(40.0F);
/* 156 */     text("-", this.rect_r_minus_pos_x + 10.0F, this.rect_r_minus_pos_y + this.rect_size - 4);
/* 157 */     text("+", this.rect_r_plus_pos_x + 3.2F, this.rect_r_plus_pos_y + this.rect_size);
/* 158 */     textSize(20.0F);
/* 159 */     text("r = ", this.rect_r_minus_pos_x - 27.0F, this.rect_r_minus_pos_y + this.rect_size + 25.0F);
/* 160 */     text(this.r, this.rect_r_minus_pos_x, this.rect_r_minus_pos_y + this.rect_size + 25.0F);
/*     */ 
/* 162 */     if (this.mousePressed)
/*     */     {
/* 164 */       if (this.rect_b_plus)
/*     */       {
/* 166 */         this.z += this.move_speed;
/*     */       }
/* 168 */       if (this.rect_b_minus)
/*     */       {
/* 170 */         this.z -= this.move_speed;
/*     */       }
/* 172 */       if (this.rect_a_plus)
/*     */       {
/* 174 */         this.angle += this.angle_speed;
/* 175 */         if (this.angle >= 6.283186F) this.angle = 0.0F;
/*     */       }
/* 177 */       if (this.rect_a_minus)
/*     */       {
/* 179 */         this.angle -= this.angle_speed;
/* 180 */         if (this.angle < 0.0F) this.angle = 6.283186F;
/*     */       }
/* 182 */       if (this.rect_r_plus)
/*     */       {
/* 184 */         this.r += this.move_speed;
/*     */       }
/* 186 */       if (this.rect_r_minus)
/*     */       {
/* 188 */         this.r -= this.move_speed;
/* 189 */         if (this.r < 0.0F) this.r = 0.0F;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 194 */     translate(this.axes_centre_x, this.axes_centre_y, this.axes_centre_z);
/* 195 */     translate(this.axes_length / 2.0F, -this.axes_length / 2.0F, this.axes_length / 2.0F);
/* 196 */     if ((this.mousePressed) && 
/* 198 */       (this.mouseButton == 39))
/*     */     {
/* 200 */       if (this.mouseX - this.pmouseX > 0.0F) this.rotate_y += this.rotate_speed;
/* 201 */       if (this.mouseX - this.pmouseX < 0.0F) this.rotate_y -= this.rotate_speed;
/* 202 */       if (this.rotate_y >= 6.283186F) this.rotate_y = 0.0F;
/*     */ 
/* 204 */       if (this.mouseY - this.pmouseY > 0.0F) this.rotate_x -= this.rotate_speed;
/* 205 */       if (this.mouseY - this.pmouseY < 0.0F) this.rotate_x += this.rotate_speed;
/* 206 */       if (this.rotate_x >= 6.283186F) this.rotate_x = 0.0F;
/*     */     }
/*     */ 
/* 209 */     rotateX(this.rotate_x);
/* 210 */     rotateY(this.rotate_y);
/* 211 */     translate(-this.axes_length / 2.0F, this.axes_length / 2.0F, -this.axes_length / 2.0F);
/*     */ 
/* 214 */     textSize(30.0F);
/* 215 */     stroke(0);
/* 216 */     fill(0);
/* 217 */     line(0.0F, 0.0F, 0.0F, this.axes_length, 0.0F, 0.0F);
/* 218 */     line(0.0F, 0.0F, 0.0F, 0.0F, -this.axes_length, 0.0F);
/* 219 */     line(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, this.axes_length);
/* 220 */     text("z", 0.0F, -this.axes_length - 10.0F, 0.0F);
/* 221 */     text("x", this.axes_length + 10.0F, 0.0F, 0.0F);
/* 222 */     text("y", 0.0F, 0.0F, this.axes_length + 10.0F);
/*     */ 
/* 225 */     stroke(0);
/* 226 */     this.x = (this.r * cos(this.angle));
/* 227 */     this.y = (this.r * sin(this.angle));
/* 228 */     line(0.0F, 0.0F, 0.0F, this.x, -this.z, this.y);
/*     */ 
/* 231 */     stroke(0.0F, 0.0F, 255.0F);
/* 232 */     if (this.z > 0.0F)
/*     */     {
/* 234 */       for (f1 = -this.z; f1 < 0.0F; f1 += this.dotted_line_length * 2.0F)
/*     */       {
/* 236 */         line(this.x, f1, this.y, this.x, f1 + this.dotted_line_length, this.y);
/*     */       }
/*     */     }
/* 239 */     else if (this.z < 0.0F)
/*     */     {
/* 241 */       for (f1 = -this.z; f1 > 0.0F; f1 -= this.dotted_line_length * 2.0F)
/*     */       {
/* 243 */         line(this.x, f1, this.y, this.x, f1 - this.dotted_line_length, this.y);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 248 */     stroke(0.0F, 255.0F, 0.0F);
/* 249 */     if (this.z != 0.0F) line(0.0F, 0.0F, 0.0F, this.x, 0.0F, this.y);
/* 250 */     text("r", this.x / 2.0F, 0.0F, this.y / 2.0F);
/*     */ 
/* 253 */     float f1 = this.arc_size;
/* 254 */     float f2 = 0.0F;
/* 255 */     float f3 = 0.0F;
/* 256 */     float f4 = 0.0F;
/* 257 */     float f5 = 0.05F;
/* 258 */     if (this.angle < 0.0F) f5 = -f5;
/* 259 */     stroke(255.0F, 0.0F, 0.0F);
/* 260 */     fill(255.0F, 0.0F, 0.0F);
/* 261 */     beginShape(256);
/* 262 */     for (float f6 = 0.0F; abs(f6) <= abs(this.angle); f6 += f5)
/*     */     {
/* 264 */       f3 = this.arc_size * cos(f6);
/* 265 */       f4 = this.arc_size * sin(f6);
/* 266 */       vertex(f3, 0.0F, f4);
/* 267 */       f1 = f3;
/* 268 */       f2 = f4;
/*     */     }
/* 270 */     vertex(0.0F, 0.0F, 0.0F);
/* 271 */     endShape();
/*     */   }
/*     */ 
/*     */   private final void jdMethod_this()
/*     */   {
/*   4 */     this.axes_centre_x = 150.0F;
/*   5 */     this.axes_centre_y = 400.0F;
/*   6 */     this.axes_centre_z = -300.0F;
/*   7 */     this.axes_length = 365.0F;
/*   8 */     this.rotate_y = 0.0F;
/*   9 */     this.rotate_x = 0.0F;
/*  10 */     this.rotate_speed = 0.05F;
/*  11 */     this.r = sqrt(sq(this.axes_length / 2.0F) + sq(this.axes_length / 2.0F));
/*  12 */     this.angle = 0.7853982F;
/*  13 */     this.z = 0.0F;
/*  14 */     this.x = 0.0F;
/*  15 */     this.y = 0.0F;
/*  16 */     this.arc_size = 50.0F;
/*  17 */     this.move_speed = 10.0F;
/*  18 */     this.angle_speed = 0.03F;
/*  19 */     this.dotted_line_length = 5;
/*  20 */     this.arrowhead_size = 7.0F;
/*  21 */     this.rect_size = 30.0F;
/*  22 */     this.rect_a_minus_pos_x = 520.0F;
/*  23 */     this.rect_a_minus_pos_y = 10.0F;
/*  24 */     this.rect_a_plus_pos_x = (this.rect_a_minus_pos_x + this.rect_size + 10.0F);
/*  25 */     this.rect_a_plus_pos_y = this.rect_a_minus_pos_y;
/*  26 */     this.rect_a_minus = false;
/*  27 */     this.rect_a_plus = false;
/*  28 */     this.rect_b_minus_pos_x = 520.0F;
/*  29 */     this.rect_b_minus_pos_y = 100.0F;
/*  30 */     this.rect_b_plus_pos_x = (this.rect_b_minus_pos_x + this.rect_size + 10.0F);
/*  31 */     this.rect_b_plus_pos_y = this.rect_b_minus_pos_y;
/*  32 */     this.rect_b_minus = false;
/*  33 */     this.rect_b_plus = false;
/*  34 */     this.rect_r_minus_pos_x = 520.0F;
/*  35 */     this.rect_r_minus_pos_y = 185.0F;
/*  36 */     this.rect_r_plus_pos_x = (this.rect_r_minus_pos_x + this.rect_size + 10.0F);
/*  37 */     this.rect_r_plus_pos_y = this.rect_r_minus_pos_y;
/*  38 */     this.rect_r_minus = false;
/*  39 */     this.rect_r_plus = false;
/*  40 */     this.rect_color = color(200);
/*  41 */     this.rect_highlight_color = color(255);
/*  42 */     this.mouse_over_button = false;
/*     */   }
/*     */ 
/*     */   public Cylindrical_Polar_Coordinates()
/*     */   {
/*   1 */     jdMethod_this();
/*     */   }
/*     */ }

/* Location:           /Users/mfeyereisen/applets-final/classes/
 * Qualified Name:     Cylindrical_Polar_Coordinates
 * JD-Core Version:    0.5.3
 */