/*     */ import processing.core.PApplet;
/*     */ import processing.core.PFont;
/*     */ 
/*     */ public class Coordinate_Systems extends PApplet
/*     */ {
/*     */   float axes_centre_x1;
/*     */   float axes_centre_y1;
/*     */   float x_axes_length;
/*     */   float y_axes_length;
/*     */   float axes_centre_x2;
/*     */   float axes_centre_y2;
/*     */   float dotted_line_length;
/*     */   float move_speed;
/*     */   float point_x1;
/*     */   float point_y1;
/*     */   float point_x2;
/*     */   float point_y2;
/*     */   float point_size;
/*     */   float arc_size;
/*     */   float move_to_x;
/*     */   float move_to_y;
/*     */   float grid_res;
/*     */   float grid_res2;
/*     */   boolean animating1;
/*     */   boolean animating2;
/*     */   PFont font;
/*     */ 
/*     */   public void reset()
/*     */   {
/*  28 */     this.axes_centre_x2 = (this.axes_centre_x1 + this.x_axes_length + 40.0F);
/*  29 */     this.axes_centre_y2 = this.axes_centre_y1;
/*  30 */     this.point_x1 = (this.x_axes_length / 2.0F);
/*  31 */     this.point_y1 = (this.y_axes_length / 2.0F);
/*  32 */     this.point_x2 = this.point_x1;
/*  33 */     this.point_y2 = this.point_y1;
/*  34 */     this.move_to_x = this.point_x1;
/*  35 */     this.move_to_y = this.point_y1;
/*  36 */     this.animating1 = false;
/*  37 */     this.animating2 = false;
/*     */   }
/*     */ 
/*     */   public void setup()
/*     */   {
/*  42 */     size(640, 480);
/*  43 */     background(255);
/*  44 */     stroke(0);
/*  45 */     framerate(60.0F);
/*  46 */     this.font = loadFont("ArialMT-20.vlw");
/*  47 */     textFont(this.font, 20.0F);
/*     */   }
/*     */ 
/*     */   public void mousePressed()
/*     */   {
/*  52 */     if ((this.mouseX > this.axes_centre_x1) && (this.mouseX < this.axes_centre_x1 + this.x_axes_length) && 
/*  54 */       (this.mouseY < this.axes_centre_y1) && (this.mouseY > this.axes_centre_y1 - this.y_axes_length))
/*     */     {
/*  56 */       this.move_to_x = (this.mouseX - this.axes_centre_x1);
/*  57 */       this.move_to_y = (-this.mouseY + this.axes_centre_y1);
/*     */     }
/*     */ 
/*  60 */     if ((this.mouseX <= this.axes_centre_x2) || (this.mouseX >= this.axes_centre_x2 + this.x_axes_length) || 
/*  62 */       (this.mouseY >= this.axes_centre_y2) || (this.mouseY <= this.axes_centre_y2 - this.y_axes_length))
/*     */       return;
/*  64 */     this.move_to_x = (this.mouseX - this.axes_centre_x2);
/*  65 */     this.move_to_y = (-this.mouseY + this.axes_centre_y2);
/*     */   }
/*     */ 
/*     */   public void keyPressed()
/*     */   {
/*  72 */     if (this.key != 'r') return; reset();
/*     */   }
/*     */ 
/*     */   public void draw()
/*     */   {
/*  77 */     background(255);
/*     */ 
/*  81 */     this.animating1 = false;
/*  82 */     if ((this.move_to_x < this.point_x1 - 1.0F) || (this.move_to_x > this.point_x1 + 1.0F))
/*     */     {
/*  84 */       if (this.move_to_x < this.point_x1) this.point_x1 -= this.move_speed; else this.point_x1 += this.move_speed;
/*  85 */       this.animating1 = true;
/*     */     }
/*  87 */     else if ((this.move_to_y < this.point_y1 - 1.0F) || (this.move_to_y > this.point_y1 + 1.0F))
/*     */     {
/*  89 */       this.point_x1 = this.move_to_x;
/*  90 */       if (this.move_to_y < this.point_y1) this.point_y1 -= this.move_speed; else this.point_y1 += this.move_speed;
/*  91 */       this.animating1 = true;
/*     */     } else {
/*  93 */       this.point_y1 = this.move_to_y;
/*     */     }
/*     */ 
/*  96 */     fill(0);
/*  97 */     text("cartesian", 120.0F, 400.0F);
/*  98 */     text("polar", 450.0F, 400.0F);
/*     */ 
/* 101 */     pushMatrix();
/* 102 */     translate(this.axes_centre_x1, this.axes_centre_y1);
/* 103 */     stroke(200.0F);
/* 104 */     for (float f1 = 0.0F; f1 <= this.x_axes_length; f1 += this.grid_res)
/*     */     {
/* 106 */       for (f2 = 0.0F; f2 <= this.y_axes_length; f2 += this.grid_res)
/*     */       {
/* 108 */         line(f1, 0.0F, f1, -this.y_axes_length);
/* 109 */         line(0.0F, -f2, this.x_axes_length, -f2);
/*     */       }
/*     */     }
/* 112 */     stroke(0);
/* 113 */     line(0.0F, 0.0F, this.x_axes_length, 0.0F);
/* 114 */     line(0.0F, 0.0F, 0.0F, -this.y_axes_length);
/* 115 */     line(-5.0F, -this.y_axes_length + 5, 0.0F, -this.y_axes_length);
/* 116 */     line(0.0F, -this.y_axes_length, 5, -this.y_axes_length + 5);
/* 117 */     line(this.x_axes_length - 5, -5.0F, this.x_axes_length, 0.0F);
/* 118 */     line(this.x_axes_length, 0.0F, this.x_axes_length - 5, 5);
/*     */ 
/* 121 */     line(this.point_x1 - this.point_size, -this.point_y1 - this.point_size, this.point_x1 + this.point_size, -this.point_y1 + this.point_size);
/* 122 */     line(this.point_x1 - this.point_size, -this.point_y1 + this.point_size, this.point_x1 + this.point_size, -this.point_y1 - this.point_size);
/* 123 */     if (this.animating1)
/*     */     {
/* 125 */       stroke(140);
/* 126 */       line(this.move_to_x - this.point_size, -this.move_to_y - this.point_size, this.move_to_x + this.point_size, -this.move_to_y + this.point_size);
/* 127 */       line(this.move_to_x - this.point_size, -this.move_to_y + this.point_size, this.move_to_x + this.point_size, -this.move_to_y - this.point_size);
/*     */     }
/*     */ 
/* 131 */     stroke(100.0F);
/* 132 */     f1 = this.point_x1;
/* 133 */     while (f1 > 0.0F)
/*     */     {
/* 135 */       line(f1, -this.point_y1, f1 - this.dotted_line_length, -this.point_y1);
/* 136 */       f1 -= this.dotted_line_length * 2.0F;
/*     */     }
/* 138 */     f1 = -this.point_y1;
/* 139 */     while (f1 < 0.0F)
/*     */     {
/* 141 */       line(this.point_x1, f1, this.point_x1, f1 + this.dotted_line_length);
/* 142 */       f1 += this.dotted_line_length * 2.0F;
/*     */     }
/* 144 */     fill(0);
/* 145 */     text("x", this.point_x1 / 2.0F, -this.point_y1 - 10.0F);
/* 146 */     text("y", this.point_x1 + 10.0F, -this.point_y1 / 2.0F);
/* 147 */     fill(150);
/* 148 */     text("(x,y)", this.point_x1 + 7.0F, -this.point_y1 - 7.0F);
/*     */ 
/* 152 */     this.animating2 = false;
/* 153 */     float f2 = atan2(this.point_y2, this.point_x2);
/* 154 */     float f3 = sqrt(this.point_x2 * this.point_x2 + this.point_y2 * this.point_y2);
/* 155 */     float f4 = atan2(this.move_to_y, this.move_to_x);
/* 156 */     float f5 = sqrt(this.move_to_x * this.move_to_x + this.move_to_y * this.move_to_y);
/* 157 */     if ((f5 < f3 - 1.0F) || (f5 > f3 + 1.0F))
/*     */     {
/* 159 */       if (f5 < f3) f3 -= this.move_speed; else f3 += this.move_speed;
/* 160 */       this.point_x2 = (f3 * cos(f2));
/* 161 */       this.point_y2 = (f3 * sin(f2));
/* 162 */       this.animating2 = true;
/*     */     }
/* 164 */     else if ((f4 < f2 - 0.05F) || (f4 > f2 + 0.05F))
/*     */     {
/* 166 */       f3 = f5;
/* 167 */       if (f4 < f2) f2 -= 0.01F; else f2 += 0.01F;
/* 168 */       this.point_x2 = (f3 * cos(f2));
/* 169 */       this.point_y2 = (f3 * sin(f2));
/* 170 */       this.animating2 = true;
/*     */     }
/*     */     else
/*     */     {
/* 174 */       f2 = f4;
/* 175 */       this.point_x2 = (f3 * cos(f2));
/* 176 */       this.point_y2 = (f3 * sin(f2));
/*     */     }
/*     */ 
/* 180 */     popMatrix();
/* 181 */     translate(this.axes_centre_x2, this.axes_centre_y2);
/* 182 */     stroke(200.0F);
/* 183 */     noFill();
/* 184 */     for (f1 = 0.0F; f1 <= this.x_axes_length * 2.0F; f1 += this.grid_res2)
/*     */     {
/* 186 */       arc(0.0F, 0.0F, f1, f1, -1.570796F, 0.0F);
/*     */     }
/* 188 */     for (float f6 = -1.570796F; f6 < 0.0F; f6 += 0.07F)
/*     */     {
/* 190 */       line(0.0F, 0.0F, this.x_axes_length * cos(f6), this.y_axes_length * sin(f6));
/*     */     }
/* 192 */     stroke(0);
/* 193 */     line(0.0F, 0.0F, this.x_axes_length, 0.0F);
/* 194 */     line(0.0F, 0.0F, 0.0F, -this.y_axes_length);
/* 195 */     line(-5.0F, -this.y_axes_length + 5, 0.0F, -this.y_axes_length);
/* 196 */     line(0.0F, -this.y_axes_length, 5, -this.y_axes_length + 5);
/* 197 */     line(this.x_axes_length - 5, -5.0F, this.x_axes_length, 0.0F);
/* 198 */     line(this.x_axes_length, 0.0F, this.x_axes_length - 5, 5);
/*     */ 
/* 201 */     line(this.point_x2 - this.point_size, -this.point_y2 - this.point_size, this.point_x2 + this.point_size, -this.point_y2 + this.point_size);
/* 202 */     line(this.point_x2 - this.point_size, -this.point_y2 + this.point_size, this.point_x2 + this.point_size, -this.point_y2 - this.point_size);
/* 203 */     if (this.animating2)
/*     */     {
/* 205 */       stroke(140);
/* 206 */       line(this.move_to_x - this.point_size, -this.move_to_y - this.point_size, this.move_to_x + this.point_size, -this.move_to_y + this.point_size);
/* 207 */       line(this.move_to_x - this.point_size, -this.move_to_y + this.point_size, this.move_to_x + this.point_size, -this.move_to_y - this.point_size);
/*     */     }
/*     */ 
/* 211 */     stroke(100.0F);
/* 212 */     f2 = atan2(this.point_y2, this.point_x2);
/* 213 */     f3 = sqrt(this.point_x2 * this.point_x2 + this.point_y2 * this.point_y2);
/* 214 */     f6 = this.point_y2 / this.point_x2;
/* 215 */     f1 = this.point_x2;
/* 216 */     while (f1 > 0.0F)
/*     */     {
/* 218 */       line(f1, -f6 * f1, f1 - (this.dotted_line_length * cos(f2)), -f6 * (f1 - (this.dotted_line_length * cos(f2))));
/* 219 */       f1 -= this.dotted_line_length * cos(f2) * 2.0F;
/*     */     }
/* 221 */     fill(170);
/* 222 */     arc(0.0F, 0.0F, this.arc_size, this.arc_size, -f2, 0.0F);
/* 223 */     fill(0);
/* 224 */     text("r", f3 * cos(f2) / 2.0F - 10.0F, -(f3 * sin(f2)) / 2.0F);
/* 225 */     text("a", 15.0F, -(f6 * 15.0F) / 2.0F + 4);
/* 226 */     fill(150);
/* 227 */     text("(r,a)", this.point_x2 + 7.0F, -this.point_y2 - 7.0F);
/*     */   }
/*     */ 
/*     */   private final void jdMethod_this()
/*     */   {
/*   4 */     this.axes_centre_x1 = 30.0F;
/*   5 */     this.axes_centre_y1 = 350.0F;
/*   6 */     this.x_axes_length = 265.0F;
/*   7 */     this.y_axes_length = 265.0F;
/*   8 */     this.axes_centre_x2 = (this.axes_centre_x1 + this.x_axes_length + 40.0F);
/*   9 */     this.axes_centre_y2 = this.axes_centre_y1;
/*  10 */     this.dotted_line_length = 5;
/*  11 */     this.move_speed = 2.0F;
/*  12 */     this.point_x1 = (this.x_axes_length / 2.0F);
/*  13 */     this.point_y1 = (this.y_axes_length / 2.0F);
/*  14 */     this.point_x2 = this.point_x1;
/*  15 */     this.point_y2 = this.point_y1;
/*  16 */     this.point_size = 5;
/*  17 */     this.arc_size = 70.0F;
/*  18 */     this.move_to_x = this.point_x1;
/*  19 */     this.move_to_y = this.point_y1;
/*  20 */     this.grid_res = 10.0F;
/*  21 */     this.grid_res2 = 20.0F;
/*  22 */     this.animating1 = false;
/*  23 */     this.animating2 = false;
/*     */   }
/*     */ 
/*     */   public Coordinate_Systems()
/*     */   {
/*   1 */     jdMethod_this();
/*     */   }
/*     */ }

/* Location:           /Users/mfeyereisen/applets-final/classes/
 * Qualified Name:     Coordinate_Systems
 * JD-Core Version:    0.5.3
 */