/*     */ import processing.core.PApplet;
/*     */ import processing.core.PFont;
/*     */ 
/*     */ public class Spherical_Polar_Coordinates extends PApplet
/*     */ {
/*     */   float axes_centre_x;
/*     */   float axes_centre_y;
/*     */   float axes_centre_z;
/*     */   float axes_length;
/*     */   float rotate_y;
/*     */   float rotate_x;
/*     */   float rotate_speed;
/*     */   float r;
/*     */   float azimuthal_angle;
/*     */   float polar_angle;
/*     */   float z;
/*     */   float x;
/*     */   float y;
/*     */   float arc_size;
/*     */   float move_speed;
/*     */   float angle_speed;
/*     */   float dotted_line_length;
/*     */   float arrowhead_size;
/*     */   float rect_size;
/*     */   float rect_a_minus_pos_x;
/*     */   float rect_a_minus_pos_y;
/*     */   float rect_a_plus_pos_x;
/*     */   float rect_a_plus_pos_y;
/*     */   boolean rect_a_minus;
/*     */   boolean rect_a_plus;
/*     */   float rect_b_minus_pos_x;
/*     */   float rect_b_minus_pos_y;
/*     */   float rect_b_plus_pos_x;
/*     */   float rect_b_plus_pos_y;
/*     */   boolean rect_b_minus;
/*     */   boolean rect_b_plus;
/*     */   float rect_r_minus_pos_x;
/*     */   float rect_r_minus_pos_y;
/*     */   float rect_r_plus_pos_x;
/*     */   float rect_r_plus_pos_y;
/*     */   boolean rect_r_minus;
/*     */   boolean rect_r_plus;
/*     */   int rect_color;
/*     */   int rect_highlight_color;
/*     */   boolean mouse_over_button;
/*     */   boolean leave_trace;
/*     */   PFont font;
/*     */   Spherical_Polar_Coordinates.ToggleButton tbCurve;
/*     */ 
/*     */   public void reset()
/*     */   {
/*  51 */     this.rotate_y = 0.0F;
/*  52 */     this.rotate_x = 0.0F;
/*  53 */     this.r = sqrt(sq(this.axes_length / 2.0F) + sq(this.axes_length / 2.0F));
/*  54 */     this.azimuthal_angle = 0.7853982F;
/*  55 */     this.polar_angle = 0.7853982F;
/*  56 */     this.z = 0.0F;
/*  57 */     this.x = 0.0F;
/*  58 */     this.y = 0.0F;
/*  59 */     this.arc_size = 50.0F;
/*  60 */     this.leave_trace = false;
/*  61 */     this.tbCurve.value = false;
/*     */   }
/*     */ 
/*     */   public void setup()
/*     */   {
/*  66 */     size(640, 480, "processing.core.PGraphics3");
/*  67 */     background(255.0F, 255.0F, 255.0F);
/*  68 */     stroke(0.0F, 0.0F, 0.0F);
/*  69 */     framerate(60.0F);
/*  70 */     this.font = loadFont("Arial-Black-20.vlw");
/*  71 */     textFont(this.font, 20.0F);
/*     */ 
/*  73 */     this.tbCurve = new Spherical_Polar_Coordinates.ToggleButton(500, 430, 124, 20, "Draw Volume");
/*     */   }
/*     */ 
/*     */   public boolean mouseOverRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*     */   {
/*  80 */     return ((this.mouseX >= paramFloat1) && (this.mouseX <= paramFloat1 + paramFloat3) && (this.mouseY >= paramFloat2) && (this.mouseY <= paramFloat2 + paramFloat4));
/*     */   }
/*     */ 
/*     */   public void checkMouse(float paramFloat1, float paramFloat2)
/*     */   {
/*  88 */     this.mouse_over_button = false;
/*     */ 
/*  90 */     if (mouseOverRect(this.rect_a_minus_pos_x, this.rect_a_minus_pos_y, this.rect_size, this.rect_size)) { this.rect_a_minus = true; this.mouse_over_button = true; } else { this.rect_a_minus = false; }
/*  91 */     if (mouseOverRect(this.rect_a_plus_pos_x, this.rect_a_plus_pos_y, this.rect_size, this.rect_size)) { this.rect_a_plus = true; this.mouse_over_button = true; } else { this.rect_a_plus = false; }
/*  92 */     if (mouseOverRect(this.rect_b_minus_pos_x, this.rect_b_minus_pos_y, this.rect_size, this.rect_size)) { this.rect_b_minus = true; this.mouse_over_button = true; } else { this.rect_b_minus = false; }
/*  93 */     if (mouseOverRect(this.rect_b_plus_pos_x, this.rect_b_plus_pos_y, this.rect_size, this.rect_size)) { this.rect_b_plus = true; this.mouse_over_button = true; } else { this.rect_b_plus = false; }
/*  94 */     if (mouseOverRect(this.rect_r_minus_pos_x, this.rect_r_minus_pos_y, this.rect_size, this.rect_size)) { this.rect_r_minus = true; this.mouse_over_button = true; } else { this.rect_r_minus = false; }
/*  95 */     if (mouseOverRect(this.rect_r_plus_pos_x, this.rect_r_plus_pos_y, this.rect_size, this.rect_size)) { this.rect_r_plus = true; this.mouse_over_button = true; } else { this.rect_r_plus = false;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void keyPressed() {
/* 100 */     if (this.key == 'r') reset();
/* 101 */     if (this.keyCode == 16)
/*     */     {
/* 103 */       this.polar_angle += this.angle_speed;
/* 104 */       if (this.polar_angle > 3.141593F) this.polar_angle = 3.141593F;
/*     */     }
/* 106 */     if (this.keyCode == 17)
/*     */     {
/* 108 */       this.polar_angle -= this.angle_speed;
/* 109 */       if (this.polar_angle < 0.0F) this.polar_angle = 0.0F;
/*     */     }
/* 111 */     if (this.keyCode == 38)
/*     */     {
/* 113 */       this.azimuthal_angle += this.angle_speed;
/* 114 */       if (this.azimuthal_angle >= 6.283186F) this.azimuthal_angle = 0.0F;
/*     */     }
/* 116 */     if (this.keyCode == 40)
/*     */     {
/* 118 */       this.azimuthal_angle -= this.angle_speed;
/* 119 */       if (this.azimuthal_angle < 0.0F) this.azimuthal_angle = 6.283186F;
/*     */     }
/* 121 */     if (this.keyCode == 39)
/*     */     {
/* 123 */       this.r += this.move_speed;
/*     */     }
/* 125 */     if (this.keyCode == 37)
/*     */     {
/* 127 */       this.r -= this.move_speed;
/* 128 */       if (this.r < 0.0F) this.r = 0.0F;
/*     */     }
/* 130 */     if (this.keyCode != 10)
/*     */       return;
/* 132 */     if (this.leave_trace) this.leave_trace = false; else this.leave_trace = true;
/*     */   }
/*     */ 
/*     */   public void mousePressed()
/*     */   {
/* 138 */     if (this.mouseButton != 37)
/*     */       return;
/* 140 */     this.tbCurve.processMouseDown();
/*     */   }
/*     */ 
/*     */   public void draw()
/*     */   {
/* 147 */     background(255);
/* 148 */     checkMouse(this.mouseX, this.mouseY);
/*     */ 
/* 150 */     this.tbCurve.draw();
/* 151 */     this.leave_trace = this.tbCurve.value;
/*     */ 
/* 154 */     stroke(0);
/* 155 */     if (this.rect_a_minus) fill(255.0F, 200.0F, 200.0F); else fill(255.0F, 0.0F, 0.0F);
/* 156 */     rect(this.rect_a_minus_pos_x, this.rect_a_minus_pos_y, this.rect_size, this.rect_size);
/* 157 */     if (this.rect_a_plus) fill(255.0F, 200.0F, 200.0F); else fill(255.0F, 0.0F, 0.0F);
/* 158 */     rect(this.rect_a_plus_pos_x, this.rect_a_plus_pos_y, this.rect_size, this.rect_size);
/* 159 */     if (this.rect_b_minus) fill(200.0F, 200.0F, 255.0F); else fill(0.0F, 0.0F, 255.0F);
/* 160 */     rect(this.rect_b_minus_pos_x, this.rect_b_minus_pos_y, this.rect_size, this.rect_size);
/* 161 */     if (this.rect_b_plus) fill(200.0F, 200.0F, 255.0F); else fill(0.0F, 0.0F, 255.0F);
/* 162 */     rect(this.rect_b_plus_pos_x, this.rect_b_plus_pos_y, this.rect_size, this.rect_size);
/* 163 */     if (this.rect_r_minus) fill(200.0F, 255.0F, 200.0F); else fill(0.0F, 255.0F, 0.0F);
/* 164 */     rect(this.rect_r_minus_pos_x, this.rect_r_minus_pos_y, this.rect_size, this.rect_size);
/* 165 */     if (this.rect_r_plus) fill(200.0F, 255.0F, 200.0F); else fill(0.0F, 255.0F, 0.0F);
/* 166 */     rect(this.rect_r_plus_pos_x, this.rect_r_plus_pos_y, this.rect_size, this.rect_size);
/* 167 */     fill(0);
/* 168 */     textSize(40.0F);
/* 169 */     text("-", this.rect_a_minus_pos_x + 10.0F, this.rect_a_minus_pos_y + this.rect_size - 4);
/* 170 */     text("+", this.rect_a_plus_pos_x + 3.2F, this.rect_a_plus_pos_y + this.rect_size);
/* 171 */     textSize(20.0F);
/* 172 */     text("azimuthal angle", this.rect_a_minus_pos_x - 55.0F, this.rect_a_minus_pos_y + this.rect_size + 20.0F);
/* 173 */     text("=", this.rect_a_minus_pos_x - 25.0F, this.rect_a_minus_pos_y + this.rect_size + 40.0F);
/* 174 */     text(this.azimuthal_angle, this.rect_a_minus_pos_x, this.rect_a_minus_pos_y + this.rect_size + 40.0F);
/* 175 */     textSize(40.0F);
/* 176 */     text("-", this.rect_b_minus_pos_x + 10.0F, this.rect_b_minus_pos_y + this.rect_size - 4);
/* 177 */     text("+", this.rect_b_plus_pos_x + 3.2F, this.rect_b_plus_pos_y + this.rect_size);
/* 178 */     textSize(20.0F);
/* 179 */     text("polar angle", this.rect_b_minus_pos_x - 20.0F, this.rect_b_minus_pos_y + this.rect_size + 20.0F);
/* 180 */     text("=", this.rect_b_minus_pos_x, this.rect_b_minus_pos_y + this.rect_size + 40.0F);
/* 181 */     text(this.polar_angle, this.rect_b_minus_pos_x + 25.0F, this.rect_b_minus_pos_y + this.rect_size + 40.0F);
/* 182 */     textSize(40.0F);
/* 183 */     text("-", this.rect_r_minus_pos_x + 10.0F, this.rect_r_minus_pos_y + this.rect_size - 4);
/* 184 */     text("+", this.rect_r_plus_pos_x + 3.2F, this.rect_r_plus_pos_y + this.rect_size);
/* 185 */     textSize(20.0F);
/* 186 */     text("r = ", this.rect_r_minus_pos_x - 27.0F, this.rect_r_minus_pos_y + this.rect_size + 25.0F);
/* 187 */     text(this.r, this.rect_r_minus_pos_x, this.rect_r_minus_pos_y + this.rect_size + 25.0F);
/*     */ 
/* 189 */     if ((this.mousePressed) && (this.mouseButton == 37))
/*     */     {
/* 191 */       if (this.rect_b_plus)
/*     */       {
/* 193 */         this.polar_angle += this.angle_speed;
/* 194 */         if (this.polar_angle > 3.141593F) this.polar_angle = 3.141593F;
/*     */       }
/* 196 */       if (this.rect_b_minus)
/*     */       {
/* 198 */         this.polar_angle -= this.angle_speed;
/* 199 */         if (this.polar_angle < 0.0F) this.polar_angle = 0.0F;
/*     */       }
/* 201 */       if (this.rect_a_plus)
/*     */       {
/* 203 */         this.azimuthal_angle += this.angle_speed;
/* 204 */         if (this.azimuthal_angle >= 6.283186F) this.azimuthal_angle = 0.0F;
/*     */       }
/* 206 */       if (this.rect_a_minus)
/*     */       {
/* 208 */         this.azimuthal_angle -= this.angle_speed;
/* 209 */         if (this.azimuthal_angle < 0.0F) this.azimuthal_angle = 6.283186F;
/*     */       }
/* 211 */       if (this.rect_r_plus)
/*     */       {
/* 213 */         this.r += this.move_speed;
/*     */       }
/* 215 */       if (this.rect_r_minus)
/*     */       {
/* 217 */         this.r -= this.move_speed;
/* 218 */         if (this.r < 0.0F) this.r = 0.0F;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 223 */     translate(this.axes_centre_x, this.axes_centre_y, this.axes_centre_z);
/* 224 */     translate(this.axes_length / 2.0F, -this.axes_length / 2.0F, this.axes_length / 2.0F);
/* 225 */     if ((this.mousePressed) && 
/* 227 */       (this.mouseButton == 39))
/*     */     {
/* 229 */       if (this.mouseX - this.pmouseX > 0.0F) this.rotate_y += this.rotate_speed;
/* 230 */       if (this.mouseX - this.pmouseX < 0.0F) this.rotate_y -= this.rotate_speed;
/* 231 */       if (this.rotate_y >= 6.283186F) this.rotate_y = 0.0F;
/*     */ 
/* 233 */       if (this.mouseY - this.pmouseY > 0.0F) this.rotate_x -= this.rotate_speed;
/* 234 */       if (this.mouseY - this.pmouseY < 0.0F) this.rotate_x += this.rotate_speed;
/* 235 */       if (this.rotate_x >= 6.283186F) this.rotate_x = 0.0F;
/*     */     }
/*     */ 
/* 238 */     rotateX(this.rotate_x);
/* 239 */     rotateY(this.rotate_y);
/* 240 */     translate(-this.axes_length / 2.0F, this.axes_length / 2.0F, -this.axes_length / 2.0F);
/*     */ 
/* 243 */     textSize(30.0F);
/* 244 */     stroke(0);
/* 245 */     fill(0);
/* 246 */     line(0.0F, 0.0F, 0.0F, this.axes_length, 0.0F, 0.0F);
/* 247 */     line(0.0F, 0.0F, 0.0F, 0.0F, -this.axes_length, 0.0F);
/* 248 */     line(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, this.axes_length);
/* 249 */     text("z", 0.0F, -this.axes_length - 10.0F, 0.0F);
/* 250 */     text("x", this.axes_length + 10.0F, 0.0F, 0.0F);
/* 251 */     text("y", 0.0F, 0.0F, this.axes_length + 10.0F);
/*     */ 
/* 254 */     stroke(0.0F, 255.0F, 0.0F);
/* 255 */     this.x = (this.r * sin(this.polar_angle) * cos(this.azimuthal_angle));
/* 256 */     this.y = (this.r * sin(this.polar_angle) * sin(this.azimuthal_angle));
/* 257 */     this.z = (this.r * cos(this.polar_angle));
/* 258 */     line(0.0F, 0.0F, 0.0F, this.x, -this.z, this.y);
/* 259 */     text("r", this.x / 2.0F, -this.z / 2.0F - 10.0F, this.y / 2.0F);
/*     */ 
/* 262 */     stroke(100);
/* 263 */     if (this.z > 0.0F)
/*     */     {
/* 265 */       for (f1 = -this.z; f1 < 0.0F; f1 += this.dotted_line_length * 2.0F)
/*     */       {
/* 267 */         line(this.x, f1, this.y, this.x, f1 + this.dotted_line_length, this.y);
/*     */       }
/*     */     }
/* 270 */     else if (this.z < 0.0F)
/*     */     {
/* 272 */       for (f1 = -this.z; f1 > 0.0F; f1 -= this.dotted_line_length * 2.0F)
/*     */       {
/* 274 */         line(this.x, f1, this.y, this.x, f1 - this.dotted_line_length, this.y);
/*     */       }
/*     */     }
/* 277 */     for (float f1 = 0.0F; f1 <= this.r; f1 += this.dotted_line_length * 2.0F)
/*     */     {
/* 279 */       line(f1 * sin(this.polar_angle) * cos(this.azimuthal_angle), 0.0F, f1 * sin(this.polar_angle) * sin(this.azimuthal_angle), (f1 + this.dotted_line_length) * sin(this.polar_angle) * cos(this.azimuthal_angle), 0.0F, (f1 + this.dotted_line_length) * sin(this.polar_angle) * sin(this.azimuthal_angle));
/*     */     }
/*     */ 
/* 285 */     if (this.leave_trace) this.arc_size = this.r; else this.arc_size = 50.0F;
/* 286 */     f1 = this.arc_size;
/* 287 */     float f2 = 0.0F;
/* 288 */     float f3 = 0.0F;
/* 289 */     float f4 = 0.0F;
/* 290 */     float f5 = 0.05F;
/* 291 */     if (this.azimuthal_angle < 0.0F) f5 = -f5;
/* 292 */     stroke(255.0F, 0.0F, 0.0F, 255.0F);
/* 293 */     fill(255.0F, 0.0F, 0.0F, 100.0F);
/* 294 */     beginShape(256);
/* 295 */     for (float f6 = 0.0F; abs(f6) <= abs(this.azimuthal_angle); f6 += f5)
/*     */     {
/* 297 */       f3 = this.arc_size * cos(f6);
/* 298 */       f4 = this.arc_size * sin(f6);
/* 299 */       vertex(f3, 0.0F, f4);
/* 300 */       f1 = f3;
/* 301 */       f2 = f4;
/*     */     }
/* 303 */     vertex(0.0F, 0.0F, 0.0F);
/* 304 */     endShape();
/*     */ 
/* 307 */     f6 = this.arc_size;
/* 308 */     f1 = 0.0F;
/* 309 */     f2 = 0.0F;
/* 310 */     float f7 = 0.0F;
/* 311 */     f3 = 0.0F;
/* 312 */     f4 = 0.0F;
/* 313 */     stroke(0.0F, 0.0F, 255.0F);
/* 314 */     fill(0.0F, 0.0F, 255.0F, 30.0F);
/* 315 */     beginShape(256);
/* 316 */     for (float f8 = 0.0F; f8 <= this.polar_angle; f8 += f5)
/*     */     {
/* 318 */       f3 = this.arc_size * sin(f8) * cos(this.azimuthal_angle);
/* 319 */       f4 = this.arc_size * sin(f8) * sin(this.azimuthal_angle);
/* 320 */       f7 = this.arc_size * cos(f8);
/* 321 */       vertex(f3, -f7, f4);
/* 322 */       f1 = f3;
/* 323 */       f6 = f7;
/* 324 */       f2 = f4;
/*     */     }
/* 326 */     vertex(0.0F, 0.0F, 0.0F);
/* 327 */     endShape();
/*     */ 
/* 329 */     if (!(this.leave_trace))
/*     */       return;
/* 331 */     for (f8 = 0.0F; f8 <= this.azimuthal_angle; f8 += f5 * 2.0F)
/*     */     {
/* 333 */       beginShape(256);
/* 334 */       for (float f9 = 0.0F; f9 <= this.polar_angle; f9 += f5)
/*     */       {
/* 336 */         f3 = this.arc_size * sin(f9) * cos(f8);
/* 337 */         f4 = this.arc_size * sin(f9) * sin(f8);
/* 338 */         f7 = this.arc_size * cos(f9);
/* 339 */         vertex(f3, -f7, f4);
/* 340 */         f1 = f3;
/* 341 */         f6 = f7;
/* 342 */         f2 = f4;
/*     */       }
/* 344 */       vertex(0.0F, 0.0F, 0.0F);
/* 345 */       endShape();
/*     */     }
/*     */   }
/*     */ 
/*     */   private final void jdMethod_this()
/*     */   {
/*   4 */     this.axes_centre_x = 150.0F;
/*   5 */     this.axes_centre_y = 400.0F;
/*   6 */     this.axes_centre_z = -300.0F;
/*   7 */     this.axes_length = 365.0F;
/*   8 */     this.rotate_y = 0.0F;
/*   9 */     this.rotate_x = 0.0F;
/*  10 */     this.rotate_speed = 0.05F;
/*  11 */     this.r = sqrt(sq(this.axes_length / 2.0F) + sq(this.axes_length / 2.0F));
/*  12 */     this.azimuthal_angle = 0.7853982F;
/*  13 */     this.polar_angle = 0.7853982F;
/*  14 */     this.z = 0.0F;
/*  15 */     this.x = 0.0F;
/*  16 */     this.y = 0.0F;
/*  17 */     this.arc_size = 50.0F;
/*  18 */     this.move_speed = 10.0F;
/*  19 */     this.angle_speed = 0.03F;
/*  20 */     this.dotted_line_length = 7.0F;
/*  21 */     this.arrowhead_size = 7.0F;
/*  22 */     this.rect_size = 30.0F;
/*  23 */     this.rect_a_minus_pos_x = 520.0F;
/*  24 */     this.rect_a_minus_pos_y = 10.0F;
/*  25 */     this.rect_a_plus_pos_x = (this.rect_a_minus_pos_x + this.rect_size + 10.0F);
/*  26 */     this.rect_a_plus_pos_y = this.rect_a_minus_pos_y;
/*  27 */     this.rect_a_minus = false;
/*  28 */     this.rect_a_plus = false;
/*  29 */     this.rect_b_minus_pos_x = 520.0F;
/*  30 */     this.rect_b_minus_pos_y = 100.0F;
/*  31 */     this.rect_b_plus_pos_x = (this.rect_b_minus_pos_x + this.rect_size + 10.0F);
/*  32 */     this.rect_b_plus_pos_y = this.rect_b_minus_pos_y;
/*  33 */     this.rect_b_minus = false;
/*  34 */     this.rect_b_plus = false;
/*  35 */     this.rect_r_minus_pos_x = 520.0F;
/*  36 */     this.rect_r_minus_pos_y = 185.0F;
/*  37 */     this.rect_r_plus_pos_x = (this.rect_r_minus_pos_x + this.rect_size + 10.0F);
/*  38 */     this.rect_r_plus_pos_y = this.rect_r_minus_pos_y;
/*  39 */     this.rect_r_minus = false;
/*  40 */     this.rect_r_plus = false;
/*  41 */     this.rect_color = color(200);
/*  42 */     this.rect_highlight_color = color(255);
/*  43 */     this.mouse_over_button = false;
/*  44 */     this.leave_trace = false;
/*     */   }
/*     */ 
/*     */   public Spherical_Polar_Coordinates()
/*     */   {
/*   1 */     jdMethod_this();
/*     */   }
/*     */ 
/*     */   class ToggleButton
/*     */   {
/*     */     public boolean value;
/*     */     public String msg;
/*     */     public int x;
/*     */     public int y;
/*     */     public int w;
/*     */     public int h;
/*     */ 
/*     */     public void draw()
/*     */     {
/* 361 */       Spherical_Polar_Coordinates.this.pushMatrix();
/* 362 */       Spherical_Polar_Coordinates.this.translate(this.x, this.y);
/* 363 */       if (this.value) {
/* 364 */         Spherical_Polar_Coordinates.this.fill(250.0F, 130.0F, 20.0F);
/* 365 */         Spherical_Polar_Coordinates.this.stroke(0);
/* 366 */         Spherical_Polar_Coordinates.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/*     */       else
/*     */       {
/* 374 */         Spherical_Polar_Coordinates.this.fill(255.0F, 255.0F, 255.0F);
/* 375 */         Spherical_Polar_Coordinates.this.stroke(0);
/* 376 */         Spherical_Polar_Coordinates.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/* 378 */       Spherical_Polar_Coordinates.this.rect(0.0F, 0.0F, this.w, this.h);
/* 379 */       Spherical_Polar_Coordinates.this.noStroke();
/* 380 */       Spherical_Polar_Coordinates.this.fill(255.0F, 255.0F, 255.0F);
/* 381 */       Spherical_Polar_Coordinates.this.rect(2.0F, 2.0F, this.w - 4, this.h - 4);
/*     */ 
/* 383 */       Spherical_Polar_Coordinates.this.fill(0);
/*     */ 
/* 385 */       Spherical_Polar_Coordinates.this.textSize(16.0F);
/* 386 */       Spherical_Polar_Coordinates.this.text(this.msg, 5, this.h - 5);
/*     */ 
/* 388 */       Spherical_Polar_Coordinates.this.popMatrix();
/*     */     }
/*     */ 
/*     */     public void processMouseDown() {
/* 392 */       int i = Spherical_Polar_Coordinates.this.mouseX - this.x;
/* 393 */       int j = Spherical_Polar_Coordinates.this.mouseY - this.y;
/*     */ 
/* 395 */       if ((i < 0) || (i > this.w) || 
/* 396 */         (j < 0) || (j > this.h)) return;
/* 397 */       this.value ^= true;
/*     */     }
/*     */ 
/*     */     private final void jdMethod_this()
/*     */     {
/* 402 */       this.value = false;
/*     */     }
/*     */ 
/*     */     public ToggleButton(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString)
/*     */     {
/* 352 */       jdMethod_this();
/* 353 */       this.x = paramInt1;
/* 354 */       this.y = paramInt2;
/* 355 */       this.w = paramInt3;
/* 356 */       this.h = paramInt4;
/* 357 */       this.msg = paramString;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/mfeyereisen/applets-final/classes/
 * Qualified Name:     Spherical_Polar_Coordinates
 * JD-Core Version:    0.5.3
 */