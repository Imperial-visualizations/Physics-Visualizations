/*     */ import processing.core.PApplet;
/*     */ import processing.core.PFont;
/*     */ 
/*     */ public class Vector_Field_Flux extends PApplet
/*     */ {
/*     */   float axes_centre_x;
/*     */   float axes_centre_y;
/*     */   float axes_length;
/*     */   float field_density;
/*     */   float scale_factor;
/*     */   float axes_arrowhead_length;
/*     */   boolean show_components;
/*     */   int field_selection;
/*     */   float rect_x;
/*     */   float rect_y;
/*     */   float rect_size_x;
/*     */   float rect_size_y;
/*     */   boolean button_pressed;
/*     */   float rect_field_density;
/*     */   PFont font;
/*     */   Vector_Field_Flux.ToggleButton tbData;
/*     */   Vector_Field_Flux.ToggleButton tbField;
/*     */ 
/*     */   public void reset()
/*     */   {
/*  25 */     this.field_density = 30.0F;
/*  26 */     this.scale_factor = 10.0F;
/*  27 */     this.show_components = false;
/*  28 */     this.field_selection = 0;
/*  29 */     this.rect_x = 0.0F;
/*  30 */     this.rect_y = 0.0F;
/*  31 */     this.rect_size_x = 0.0F;
/*  32 */     this.rect_size_y = 0.0F;
/*  33 */     this.button_pressed = false;
/*  34 */     this.rect_field_density = 20.0F;
/*  35 */     this.tbData.value = false;
/*  36 */     this.tbField.value = false;
/*     */   }
/*     */ 
/*     */   public void setup()
/*     */   {
/*  41 */     size(640, 480);
/*  42 */     background(255);
/*  43 */     stroke(0);
/*  44 */     framerate(60.0F);
/*  45 */     this.font = loadFont("ArialMT-20.vlw");
/*  46 */     textFont(this.font, 20.0F);
/*     */ 
/*  48 */     this.tbData = new Vector_Field_Flux.ToggleButton(520, 10, 75, 20, "show flux");
/*  49 */     this.tbField = new Vector_Field_Flux.ToggleButton(510, 40, 90, 20, "vector field");
/*     */   }
/*     */ 
/*     */   public float P(float paramFloat1, float paramFloat2)
/*     */   {
/*  57 */     return paramFloat1;
/*     */   }
/*     */ 
/*     */   public float dPdX(float paramFloat1, float paramFloat2)
/*     */   {
/*  66 */     return 1.0F;
/*     */   }
/*     */ 
/*     */   public float Q(float paramFloat1, float paramFloat2)
/*     */   {
/*  72 */     switch (this.field_selection)
/*     */     {
/*     */     case 1:
/*  75 */       return (-paramFloat2);
/*     */     }
/*  77 */     return paramFloat2;
/*     */   }
/*     */ 
/*     */   public float dQdY(float paramFloat1, float paramFloat2)
/*     */   {
/*  83 */     switch (this.field_selection)
/*     */     {
/*     */     case 1:
/*  86 */       return (-1.0F);
/*     */     }
/*  88 */     return 1.0F;
/*     */   }
/*     */ 
/*     */   public void keyPressed()
/*     */   {
/*  94 */     if (this.key == 'r') reset();
/*  95 */     if (this.keyCode == 10)
/*     */     {
/*  97 */       if (this.show_components) this.show_components = false; else this.show_components = true;
/*     */     }
/*  99 */     if (this.keyCode != 16)
/*     */       return;
/* 101 */     this.field_selection += 1;
/* 102 */     if (this.field_selection <= 2) return; this.field_selection = 0;
/*     */   }
/*     */ 
/*     */   public void mousePressed()
/*     */   {
/* 108 */     if (this.mouseButton != 37)
/*     */       return;
/* 110 */     if ((!(this.button_pressed)) && (this.mouseX - this.axes_centre_x < this.axes_length))
/*     */     {
/* 112 */       this.button_pressed = true;
/* 113 */       this.rect_x = (this.mouseX - this.axes_centre_x);
/* 114 */       this.rect_y = (this.mouseY - this.axes_centre_y);
/* 115 */       this.rect_size_x = 0.0F;
/* 116 */       this.rect_size_y = 0.0F;
/*     */     }
/*     */ 
/* 119 */     this.tbData.processMouseDown();
/* 120 */     this.tbField.processMouseDown();
/*     */   }
/*     */ 
/*     */   public void mouseDragged()
/*     */   {
/* 127 */     if ((this.mouseX <= this.rect_x + this.axes_centre_x) || (this.mouseY <= this.rect_y + this.axes_centre_y))
/*     */       return;
/* 129 */     this.rect_size_x = (this.mouseX - (this.rect_x + this.axes_centre_x));
/* 130 */     this.rect_size_y = (this.mouseY - (this.rect_y + this.axes_centre_y));
/*     */   }
/*     */ 
/*     */   public void mouseReleased()
/*     */   {
/* 136 */     this.button_pressed = false;
/*     */   }
/*     */ 
/*     */   public void draw()
/*     */   {
/* 142 */     background(255);
/*     */ 
/* 144 */     this.tbData.draw();
/* 145 */     this.show_components = this.tbData.value;
/* 146 */     this.tbField.draw();
/* 147 */     if (this.tbField.value) this.field_selection = 1; else this.field_selection = 0;
/*     */ 
/* 150 */     stroke(0.0F, 0.0F, 0.0F);
/* 151 */     translate(this.axes_centre_x, this.axes_centre_y);
/* 152 */     line(0.0F, 0.0F, this.axes_length, 0.0F);
/* 153 */     line(0.0F, 0.0F, -this.axes_length, 0.0F);
/* 154 */     line(0.0F, 0.0F, 0.0F, this.axes_length);
/* 155 */     line(0.0F, 0.0F, 0.0F, -this.axes_length);
/* 156 */     line(this.axes_length, 0.0F, this.axes_length - this.axes_arrowhead_length, -5.0F);
/* 157 */     line(this.axes_length, 0.0F, this.axes_length - this.axes_arrowhead_length, 5);
/* 158 */     line(-this.axes_length, 0.0F, -this.axes_length + this.axes_arrowhead_length, -5.0F);
/* 159 */     line(-this.axes_length, 0.0F, -this.axes_length + this.axes_arrowhead_length, 5);
/* 160 */     line(0.0F, this.axes_length, -5.0F, this.axes_length - this.axes_arrowhead_length);
/* 161 */     line(0.0F, this.axes_length, 5, this.axes_length - this.axes_arrowhead_length);
/* 162 */     line(0.0F, -this.axes_length, -5.0F, -this.axes_length + this.axes_arrowhead_length);
/* 163 */     line(0.0F, -this.axes_length, 5, -this.axes_length + this.axes_arrowhead_length);
/*     */ 
/* 166 */     for (float f1 = -this.axes_length; f1 <= this.axes_length; f1 += this.field_density)
/*     */     {
/* 168 */       for (f2 = -this.axes_length; f2 <= this.axes_length; f2 += this.field_density)
/*     */       {
/* 177 */         stroke(200);
/* 178 */         line(f1, -f2, f1 + P(f1 / this.scale_factor, f2 / this.scale_factor), -f2 - Q(f1 / this.scale_factor, f2 / this.scale_factor));
/* 179 */         pushMatrix();
/* 180 */         translate(f1 + P(f1 / this.scale_factor, f2 / this.scale_factor), -f2 - Q(f1 / this.scale_factor, f2 / this.scale_factor));
/* 181 */         f3 = sqrt(sq(P(f1 / this.scale_factor, f2 / this.scale_factor)) + sq(Q(f1 / this.scale_factor, f2 / this.scale_factor))) / 3;
/* 182 */         f4 = atan(Q(f1 / this.scale_factor, f2 / this.scale_factor) / P(f1 / this.scale_factor, f2 / this.scale_factor));
/* 183 */         f5 = 1.0F;
/* 184 */         if (f1 >= 0.0F) f5 = -1.0F;
/* 185 */         line(0.0F, 0.0F, f5 * f3 * sin(radians(45.0F) - f4), -f3 * f5 * cos(radians(45.0F) - f4));
/* 186 */         line(0.0F, 0.0F, f5 * f3 * cos(f4 - radians(45.0F)), -f3 * f5 * sin(f4 - radians(45.0F)));
/* 187 */         popMatrix();
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 193 */     stroke(0.0F, 0.0F, 0.0F);
/* 194 */     fill(0.0F, 0.0F, 0.0F, 100.0F);
/* 195 */     beginShape(128);
/* 196 */     vertex(this.rect_x, this.rect_y);
/* 197 */     vertex(this.rect_x + this.rect_size_x, this.rect_y);
/* 198 */     vertex(this.rect_x + this.rect_size_x, this.rect_y + this.rect_size_y);
/* 199 */     vertex(this.rect_x, this.rect_y + this.rect_size_y);
/* 200 */     endShape();
/*     */ 
/* 203 */     for (f1 = this.rect_x; f1 <= this.rect_x + this.rect_size_x; f1 += this.rect_field_density)
/*     */     {
/* 205 */       for (f2 = -this.rect_y; f2 >= -this.rect_y - this.rect_size_y; f2 -= this.rect_field_density)
/*     */       {
/* 207 */         if ((f1 != this.rect_x) && (f2 != -this.rect_y) && (f1 + this.rect_field_density <= this.rect_x + this.rect_size_x) && (f2 - this.rect_field_density >= -this.rect_y - this.rect_size_y))
/*     */           continue;
/* 209 */         if (f1 + this.rect_field_density > this.rect_x + this.rect_size_x) f1 = this.rect_x + this.rect_size_x;
/* 210 */         if (f2 - this.rect_field_density < -this.rect_y - this.rect_size_y) f2 = -this.rect_y - this.rect_size_y;
/* 211 */         if (this.show_components)
/*     */         {
/* 213 */           stroke(255.0F, 0.0F, 0.0F);
/* 214 */           line(f1, -f2, f1 + P(f1 / this.scale_factor, f2 / this.scale_factor), -f2);
/* 215 */           stroke(0.0F, 255.0F, 0.0F);
/* 216 */           line(f1 + P(f1 / this.scale_factor, f2 / this.scale_factor), -f2, f1 + P(f1 / this.scale_factor, f2 / this.scale_factor), -f2 - Q(f1 / this.scale_factor, f2 / this.scale_factor));
/*     */         }
/* 218 */         stroke(0);
/* 219 */         line(f1, -f2, f1 + P(f1 / this.scale_factor, f2 / this.scale_factor), -f2 - Q(f1 / this.scale_factor, f2 / this.scale_factor));
/* 220 */         pushMatrix();
/* 221 */         translate(f1 + P(f1 / this.scale_factor, f2 / this.scale_factor), -f2 - Q(f1 / this.scale_factor, f2 / this.scale_factor));
/* 222 */         f3 = sqrt(sq(P(f1 / this.scale_factor, f2 / this.scale_factor)) + sq(Q(f1 / this.scale_factor, f2 / this.scale_factor))) / 3;
/* 223 */         f4 = atan(Q(f1 / this.scale_factor, f2 / this.scale_factor) / P(f1 / this.scale_factor, f2 / this.scale_factor));
/* 224 */         f5 = 1.0F;
/* 225 */         if (f1 >= 0.0F) f5 = -1.0F;
/* 226 */         line(0.0F, 0.0F, f5 * f3 * sin(radians(45.0F) - f4), -f3 * f5 * cos(radians(45.0F) - f4));
/* 227 */         line(0.0F, 0.0F, f5 * f3 * cos(f4 - radians(45.0F)), -f3 * f5 * sin(f4 - radians(45.0F)));
/* 228 */         popMatrix();
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 233 */     if ((!(this.show_components)) || (
/* 235 */       (this.rect_size_x <= 0.0F) && (this.rect_size_y <= 0.0F)))
/*     */       return;
/* 237 */     f1 = 50.0F;
/* 238 */     float f2 = 0.0F;
/* 239 */     float f3 = 0.0F;
/* 240 */     float f4 = 0.0F;
/* 241 */     float f5 = 0.0F;
/*     */ 
/* 243 */     for (float f6 = this.rect_y; f6 <= this.rect_y + this.rect_size_y; f6 += 10.0F)
/*     */     {
/* 245 */       f2 += -P(this.rect_x, f6);
/* 246 */       f3 += P(this.rect_x + this.rect_size_x, f6);
/*     */     }
/* 248 */     for (f6 = this.rect_x; f6 <= this.rect_x + this.rect_size_x; f6 += 10.0F)
/*     */     {
/* 250 */       f4 += -Q(f6, this.rect_y);
/* 251 */       f5 += Q(f6, this.rect_y + this.rect_size_y);
/*     */     }
/*     */ 
/* 263 */     stroke(255.0F, 0.0F, 0.0F); fill(255.0F, 0.0F, 0.0F);
/* 264 */     text(f2, this.rect_x - (f1 * 2.0F), this.rect_y + this.rect_size_y / 2.0F);
/* 265 */     text(f3, this.rect_x + this.rect_size_x + f1, this.rect_y + this.rect_size_y / 2.0F);
/* 266 */     stroke(50.0F, 255.0F, 50.0F); fill(0.0F, 255.0F, 0.0F);
/* 267 */     text(f4, this.rect_x + this.rect_size_x / 2.0F - f1, this.rect_y - f1);
/* 268 */     text(f5, this.rect_x + this.rect_size_x / 2.0F - f1, this.rect_y + this.rect_size_y + f1);
/*     */   }
/*     */ 
/*     */   private final void jdMethod_this()
/*     */   {
/*   4 */     this.axes_centre_x = 250.0F;
/*   5 */     this.axes_centre_y = 230.0F;
/*   6 */     this.axes_length = 220.0F;
/*   7 */     this.field_density = 30.0F;
/*   8 */     this.scale_factor = 10.0F;
/*   9 */     this.axes_arrowhead_length = 10.0F;
/*  10 */     this.show_components = false;
/*  11 */     this.field_selection = 0;
/*  12 */     this.rect_x = 0.0F;
/*  13 */     this.rect_y = 0.0F;
/*  14 */     this.rect_size_x = 0.0F;
/*  15 */     this.rect_size_y = 0.0F;
/*  16 */     this.button_pressed = false;
/*  17 */     this.rect_field_density = 20.0F;
/*     */   }
/*     */ 
/*     */   public Vector_Field_Flux()
/*     */   {
/*   1 */     jdMethod_this();
/*     */   }
/*     */ 
/*     */   class ToggleButton
/*     */   {
/*     */     public boolean value;
/*     */     public String msg;
/*     */     public int x;
/*     */     public int y;
/*     */     public int w;
/*     */     public int h;
/*     */ 
/*     */     public void draw()
/*     */     {
/* 290 */       Vector_Field_Flux.this.pushMatrix();
/* 291 */       Vector_Field_Flux.this.translate(this.x, this.y);
/* 292 */       if (this.value) {
/* 293 */         Vector_Field_Flux.this.fill(250.0F, 130.0F, 20.0F);
/* 294 */         Vector_Field_Flux.this.stroke(0);
/* 295 */         Vector_Field_Flux.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/*     */       else
/*     */       {
/* 303 */         Vector_Field_Flux.this.fill(255.0F, 255.0F, 255.0F);
/* 304 */         Vector_Field_Flux.this.stroke(0);
/* 305 */         Vector_Field_Flux.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/* 307 */       Vector_Field_Flux.this.rect(0.0F, 0.0F, this.w, this.h);
/* 308 */       Vector_Field_Flux.this.noStroke();
/* 309 */       Vector_Field_Flux.this.fill(255.0F, 255.0F, 255.0F);
/* 310 */       Vector_Field_Flux.this.rect(2.0F, 2.0F, this.w - 4, this.h - 4);
/*     */ 
/* 312 */       Vector_Field_Flux.this.fill(0);
/*     */ 
/* 314 */       Vector_Field_Flux.this.textSize(16.0F);
/* 315 */       Vector_Field_Flux.this.text(this.msg, 5, this.h - 5);
/*     */ 
/* 317 */       Vector_Field_Flux.this.popMatrix();
/*     */     }
/*     */ 
/*     */     public void processMouseDown() {
/* 321 */       int i = Vector_Field_Flux.this.mouseX - this.x;
/* 322 */       int j = Vector_Field_Flux.this.mouseY - this.y;
/*     */ 
/* 324 */       if ((i < 0) || (i > this.w) || 
/* 325 */         (j < 0) || (j > this.h)) return;
/* 326 */       this.value ^= true;
/*     */     }
/*     */ 
/*     */     private final void jdMethod_this()
/*     */     {
/* 331 */       this.value = false;
/*     */     }
/*     */ 
/*     */     public ToggleButton(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString)
/*     */     {
/* 281 */       jdMethod_this();
/* 282 */       this.x = paramInt1;
/* 283 */       this.y = paramInt2;
/* 284 */       this.w = paramInt3;
/* 285 */       this.h = paramInt4;
/* 286 */       this.msg = paramString;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/mfeyereisen/applets-final/classes/
 * Qualified Name:     Vector_Field_Flux
 * JD-Core Version:    0.5.3
 */