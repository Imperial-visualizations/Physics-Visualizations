/*     */ import processing.core.PApplet;
/*     */ import processing.core.PFont;
/*     */ import processing.core.PImage;
/*     */ 
/*     */ public class ContourTerrain extends PApplet
/*     */ {
/*     */   float axes_centre_x;
/*     */   float axes_centre_y;
/*     */   float axes_centre_z;
/*     */   float x_axes_length;
/*     */   float y_axes_length;
/*     */   float z_axes_length;
/*     */   float axes_length;
/*     */   boolean rotate_cam_y;
/*     */   boolean rotate_cam_x;
/*     */   float rotate_y;
/*     */   float rotate_x;
/*     */   float rotate_speed;
/*     */   int surface_res;
/*     */   float scale_factor;
/*     */   PFont font;
/*     */   PImage heightmap;
/*     */   PImage texturemap;
/*     */   int[] heightmapPixels;
/*     */   ContourTerrain.Slider sSlider;
/*     */ 
/*     */   public void reset()
/*     */   {
/*  31 */     this.rotate_cam_y = false;
/*  32 */     this.rotate_cam_x = false;
/*  33 */     this.rotate_y = 0.0F;
/*  34 */     this.rotate_x = 0.0F;
/*  35 */     this.sSlider.updatePosition(0);
/*     */   }
/*     */ 
/*     */   public void setup()
/*     */   {
/*  40 */     size(640, 480, "processing.core.PGraphics3");
/*  41 */     background(255.0F, 255.0F, 255.0F);
/*  42 */     stroke(0.0F, 0.0F, 0.0F);
/*  43 */     framerate(60.0F);
/*  44 */     this.font = loadFont("Tahoma-14.vlw");
/*  45 */     textFont(this.font, 14.0F);
/*     */ 
/*  47 */     this.texturemap = loadImage("Texture.jpg");
/*  48 */     this.heightmapPixels = new int[102400];
/*  49 */     this.heightmap = loadImage("Terrain.jpg");
/*  50 */     for (int i = 0; i < 102400; ++i) {
/*  51 */       this.heightmapPixels[i] = this.heightmap.pixels[i];
/*     */     }
/*     */ 
/*  54 */     this.sSlider = new ContourTerrain.Slider(480, 45, 140, 14, 0, 13, 0);
/*  55 */     reset();
/*     */   }
/*     */ 
/*     */   public void keyPressed()
/*     */   {
/*  60 */     if (this.key == 'r')
/*  61 */       reset();
/*     */   }
/*     */ 
/*     */   public void mousePressed()
/*     */   {
/*  67 */     if (this.mouseButton == 39)
/*     */     {
/*  69 */       this.rotate_cam_y = true;
/*  70 */       this.rotate_cam_x = true;
/*     */     } else {
/*  72 */       this.sSlider.processMouseDown();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void mouseReleased() {
/*  77 */     if (this.mouseButton == 39)
/*     */     {
/*  79 */       this.rotate_cam_y = false;
/*  80 */       this.rotate_cam_x = false;
/*     */     } else {
/*  82 */       this.sSlider.processMouseUp();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void draw() {
/*  87 */     background(255);
/*     */ 
/*  89 */     this.sSlider.draw();
/*  90 */     textSize(14.0F);
/*  91 */     stroke(0); fill(0);
/*  92 */     text("Contour map elevation:", 475.0F, 30.0F, 0.0F);
/*     */ 
/*  95 */     stroke(0.0F, 0.0F, 0.0F, 100.0F); fill(0.0F, 0.0F, 0.0F, 100.0F);
/*  96 */     translate(this.axes_centre_x, this.axes_centre_y, this.axes_centre_z);
/*  97 */     translate(this.x_axes_length / 2.0F, -this.y_axes_length / 2.0F, this.z_axes_length / 2.0F);
/*  98 */     if (this.rotate_cam_y)
/*     */     {
/* 102 */       this.rotate_y += 3.141593F * (this.mouseX - this.pmouseX) / this.width;
/* 103 */       if (this.rotate_y >= 6.283186F) this.rotate_y -= 6.283186F;
/* 104 */       if (this.rotate_y < 0.0F) this.rotate_y += 6.283186F;
/*     */     }
/* 106 */     if (this.rotate_cam_x)
/*     */     {
/* 110 */       this.rotate_x -= 3.141593F * (this.mouseY - this.pmouseY) / this.height;
/* 111 */       if (this.rotate_x >= 6.283186F) this.rotate_x -= 6.283186F;
/* 112 */       if (this.rotate_x < 0.0F) this.rotate_x += 6.283186F;
/*     */     }
/* 114 */     rotateX(this.rotate_x);
/* 115 */     rotateY(this.rotate_y);
/* 116 */     translate(-this.x_axes_length / 2.0F, this.y_axes_length / 2.0F, -this.z_axes_length / 2.0F);
/* 117 */     stroke(200.0F, 20.0F, 20.0F);
/* 118 */     line(0.0F, 0.0F, 0.0F, this.x_axes_length, 0.0F, 0.0F);
/* 119 */     stroke(20.0F, 200.0F, 20.0F);
/* 120 */     line(0.0F, 0.0F, 0.0F, 0.0F, -this.y_axes_length, 0.0F);
/* 121 */     stroke(20.0F, 20.0F, 200.0F);
/* 122 */     line(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, this.z_axes_length);
/*     */ 
/* 129 */     fill(255.0F, 255.0F, 255.0F, 255.0F);
/* 130 */     textureMode(1);
/*     */ 
/* 132 */     noStroke();
/*     */ 
/* 135 */     for (int i = 0; i < this.surface_res - 1; ++i)
/* 136 */       for (int j = 0; j < this.surface_res - 1; ++j) {
/* 137 */         float f1 = i / this.surface_res;
/* 138 */         float f2 = (i + 1) / this.surface_res;
/* 139 */         float f3 = j / this.surface_res;
/* 140 */         float f4 = (j + 1) / this.surface_res;
/*     */ 
/* 142 */         float f5 = i * this.axes_length / this.surface_res;
/* 143 */         float f6 = (i + 1) * this.axes_length / this.surface_res;
/* 144 */         float f7 = j * this.axes_length / this.surface_res;
/* 145 */         float f8 = (j + 1) * this.axes_length / this.surface_res;
/*     */ 
/* 147 */         beginShape(128);
/* 148 */         texture(this.texturemap);
/* 149 */         vertex(f5, h(f1, f3), f7, f1, f3);
/* 150 */         vertex(f6, h(f2, f3), f7, f2, f3);
/* 151 */         vertex(f6, h(f2, f4), f8, f2, f4);
/* 152 */         vertex(f5, h(f1, f4), f8, f1, f4);
/* 153 */         endShape();
/*     */       }
/*     */   }
/*     */ 
/*     */   public float h(float paramFloat1, float paramFloat2)
/*     */   {
/* 183 */     return (this.scale_factor * this.heightmap.get((int)(this.heightmap.width * paramFloat1), (int)(this.heightmap.height * paramFloat2)));
/*     */   }
/*     */ 
/*     */   private final void jdMethod_this()
/*     */   {
/*   6 */     this.axes_centre_x = 100.0F;
/*   7 */     this.axes_centre_y = 400.0F;
/*   8 */     this.axes_centre_z = -400.0F;
/*   9 */     this.x_axes_length = 400.0F;
/*  10 */     this.y_axes_length = 400.0F;
/*  11 */     this.z_axes_length = 400.0F;
/*  12 */     this.axes_length = 400.0F;
/*  13 */     this.rotate_cam_y = false;
/*  14 */     this.rotate_cam_x = false;
/*  15 */     this.rotate_y = 0.0F;
/*  16 */     this.rotate_x = 0.0F;
/*  17 */     this.rotate_speed = 0.05F;
/*  18 */     this.surface_res = 96;
/*  19 */     this.scale_factor = 9.0E-07F;
/*     */   }
/*     */ 
/*     */   public ContourTerrain()
/*     */   {
/*   1 */     jdMethod_this();
/*     */   }
/*     */ 
/*     */   class Slider
/*     */   {
/*     */     private int _x;
/*     */     private int _y;
/*     */     private int _w;
/*     */     private int _h;
/*     */     private int _minValue;
/*     */     private int _maxValue;
/*     */     private int _pos;
/*     */     private float _frac;
/*     */     private boolean _dragging;
/*     */ 
/*     */     public void draw()
/*     */     {
/* 199 */       if (this._dragging) {
/* 200 */         int i = ContourTerrain.this.mouseX - this._x;
/* 201 */         if (i < 0) {
/* 202 */           i = 0;
/*     */         }
/* 204 */         else if (i > this._w) {
/* 205 */           i = this._w;
/*     */         }
/* 207 */         this._frac = (i / this._w);
/* 208 */         updatePosition((int)(i / this._w * (this._maxValue - this._minValue)));
/*     */       }
/*     */ 
/* 211 */       ContourTerrain.this.pushMatrix();
/* 212 */       ContourTerrain.this.translate(this._x, this._y);
/* 213 */       ContourTerrain.this.stroke(50.0F, 50.0F, 50.0F);
/* 214 */       ContourTerrain.this.line(0.0F, 0.0F, this._w, 0.0F);
/* 215 */       ContourTerrain.this.pushMatrix();
/* 216 */       ContourTerrain.this.translate(this._w * this._pos / (this._maxValue - this._minValue), 0.0F);
/*     */ 
/* 218 */       ContourTerrain.this.stroke(0.0F, 0.0F, 0.0F);
/* 219 */       ContourTerrain.this.fill(250.0F, 130.0F, 20.0F);
/* 220 */       ContourTerrain.this.rectMode(3);
/* 221 */       ContourTerrain.this.rect(0.0F, 0.0F, this._h, this._h);
/* 222 */       ContourTerrain.this.popMatrix();
/* 223 */       ContourTerrain.this.popMatrix();
/*     */     }
/*     */ 
/*     */     public void updatePosition(int paramInt) {
/* 227 */       this._pos = paramInt;
/* 228 */       ContourTerrain.this.scale_factor = (this._minValue + (this._maxValue - this._minValue) * paramInt);
/* 229 */       ContourTerrain.this.scale_factor *= 1.0E-07F;
/*     */     }
/*     */ 
/*     */     public void processMouseDown() {
/* 233 */       int i = ContourTerrain.this.mouseX - this._x;
/* 234 */       int j = ContourTerrain.this.mouseY - this._y;
/* 235 */       if (ContourTerrain.mag(i - (this._w * this._pos / (this._maxValue - this._minValue)), j) <= this._h)
/* 236 */         this._dragging = true;
/*     */     }
/*     */ 
/*     */     public void processMouseUp()
/*     */     {
/* 241 */       this._dragging = false;
/*     */     }
/*     */ 
/*     */     private final void jdMethod_this()
/*     */     {
/* 253 */       this._dragging = false;
/*     */     }
/*     */ 
/*     */     public Slider(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7)
/*     */     {
/* 188 */       jdMethod_this();
/* 189 */       this._x = paramInt1;
/* 190 */       this._y = paramInt2;
/* 191 */       this._w = paramInt3;
/* 192 */       this._h = paramInt4;
/* 193 */       this._minValue = paramInt5;
/* 194 */       this._maxValue = paramInt6;
/* 195 */       updatePosition(paramInt7);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/mfeyereisen/applets-final/classes/
 * Qualified Name:     ContourTerrain
 * JD-Core Version:    0.5.3
 */