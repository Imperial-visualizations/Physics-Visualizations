/*     */ import processing.core.PApplet;
/*     */ import processing.core.PFont;
/*     */ 
/*     */ public class Gradient3D extends PApplet
/*     */ {
/*     */   float axes_centre_x;
/*     */   float axes_centre_y;
/*     */   float axes_centre_z;
/*     */   float axes_length;
/*     */   boolean rotate_cam_y;
/*     */   boolean rotate_cam_x;
/*     */   float rotate_y;
/*     */   float rotate_x;
/*     */   float rotate_speed;
/*     */   float scale_factor;
/*     */   float gradient_scale_factor;
/*     */   float vector_field_scale_factor;
/*     */   float surface_alpha_value;
/*     */   float vector_res;
/*     */   boolean display_vector_field;
/*     */   PFont font;
/*     */   Gradient3D.Slider sSlider;
/*     */ 
/*     */   public void setup()
/*     */   {
/*  25 */     size(640, 480, "processing.core.PGraphics3");
/*  26 */     background(255.0F, 255.0F, 255.0F);
/*  27 */     stroke(0.0F, 0.0F, 0.0F);
/*  28 */     framerate(60.0F);
/*  29 */     this.font = loadFont("Arial-Black-20.vlw");
/*  30 */     textFont(this.font, 20.0F);
/*     */ 
/*  32 */     this.sSlider = new Gradient3D.Slider(500, 90, 100, 14, 0, 4, 1);
/*     */   }
/*     */ 
/*     */   public void mousePressed()
/*     */   {
/*  37 */     if (this.mouseButton == 37)
/*     */     {
/*  39 */       this.sSlider.processMouseDown();
/*     */     }
/*     */     else
/*     */     {
/*  43 */       this.rotate_cam_y = true;
/*  44 */       this.rotate_cam_x = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void mouseReleased()
/*     */   {
/*  50 */     this.rotate_cam_y = false;
/*  51 */     this.rotate_cam_x = false;
/*     */ 
/*  53 */     if (this.mouseButton != 37)
/*     */       return;
/*  55 */     this.sSlider.processMouseUp();
/*     */   }
/*     */ 
/*     */   public void keyPressed()
/*     */   {
/*  61 */     if (this.keyCode == 10)
/*     */     {
/*  63 */       if (this.display_vector_field) this.display_vector_field = false; else this.display_vector_field = true;
/*     */     }
/*     */ 
/*  66 */     if (this.keyCode == 39)
/*     */     {
/*  68 */       this.vector_res += 1.0F;
/*     */     }
/*  70 */     if (this.keyCode != 37)
/*     */       return;
/*  72 */     this.vector_res -= 1.0F;
/*  73 */     if (this.vector_res >= 1.0F) return; this.vector_res = 1.0F;
/*     */   }
/*     */ 
/*     */   public void draw()
/*     */   {
/*  79 */     background(255);
/*     */ 
/*  81 */     this.sSlider.draw();
/*  82 */     stroke(0); fill(0);
/*  83 */     textSize(15.0F);
/*  84 */     text("arrow resolution", 490.0F, 115.0F, 0.0F);
/*     */ 
/*  87 */     stroke(0);
/*  88 */     fill(0);
/*  89 */     translate(this.axes_centre_x, this.axes_centre_y, this.axes_centre_z);
/*     */ 
/*  91 */     if (this.rotate_cam_y)
/*     */     {
/*  93 */       if (this.mouseX - this.pmouseX > 0.0F) this.rotate_y += this.rotate_speed;
/*  94 */       if (this.mouseX - this.pmouseX < 0.0F) this.rotate_y -= this.rotate_speed;
/*  95 */       if (this.rotate_y >= 6.283186F) this.rotate_y = 0.0F;
/*     */     }
/*  97 */     if (this.rotate_cam_x)
/*     */     {
/*  99 */       if (this.mouseY - this.pmouseY > 0.0F) this.rotate_x -= this.rotate_speed;
/* 100 */       if (this.mouseY - this.pmouseY < 0.0F) this.rotate_x += this.rotate_speed;
/* 101 */       if (this.rotate_x >= 6.283186F) this.rotate_x = 0.0F;
/*     */     }
/* 103 */     rotateX(this.rotate_x);
/* 104 */     rotateY(this.rotate_y);
/*     */ 
/* 106 */     stroke(255.0F, 0.0F, 0.0F);
/* 107 */     line(0.0F, 0.0F, 0.0F, this.axes_length, 0.0F, 0.0F);
/* 108 */     stroke(0.0F, 0.0F, 255.0F);
/* 109 */     line(0.0F, 0.0F, 0.0F, 0.0F, -this.axes_length, 0.0F);
/* 110 */     stroke(0.0F, 255.0F, 0.0F);
/* 111 */     line(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, this.axes_length);
/* 112 */     text("z", 0.0F, -this.axes_length - 20.0F, 0.0F);
/* 113 */     text("x", this.axes_length + 20.0F, 0.0F, 0.0F);
/* 114 */     text("y", 0.0F, 0.0F, this.axes_length + 20.0F);
/*     */ 
/* 117 */     stroke(100.0F, 100.0F, 100.0F, 50.0F);
/* 118 */     fill(50.0F, 50.0F, 50.0F, 50.0F);
/* 119 */     sphere(this.scale_factor);
/*     */ 
/* 123 */     float f1 = 0.0F;
/* 124 */     float f2 = 0.0F;
/* 125 */     float f3 = 1.0F;
/* 126 */     float f4 = 0.0F;
/* 127 */     float f5 = 0.0F;
/* 128 */     float f6 = 6.283186F / this.vector_res * 2.0F;
/* 129 */     for (f1 = 0.0F; f1 < 3.141593F; f1 += 3.141593F / this.vector_res)
/*     */     {
/* 131 */       f2 = 0.0F;
/* 132 */       f4 = 0.0F;
/* 133 */       f5 = 0.0F;
/* 134 */       stroke(0.0F, 0.0F, 0.0F);
/* 135 */       fill(0.0F, 0.0F, 0.0F, 0.0F);
/* 136 */       for (float f7 = 0.0F; f7 < 6.283186F; f7 += f6)
/*     */       {
/* 138 */         f4 = f3 * this.scale_factor * sin(f7) * cos(f1);
/* 139 */         f5 = f3 * this.scale_factor * sin(f7) * sin(f1);
/* 140 */         f2 = f3 * this.scale_factor * cos(f7);
/*     */ 
/* 142 */         if (!(this.display_vector_field))
/*     */         {
/* 145 */           line(f4, -f2, f5, f4 + 2.0F * f3 * this.gradient_scale_factor * sin(f7) * cos(f1), -f2 - (2.0F * f3 * this.gradient_scale_factor * cos(f7)), f5 + 2.0F * f3 * this.gradient_scale_factor * sin(f7) * sin(f1));
/*     */ 
/* 148 */           pushMatrix();
/* 149 */           translate(f4 + 2.0F * f3 * this.gradient_scale_factor * sin(f7) * cos(f1), -f2 - (2.0F * f3 * this.gradient_scale_factor * cos(f7)), f5 + 2.0F * f3 * this.gradient_scale_factor * sin(f7) * sin(f1));
/* 150 */           float f8 = sqrt(sq(2.0F * f3 * this.gradient_scale_factor * sin(f7) * cos(f1)) + sq(2.0F * f3 * this.gradient_scale_factor * cos(f7)) + sq(2.0F * f3 * this.gradient_scale_factor * sin(f7) * sin(f1))) / 3;
/* 151 */           float f9 = 1.0F;
/* 152 */           float f10 = 1.0F;
/* 153 */           if ((f5 < 0.0F) || ((f5 == 0.0F) && (f4 < 0.0F)) || ((f5 == 0.0F) && (f4 == 0.0F))) f10 = -1.0F;
/* 154 */           if ((f5 > 0.0F) || ((f5 == 0.0F) && (f4 > 0.0F))) f9 = -1.0F;
/* 155 */           line(0.0F, 0.0F, 0.0F, f9 * f8 * sin(radians(45.0F) - f1), f10 * f9 * f8 * sin(f7 - radians(90.0F)), f8 * f9 * cos(radians(45.0F) - f1));
/* 156 */           line(0.0F, 0.0F, 0.0F, f9 * f8 * cos(f1 - radians(45.0F)), f10 * f9 * f8 * sin(f7 - radians(90.0F)), f8 * f9 * sin(f1 - radians(45.0F)));
/* 157 */           popMatrix();
/*     */         }
/*     */         else
/*     */         {
/* 163 */           line(f4, -f2, f5, f4 + f3 * this.vector_field_scale_factor * sin(f7) * sin(f1), -f2 - (f3 * this.vector_field_scale_factor * cos(f7)), f5 - (f3 * this.vector_field_scale_factor * sin(f7) * cos(f1)));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private final void jdMethod_this()
/*     */   {
/*   4 */     this.axes_centre_x = 180.0F;
/*   5 */     this.axes_centre_y = 300.0F;
/*   6 */     this.axes_centre_z = -500.0F;
/*   7 */     this.axes_length = 365.0F;
/*   8 */     this.rotate_cam_y = false;
/*   9 */     this.rotate_cam_x = false;
/*  10 */     this.rotate_y = 0.0F;
/*  11 */     this.rotate_x = 0.0F;
/*  12 */     this.rotate_speed = 0.05F;
/*  13 */     this.scale_factor = 200.0F;
/*  14 */     this.gradient_scale_factor = 50.0F;
/*  15 */     this.vector_field_scale_factor = 100.0F;
/*  16 */     this.surface_alpha_value = 30.0F;
/*  17 */     this.vector_res = 3;
/*  18 */     this.display_vector_field = false;
/*     */   }
/*     */ 
/*     */   public Gradient3D()
/*     */   {
/*   1 */     jdMethod_this();
/*     */   }
/*     */ 
/*     */   class Slider
/*     */   {
/*     */     private int _x;
/*     */     private int _y;
/*     */     private int _w;
/*     */     private int _h;
/*     */     private int _minValue;
/*     */     private int _maxValue;
/*     */     private int _pos;
/*     */     private float _frac;
/*     */     private boolean _dragging;
/*     */ 
/*     */     public void draw()
/*     */     {
/* 186 */       if (this._dragging) {
/* 187 */         int i = Gradient3D.this.mouseX - this._x;
/* 188 */         if (i < 0) {
/* 189 */           i = 0;
/*     */         }
/* 191 */         else if (i > this._w) {
/* 192 */           i = this._w;
/*     */         }
/* 194 */         this._frac = (i / this._w);
/* 195 */         updatePosition((int)(i / this._w * (this._maxValue - this._minValue)));
/*     */       }
/*     */ 
/* 198 */       Gradient3D.this.pushMatrix();
/* 199 */       Gradient3D.this.translate(this._x, this._y);
/* 200 */       Gradient3D.this.stroke(50.0F, 50.0F, 50.0F);
/* 201 */       Gradient3D.this.line(0.0F, 0.0F, this._w, 0.0F);
/* 202 */       Gradient3D.this.pushMatrix();
/* 203 */       Gradient3D.this.translate(this._w * this._pos / (this._maxValue - this._minValue), 0.0F);
/*     */ 
/* 205 */       Gradient3D.this.fill(100.0F, 100.0F, 100.0F);
/* 206 */       Gradient3D.this.rectMode(3);
/* 207 */       Gradient3D.this.rect(0.0F, 0.0F, this._h, this._h);
/* 208 */       Gradient3D.this.popMatrix();
/* 209 */       Gradient3D.this.popMatrix();
/*     */     }
/*     */ 
/*     */     public void updatePosition(int paramInt) {
/* 213 */       this._pos = paramInt;
/* 214 */       Gradient3D.this.vector_res = (this._minValue + (this._maxValue - this._minValue) * paramInt);
/*     */     }
/*     */ 
/*     */     public void processMouseDown() {
/* 218 */       int i = Gradient3D.this.mouseX - this._x;
/* 219 */       int j = Gradient3D.this.mouseY - this._y;
/* 220 */       if (Gradient3D.mag(i - (this._w * this._pos / (this._maxValue - this._minValue)), j) <= this._h)
/* 221 */         this._dragging = true;
/*     */     }
/*     */ 
/*     */     public void processMouseUp()
/*     */     {
/* 226 */       this._dragging = false;
/*     */     }
/*     */ 
/*     */     private final void jdMethod_this()
/*     */     {
/* 238 */       this._dragging = false;
/*     */     }
/*     */ 
/*     */     public Slider(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7)
/*     */     {
/* 175 */       jdMethod_this();
/* 176 */       this._x = paramInt1;
/* 177 */       this._y = paramInt2;
/* 178 */       this._w = paramInt3;
/* 179 */       this._h = paramInt4;
/* 180 */       this._minValue = paramInt5;
/* 181 */       this._maxValue = paramInt6;
/* 182 */       updatePosition(paramInt7);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/mfeyereisen/applets-final/classes/
 * Qualified Name:     Gradient3D
 * JD-Core Version:    0.5.3
 */