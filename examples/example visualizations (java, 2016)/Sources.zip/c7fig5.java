/*     */ import processing.core.PApplet;
/*     */ import processing.core.PFont;
/*     */ 
/*     */ public class c7fig5 extends PApplet
/*     */ {
/*     */   float minX;
/*     */   float maxX;
/*     */   float stepX;
/*     */   float minY;
/*     */   float maxY;
/*     */   float stepY;
/*     */   float dx;
/*     */   float dy;
/*     */   boolean fadingOut;
/*     */   float scalefactor;
/*     */   int internalAlpha;
/*     */   c7fig5.Button btnDecrease;
/*     */   c7fig5.Button btnIncrease;
/*     */   PFont Tahoma14;
/*     */ 
/*     */   public void setup()
/*     */   {
/*  25 */     size(640, 480, "processing.core.PGraphics3");
/*     */ 
/*  27 */     this.btnDecrease = new c7fig5.Button(510, 10, 120, 20, "Decrease grid size");
/*  28 */     this.btnIncrease = new c7fig5.Button(510, 35, 120, 20, "Increase grid size");
/*     */ 
/*  30 */     reset();
/*     */   }
/*     */ 
/*     */   public void draw() {
/*  34 */     pushMatrix();
/*  35 */     translate(this.width / 2.0F, this.height / 2.0F);
/*  36 */     scale(35.0F, -35.0F, 35.0F);
/*     */ 
/*  38 */     scale(10.0F, 10.0F, 10.0F);
/*     */ 
/*  40 */     translate(-0.55F, -0.55F);
/*     */ 
/*  42 */     background(255);
/*     */ 
/*  44 */     if (this.fadingOut) {
/*  45 */       if (this.internalAlpha > 0) {
/*  46 */         this.internalAlpha -= 15;
/*  47 */         if (this.internalAlpha < 0) {
/*  48 */           this.internalAlpha = 0;
/*     */         }
/*     */       }
/*     */     }
/*  52 */     else if (this.internalAlpha < 255) {
/*  53 */       this.internalAlpha += 10;
/*  54 */       if (this.internalAlpha > 255) {
/*  55 */         this.internalAlpha = 255;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  60 */     drawAxes();
/*  61 */     drawField();
/*  62 */     stroke(0.0F, 0.0F, 0.0F);
/*  63 */     drawCircle();
/*  64 */     translate(-0.5F, -0.5F);
/*     */ 
/*  66 */     drawCarpet();
/*  67 */     drawCirculation();
/*     */ 
/*  69 */     popMatrix();
/*     */ 
/*  71 */     this.btnDecrease.draw();
/*  72 */     this.btnIncrease.draw();
/*     */   }
/*     */ 
/*     */   public void drawField()
/*     */   {
/*  77 */     stroke(0.0F, 0.0F, 0.0F, 50.0F);
/*  78 */     for (float f1 = this.minX; f1 <= this.maxX; f1 += this.stepX)
/*  79 */       for (float f2 = this.minY; f2 <= this.maxY; f2 += this.stepY)
/*  80 */         drawArrow(f1, f2, fieldI(f1, f2), fieldJ(f1, f2));
/*     */   }
/*     */ 
/*     */   public void drawAxes()
/*     */   {
/*  86 */     stroke(200.0F, 20.0F, 20.0F);
/*  87 */     drawArrowU(0.55F, 0.0F, 1.1F, 0.0F);
/*  88 */     stroke(20.0F, 200.0F, 20.0F);
/*  89 */     drawArrowU(0.0F, 0.55F, 0.0F, 1.1F);
/*  90 */     stroke(0.0F, 0.0F, 0.0F);
/*     */   }
/*     */ 
/*     */   public void drawCircle() {
/*  94 */     float f = 0.0F;
/*     */ 
/*  96 */     pushMatrix();
/*  97 */     translate(0.6F, 0.6F);
/*     */ 
/* 100 */     beginShape(34);
/* 101 */     while (f < 6.283186F) {
/* 102 */       f += 0.1745329F;
/* 103 */       vertex(0.3F * cos(f), 0.3F * sin(f));
/*     */     }
/* 105 */     endShape();
/*     */ 
/* 107 */     popMatrix();
/*     */   }
/*     */ 
/*     */   public void drawCarpet() {
/* 111 */     float f1 = this.minX;
/* 112 */     while (f1 <= this.maxX) {
/* 113 */       float f2 = this.minY;
/* 114 */       while (f2 <= this.maxY) {
/* 115 */         if (closeEnoughToCurve(f1, f2)) {
/* 116 */           drawSquare(f1, f2, this.dx, this.dy);
/* 117 */           if (this.internalAlpha < 255) {
/* 118 */             drawMargin(f1, f2);
/*     */           }
/*     */         }
/*     */ 
/* 122 */         f2 += this.dy;
/*     */       }
/*     */ 
/* 125 */       f1 += this.dx;
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean closeEnoughToCurve(float paramFloat1, float paramFloat2) {
/* 130 */     float f1 = paramFloat1 - 0.6F;
/* 131 */     float f2 = paramFloat2 - 0.6F;
/*     */ 
/* 133 */     float f3 = mag(f1, f2);
/*     */ 
/* 136 */     return (f3 < 0.3F);
/*     */   }
/*     */ 
/*     */   public void drawSquare(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*     */   {
/* 145 */     pushMatrix();
/* 146 */     translate(paramFloat1, paramFloat2);
/* 147 */     translate(0.5F, 0.5F);
/* 148 */     scale(paramFloat3, paramFloat4);
/*     */ 
/* 150 */     stroke(0.0F, 0.0F, 0.0F, this.internalAlpha);
/* 151 */     fill(0.0F, 0.0F, 0.0F, 100.0F);
/* 152 */     beginShape(128);
/* 153 */     vertex(-0.5F, 0.5F);
/* 154 */     vertex(0.5F, 0.5F);
/* 155 */     vertex(0.5F, -0.5F);
/* 156 */     vertex(-0.5F, -0.5F);
/* 157 */     endShape();
/*     */ 
/* 159 */     fill(0.0F, 0.0F, 0.0F, this.internalAlpha);
/* 160 */     pushMatrix();
/* 161 */     for (int i = 0; i < 4; ++i) {
/* 162 */       line(-0.3F, -0.4F, 0.3F, -0.4F);
/* 163 */       rotateZ(1.570796F);
/* 164 */       beginShape(64);
/* 165 */       vertex(0.3F, -0.4F);
/* 166 */       vertex(0.2F, -0.35F);
/* 167 */       vertex(0.25F, -0.4F);
/* 168 */       vertex(0.3F, -0.4F);
/* 169 */       vertex(0.2F, -0.45F);
/* 170 */       vertex(0.25F, -0.4F);
/* 171 */       endShape();
/*     */     }
/* 173 */     popMatrix();
/*     */ 
/* 175 */     popMatrix();
/*     */   }
/*     */ 
/*     */   public void drawMargin(float paramFloat1, float paramFloat2) {
/* 179 */     pushMatrix();
/* 180 */     translate(paramFloat1, paramFloat2);
/* 181 */     translate(0.5F, 0.5F);
/* 182 */     scale(this.dx, this.dy);
/*     */ 
/* 184 */     stroke(0.0F, 0.0F, 0.0F, 255.0F);
/*     */ 
/* 186 */     if (!(closeEnoughToCurve(paramFloat1 - this.dx, paramFloat2))) {
/* 187 */       line(-0.5F, -0.5F, -0.5F, 0.5F);
/*     */     }
/* 189 */     if (!(closeEnoughToCurve(paramFloat1, paramFloat2 + this.dy))) {
/* 190 */       line(-0.5F, 0.5F, 0.5F, 0.5F);
/*     */     }
/* 192 */     if (!(closeEnoughToCurve(paramFloat1 + this.dx, paramFloat2))) {
/* 193 */       line(0.5F, 0.5F, 0.5F, -0.5F);
/*     */     }
/* 195 */     if (!(closeEnoughToCurve(paramFloat1, paramFloat2 - this.dy))) {
/* 196 */       line(0.5F, -0.5F, -0.5F, -0.5F);
/*     */     }
/*     */ 
/* 199 */     popMatrix();
/*     */   }
/*     */ 
/*     */   public float fieldI(float paramFloat1, float paramFloat2) {
/* 203 */     return (-paramFloat2);
/*     */   }
/*     */ 
/*     */   public float fieldJ(float paramFloat1, float paramFloat2) {
/* 207 */     return paramFloat1;
/*     */   }
/*     */ 
/*     */   public void drawArrow(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 211 */     pushMatrix();
/* 212 */     translate(paramFloat1, paramFloat2);
/* 213 */     rotateZ(atan2(paramFloat4, paramFloat3));
/* 214 */     float f = this.scalefactor * mag(paramFloat3, paramFloat4);
/* 215 */     line(-f / 2.0F, 0.0F, f / 2.0F, 0.0F);
/* 216 */     translate(f / 2.0F, 0.0F);
/* 217 */     line(-0.2F * this.scalefactor, 0.1F * this.scalefactor, 0.0F, 0.0F);
/* 218 */     line(-0.2F * this.scalefactor, -0.1F * this.scalefactor, 0.0F, 0.0F);
/* 219 */     popMatrix();
/*     */   }
/*     */ 
/*     */   public void drawArrowU(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 223 */     pushMatrix();
/* 224 */     translate(paramFloat1, paramFloat2);
/* 225 */     rotateZ(atan2(paramFloat4, paramFloat3));
/* 226 */     float f = mag(paramFloat3, paramFloat4);
/* 227 */     line(-f / 2.0F, 0.0F, f / 2.0F, 0.0F);
/* 228 */     translate(f / 2.0F, 0.0F);
/* 229 */     line(-0.4F * this.scalefactor, 0.2F * this.scalefactor, 0.0F, 0.0F);
/* 230 */     line(-0.4F * this.scalefactor, -0.2F * this.scalefactor, 0.0F, 0.0F);
/* 231 */     popMatrix();
/*     */   }
/*     */ 
/*     */   public void keyPressed()
/*     */   {
/* 244 */     if (this.key == 'r')
/* 245 */       reset();
/*     */   }
/*     */ 
/*     */   public void mousePressed()
/*     */   {
/* 250 */     if (this.mouseButton == 37) {
/* 251 */       this.btnIncrease.processMouseDown();
/* 252 */       this.btnDecrease.processMouseDown();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void mouseReleased() {
/* 257 */     if (this.mouseButton == 37) {
/* 258 */       this.btnIncrease.processMouseUp();
/* 259 */       this.btnDecrease.processMouseUp();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void drawCirculation() {
/* 264 */     stroke(0.0F, 0.0F, 0.0F, 255 - this.internalAlpha);
/*     */ 
/* 266 */     fill(0.0F, 0.0F, 0.0F, 255 - this.internalAlpha);
/* 267 */     pushMatrix();
/* 268 */     translate(1.1F, 1.1F);
/* 269 */     scale(0.9F, 0.9F, 0.9F);
/* 270 */     for (int i = 0; i < 4; ++i) {
/* 271 */       line(-0.3F, -0.4F, 0.3F, -0.4F);
/* 272 */       rotateZ(1.570796F);
/* 273 */       beginShape(64);
/* 274 */       vertex(0.3F, -0.4F);
/* 275 */       vertex(0.2F, -0.35F);
/* 276 */       vertex(0.25F, -0.4F);
/* 277 */       vertex(0.3F, -0.4F);
/* 278 */       vertex(0.2F, -0.45F);
/* 279 */       vertex(0.25F, -0.4F);
/* 280 */       endShape();
/*     */     }
/* 282 */     popMatrix();
/*     */   }
/*     */ 
/*     */   public void reset() {
/* 286 */     this.dx = 0.23F;
/* 287 */     this.dy = 0.23F;
/*     */ 
/* 289 */     this.internalAlpha = 255;
/* 290 */     this.fadingOut = false;
/*     */   }
/*     */ 
/*     */   private final void jdMethod_this()
/*     */   {
/*   1 */     this.minX = 0.1F;
/*   2 */     this.maxX = 1.0F;
/*   3 */     this.stepX = 0.1F;
/*     */ 
/*   5 */     this.minY = 0.1F;
/*   6 */     this.maxY = 1.0F;
/*   7 */     this.stepY = 0.1F;
/*     */ 
/*  10 */     this.dx = 0.23F;
/*  11 */     this.dy = 0.23F;
/*     */ 
/*  13 */     this.fadingOut = false;
/*     */ 
/*  15 */     this.scalefactor = 0.1F;
/*     */ 
/*  17 */     this.internalAlpha = 255;
/*     */ 
/*  22 */     this.Tahoma14 = loadFont("Tahoma-14.vlw");
/*     */   }
/*     */ 
/*     */   public c7fig5()
/*     */   {
/*   1 */     jdMethod_this();
/*     */   }
/*     */ 
/*     */   class Button
/*     */   {
/*     */     public boolean value;
/*     */     public String msg;
/*     */     public int x;
/*     */     public int y;
/*     */     public int w;
/*     */     public int h;
/*     */ 
/*     */     public void draw()
/*     */     {
/* 304 */       c7fig5.this.pushMatrix();
/* 305 */       c7fig5.this.translate(this.x, this.y);
/* 306 */       if (this.value) {
/* 307 */         c7fig5.this.fill(250.0F, 130.0F, 20.0F);
/* 308 */         c7fig5.this.stroke(0);
/* 309 */         c7fig5.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/*     */       else
/*     */       {
/* 317 */         c7fig5.this.fill(255.0F, 255.0F, 255.0F);
/* 318 */         c7fig5.this.stroke(0);
/* 319 */         c7fig5.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/* 321 */       c7fig5.this.rect(0.0F, 0.0F, this.w, this.h);
/* 322 */       c7fig5.this.noStroke();
/* 323 */       c7fig5.this.fill(255.0F, 255.0F, 255.0F);
/* 324 */       c7fig5.this.rect(2.0F, 2.0F, this.w - 4, this.h - 4);
/*     */ 
/* 326 */       c7fig5.this.fill(0);
/* 327 */       c7fig5.this.textFont(c7fig5.this.Tahoma14, 14.0F);
/* 328 */       c7fig5.this.text(this.msg, 5, this.h - 5);
/*     */ 
/* 330 */       c7fig5.this.popMatrix();
/*     */     }
/*     */ 
/*     */     public void processMouseDown() {
/* 334 */       int i = c7fig5.this.mouseX - this.x;
/* 335 */       int j = c7fig5.this.mouseY - this.y;
/*     */ 
/* 337 */       if ((i < 0) || (i > this.w) || 
/* 338 */         (j < 0) || (j > this.h)) return;
/* 339 */       this.value = true;
/*     */     }
/*     */ 
/*     */     public void processMouseUp()
/*     */     {
/* 345 */       if (this.value) {
/* 346 */         this.value = false;
/*     */ 
/* 348 */         if (this.msg == "Decrease grid size") {
/* 349 */           c7fig5.this.dx *= 0.8F;
/* 350 */           c7fig5.this.dy *= 0.8F;
/*     */         }
/* 352 */         else if (this.msg == "Increase grid size") {
/* 353 */           c7fig5.this.dx *= 1.25F;
/* 354 */           c7fig5.this.dy *= 1.25F;
/*     */         }
/* 356 */         if (c7fig5.this.dx < 0.013F) {
/* 357 */           c7fig5.this.fadingOut = true;
/*     */         }
/*     */         else
/* 360 */           c7fig5.this.fadingOut = false;
/*     */       }
/*     */     }
/*     */ 
/*     */     private final void jdMethod_this() {
/* 365 */       this.value = false;
/*     */     }
/*     */ 
/*     */     public Button(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString)
/*     */     {
/* 294 */       jdMethod_this();
/* 295 */       this.x = paramInt1;
/* 296 */       this.y = paramInt2;
/* 297 */       this.w = paramInt3;
/* 298 */       paramInt4 = 20;
/* 299 */       this.h = paramInt4;
/* 300 */       this.msg = paramString;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/mfeyereisen/applets-final/classes/
 * Qualified Name:     c7fig5
 * JD-Core Version:    0.5.3
 */