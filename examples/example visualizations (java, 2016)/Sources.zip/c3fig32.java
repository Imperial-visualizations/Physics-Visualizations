/*     */ import processing.core.PApplet;
/*     */ import processing.core.PFont;
/*     */ 
/*     */ public class c3fig32 extends PApplet
/*     */ {
/*     */   float rotZ;
/*     */   float rotX;
/*     */   PFont font;
/*     */   int gridRes;
/*     */   boolean dragL;
/*     */   boolean dragR;
/*     */   int downL;
/*     */   int downRX;
/*     */   int downRY;
/*     */   boolean running;
/*     */   int geom;
/*     */   public float dPhi;
/*     */   public float minPhi;
/*     */   public float maxPhi;
/*     */   public float minTheta;
/*     */   public float maxTheta;
/*     */   public float dTheta;
/*     */   float minR;
/*     */   float maxR;
/*     */   float dR;
/*     */   float minZ;
/*     */   float maxZ;
/*     */   float dZ;
/*     */   PFont Tahoma14;
/*     */   c3fig32.RadioGroup rgGeometry;
/*     */   c3fig32.TwoSlider tsLimits;
/*     */ 
/*     */   public void setup()
/*     */   {
/*  62 */     size(640, 480, "processing.core.PGraphics3");
/*  63 */     String[] arrayOfString = { "Hemisphere", "Cone", "Torus" };
/*     */ 
/*  66 */     this.rgGeometry = new c3fig32.RadioGroup(520, 30, arrayOfString, 0);
/*  67 */     this.tsLimits = new c3fig32.TwoSlider(40, this.height - 40, this.width - 80, 14, 0, 36, 0, 22);
/*     */ 
/*  69 */     reset();
/*     */   }
/*     */ 
/*     */   public void draw()
/*     */   {
/*  74 */     this.geom = this.rgGeometry._selected;
/*  75 */     background(255);
/*  76 */     this.minPhi = (this.tsLimits._pos1 * this.dPhi);
/*  77 */     this.maxPhi = (this.tsLimits._pos2 * this.dPhi);
/*     */ 
/*  79 */     updateRotation();
/*     */ 
/*  81 */     pushMatrix();
/*     */ 
/*  83 */     translate(this.width / 2, this.height / 2, 0.0F);
/*     */ 
/*  94 */     pushMatrix();
/*  95 */     scale(0.95F, 0.95F, 0.95F);
/*     */ 
/*  97 */     rotateX(this.rotX);
/*  98 */     rotateZ(this.rotZ);
/*     */ 
/* 100 */     scale(27.0F, -27.0F, 27.0F);
/*     */ 
/* 102 */     drawAxes();
/*     */ 
/* 104 */     if (this.geom == 0)
/* 105 */       drawHemiSphere();
/* 106 */     else if (this.geom == 1)
/* 107 */       drawCone();
/* 108 */     else if (this.geom == 2) {
/* 109 */       drawTorus();
/*     */     }
/*     */ 
/* 112 */     popMatrix();
/*     */ 
/* 114 */     popMatrix();
/*     */ 
/* 116 */     textFont(this.Tahoma14, 14.0F);
/* 117 */     fill(0);
/* 118 */     stroke(0);
/* 119 */     text("Select Geometry:", 520.0F, 20.0F);
/* 120 */     line(520.0F, 25.0F, 620.0F, 25.0F);
/*     */ 
/* 122 */     this.rgGeometry.draw();
/* 123 */     this.tsLimits.draw();
/*     */   }
/*     */ 
/*     */   public void mousePressed() {
/* 127 */     if (this.mouseButton == 37)
/*     */     {
/* 130 */       this.rgGeometry.processMouseDown();
/* 131 */       this.tsLimits.processMouseDown();
/*     */     }
/* 133 */     else if (this.mouseButton == 39) {
/* 134 */       this.dragR = true;
/* 135 */       this.downRX = this.mouseX;
/* 136 */       this.downRY = this.mouseY;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void mouseReleased() {
/* 141 */     if (this.mouseButton == 37) {
/* 142 */       this.dragL = false;
/* 143 */       this.tsLimits.processMouseUp();
/*     */     }
/* 145 */     else if (this.mouseButton == 39) {
/* 146 */       this.dragR = false;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void keyPressed() {
/* 151 */     if (this.key == 'r') {
/* 152 */       reset();
/*     */     }
/* 154 */     else if (this.key == 'x') {
/* 155 */       this.rotZ = -1.570796F;
/* 156 */       this.rotX = -1.570796F;
/*     */     }
/* 158 */     else if (this.key == 'y') {
/* 159 */       this.rotZ = 3.141593F;
/* 160 */       this.rotX = -1.570796F;
/*     */     }
/* 162 */     else if (this.key == 'z') {
/* 163 */       this.rotZ = 0.0F;
/* 164 */       this.rotX = 0.0F;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updateRotation() {
/* 169 */     if (this.dragR) {
/* 170 */       this.rotZ -= 6.283186F * (this.mouseX - this.downRX) / this.width;
/* 171 */       this.rotX -= 3.141593F * (this.mouseY - this.downRY) / this.height;
/*     */ 
/* 173 */       if (this.rotZ > 6.283186F) {
/* 174 */         this.rotZ -= 6.283186F;
/*     */       }
/* 176 */       else if (this.rotZ < 6.283186F) {
/* 177 */         this.rotZ += 6.283186F;
/*     */       }
/*     */ 
/* 180 */       if (this.rotX > 3.141593F) {
/* 181 */         this.rotX = 3.141593F;
/*     */       }
/* 183 */       else if (this.rotX < 0.0F) {
/* 184 */         this.rotX = 0.0F;
/*     */       }
/*     */ 
/* 187 */       this.downRX = this.mouseX;
/* 188 */       this.downRY = this.mouseY;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void drawAxes() {
/* 193 */     strokeWeight(2.0F);
/* 194 */     stroke(200.0F, 20.0F, 20.0F, 200.0F);
/* 195 */     line(0.0F, 0.0F, 0.0F, 12.0F, 0.0F, 0.0F);
/* 196 */     stroke(20.0F, 200.0F, 20.0F, 200.0F);
/* 197 */     line(0.0F, 0.0F, 0.0F, 0.0F, 12.0F, 0.0F);
/* 198 */     stroke(20.0F, 20.0F, 200.0F, 200.0F);
/* 199 */     line(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 12.0F);
/* 200 */     strokeWeight(1.0F);
/*     */ 
/* 202 */     stroke(0.0F, 0.0F, 0.0F, 50.0F);
/*     */ 
/* 204 */     for (int i = -10 * this.gridRes; i <= 10 * this.gridRes; ++i)
/* 205 */       if (i != 0) {
/* 206 */         if (i % this.gridRes != 0) {
/* 207 */           line(i / this.gridRes, -10.0F, 0.0F, i / this.gridRes, 10.0F, 0.0F);
/* 208 */           line(-10.0F, i / this.gridRes, 0.0F, 10.0F, i / this.gridRes, 0.0F);
/*     */         }
/*     */         else
/*     */         {
/* 212 */           stroke(0.0F, 0.0F, 0.0F, 100.0F);
/* 213 */           line(i / this.gridRes, -10.0F, 0.0F, i / this.gridRes, 10.0F, 0.0F);
/* 214 */           line(-10.0F, i / this.gridRes, 0.0F, 10.0F, i / this.gridRes, 0.0F);
/* 215 */           stroke(0.0F, 0.0F, 0.0F, 50.0F);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 220 */         stroke(0.0F, 0.0F, 0.0F, 100.0F);
/* 221 */         line(i / this.gridRes, -10.0F, 0.0F, i / this.gridRes, 0.0F, 0.0F);
/* 222 */         line(-10.0F, i / this.gridRes, 0.0F, 0.0F, i / this.gridRes, 0.0F);
/* 223 */         stroke(0.0F, 0.0F, 0.0F, 50.0F);
/*     */       }
/*     */   }
/*     */ 
/*     */   public void reset()
/*     */   {
/* 230 */     this.rotZ = 0.0F;
/* 231 */     this.rotX = 0.0F;
/* 232 */     this.rgGeometry._selected = 0;
/* 233 */     this.tsLimits._pos1 = 0;
/* 234 */     this.tsLimits._pos2 = 22;
/*     */   }
/*     */ 
/*     */   public void drawHemiSphere() {
/* 238 */     stroke(0.0F, 0.0F, 0.0F, 50.0F);
/*     */ 
/* 240 */     fill(0.0F, 0.0F, 0.0F, 50.0F);
/*     */     float f2;
/*     */     float[] arrayOfFloat1;
/*     */     float[] arrayOfFloat2;
/*     */     float[] arrayOfFloat3;
/*     */     float[] arrayOfFloat4;
/* 242 */     for (float f1 = this.minPhi; f1 <= this.maxPhi - this.dPhi; f1 += this.dPhi) {
/* 243 */       for (f2 = this.minTheta; f2 <= this.maxTheta - this.dTheta; f2 += this.dTheta) {
/* 244 */         beginShape(128);
/* 245 */         arrayOfFloat1 = getCartesianS(this.maxR, f1, f2);
/* 246 */         arrayOfFloat2 = getCartesianS(this.maxR, f1, f2 + this.dTheta);
/* 247 */         arrayOfFloat3 = getCartesianS(this.maxR, f1 + this.dPhi, f2 + this.dTheta);
/* 248 */         arrayOfFloat4 = getCartesianS(this.maxR, f1 + this.dPhi, f2);
/*     */ 
/* 250 */         vertex(arrayOfFloat1[0], arrayOfFloat1[1], arrayOfFloat1[2]);
/* 251 */         vertex(arrayOfFloat2[0], arrayOfFloat2[1], arrayOfFloat2[2]);
/* 252 */         vertex(arrayOfFloat3[0], arrayOfFloat3[1], arrayOfFloat3[2]);
/* 253 */         vertex(arrayOfFloat4[0], arrayOfFloat4[1], arrayOfFloat4[2]);
/* 254 */         endShape();
/*     */       }
/*     */     }
/*     */ 
/* 258 */     if ((this.minPhi == 0.0F) && (this.maxPhi == 6.283186F))
/*     */       return;
/* 260 */     for (f1 = this.minR; f1 <= this.maxR - this.dR; f1 += this.dR)
/*     */     {
/* 262 */       for (f2 = this.minTheta; f2 <= this.maxTheta - this.dTheta; f2 += this.dTheta) {
/* 263 */         arrayOfFloat1 = getCartesianS(f1, this.minPhi, f2);
/* 264 */         arrayOfFloat2 = getCartesianS(f1, this.minPhi, f2 + this.dTheta);
/* 265 */         arrayOfFloat3 = getCartesianS(f1 + this.dR, this.minPhi, f2 + this.dTheta);
/* 266 */         arrayOfFloat4 = getCartesianS(f1 + this.dR, this.minPhi, f2);
/*     */ 
/* 268 */         beginShape(128);
/* 269 */         vertex(arrayOfFloat1[0], arrayOfFloat1[1], arrayOfFloat1[2]);
/* 270 */         vertex(arrayOfFloat2[0], arrayOfFloat2[1], arrayOfFloat2[2]);
/* 271 */         vertex(arrayOfFloat3[0], arrayOfFloat3[1], arrayOfFloat3[2]);
/* 272 */         vertex(arrayOfFloat4[0], arrayOfFloat4[1], arrayOfFloat4[2]);
/* 273 */         endShape();
/*     */ 
/* 275 */         arrayOfFloat1 = getCartesianS(f1, this.maxPhi, f2);
/* 276 */         arrayOfFloat2 = getCartesianS(f1, this.maxPhi, f2 + this.dTheta);
/* 277 */         arrayOfFloat3 = getCartesianS(f1 + this.dR, this.maxPhi, f2 + this.dTheta);
/* 278 */         arrayOfFloat4 = getCartesianS(f1 + this.dR, this.maxPhi, f2);
/*     */ 
/* 280 */         beginShape(128);
/* 281 */         vertex(arrayOfFloat1[0], arrayOfFloat1[1], arrayOfFloat1[2]);
/* 282 */         vertex(arrayOfFloat2[0], arrayOfFloat2[1], arrayOfFloat2[2]);
/* 283 */         vertex(arrayOfFloat3[0], arrayOfFloat3[1], arrayOfFloat3[2]);
/* 284 */         vertex(arrayOfFloat4[0], arrayOfFloat4[1], arrayOfFloat4[2]);
/* 285 */         endShape();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void drawCone()
/*     */   {
/* 292 */     stroke(0.0F, 0.0F, 0.0F, 50.0F);
/*     */ 
/* 294 */     fill(0.0F, 0.0F, 0.0F, 50.0F);
/*     */     float f2;
/*     */     float[] arrayOfFloat1;
/*     */     float[] arrayOfFloat2;
/*     */     float[] arrayOfFloat3;
/*     */     float[] arrayOfFloat4;
/* 296 */     for (float f1 = this.minPhi; f1 <= this.maxPhi - this.dPhi; f1 += this.dPhi) {
/* 297 */       for (f2 = this.minZ; f2 <= this.maxZ - this.dZ; f2 += this.dZ) {
/* 298 */         arrayOfFloat1 = getCartesianC(0.5F * f2, f1, 6.0F - f2);
/* 299 */         arrayOfFloat2 = getCartesianC(0.5F * (f2 + this.dZ), f1, 6.0F - (f2 + this.dZ));
/* 300 */         arrayOfFloat3 = getCartesianC(0.5F * (f2 + this.dZ), f1 + this.dPhi, 6.0F - (f2 + this.dZ));
/* 301 */         arrayOfFloat4 = getCartesianC(0.5F * f2, f1 + this.dPhi, 6.0F - f2);
/*     */ 
/* 303 */         beginShape(128);
/* 304 */         vertex(arrayOfFloat1[0], arrayOfFloat1[1], arrayOfFloat1[2]);
/* 305 */         vertex(arrayOfFloat2[0], arrayOfFloat2[1], arrayOfFloat2[2]);
/* 306 */         vertex(arrayOfFloat3[0], arrayOfFloat3[1], arrayOfFloat3[2]);
/* 307 */         vertex(arrayOfFloat4[0], arrayOfFloat4[1], arrayOfFloat4[2]);
/* 308 */         endShape();
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 313 */     if ((this.minPhi == 0.0F) && (this.maxPhi == 6.283186F))
/*     */       return;
/* 315 */     for (f1 = this.minZ; f1 <= this.maxZ - this.dZ; f1 += this.dZ) {
/* 316 */       f2 = this.minR;
/* 317 */       while ((f2 <= 0.5F * (6.0F - f1) - this.dR) && (f2 <= 0.5F * (6.0F - (f1 + this.dZ)) - this.dR)) {
/* 318 */         arrayOfFloat1 = getCartesianC(f2, this.minPhi, f1);
/* 319 */         arrayOfFloat2 = getCartesianC(f2, this.minPhi, f1 + this.dZ);
/* 320 */         arrayOfFloat3 = getCartesianC(f2 + this.dR, this.minPhi, f1 + this.dZ);
/* 321 */         arrayOfFloat4 = getCartesianC(f2 + this.dR, this.minPhi, f1);
/*     */ 
/* 323 */         beginShape(128);
/* 324 */         vertex(arrayOfFloat1[0], arrayOfFloat1[1], arrayOfFloat1[2]);
/* 325 */         vertex(arrayOfFloat2[0], arrayOfFloat2[1], arrayOfFloat2[2]);
/* 326 */         vertex(arrayOfFloat3[0], arrayOfFloat3[1], arrayOfFloat3[2]);
/* 327 */         vertex(arrayOfFloat4[0], arrayOfFloat4[1], arrayOfFloat4[2]);
/* 328 */         endShape();
/*     */ 
/* 330 */         arrayOfFloat1 = getCartesianC(f2, this.maxPhi, f1);
/* 331 */         arrayOfFloat2 = getCartesianC(f2, this.maxPhi, f1 + this.dZ);
/* 332 */         arrayOfFloat3 = getCartesianC(f2 + this.dR, this.maxPhi, f1 + this.dZ);
/* 333 */         arrayOfFloat4 = getCartesianC(f2 + this.dR, this.maxPhi, f1);
/*     */ 
/* 335 */         beginShape(128);
/* 336 */         vertex(arrayOfFloat1[0], arrayOfFloat1[1], arrayOfFloat1[2]);
/* 337 */         vertex(arrayOfFloat2[0], arrayOfFloat2[1], arrayOfFloat2[2]);
/* 338 */         vertex(arrayOfFloat3[0], arrayOfFloat3[1], arrayOfFloat3[2]);
/* 339 */         vertex(arrayOfFloat4[0], arrayOfFloat4[1], arrayOfFloat4[2]);
/* 340 */         endShape();
/*     */ 
/* 342 */         f2 += this.dR;
/*     */       }
/*     */ 
/* 345 */       arrayOfFloat1 = getCartesianC(f2, this.minPhi, f1);
/* 346 */       arrayOfFloat2 = getCartesianC(f2, this.minPhi, f1 + this.dZ);
/* 347 */       arrayOfFloat3 = getCartesianC(0.5F * (6.0F - (f1 + this.dZ)), this.minPhi, f1 + this.dZ);
/* 348 */       arrayOfFloat4 = getCartesianC(0.5F * (6.0F - f1), this.minPhi, f1);
/*     */ 
/* 350 */       beginShape(128);
/* 351 */       vertex(arrayOfFloat1[0], arrayOfFloat1[1], arrayOfFloat1[2]);
/* 352 */       vertex(arrayOfFloat2[0], arrayOfFloat2[1], arrayOfFloat2[2]);
/* 353 */       vertex(arrayOfFloat3[0], arrayOfFloat3[1], arrayOfFloat3[2]);
/* 354 */       vertex(arrayOfFloat4[0], arrayOfFloat4[1], arrayOfFloat4[2]);
/* 355 */       endShape();
/*     */ 
/* 357 */       arrayOfFloat1 = getCartesianC(f2, this.maxPhi, f1);
/* 358 */       arrayOfFloat2 = getCartesianC(f2, this.maxPhi, f1 + this.dZ);
/* 359 */       arrayOfFloat3 = getCartesianC(0.5F * (6.0F - (f1 + this.dZ)), this.maxPhi, f1 + this.dZ);
/* 360 */       arrayOfFloat4 = getCartesianC(0.5F * (6.0F - f1), this.maxPhi, f1);
/*     */ 
/* 362 */       beginShape(128);
/* 363 */       vertex(arrayOfFloat1[0], arrayOfFloat1[1], arrayOfFloat1[2]);
/* 364 */       vertex(arrayOfFloat2[0], arrayOfFloat2[1], arrayOfFloat2[2]);
/* 365 */       vertex(arrayOfFloat3[0], arrayOfFloat3[1], arrayOfFloat3[2]);
/* 366 */       vertex(arrayOfFloat4[0], arrayOfFloat4[1], arrayOfFloat4[2]);
/* 367 */       endShape();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void drawTorus()
/*     */   {
/* 373 */     float f1 = 3;
/* 374 */     float f2 = 1.0F;
/*     */ 
/* 376 */     float f3 = 0.5235988F;
/* 377 */     float f4 = this.dPhi;
/*     */ 
/* 385 */     fill(0.0F, 0.0F, 0.0F, 50.0F);
/* 386 */     stroke(0.0F, 0.0F, 0.0F, 50.0F);
/* 387 */     pushMatrix();
/*     */ 
/* 390 */     rotateX(3.141593F);
/*     */ 
/* 392 */     for (float f6 = this.minPhi; f6 <= this.maxPhi - this.dPhi; f6 += this.dPhi) {
/* 393 */       beginShape(129);
/* 394 */       for (float f7 = 0.0F; f7 <= 6.283186F; f7 += f3) {
/* 395 */         float f5 = f1 + f2 * cos(f7);
/*     */ 
/* 397 */         vertex(cos(f6 + this.dPhi) * f5, -sin(f6 + this.dPhi) * f5, f2 * sin(f7));
/* 398 */         vertex(cos(f6) * f5, -sin(f6) * f5, f2 * sin(f7));
/*     */       }
/* 400 */       endShape();
/*     */     }
/*     */ 
/* 404 */     if ((this.minPhi != 0.0F) || (this.maxPhi != 6.283186F)) {
/* 405 */       pushMatrix();
/* 406 */       rotateZ(-this.minPhi);
/* 407 */       translate(f1, 0.0F, 0.0F);
/* 408 */       beginShape(66);
/* 409 */       vertex(0.0F, 0.0F, 0.0F);
/* 410 */       for (f6 = 0.0F; f6 <= 6.283186F; f6 += f3) {
/* 411 */         vertex(f2 * cos(f6), 0.0F, f2 * sin(f6));
/*     */       }
/* 413 */       endShape();
/* 414 */       popMatrix();
/*     */ 
/* 416 */       pushMatrix();
/* 417 */       rotateZ(-this.maxPhi);
/* 418 */       translate(f1, 0.0F, 0.0F);
/* 419 */       beginShape(66);
/* 420 */       vertex(0.0F, 0.0F, 0.0F);
/* 421 */       for (f6 = 0.0F; f6 <= 6.283186F; f6 += f3) {
/* 422 */         vertex(f2 * cos(f6), 0.0F, f2 * sin(f6));
/*     */       }
/* 424 */       endShape();
/* 425 */       popMatrix();
/*     */     }
/* 427 */     popMatrix();
/*     */   }
/*     */ 
/*     */   public float[] getCartesianS(float paramFloat1, float paramFloat2, float paramFloat3)
/*     */   {
/* 432 */     float[] arrayOfFloat = new float[3];
/* 433 */     arrayOfFloat[0] = (paramFloat1 * cos(paramFloat2) * sin(paramFloat3));
/* 434 */     arrayOfFloat[1] = (paramFloat1 * sin(paramFloat2) * sin(paramFloat3));
/* 435 */     arrayOfFloat[2] = (paramFloat1 * cos(paramFloat3));
/*     */ 
/* 437 */     return arrayOfFloat;
/*     */   }
/*     */ 
/*     */   public float[] getCartesianC(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 441 */     float[] arrayOfFloat = new float[3];
/* 442 */     arrayOfFloat[0] = (paramFloat1 * cos(paramFloat2));
/* 443 */     arrayOfFloat[1] = (paramFloat1 * sin(paramFloat2));
/* 444 */     arrayOfFloat[2] = paramFloat3;
/*     */ 
/* 446 */     return arrayOfFloat;
/*     */   }
/*     */ 
/*     */   private final void jdMethod_this()
/*     */   {
/*  12 */     this.rotZ = 0.0F;
/*  13 */     this.rotX = 0.0F;
/*     */ 
/*  16 */     this.gridRes = 5;
/*     */ 
/*  18 */     this.dragL = false;
/*  19 */     this.dragR = false;
/*  20 */     this.downL = 0;
/*  21 */     this.downRX = 0;
/*  22 */     this.downRY = 0;
/*     */ 
/*  24 */     this.running = false;
/*     */ 
/*  30 */     this.geom = 0;
/*     */ 
/*  32 */     this.dPhi = 0.1745329F;
/*  33 */     this.minPhi = 0.0F;
/*     */ 
/*  35 */     this.maxPhi = (22.0F * this.dPhi);
/*     */ 
/*  40 */     this.minTheta = 0.0F;
/*  41 */     this.maxTheta = 1.570796F;
/*     */ 
/*  43 */     this.dTheta = 0.08726647F;
/*     */ 
/*  46 */     this.minR = 0.0F;
/*  47 */     this.maxR = 3;
/*  48 */     this.dR = ((this.maxR - this.minR) / this.maxR);
/*     */ 
/*  50 */     this.minZ = 0.0F;
/*  51 */     this.maxZ = 6.0F;
/*  52 */     this.dZ = ((this.maxZ - this.minZ) / 6.0F);
/*     */ 
/*  54 */     this.Tahoma14 = loadFont("Tahoma-14.vlw");
/*     */   }
/*     */ 
/*     */   public c3fig32()
/*     */   {
/*   1 */     jdMethod_this();
/*     */   }
/*     */ 
/*     */   class RadioGroup
/*     */   {
/*     */     private int _x;
/*     */     private int _y;
/*     */     private int _w;
/*     */     private String[] _options;
/*     */     public int _selected;
/*     */ 
/*     */     public void draw()
/*     */     {
/* 460 */       c3fig32.this.textFont(c3fig32.this.Tahoma14, 14.0F);
/* 461 */       c3fig32.this.pushMatrix();
/* 462 */       c3fig32.this.translate(this._x, this._y);
/* 463 */       for (int i = 0; i < this._options.length; ++i) {
/* 464 */         c3fig32.this.pushMatrix();
/* 465 */         c3fig32.this.translate(6.0F, 6 + i * 18);
/* 466 */         c3fig32.this.ellipseMode(3);
/* 467 */         c3fig32.this.fill(255.0F, 255.0F, 255.0F);
/* 468 */         c3fig32.this.stroke(0.0F, 0.0F, 0.0F);
/* 469 */         c3fig32.this.ellipse(0.0F, 0.0F, 12.0F, 12.0F);
/* 470 */         if (i == this._selected) {
/* 471 */           c3fig32.this.fill(250.0F, 130.0F, 20.0F);
/* 472 */           c3fig32.this.noStroke();
/* 473 */           c3fig32.this.ellipse(0.0F, 0.0F, 8.0F, 8.0F);
/*     */         }
/*     */         else
/*     */         {
/* 477 */           c3fig32.this.fill(0.0F, 0.0F, 0.0F);
/*     */         }
/* 479 */         c3fig32.this.pushMatrix();
/* 480 */         c3fig32.this.translate(10.0F, 6.0F);
/*     */ 
/* 482 */         c3fig32.this.text(this._options[i], 0.0F, -2.0F);
/* 483 */         c3fig32.this.popMatrix();
/* 484 */         c3fig32.this.popMatrix();
/*     */       }
/* 486 */       c3fig32.this.popMatrix();
/*     */     }
/*     */ 
/*     */     public void processMouseDown() {
/* 490 */       int i = c3fig32.this.mouseX - this._x;
/* 491 */       int j = c3fig32.this.mouseY - this._y;
/*     */ 
/* 493 */       if ((i >= 0) && (i <= this._w)) {
/* 494 */         int k = 0;
/* 495 */         if (j <= this._options.length * 18) {
/* 496 */           while (j > 18) {
/* 497 */             ++k;
/* 498 */             j -= 18;
/*     */           }
/* 500 */           if ((j >= 0) && (j <= 12))
/* 501 */             this._selected = k;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     public RadioGroup(int paramInt1, int paramInt2, String[] paramArrayOfString, int paramInt3)
/*     */     {
/* 452 */       this._x = paramInt1;
/* 453 */       this._y = paramInt2;
/* 454 */       this._w = 60;
/* 455 */       this._options = paramArrayOfString;
/* 456 */       this._selected = paramInt3;
/*     */     }
/*     */   }
/*     */ 
/*     */   class TwoSlider
/*     */   {
/*     */     private int _x;
/*     */     private int _y;
/*     */     private int _w;
/*     */     private int _h;
/*     */     private int _minValue;
/*     */     private int _maxValue;
/*     */     private int _pos1;
/*     */     private int _pos2;
/*     */     private float _frac;
/*     */     private int _dragging;
/*     */ 
/*     */     public void draw()
/*     */     {
/* 527 */       if (this._dragging != 0) {
/* 528 */         int i = c3fig32.this.mouseX - this._x;
/* 529 */         if (i < 0) {
/* 530 */           i = 0;
/*     */         }
/* 532 */         else if (i > this._w) {
/* 533 */           i = this._w;
/*     */         }
/* 535 */         this._frac = (i / this._w);
/* 536 */         if (this._dragging == -1) {
/* 537 */           if ((int)(i / this._w * (this._maxValue - this._minValue)) < this._pos2) {
/* 538 */             updatePosition1((int)(i / this._w * (this._maxValue - this._minValue)));
/*     */           }
/*     */         }
/* 541 */         else if ((this._dragging == 1) && 
/* 542 */           ((int)(i / this._w * (this._maxValue - this._minValue)) > this._pos1)) {
/* 543 */           updatePosition2((int)(i / this._w * (this._maxValue - this._minValue)));
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 548 */       c3fig32.this.pushMatrix();
/* 549 */       c3fig32.this.translate(this._x, this._y);
/* 550 */       c3fig32.this.stroke(50.0F, 50.0F, 50.0F);
/* 551 */       c3fig32.this.line(0.0F, 0.0F, this._w, 0.0F);
/*     */ 
/* 553 */       c3fig32.this.fill(250.0F, 130.0F, 20.0F);
/*     */ 
/* 555 */       c3fig32.this.pushMatrix();
/* 556 */       c3fig32.this.translate(this._w * this._pos1 / (this._maxValue - this._minValue), 0.0F);
/*     */ 
/* 558 */       c3fig32.this.rectMode(3);
/* 559 */       c3fig32.this.beginShape(64);
/* 560 */       c3fig32.this.vertex(-8.0F, 0.0F);
/* 561 */       c3fig32.this.vertex(0.0F, 6.0F);
/* 562 */       c3fig32.this.vertex(0.0F, -6.0F);
/* 563 */       c3fig32.this.endShape();
/* 564 */       c3fig32.this.popMatrix();
/*     */ 
/* 566 */       c3fig32.this.pushMatrix();
/* 567 */       c3fig32.this.translate(this._w * this._pos2 / (this._maxValue - this._minValue), 0.0F);
/*     */ 
/* 569 */       c3fig32.this.rectMode(3);
/* 570 */       c3fig32.this.beginShape(64);
/* 571 */       c3fig32.this.vertex(8.0F, 0.0F);
/* 572 */       c3fig32.this.vertex(0.0F, -6.0F);
/* 573 */       c3fig32.this.vertex(0.0F, 6.0F);
/* 574 */       c3fig32.this.endShape();
/* 575 */       c3fig32.this.popMatrix();
/*     */ 
/* 578 */       c3fig32.this.stroke(0);
/* 579 */       c3fig32.this.rectMode(1);
/* 580 */       c3fig32.this.rect(this._w * this._pos1 / (this._maxValue - this._minValue), 1.0F, this._w * this._pos2 / (this._maxValue - this._minValue), -1.0F);
/*     */ 
/* 582 */       c3fig32.this.popMatrix();
/*     */     }
/*     */ 
/*     */     public void updatePosition1(int paramInt) {
/* 586 */       this._pos1 = paramInt;
/*     */     }
/*     */ 
/*     */     public void updatePosition2(int paramInt)
/*     */     {
/* 592 */       this._pos2 = paramInt;
/*     */     }
/*     */ 
/*     */     public void processMouseDown() {
/* 596 */       int i = c3fig32.this.mouseX - this._x;
/* 597 */       int j = c3fig32.this.mouseY - this._y;
/* 598 */       if (c3fig32.mag(i - (this._w * this._pos1 / (this._maxValue - this._minValue)), j) <= this._h) {
/* 599 */         this._dragging = -1;
/*     */       }
/*     */ 
/* 602 */       if (c3fig32.mag(i - (this._w * this._pos2 / (this._maxValue - this._minValue)), j) <= this._h)
/* 603 */         this._dragging = 1;
/*     */     }
/*     */ 
/*     */     public void processMouseUp()
/*     */     {
/* 608 */       this._dragging = 0;
/*     */     }
/*     */ 
/*     */     private final void jdMethod_this()
/*     */     {
/* 621 */       this._dragging = 0;
/*     */     }
/*     */ 
/*     */     public TwoSlider(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8)
/*     */     {
/* 515 */       jdMethod_this();
/* 516 */       this._x = paramInt1;
/* 517 */       this._y = paramInt2;
/* 518 */       this._w = paramInt3;
/* 519 */       this._h = paramInt4;
/* 520 */       this._minValue = paramInt5;
/* 521 */       this._maxValue = paramInt6;
/* 522 */       updatePosition1(paramInt7);
/* 523 */       updatePosition2(paramInt8);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/mfeyereisen/applets-final/classes/
 * Qualified Name:     c3fig32
 * JD-Core Version:    0.5.3
 */