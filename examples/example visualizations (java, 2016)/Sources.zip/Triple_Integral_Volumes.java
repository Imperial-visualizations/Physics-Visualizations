/*     */ import processing.core.PApplet;
/*     */ import processing.core.PFont;
/*     */ 
/*     */ public class Triple_Integral_Volumes extends PApplet
/*     */ {
/*     */   float axes_centre_x;
/*     */   float axes_centre_y;
/*     */   float axes_centre_z;
/*     */   float axes_length;
/*     */   float offset;
/*     */   float rotate_y;
/*     */   float rotate_x;
/*     */   float rotate_speed;
/*     */   int shape;
/*     */   int max_shapes;
/*     */   float rect_size;
/*     */   float rect_pos_x;
/*     */   float rect_pos_y;
/*     */   boolean rect_limits;
/*     */   boolean mouse_over_button;
/*     */   boolean mouse_released;
/*     */   PFont font;
/*     */ 
/*     */   public void reset()
/*     */   {
/*  24 */     this.offset = 10.0F;
/*  25 */     this.rotate_y = 0.0F;
/*  26 */     this.rotate_x = 0.0F;
/*  27 */     this.shape = 0;
/*  28 */     this.rect_limits = false;
/*  29 */     this.mouse_over_button = false;
/*  30 */     this.mouse_released = true;
/*     */   }
/*     */ 
/*     */   public void setup()
/*     */   {
/*  35 */     size(640, 480, "processing.core.PGraphics3");
/*  36 */     background(255.0F, 255.0F, 255.0F);
/*  37 */     stroke(0.0F, 0.0F, 0.0F);
/*  38 */     framerate(60.0F);
/*  39 */     this.font = loadFont("Arial-Black-20.vlw");
/*  40 */     textFont(this.font, 20.0F);
/*     */   }
/*     */ 
/*     */   public boolean mouseOverRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*     */   {
/*  47 */     return ((this.mouseX >= paramFloat1) && (this.mouseX <= paramFloat1 + paramFloat3) && (this.mouseY >= paramFloat2) && (this.mouseY <= paramFloat2 + paramFloat4));
/*     */   }
/*     */ 
/*     */   public void checkMouse(float paramFloat1, float paramFloat2)
/*     */   {
/*  55 */     this.mouse_over_button = false;
/*     */ 
/*  57 */     if (mouseOverRect(this.rect_pos_x, this.rect_pos_y, this.rect_size, this.rect_size)) { this.rect_limits = true; this.mouse_over_button = true; } else { this.rect_limits = false;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void mouseReleased() {
/*  62 */     this.mouse_released = true;
/*     */   }
/*     */ 
/*     */   public void keyPressed()
/*     */   {
/*  67 */     if (this.key == 'r') reset();
/*  68 */     if (this.keyCode != 10)
/*     */       return;
/*  70 */     this.shape += 1;
/*  71 */     if (this.shape < this.max_shapes) return; this.shape = 0;
/*     */   }
/*     */ 
/*     */   public void draw()
/*     */   {
/*  77 */     background(255);
/*  78 */     checkMouse(this.mouseX, this.mouseY);
/*     */ 
/*  81 */     stroke(0);
/*  82 */     if (this.rect_limits) fill(255.0F, 255.0F, 255.0F); else fill(150.0F, 150.0F, 150.0F);
/*  83 */     rect(this.rect_pos_x, this.rect_pos_y, this.rect_size, this.rect_size);
/*  84 */     pushMatrix();
/*  85 */     translate(this.rect_pos_x, this.rect_pos_y, 0.0F);
/*  86 */     line(5, 5, 0.0F, 5, this.rect_size - 5, 0.0F);
/*  87 */     line(5, 5, 0.0F, this.rect_size - 5, this.rect_size / 2.0F, 0.0F);
/*  88 */     line(5, this.rect_size - 5, 0.0F, this.rect_size - 5, this.rect_size / 2.0F, 0.0F);
/*  89 */     popMatrix();
/*     */ 
/*  91 */     if ((this.mousePressed) && 
/*  93 */       (this.rect_limits) && (this.mouse_released))
/*     */     {
/*  95 */       this.shape += 1;
/*  96 */       if (this.shape >= this.max_shapes) this.shape = 0;
/*  97 */       this.mouse_released = false;
/*     */     }
/*     */ 
/* 102 */     stroke(0);
/* 103 */     fill(0);
/* 104 */     if (this.shape == 0)
/*     */     {
/* 106 */       text("0 < x < 1", 500.0F, 30.0F);
/* 107 */       text("   _", 500.0F, 29.0F);
/* 108 */       text("_", 562.0F, 29.0F);
/* 109 */       text("0 < y < 1", 500.0F, 60.0F);
/* 110 */       text("   _", 500.0F, 59.0F);
/* 111 */       text("_", 562.0F, 59.0F);
/* 112 */       text("0 < z < 1", 500.0F, 90.0F);
/* 113 */       text("   _", 500.0F, 89.0F);
/* 114 */       text("_", 562.0F, 89.0F);
/*     */     }
/* 116 */     else if (this.shape == 1)
/*     */     {
/* 118 */       text("0 < x < 1", 500.0F, 30.0F);
/* 119 */       text("   _", 500.0F, 29.0F);
/* 120 */       text("_", 562.0F, 29.0F);
/* 121 */       text("0 < y < 1", 500.0F, 60.0F);
/* 122 */       text("   _", 500.0F, 59.0F);
/* 123 */       text("_", 562.0F, 59.0F);
/* 124 */       text("0 < z < y", 500.0F, 90.0F);
/* 125 */       text("   _", 500.0F, 89.0F);
/* 126 */       text("_", 562.0F, 89.0F);
/*     */     }
/* 128 */     else if (this.shape == 2)
/*     */     {
/* 130 */       text("0 < x < 1", 450.0F, 30.0F);
/* 131 */       text("   _", 450.0F, 29.0F);
/* 132 */       text("_", 512.0F, 29.0F);
/* 133 */       text("0 < y < 1 - x", 450.0F, 60.0F);
/* 134 */       text("   _", 450.0F, 59.0F);
/* 135 */       text("_", 512.0F, 59.0F);
/* 136 */       text("0 < z < 1 - x - y", 450.0F, 90.0F);
/* 137 */       text("   _", 450.0F, 89.0F);
/* 138 */       text("_", 512.0F, 89.0F);
/*     */     }
/*     */ 
/* 142 */     translate(this.axes_centre_x, this.axes_centre_y, this.axes_centre_z);
/* 143 */     translate(this.axes_length / 2.0F, -this.axes_length / 2.0F, this.axes_length / 2.0F);
/* 144 */     if ((this.mousePressed) && 
/* 146 */       (this.mouseButton == 39))
/*     */     {
/* 148 */       if (this.mouseX - this.pmouseX > 0.0F) this.rotate_y += this.rotate_speed;
/* 149 */       if (this.mouseX - this.pmouseX < 0.0F) this.rotate_y -= this.rotate_speed;
/* 150 */       if (this.rotate_y >= 6.283186F) this.rotate_y = 0.0F;
/*     */ 
/* 152 */       if (this.mouseY - this.pmouseY > 0.0F) this.rotate_x -= this.rotate_speed;
/* 153 */       if (this.mouseY - this.pmouseY < 0.0F) this.rotate_x += this.rotate_speed;
/* 154 */       if (this.rotate_x >= 6.283186F) this.rotate_x = 0.0F;
/*     */     }
/*     */ 
/* 157 */     rotateX(this.rotate_x);
/* 158 */     rotateY(this.rotate_y);
/* 159 */     translate(-this.axes_length / 2.0F, this.axes_length / 2.0F, -this.axes_length / 2.0F);
/*     */ 
/* 162 */     stroke(0);
/* 163 */     fill(0);
/* 164 */     line(0.0F, 0.0F, 0.0F, this.axes_length, 0.0F, 0.0F);
/* 165 */     line(0.0F, 0.0F, 0.0F, 0.0F, -this.axes_length, 0.0F);
/* 166 */     line(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, this.axes_length);
/* 167 */     line(this.axes_length, 0.0F, 0.0F, this.axes_length, -this.axes_length, 0.0F);
/* 168 */     line(this.axes_length, -this.axes_length, 0.0F, 0.0F, -this.axes_length, 0.0F);
/* 169 */     line(0.0F, 0.0F, this.axes_length, 0.0F, -this.axes_length, this.axes_length);
/* 170 */     line(0.0F, -this.axes_length, this.axes_length, 0.0F, -this.axes_length, 0.0F);
/* 171 */     line(this.axes_length, 0.0F, 0.0F, this.axes_length, 0.0F, this.axes_length);
/* 172 */     line(this.axes_length, 0.0F, this.axes_length, this.axes_length, -this.axes_length, this.axes_length);
/* 173 */     line(this.axes_length, -this.axes_length, this.axes_length, this.axes_length, -this.axes_length, 0.0F);
/* 174 */     line(this.axes_length, -this.axes_length, this.axes_length, 0.0F, -this.axes_length, this.axes_length);
/* 175 */     line(this.axes_length, 0.0F, this.axes_length, 0.0F, 0.0F, this.axes_length);
/* 176 */     text("x", this.axes_length / 2.0F, 15.0F, this.axes_length);
/* 177 */     text("z", -15.0F, -this.axes_length / 2.0F, this.axes_length - 15.0F);
/* 178 */     text("y", -15.0F, 0.0F, this.axes_length / 2.0F);
/* 179 */     text("0", 0.0F, 17.0F, this.axes_length);
/* 180 */     text("1", this.axes_length, 17.0F, this.axes_length);
/* 181 */     text("0", -15.0F, 17.0F, this.axes_length - 15.0F);
/* 182 */     text("1", -15.0F, -this.axes_length, this.axes_length - 15.0F);
/* 183 */     text("1", -15.0F, 17.0F, 0.0F);
/*     */ 
/* 186 */     fill(0.0F, 0.0F, 0.0F, 50.0F);
/* 187 */     if (this.shape == 0)
/*     */     {
/* 189 */       beginShape(128);
/* 190 */       vertex(this.offset, -this.offset, this.offset);
/* 191 */       vertex(this.axes_length - this.offset, -this.offset, this.offset);
/* 192 */       vertex(this.axes_length - this.offset, -this.axes_length + this.offset, this.offset);
/* 193 */       vertex(this.offset, -this.axes_length + this.offset, this.offset);
/* 194 */       vertex(this.offset, -this.offset, this.axes_length - this.offset);
/* 195 */       vertex(this.axes_length - this.offset, -this.offset, this.axes_length - this.offset);
/* 196 */       vertex(this.axes_length - this.offset, -this.axes_length + this.offset, this.axes_length - this.offset);
/* 197 */       vertex(this.offset, -this.axes_length + this.offset, this.axes_length - this.offset);
/* 198 */       vertex(this.offset, -this.offset, this.offset);
/* 199 */       vertex(this.offset, -this.offset, this.axes_length - this.offset);
/* 200 */       vertex(this.offset, -this.axes_length + this.offset, this.axes_length - this.offset);
/* 201 */       vertex(this.offset, -this.axes_length + this.offset, this.offset);
/* 202 */       vertex(this.axes_length - this.offset, -this.offset, this.offset);
/* 203 */       vertex(this.axes_length - this.offset, -this.offset, this.axes_length - this.offset);
/* 204 */       vertex(this.axes_length - this.offset, -this.axes_length + this.offset, this.axes_length - this.offset);
/* 205 */       vertex(this.axes_length - this.offset, -this.axes_length + this.offset, this.offset);
/* 206 */       vertex(this.offset, -this.offset, this.offset);
/* 207 */       vertex(this.axes_length - this.offset, -this.offset, this.offset);
/* 208 */       vertex(this.axes_length - this.offset, -this.offset, this.axes_length - this.offset);
/* 209 */       vertex(this.offset, -this.offset, this.axes_length - this.offset);
/* 210 */       vertex(this.offset, -this.axes_length + this.offset, this.offset);
/* 211 */       vertex(this.axes_length - this.offset, -this.axes_length + this.offset, this.offset);
/* 212 */       vertex(this.axes_length - this.offset, -this.axes_length + this.offset, this.axes_length - this.offset);
/* 213 */       vertex(this.offset, -this.axes_length + this.offset, this.axes_length - this.offset);
/* 214 */       endShape();
/* 215 */       stroke(0);
/* 216 */       fill(0);
/*     */     }
/* 218 */     else if (this.shape == 1)
/*     */     {
/* 220 */       beginShape(128);
/* 221 */       vertex(this.offset, -this.offset, this.offset);
/* 222 */       vertex(this.axes_length - this.offset, -this.offset, this.offset);
/* 223 */       vertex(this.axes_length - this.offset, -this.offset, this.axes_length - this.offset);
/* 224 */       vertex(this.offset, -this.offset, this.axes_length - this.offset);
/* 225 */       vertex(this.offset, -this.offset, this.offset);
/* 226 */       vertex(this.axes_length - this.offset, -this.offset, this.offset);
/* 227 */       vertex(this.axes_length - this.offset, -this.axes_length + this.offset, this.offset);
/* 228 */       vertex(this.offset, -this.axes_length + this.offset, this.offset);
/* 229 */       vertex(this.offset, -this.axes_length + this.offset, this.offset);
/* 230 */       vertex(this.offset, -this.offset, this.axes_length - this.offset);
/* 231 */       vertex(this.axes_length - this.offset, -this.offset, this.axes_length - this.offset);
/* 232 */       vertex(this.axes_length - this.offset, -this.axes_length + this.offset, this.offset);
/* 233 */       endShape();
/* 234 */       beginShape(64);
/* 235 */       vertex(this.offset, -this.offset, this.offset);
/* 236 */       vertex(this.offset, -this.offset, this.axes_length - this.offset);
/* 237 */       vertex(this.offset, -this.axes_length + this.offset, this.offset);
/* 238 */       vertex(this.axes_length - this.offset, -this.offset, this.offset);
/* 239 */       vertex(this.axes_length - this.offset, -this.offset, this.axes_length - this.offset);
/* 240 */       vertex(this.axes_length - this.offset, -this.axes_length + this.offset, this.offset);
/* 241 */       endShape();
/*     */     } else {
/* 243 */       if (this.shape != 2)
/*     */         return;
/* 245 */       beginShape(64);
/* 246 */       vertex(this.offset, -this.offset, this.offset);
/* 247 */       vertex(this.offset, -this.offset, this.axes_length - this.offset);
/* 248 */       vertex(this.axes_length - this.offset, -this.offset, this.axes_length - this.offset);
/* 249 */       vertex(this.offset, -this.offset, this.offset);
/* 250 */       vertex(this.offset, -this.offset, this.axes_length - this.offset);
/* 251 */       vertex(this.offset, -this.axes_length + this.offset, this.axes_length - this.offset);
/* 252 */       vertex(this.offset, -this.offset, this.axes_length - this.offset);
/* 253 */       vertex(this.offset, -this.axes_length + this.offset, this.axes_length - this.offset);
/* 254 */       vertex(this.axes_length - this.offset, -this.offset, this.axes_length - this.offset);
/* 255 */       vertex(this.offset, -this.offset, this.offset);
/* 256 */       vertex(this.axes_length - this.offset, -this.offset, this.axes_length - this.offset);
/* 257 */       vertex(this.offset, -this.axes_length + this.offset, this.axes_length - this.offset);
/* 258 */       endShape();
/*     */     }
/*     */   }
/*     */ 
/*     */   private final void jdMethod_this()
/*     */   {
/*   4 */     this.axes_centre_x = 0.0F;
/*   5 */     this.axes_centre_y = 400.0F;
/*   6 */     this.axes_centre_z = -450.0F;
/*   7 */     this.axes_length = 365.0F;
/*   8 */     this.offset = 10.0F;
/*   9 */     this.rotate_y = 0.0F;
/*  10 */     this.rotate_x = 0.0F;
/*  11 */     this.rotate_speed = 0.05F;
/*  12 */     this.shape = 0;
/*  13 */     this.max_shapes = 3;
/*  14 */     this.rect_size = 30.0F;
/*  15 */     this.rect_pos_x = 580.0F;
/*  16 */     this.rect_pos_y = 400.0F;
/*  17 */     this.rect_limits = false;
/*  18 */     this.mouse_over_button = false;
/*  19 */     this.mouse_released = true;
/*     */   }
/*     */ 
/*     */   public Triple_Integral_Volumes()
/*     */   {
/*   1 */     jdMethod_this();
/*     */   }
/*     */ }

/* Location:           /Users/mfeyereisen/applets-final/classes/
 * Qualified Name:     Triple_Integral_Volumes
 * JD-Core Version:    0.5.3
 */