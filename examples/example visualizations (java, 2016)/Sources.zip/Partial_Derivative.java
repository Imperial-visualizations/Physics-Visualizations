/*     */ import processing.core.PApplet;
/*     */ import processing.core.PFont;
/*     */ 
/*     */ public class Partial_Derivative extends PApplet
/*     */ {
/*     */   float axes_centre_x;
/*     */   float axes_centre_y;
/*     */   float axes_centre_z;
/*     */   float x_axes_length;
/*     */   float y_axes_length;
/*     */   float z_axes_length;
/*     */   boolean rotate_cam_y;
/*     */   boolean rotate_cam_x;
/*     */   float rotate_y;
/*     */   float rotate_x;
/*     */   float rotate_speed;
/*     */   float surface_res;
/*     */   float stretchFactor;
/*     */   float transformx;
/*     */   float transformy;
/*     */   float transformz;
/*     */   float infinitesimal;
/*     */   float gradient_y_const;
/*     */   float gradient_x_const;
/*     */   float grad_x_coord;
/*     */   float grad_y_coord;
/*     */   float delta_x;
/*     */   float delta_y;
/*     */   float tangent_length;
/*     */   float speed;
/*     */   float scale_speed;
/*     */   float dotted_line_length;
/*     */   float surface_alpha_value;
/*     */   boolean draw_overlay_2d;
/*     */   boolean derivative_y_constant;
/*     */   PFont font;
/*     */   Partial_Derivative.Button btnXminus;
/*     */   Partial_Derivative.Button btnXplus;
/*     */   Partial_Derivative.Button btnYminus;
/*     */   Partial_Derivative.Button btnYplus;
/*     */   Partial_Derivative.Slider sSlider;
/*     */   Partial_Derivative.RadioGroup rgConstant;
/*     */   Partial_Derivative.ToggleButton tbCurve;
/*     */ 
/*     */   public void reset()
/*     */   {
/*  46 */     this.rotate_cam_y = false;
/*  47 */     this.rotate_cam_x = false;
/*  48 */     this.rotate_y = 0.0F;
/*  49 */     this.rotate_x = 0.0F;
/*  50 */     this.infinitesimal = 0.001F;
/*  51 */     this.gradient_y_const = 0.0F;
/*  52 */     this.gradient_x_const = 0.0F;
/*  53 */     this.grad_x_coord = (this.x_axes_length / 2.0F);
/*  54 */     this.grad_y_coord = (this.z_axes_length / 2.0F);
/*  55 */     this.delta_x = 80.0F;
/*  56 */     this.delta_y = 80.0F;
/*  57 */     this.tangent_length = 100.0F;
/*  58 */     this.surface_alpha_value = 30.0F;
/*  59 */     this.draw_overlay_2d = false;
/*  60 */     this.derivative_y_constant = true;
/*  61 */     this.sSlider.updatePosition(5);
/*  62 */     this.rgConstant._selected = 0;
/*  63 */     this.tbCurve.value = false;
/*     */   }
/*     */ 
/*     */   public void setup()
/*     */   {
/*  68 */     size(640, 480, "processing.core.PGraphics3");
/*  69 */     background(255.0F, 255.0F, 255.0F);
/*  70 */     stroke(0.0F, 0.0F, 0.0F);
/*  71 */     framerate(60.0F);
/*  72 */     this.font = loadFont("Arial-Black-20.vlw");
/*  73 */     textFont(this.font, 20.0F);
/*  74 */     String[] arrayOfString = { "y constant", "x constant" };
/*     */ 
/*  77 */     this.btnXminus = new Partial_Derivative.Button(510, 370, 30, 30, "-x");
/*  78 */     this.btnXplus = new Partial_Derivative.Button(575, 370, 30, 30, "+x");
/*  79 */     this.btnYplus = new Partial_Derivative.Button(542, 330, 30, 30, "+y");
/*  80 */     this.btnYminus = new Partial_Derivative.Button(542, 410, 30, 30, "-y");
/*  81 */     this.sSlider = new Partial_Derivative.Slider(500, 90, 100, 14, 1, 14, 5);
/*  82 */     this.rgConstant = new Partial_Derivative.RadioGroup(500, 30, arrayOfString, 0);
/*  83 */     this.tbCurve = new Partial_Derivative.ToggleButton(500, 130, 110, 20, "Draw Curve");
/*     */   }
/*     */ 
/*     */   public void keyPressed()
/*     */   {
/*  88 */     if (this.key == 'r')
/*     */     {
/*  90 */       reset();
/*     */     }
/*  92 */     if (this.keyCode == 40)
/*     */     {
/*  94 */       if (this.derivative_y_constant)
/*     */       {
/*  96 */         this.grad_y_coord += this.speed;
/*  97 */         if (this.grad_y_coord > this.y_axes_length) this.grad_y_coord = this.y_axes_length;
/*     */       }
/*     */       else
/*     */       {
/* 101 */         this.grad_x_coord -= this.speed;
/* 102 */         if (this.grad_x_coord < 0.0F) this.grad_x_coord = 0.0F;
/*     */       }
/*     */     }
/* 105 */     if (this.keyCode == 38)
/*     */     {
/* 107 */       if (this.derivative_y_constant)
/*     */       {
/* 109 */         this.grad_y_coord -= this.speed;
/* 110 */         if (this.grad_y_coord < 0.0F) this.grad_y_coord = 0.0F;
/*     */       }
/*     */       else
/*     */       {
/* 114 */         this.grad_x_coord += this.speed;
/* 115 */         if (this.grad_x_coord > this.x_axes_length) this.grad_x_coord = this.x_axes_length;
/*     */       }
/*     */     }
/* 118 */     if (this.keyCode == 39)
/*     */     {
/* 120 */       if (this.derivative_y_constant)
/*     */       {
/* 122 */         this.grad_x_coord += this.speed;
/* 123 */         if (this.grad_x_coord + this.delta_x > this.x_axes_length) this.grad_x_coord = (this.x_axes_length - this.delta_x);
/*     */       }
/*     */       else
/*     */       {
/* 127 */         this.grad_y_coord += this.speed;
/* 128 */         if (this.grad_y_coord + this.delta_y > this.y_axes_length) this.grad_y_coord = (this.y_axes_length - this.delta_y);
/*     */       }
/*     */     }
/* 131 */     if (this.keyCode == 37)
/*     */     {
/* 133 */       if (this.derivative_y_constant)
/*     */       {
/* 135 */         this.grad_x_coord -= this.speed;
/* 136 */         if (this.grad_x_coord < 0.0F) this.grad_x_coord = 0.0F;
/*     */       }
/*     */       else
/*     */       {
/* 140 */         this.grad_y_coord -= this.speed;
/* 141 */         if (this.grad_y_coord < 0.0F) this.grad_y_coord = 0.0F;
/*     */       }
/*     */     }
/* 144 */     if (this.keyCode == 16)
/*     */     {
/* 146 */       if (this.derivative_y_constant)
/*     */       {
/* 148 */         if (this.grad_x_coord + this.delta_x + this.scale_speed < this.x_axes_length) this.delta_x += this.scale_speed;
/*     */ 
/*     */       }
/* 152 */       else if (this.grad_y_coord + this.delta_y + this.scale_speed < this.y_axes_length) this.delta_y += this.scale_speed;
/*     */     }
/*     */ 
/* 155 */     if (this.keyCode == 17)
/*     */     {
/* 157 */       if (this.derivative_y_constant)
/*     */       {
/* 159 */         this.delta_x -= this.scale_speed;
/* 160 */         if (this.delta_x < 0.1F) this.delta_x = 0.1F;
/*     */       }
/*     */       else
/*     */       {
/* 164 */         this.delta_y -= this.scale_speed;
/* 165 */         if (this.delta_y < 0.1F) this.delta_y = 0.1F;
/*     */       }
/*     */     }
/* 168 */     if (this.keyCode == 10)
/*     */     {
/* 170 */       if (this.draw_overlay_2d) this.draw_overlay_2d = false; else this.draw_overlay_2d = true;
/*     */     }
/* 172 */     if (this.key != 'c')
/*     */       return;
/* 174 */     if (this.derivative_y_constant) this.derivative_y_constant = false; else this.derivative_y_constant = true;
/*     */   }
/*     */ 
/*     */   public void mousePressed()
/*     */   {
/* 180 */     if (this.mouseButton == 39)
/*     */     {
/* 182 */       this.rotate_cam_y = true;
/* 183 */       this.rotate_cam_x = true;
/*     */     }
/*     */     else
/*     */     {
/* 187 */       this.sSlider.processMouseDown();
/* 188 */       this.btnXminus.processMouseDown();
/* 189 */       this.btnXplus.processMouseDown();
/* 190 */       this.btnYplus.processMouseDown();
/* 191 */       this.btnYminus.processMouseDown();
/* 192 */       this.rgConstant.processMouseDown();
/* 193 */       this.tbCurve.processMouseDown();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void mouseReleased()
/*     */   {
/* 199 */     this.rotate_cam_y = false;
/* 200 */     this.rotate_cam_x = false;
/*     */ 
/* 202 */     if (this.mouseButton != 37)
/*     */       return;
/* 204 */     this.sSlider.processMouseUp();
/* 205 */     this.btnXminus.processMouseUp();
/* 206 */     this.btnXplus.processMouseUp();
/* 207 */     this.btnYplus.processMouseUp();
/* 208 */     this.btnYminus.processMouseUp();
/*     */   }
/*     */ 
/*     */   public float actualFunction(float paramFloat1, float paramFloat2)
/*     */   {
/* 215 */     return (-paramFloat1 * paramFloat1 * 3 * paramFloat2);
/*     */   }
/*     */ 
/*     */   public float f(float paramFloat1, float paramFloat2)
/*     */   {
/* 220 */     return (this.stretchFactor * actualFunction(paramFloat1 + this.transformx, paramFloat2 + this.transformy) + this.transformz);
/*     */   }
/*     */ 
/*     */   public float fgradConstY(float paramFloat)
/*     */   {
/* 226 */     float f = f(this.grad_x_coord, this.grad_y_coord) - (this.gradient_y_const * this.grad_x_coord);
/*     */ 
/* 228 */     return (this.gradient_y_const * paramFloat + f);
/*     */   }
/*     */ 
/*     */   public float fgradConstX(float paramFloat)
/*     */   {
/* 234 */     float f = f(this.grad_x_coord, this.grad_y_coord) - (this.gradient_x_const * this.grad_y_coord);
/*     */ 
/* 236 */     return (this.gradient_x_const * paramFloat + f);
/*     */   }
/*     */ 
/*     */   public void draw()
/*     */   {
/* 241 */     background(255.0F, 255.0F, 255.0F);
/*     */ 
/* 243 */     this.btnXminus.draw();
/* 244 */     this.btnXplus.draw();
/* 245 */     this.btnYminus.draw();
/* 246 */     this.btnYplus.draw();
/* 247 */     this.sSlider.draw();
/* 248 */     stroke(0); fill(0);
/* 249 */     if (this.derivative_y_constant) text("dx", 540.0F, 115.0F, 0.0F); else text("dy", 540.0F, 115.0F, 0.0F);
/* 250 */     this.rgConstant.draw();
/* 251 */     if (this.rgConstant._selected == 0) this.derivative_y_constant = true; else this.derivative_y_constant = false;
/* 252 */     this.tbCurve.draw();
/* 253 */     this.draw_overlay_2d = this.tbCurve.value;
/*     */ 
/* 255 */     if (this.btnYminus.value)
/*     */     {
/* 257 */       if (this.derivative_y_constant)
/*     */       {
/* 259 */         this.grad_y_coord += this.speed;
/* 260 */         if (this.grad_y_coord > this.y_axes_length) this.grad_y_coord = this.y_axes_length;
/*     */       }
/*     */       else
/*     */       {
/* 264 */         this.grad_x_coord -= this.speed;
/* 265 */         if (this.grad_x_coord < 0.0F) this.grad_x_coord = 0.0F;
/*     */       }
/*     */     }
/* 268 */     if (this.btnYplus.value)
/*     */     {
/* 270 */       if (this.derivative_y_constant)
/*     */       {
/* 272 */         this.grad_y_coord -= this.speed;
/* 273 */         if (this.grad_y_coord < 0.0F) this.grad_y_coord = 0.0F;
/*     */       }
/*     */       else
/*     */       {
/* 277 */         this.grad_x_coord += this.speed;
/* 278 */         if (this.grad_x_coord > this.x_axes_length) this.grad_x_coord = this.x_axes_length;
/*     */       }
/*     */     }
/* 281 */     if (this.btnXplus.value)
/*     */     {
/* 283 */       if (this.derivative_y_constant)
/*     */       {
/* 285 */         this.grad_x_coord += this.speed;
/* 286 */         if (this.grad_x_coord + this.delta_x > this.x_axes_length) this.grad_x_coord = (this.x_axes_length - this.delta_x);
/*     */       }
/*     */       else
/*     */       {
/* 290 */         this.grad_y_coord += this.speed;
/* 291 */         if (this.grad_y_coord + this.delta_y > this.y_axes_length) this.grad_y_coord = (this.y_axes_length - this.delta_y);
/*     */       }
/*     */     }
/* 294 */     if (this.btnXminus.value)
/*     */     {
/* 296 */       if (this.derivative_y_constant)
/*     */       {
/* 298 */         this.grad_x_coord -= this.speed;
/* 299 */         if (this.grad_x_coord < 0.0F) this.grad_x_coord = 0.0F;
/*     */       }
/*     */       else
/*     */       {
/* 303 */         this.grad_y_coord -= this.speed;
/* 304 */         if (this.grad_y_coord < 0.0F) this.grad_y_coord = 0.0F;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 309 */     if (this.draw_overlay_2d) { stroke(240); fill(240); } else { stroke(0); fill(0); }
/* 310 */     translate(this.axes_centre_x, this.axes_centre_y, this.axes_centre_z);
/* 311 */     translate(this.x_axes_length / 2.0F, -this.y_axes_length / 2.0F, this.z_axes_length / 2.0F);
/* 312 */     if (this.rotate_cam_y)
/*     */     {
/* 314 */       if (this.mouseX - this.pmouseX > 0.0F) this.rotate_y += this.rotate_speed;
/* 315 */       if (this.mouseX - this.pmouseX < 0.0F) this.rotate_y -= this.rotate_speed;
/* 316 */       if (this.rotate_y >= 6.283186F) this.rotate_y = 0.0F;
/*     */     }
/* 318 */     if (this.rotate_cam_x)
/*     */     {
/* 320 */       if (this.mouseY - this.pmouseY > 0.0F) this.rotate_x -= this.rotate_speed;
/* 321 */       if (this.mouseY - this.pmouseY < 0.0F) this.rotate_x += this.rotate_speed;
/* 322 */       if (this.rotate_x >= 6.283186F) this.rotate_x = 0.0F;
/*     */     }
/* 324 */     rotateX(this.rotate_x);
/* 325 */     rotateY(this.rotate_y);
/* 326 */     translate(-this.x_axes_length / 2.0F, this.y_axes_length / 2.0F, -this.z_axes_length / 2.0F);
/* 327 */     line(0.0F, 0.0F, 0.0F, this.x_axes_length, 0.0F, 0.0F);
/* 328 */     line(0.0F, 0.0F, 0.0F, 0.0F, -this.y_axes_length, 0.0F);
/* 329 */     line(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, this.z_axes_length);
/* 330 */     text("z", 0.0F, -this.y_axes_length - 20.0F, 0.0F);
/* 331 */     text("x", this.x_axes_length + 20.0F, 0.0F, 0.0F);
/* 332 */     text("y", 0.0F, 0.0F, this.z_axes_length + 20.0F);
/*     */ 
/* 334 */     if (this.draw_overlay_2d)
/*     */     {
/* 336 */       stroke(0);
/* 337 */       fill(0);
/* 338 */       if (this.derivative_y_constant)
/*     */       {
/* 340 */         line(0.0F, 0.0F, this.grad_y_coord, 0.0F, -this.y_axes_length, this.grad_y_coord);
/* 341 */         line(0.0F, 0.0F, this.grad_y_coord, this.x_axes_length, 0.0F, this.grad_y_coord);
/* 342 */         text("f(x,y)", 0.0F, -this.y_axes_length - 10.0F, this.grad_y_coord);
/* 343 */         text("x", this.x_axes_length + 10.0F, 0.0F, this.grad_y_coord);
/*     */       }
/*     */       else
/*     */       {
/* 347 */         line(this.grad_x_coord, 0.0F, 0.0F, this.grad_x_coord, -this.y_axes_length, 0.0F);
/* 348 */         line(this.grad_x_coord, 0.0F, 0.0F, this.grad_x_coord, 0.0F, this.x_axes_length);
/* 349 */         text("f(x,y)", this.grad_x_coord, -this.y_axes_length - 10.0F, 0.0F);
/* 350 */         text("y", this.grad_x_coord, 0.0F, this.y_axes_length + 10.0F);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 356 */     if (this.draw_overlay_2d) this.surface_alpha_value = 13.0F; else this.surface_alpha_value = 30.0F;
/* 357 */     stroke(100.0F, 100.0F, 100.0F, this.surface_alpha_value);
/* 358 */     for (float f1 = 0.0F; f1 < this.x_axes_length; f1 += this.surface_res)
/*     */     {
/* 360 */       for (float f2 = 0.0F; f2 < this.y_axes_length; f2 += this.surface_res)
/*     */       {
/* 363 */         line(f1, -f(f1, f2), f2, f1 + this.surface_res, -f(f1 + this.surface_res, f2), f2);
/* 364 */         line(f1, -f(f1, f2), f2, f1, -f(f1, f2 + this.surface_res), f2 + this.surface_res);
/* 365 */         line(f1 + this.surface_res, -f(f1 + this.surface_res, f2), f2, f1 + this.surface_res, -f(f1 + this.surface_res, f2 + this.surface_res), f2 + this.surface_res);
/* 366 */         line(f1, -f(f1, f2 + this.surface_res), f2 + this.surface_res, f1 + this.surface_res, -f(f1 + this.surface_res, f2 + this.surface_res), f2 + this.surface_res);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 373 */     if (this.draw_overlay_2d)
/*     */     {
/* 375 */       stroke(0.0F, 0.0F, 0.0F);
/* 376 */       if (this.derivative_y_constant)
/*     */       {
/* 378 */         for (f1 = 0.0F; f1 < this.x_axes_length; f1 += this.surface_res)
/*     */         {
/* 380 */           line(f1, -f(f1, this.grad_y_coord), this.grad_y_coord, f1 + this.surface_res, -f(f1 + this.surface_res, this.grad_y_coord), this.grad_y_coord);
/*     */         }
/*     */ 
/*     */       }
/*     */       else {
/* 385 */         for (f1 = 0.0F; f1 < this.y_axes_length; f1 += this.surface_res)
/*     */         {
/* 387 */           line(this.grad_x_coord, -f(this.grad_x_coord, f1), f1, this.grad_x_coord, -f(this.grad_x_coord, f1 + this.surface_res), f1 + this.surface_res);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 393 */     if (this.derivative_y_constant)
/*     */     {
/* 395 */       this.gradient_y_const = ((f(this.grad_x_coord + this.delta_x, this.grad_y_coord) - f(this.grad_x_coord, this.grad_y_coord)) / this.delta_x);
/* 396 */       stroke(0.0F, 0.0F, 255.0F);
/* 397 */       line(this.grad_x_coord, -fgradConstY(this.grad_x_coord), this.grad_y_coord, this.grad_x_coord + this.delta_x, -fgradConstY(this.grad_x_coord + this.delta_x), this.grad_y_coord);
/* 398 */       stroke(0.0F, 0.0F, 0.0F);
/* 399 */       line(this.grad_x_coord - this.tangent_length, -fgradConstY(this.grad_x_coord - this.tangent_length), this.grad_y_coord, this.grad_x_coord, -fgradConstY(this.grad_x_coord), this.grad_y_coord);
/* 400 */       line(this.grad_x_coord + this.delta_x, -fgradConstY(this.grad_x_coord + this.delta_x), this.grad_y_coord, this.grad_x_coord + this.delta_x + this.tangent_length, -fgradConstY(this.grad_x_coord + this.delta_x + this.tangent_length), this.grad_y_coord);
/* 401 */       stroke(255.0F, 0.0F, 0.0F);
/* 402 */       line(this.grad_x_coord, -fgradConstY(this.grad_x_coord), this.grad_y_coord, this.grad_x_coord + this.delta_x, -fgradConstY(this.grad_x_coord), this.grad_y_coord);
/* 403 */       stroke(0.0F, 255.0F, 0.0F);
/* 404 */       line(this.grad_x_coord + this.delta_x, -fgradConstY(this.grad_x_coord), this.grad_y_coord, this.grad_x_coord + this.delta_x, -fgradConstY(this.grad_x_coord + this.delta_x), this.grad_y_coord);
/*     */     }
/*     */     else
/*     */     {
/* 408 */       this.gradient_x_const = ((f(this.grad_x_coord, this.grad_y_coord + this.delta_y) - f(this.grad_x_coord, this.grad_y_coord)) / this.delta_y);
/* 409 */       stroke(0.0F, 0.0F, 255.0F);
/* 410 */       line(this.grad_x_coord, -fgradConstX(this.grad_y_coord), this.grad_y_coord, this.grad_x_coord, -fgradConstX(this.grad_y_coord + this.delta_y), this.grad_y_coord + this.delta_y);
/* 411 */       stroke(0.0F, 0.0F, 0.0F);
/* 412 */       line(this.grad_x_coord, -fgradConstX(this.grad_y_coord - this.tangent_length), this.grad_y_coord - this.tangent_length, this.grad_x_coord, -fgradConstX(this.grad_y_coord), this.grad_y_coord);
/* 413 */       line(this.grad_x_coord, -fgradConstX(this.grad_y_coord + this.delta_y), this.grad_y_coord + this.delta_y, this.grad_x_coord, -fgradConstX(this.grad_y_coord + this.delta_y + this.tangent_length), this.grad_y_coord + this.delta_y + this.tangent_length);
/* 414 */       stroke(255.0F, 0.0F, 0.0F);
/* 415 */       line(this.grad_x_coord, -fgradConstX(this.grad_y_coord), this.grad_y_coord, this.grad_x_coord, -fgradConstX(this.grad_y_coord), this.grad_y_coord + this.delta_y);
/* 416 */       stroke(0.0F, 255.0F, 0.0F);
/* 417 */       line(this.grad_x_coord, -fgradConstX(this.grad_y_coord), this.grad_y_coord + this.delta_y, this.grad_x_coord, -fgradConstX(this.grad_y_coord + this.delta_y), this.grad_y_coord + this.delta_y);
/*     */     }
/*     */ 
/* 422 */     stroke(100);
/* 423 */     f1 = 0.0F;
/*     */ 
/* 425 */     if (this.derivative_y_constant)
/*     */     {
/* 428 */       f1 = fgradConstY(this.grad_x_coord);
/* 429 */       while (f1 > 0.0F)
/*     */       {
/* 431 */         line(this.grad_x_coord, -f1, this.grad_y_coord, this.grad_x_coord, -(f1 - this.dotted_line_length), this.grad_y_coord);
/* 432 */         f1 -= this.dotted_line_length * 2.0F;
/*     */       }
/* 434 */       f1 = fgradConstY(this.grad_x_coord + this.delta_x);
/* 435 */       while (f1 > 0.0F)
/*     */       {
/* 437 */         line(this.grad_x_coord + this.delta_x, -f1, this.grad_y_coord, this.grad_x_coord + this.delta_x, -(f1 - this.dotted_line_length), this.grad_y_coord);
/* 438 */         f1 -= this.dotted_line_length * 2.0F;
/*     */       }
/*     */ 
/* 441 */       if (!(this.draw_overlay_2d))
/*     */       {
/* 443 */         f1 = this.grad_x_coord;
/* 444 */         while (f1 > 0.0F)
/*     */         {
/* 446 */           line(f1, 0.0F, this.grad_y_coord, f1 - this.dotted_line_length, 0.0F, this.grad_y_coord);
/* 447 */           f1 -= this.dotted_line_length * 2.0F;
/*     */         }
/* 449 */         f1 = this.grad_x_coord + this.delta_x;
/* 450 */         while (f1 > this.grad_x_coord)
/*     */         {
/* 452 */           line(f1, 0.0F, this.grad_y_coord, f1 - this.dotted_line_length, 0.0F, this.grad_y_coord);
/* 453 */           f1 -= this.dotted_line_length * 2.0F;
/*     */         }
/*     */       }
/*     */ 
/* 457 */       if (this.draw_overlay_2d) stroke(240.0F); else stroke(100.0F);
/* 458 */       f1 = this.grad_y_coord;
/* 459 */       while (f1 > 0.0F)
/*     */       {
/* 461 */         line(this.grad_x_coord, 0.0F, f1, this.grad_x_coord, 0.0F, f1 - this.dotted_line_length);
/* 462 */         line(this.grad_x_coord + this.delta_x, 0.0F, f1, this.grad_x_coord + this.delta_x, 0.0F, f1 - this.dotted_line_length);
/* 463 */         f1 -= this.dotted_line_length * 2.0F;
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 468 */       f1 = fgradConstX(this.grad_y_coord);
/* 469 */       while (f1 > 0.0F)
/*     */       {
/* 471 */         line(this.grad_x_coord, -f1, this.grad_y_coord, this.grad_x_coord, -(f1 - this.dotted_line_length), this.grad_y_coord);
/* 472 */         f1 -= this.dotted_line_length * 2.0F;
/*     */       }
/* 474 */       f1 = fgradConstX(this.grad_y_coord + this.delta_y);
/* 475 */       while (f1 > 0.0F)
/*     */       {
/* 477 */         line(this.grad_x_coord, -f1, this.grad_y_coord + this.delta_y, this.grad_x_coord, -(f1 - this.dotted_line_length), this.grad_y_coord + this.delta_y);
/* 478 */         f1 -= this.dotted_line_length * 2.0F;
/*     */       }
/*     */ 
/* 481 */       if (!(this.draw_overlay_2d))
/*     */       {
/* 483 */         f1 = this.grad_y_coord;
/* 484 */         while (f1 > 0.0F)
/*     */         {
/* 486 */           line(this.grad_x_coord, 0.0F, f1, this.grad_x_coord, 0.0F, f1 - this.dotted_line_length);
/* 487 */           f1 -= this.dotted_line_length * 2.0F;
/*     */         }
/* 489 */         f1 = this.grad_y_coord + this.delta_y;
/* 490 */         while (f1 > this.grad_y_coord)
/*     */         {
/* 492 */           line(this.grad_x_coord, 0.0F, f1, this.grad_x_coord, 0.0F, f1 - this.dotted_line_length);
/* 493 */           f1 -= this.dotted_line_length * 2.0F;
/*     */         }
/*     */       }
/*     */ 
/* 497 */       if (this.draw_overlay_2d) stroke(240.0F); else stroke(100.0F);
/* 498 */       f1 = this.grad_x_coord;
/* 499 */       while (f1 > 0.0F)
/*     */       {
/* 501 */         line(f1, 0.0F, this.grad_y_coord, f1 - this.dotted_line_length, 0.0F, this.grad_y_coord);
/* 502 */         line(f1, 0.0F, this.grad_y_coord + this.delta_y, f1 - this.dotted_line_length, 0.0F, this.grad_y_coord + this.delta_y);
/* 503 */         f1 -= this.dotted_line_length * 2.0F;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private final void jdMethod_this()
/*     */   {
/*   4 */     this.axes_centre_x = 150.0F;
/*   5 */     this.axes_centre_y = 400.0F;
/*   6 */     this.axes_centre_z = -300.0F;
/*   7 */     this.x_axes_length = 365.0F;
/*   8 */     this.y_axes_length = 365.0F;
/*   9 */     this.z_axes_length = 365.0F;
/*  10 */     this.rotate_cam_y = false;
/*  11 */     this.rotate_cam_x = false;
/*  12 */     this.rotate_y = 0.0F;
/*  13 */     this.rotate_x = 0.0F;
/*  14 */     this.rotate_speed = 0.05F;
/*  15 */     this.surface_res = 10.0F;
/*  16 */     this.stretchFactor = 7.E-06F;
/*  17 */     this.transformx = -150.0F;
/*  18 */     this.transformy = -140.0F;
/*  19 */     this.transformz = 150.0F;
/*  20 */     this.infinitesimal = 0.001F;
/*  21 */     this.gradient_y_const = 0.0F;
/*  22 */     this.gradient_x_const = 0.0F;
/*  23 */     this.grad_x_coord = (this.x_axes_length / 2.0F);
/*  24 */     this.grad_y_coord = (this.z_axes_length / 2.0F);
/*  25 */     this.delta_x = 80.0F;
/*  26 */     this.delta_y = 80.0F;
/*  27 */     this.tangent_length = 100.0F;
/*  28 */     this.speed = 10.1F;
/*  29 */     this.scale_speed = 2.0F;
/*  30 */     this.dotted_line_length = 5;
/*  31 */     this.surface_alpha_value = 30.0F;
/*  32 */     this.draw_overlay_2d = false;
/*  33 */     this.derivative_y_constant = true;
/*     */   }
/*     */ 
/*     */   public Partial_Derivative()
/*     */   {
/*   1 */     jdMethod_this();
/*     */   }
/*     */ 
/*     */   class Slider
/*     */   {
/*     */     private int _x;
/*     */     private int _y;
/*     */     private int _w;
/*     */     private int _h;
/*     */     private int _minValue;
/*     */     private int _maxValue;
/*     */     private int _pos;
/*     */     private float _frac;
/*     */     private boolean _dragging;
/*     */ 
/*     */     public void draw()
/*     */     {
/* 524 */       if (this._dragging) {
/* 525 */         int i = Partial_Derivative.this.mouseX - this._x;
/* 526 */         if (i < 0) {
/* 527 */           i = 0;
/*     */         }
/* 529 */         else if (i > this._w) {
/* 530 */           i = this._w;
/*     */         }
/* 532 */         this._frac = (i / this._w);
/* 533 */         updatePosition((int)(i / this._w * (this._maxValue - this._minValue)));
/*     */       }
/*     */ 
/* 536 */       Partial_Derivative.this.pushMatrix();
/* 537 */       Partial_Derivative.this.translate(this._x, this._y);
/* 538 */       Partial_Derivative.this.stroke(50.0F, 50.0F, 50.0F);
/* 539 */       Partial_Derivative.this.line(0.0F, 0.0F, this._w, 0.0F);
/* 540 */       Partial_Derivative.this.pushMatrix();
/* 541 */       Partial_Derivative.this.translate(this._w * this._pos / (this._maxValue - this._minValue), 0.0F);
/*     */ 
/* 543 */       Partial_Derivative.this.fill(0.0F, 0.0F, 255.0F);
/* 544 */       Partial_Derivative.this.rectMode(3);
/* 545 */       Partial_Derivative.this.rect(0.0F, 0.0F, this._h, this._h);
/* 546 */       Partial_Derivative.this.popMatrix();
/* 547 */       Partial_Derivative.this.popMatrix();
/*     */     }
/*     */ 
/*     */     public void updatePosition(int paramInt) {
/* 551 */       this._pos = paramInt;
/* 552 */       if (Partial_Derivative.this.derivative_y_constant)
/*     */       {
/* 554 */         Partial_Derivative.this.delta_x = (this._minValue + (this._maxValue - this._minValue) * paramInt);
/*     */       }
/*     */       else
/*     */       {
/* 558 */         Partial_Derivative.this.delta_y = (this._minValue + (this._maxValue - this._minValue) * paramInt);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void processMouseDown() {
/* 563 */       int i = Partial_Derivative.this.mouseX - this._x;
/* 564 */       int j = Partial_Derivative.this.mouseY - this._y;
/* 565 */       if (Partial_Derivative.mag(i - (this._w * this._pos / (this._maxValue - this._minValue)), j) <= this._h)
/* 566 */         this._dragging = true;
/*     */     }
/*     */ 
/*     */     public void processMouseUp()
/*     */     {
/* 571 */       this._dragging = false;
/*     */     }
/*     */ 
/*     */     private final void jdMethod_this()
/*     */     {
/* 583 */       this._dragging = false;
/*     */     }
/*     */ 
/*     */     public Slider(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7)
/*     */     {
/* 513 */       jdMethod_this();
/* 514 */       this._x = paramInt1;
/* 515 */       this._y = paramInt2;
/* 516 */       this._w = paramInt3;
/* 517 */       this._h = paramInt4;
/* 518 */       this._minValue = paramInt5;
/* 519 */       this._maxValue = paramInt6;
/* 520 */       updatePosition(paramInt7);
/*     */     }
/*     */   }
/*     */ 
/*     */   class RadioGroup
/*     */   {
/*     */     private int _x;
/*     */     private int _y;
/*     */     private int _w;
/*     */     private String[] _options;
/*     */     public int _selected;
/*     */ 
/*     */     public void draw()
/*     */     {
/* 727 */       Partial_Derivative.this.textSize(15.0F);
/* 728 */       Partial_Derivative.this.pushMatrix();
/* 729 */       Partial_Derivative.this.translate(this._x, this._y);
/* 730 */       for (int i = 0; i < this._options.length; ++i) {
/* 731 */         Partial_Derivative.this.pushMatrix();
/* 732 */         Partial_Derivative.this.translate(6.0F, 6 + i * 18);
/* 733 */         Partial_Derivative.this.ellipseMode(3);
/* 734 */         Partial_Derivative.this.fill(255.0F, 255.0F, 255.0F);
/* 735 */         Partial_Derivative.this.stroke(0.0F, 0.0F, 0.0F);
/* 736 */         Partial_Derivative.this.ellipse(0.0F, 0.0F, 12.0F, 12.0F);
/* 737 */         if (i == this._selected) {
/* 738 */           Partial_Derivative.this.fill(250.0F, 130.0F, 20.0F);
/* 739 */           Partial_Derivative.this.noStroke();
/* 740 */           Partial_Derivative.this.ellipse(0.0F, 0.0F, 8.0F, 8.0F);
/*     */         }
/*     */         else
/*     */         {
/* 744 */           Partial_Derivative.this.fill(0.0F, 0.0F, 0.0F);
/*     */         }
/* 746 */         Partial_Derivative.this.pushMatrix();
/* 747 */         Partial_Derivative.this.translate(10.0F, 6.0F);
/*     */ 
/* 749 */         Partial_Derivative.this.text(this._options[i], 0.0F, -2.0F);
/* 750 */         Partial_Derivative.this.popMatrix();
/* 751 */         Partial_Derivative.this.popMatrix();
/*     */       }
/* 753 */       Partial_Derivative.this.popMatrix();
/*     */     }
/*     */ 
/*     */     public void processMouseDown() {
/* 757 */       int i = Partial_Derivative.this.mouseX - this._x;
/* 758 */       int j = Partial_Derivative.this.mouseY - this._y;
/*     */ 
/* 760 */       if ((i >= 0) && (i <= this._w)) {
/* 761 */         int k = 0;
/* 762 */         if (j <= this._options.length * 18) {
/* 763 */           while (j > 18) {
/* 764 */             ++k;
/* 765 */             j -= 18;
/*     */           }
/* 767 */           if ((j >= 0) && (j <= 12))
/* 768 */             this._selected = k;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     public RadioGroup(int paramInt1, int paramInt2, String[] paramArrayOfString, int paramInt3)
/*     */     {
/* 719 */       this._x = paramInt1;
/* 720 */       this._y = paramInt2;
/* 721 */       this._w = 60;
/* 722 */       this._options = paramArrayOfString;
/* 723 */       this._selected = paramInt3;
/*     */     }
/*     */   }
/*     */ 
/*     */   class ToggleButton
/*     */   {
/*     */     public boolean value;
/*     */     public String msg;
/*     */     public int x;
/*     */     public int y;
/*     */     public int w;
/*     */     public int h;
/*     */ 
/*     */     public void draw()
/*     */     {
/* 666 */       Partial_Derivative.this.rectMode(0);
/* 667 */       Partial_Derivative.this.pushMatrix();
/* 668 */       Partial_Derivative.this.translate(this.x, this.y);
/* 669 */       if (this.value) {
/* 670 */         Partial_Derivative.this.fill(250.0F, 130.0F, 20.0F);
/* 671 */         Partial_Derivative.this.stroke(0);
/* 672 */         Partial_Derivative.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/*     */       else
/*     */       {
/* 680 */         Partial_Derivative.this.fill(255.0F, 255.0F, 255.0F);
/* 681 */         Partial_Derivative.this.stroke(0);
/* 682 */         Partial_Derivative.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/* 684 */       Partial_Derivative.this.rect(0.0F, 0.0F, this.w, this.h);
/* 685 */       Partial_Derivative.this.noStroke();
/* 686 */       Partial_Derivative.this.fill(255.0F, 255.0F, 255.0F);
/* 687 */       Partial_Derivative.this.rect(2.0F, 2.0F, this.w - 4, this.h - 4);
/*     */ 
/* 689 */       Partial_Derivative.this.fill(0);
/*     */ 
/* 691 */       Partial_Derivative.this.textSize(16.0F);
/* 692 */       Partial_Derivative.this.text(this.msg, 5, this.h - 5);
/*     */ 
/* 694 */       Partial_Derivative.this.popMatrix();
/*     */     }
/*     */ 
/*     */     public void processMouseDown() {
/* 698 */       int i = Partial_Derivative.this.mouseX - this.x;
/* 699 */       int j = Partial_Derivative.this.mouseY - this.y;
/*     */ 
/* 701 */       if ((i < 0) || (i > this.w) || 
/* 702 */         (j < 0) || (j > this.h)) return;
/* 703 */       this.value ^= true;
/*     */     }
/*     */ 
/*     */     private final void jdMethod_this()
/*     */     {
/* 708 */       this.value = false;
/*     */     }
/*     */ 
/*     */     public ToggleButton(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString)
/*     */     {
/* 657 */       jdMethod_this();
/* 658 */       this.x = paramInt1;
/* 659 */       this.y = paramInt2;
/* 660 */       this.w = paramInt3;
/* 661 */       this.h = paramInt4;
/* 662 */       this.msg = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */   class Button
/*     */   {
/*     */     public boolean value;
/*     */     public String msg;
/*     */     public int x;
/*     */     public int y;
/*     */     public int w;
/*     */     public int h;
/*     */ 
/*     */     public void draw()
/*     */     {
/* 598 */       Partial_Derivative.this.rectMode(0);
/* 599 */       Partial_Derivative.this.pushMatrix();
/* 600 */       Partial_Derivative.this.translate(this.x, this.y);
/* 601 */       if (this.value) {
/* 602 */         Partial_Derivative.this.fill(250.0F, 130.0F, 20.0F);
/* 603 */         Partial_Derivative.this.stroke(0);
/* 604 */         Partial_Derivative.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/*     */       else
/*     */       {
/* 612 */         Partial_Derivative.this.fill(255.0F, 255.0F, 255.0F);
/* 613 */         Partial_Derivative.this.stroke(0);
/* 614 */         Partial_Derivative.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/* 616 */       Partial_Derivative.this.rect(0.0F, 0.0F, this.w, this.h);
/* 617 */       Partial_Derivative.this.noStroke();
/* 618 */       Partial_Derivative.this.fill(255.0F, 255.0F, 255.0F);
/* 619 */       Partial_Derivative.this.rect(2.0F, 2.0F, this.w - 4, this.h - 4);
/*     */ 
/* 621 */       Partial_Derivative.this.fill(0);
/*     */ 
/* 623 */       Partial_Derivative.this.textSize(19.0F);
/* 624 */       Partial_Derivative.this.text(this.msg, 5, this.h - 8);
/*     */ 
/* 626 */       Partial_Derivative.this.popMatrix();
/*     */     }
/*     */ 
/*     */     public void processMouseDown() {
/* 630 */       int i = Partial_Derivative.this.mouseX - this.x;
/* 631 */       int j = Partial_Derivative.this.mouseY - this.y;
/*     */ 
/* 633 */       if ((i < 0) || (i > this.w) || 
/* 634 */         (j < 0) || (j > this.h)) return;
/* 635 */       this.value = true;
/*     */     }
/*     */ 
/*     */     public void processMouseUp()
/*     */     {
/* 641 */       if (this.value)
/* 642 */         this.value = false;
/*     */     }
/*     */ 
/*     */     private final void jdMethod_this() {
/* 646 */       this.value = false;
/*     */     }
/*     */ 
/*     */     public Button(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString)
/*     */     {
/* 589 */       jdMethod_this();
/* 590 */       this.x = paramInt1;
/* 591 */       this.y = paramInt2;
/* 592 */       this.w = paramInt3;
/* 593 */       this.h = paramInt4;
/* 594 */       this.msg = paramString;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/mfeyereisen/applets-final/classes/
 * Qualified Name:     Partial_Derivative
 * JD-Core Version:    0.5.3
 */