/*     */ import processing.core.PApplet;
/*     */ import processing.core.PFont;
/*     */ 
/*     */ public class Curl extends PApplet
/*     */ {
/*     */   float axes_centre_x;
/*     */   float axes_centre_y;
/*     */   float axes_centre_z;
/*     */   float axes_length;
/*     */   boolean rotate_cam_y;
/*     */   boolean rotate_cam_x;
/*     */   float rotate_y;
/*     */   float rotate_x;
/*     */   float rotate_speed;
/*     */   float surface_res;
/*     */   float scale_factor;
/*     */   float scale_factor1;
/*     */   float scale_factor2;
/*     */   float function_factor;
/*     */   float function_factor1;
/*     */   float function_factor2;
/*     */   float curl_arrow_scale_factor;
/*     */   float curl_scale_factor;
/*     */   float curl_scale_factor1;
/*     */   float curl_scale_factor2;
/*     */   float curl_x;
/*     */   float curl_y;
/*     */   float move_speed;
/*     */   int curl_display;
/*     */   float curl_magnitude;
/*     */   PFont font;
/*     */   PFont font2;
/*     */   Curl.Button btnXminus;
/*     */   Curl.Button btnXplus;
/*     */   Curl.Button btnYminus;
/*     */   Curl.Button btnYplus;
/*     */   Curl.RadioGroup rgVectorField;
/*     */ 
/*     */   public void reset()
/*     */   {
/*  40 */     this.rotate_cam_y = false;
/*  41 */     this.rotate_cam_x = false;
/*  42 */     this.rotate_y = 0.0F;
/*  43 */     this.rotate_x = 0.0F;
/*  44 */     this.curl_x = (this.axes_length / 2.0F);
/*  45 */     this.curl_y = (-this.axes_length / 2.0F);
/*  46 */     this.curl_display = 0;
/*  47 */     this.curl_magnitude = 0.0F;
/*  48 */     this.rgVectorField._selected = 0;
/*     */   }
/*     */ 
/*     */   public void setup()
/*     */   {
/*  53 */     size(640, 480, "processing.core.PGraphics3");
/*  54 */     framerate(60.0F);
/*  55 */     this.font = loadFont("Arial-Black-20.vlw");
/*  56 */     this.font2 = loadFont("Tahoma-20.vlw");
/*  57 */     textFont(this.font, 20.0F);
/*  58 */     String[] arrayOfString = { "V = -yi + xj", "V = -y^2i + x^2j", "V = yi -xj" };
/*     */ 
/*  61 */     this.btnXminus = new Curl.Button(510, 370, 30, 30, "-x");
/*  62 */     this.btnXplus = new Curl.Button(575, 370, 30, 30, "+x");
/*  63 */     this.btnYplus = new Curl.Button(542, 330, 30, 30, "+y");
/*  64 */     this.btnYminus = new Curl.Button(542, 410, 30, 30, "-y");
/*  65 */     this.rgVectorField = new Curl.RadioGroup(490, 10, arrayOfString, 0);
/*     */   }
/*     */ 
/*     */   public void mousePressed()
/*     */   {
/*  70 */     if (this.mouseButton == 37)
/*     */     {
/*  72 */       this.btnXminus.processMouseDown();
/*  73 */       this.btnXplus.processMouseDown();
/*  74 */       this.btnYplus.processMouseDown();
/*  75 */       this.btnYminus.processMouseDown();
/*  76 */       this.rgVectorField.processMouseDown();
/*     */     } else {
/*  78 */       if (this.mouseButton != 39)
/*     */         return;
/*  80 */       this.rotate_cam_y = true;
/*  81 */       this.rotate_cam_x = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void mouseReleased()
/*     */   {
/*  87 */     this.rotate_cam_y = false;
/*  88 */     this.rotate_cam_x = false;
/*     */ 
/*  90 */     if (this.mouseButton != 37)
/*     */       return;
/*  92 */     this.btnXminus.processMouseUp();
/*  93 */     this.btnXplus.processMouseUp();
/*  94 */     this.btnYplus.processMouseUp();
/*  95 */     this.btnYminus.processMouseUp();
/*     */   }
/*     */ 
/*     */   public void keyPressed()
/*     */   {
/* 102 */     if (this.key == 'r') reset();
/*     */ 
/* 104 */     if ((this.keyCode == 38) && 
/* 106 */       (this.curl_y - this.move_speed >= -this.axes_length)) this.curl_y -= this.move_speed;
/*     */ 
/* 108 */     if ((this.keyCode == 40) && 
/* 110 */       (this.curl_y + this.move_speed <= this.axes_length)) this.curl_y += this.move_speed;
/*     */ 
/* 112 */     if ((this.keyCode == 37) && 
/* 114 */       (this.curl_x - this.move_speed >= -this.axes_length)) this.curl_x -= this.move_speed;
/*     */ 
/* 116 */     if ((this.keyCode == 39) && 
/* 118 */       (this.curl_x + this.move_speed <= this.axes_length)) this.curl_x += this.move_speed;
/*     */ 
/* 120 */     if (this.keyCode != 10)
/*     */       return;
/* 122 */     this.curl_display += 1;
/* 123 */     if (this.curl_display > 2) this.curl_display = 0;
/*     */ 
/* 125 */     switch (this.curl_display)
/*     */     {
/*     */     case 0:
/* 128 */       this.curl_arrow_scale_factor = this.curl_scale_factor;
/* 129 */       break;
/*     */     case 1:
/* 131 */       this.curl_arrow_scale_factor = this.curl_scale_factor1;
/* 132 */       break;
/*     */     case 2:
/* 134 */       this.curl_arrow_scale_factor = this.curl_scale_factor2;
/*     */     }
/*     */   }
/*     */ 
/*     */   public float P(float paramFloat1, float paramFloat2)
/*     */   {
/* 143 */     switch (this.curl_display)
/*     */     {
/*     */     case 0:
/* 146 */       return (-this.function_factor * paramFloat2);
/*     */     case 1:
/* 148 */       return (-this.function_factor1 * paramFloat2 * paramFloat2);
/*     */     case 2:
/* 150 */       return (this.function_factor2 * paramFloat2);
/*     */     }
/*     */ 
/* 153 */     return 0.0F;
/*     */   }
/*     */ 
/*     */   public float Q(float paramFloat1, float paramFloat2)
/*     */   {
/* 158 */     switch (this.curl_display)
/*     */     {
/*     */     case 0:
/* 161 */       return (this.function_factor * paramFloat1);
/*     */     case 1:
/* 163 */       return (this.function_factor1 * paramFloat1 * paramFloat1);
/*     */     case 2:
/* 165 */       return (-this.function_factor2 * paramFloat1);
/*     */     }
/*     */ 
/* 168 */     return 0.0F;
/*     */   }
/*     */ 
/*     */   public float dPdY(float paramFloat1, float paramFloat2)
/*     */   {
/* 173 */     switch (this.curl_display)
/*     */     {
/*     */     case 0:
/* 176 */       return (-this.function_factor);
/*     */     case 1:
/* 178 */       return (-this.function_factor1 * 2.0F * paramFloat2);
/*     */     case 2:
/* 180 */       return this.function_factor2;
/*     */     }
/*     */ 
/* 183 */     return 0.0F;
/*     */   }
/*     */ 
/*     */   public float dQdX(float paramFloat1, float paramFloat2)
/*     */   {
/* 188 */     switch (this.curl_display)
/*     */     {
/*     */     case 0:
/* 191 */       return this.function_factor;
/*     */     case 1:
/* 193 */       return (this.function_factor1 * paramFloat1);
/*     */     case 2:
/* 195 */       return (-this.function_factor2);
/*     */     }
/*     */ 
/* 198 */     return 0.0F;
/*     */   }
/*     */ 
/*     */   public void draw()
/*     */   {
/* 203 */     background(255);
/*     */ 
/* 205 */     textFont(this.font, 16.0F);
/* 206 */     fill(0);
/* 207 */     stroke(0);
/* 208 */     text("Curl: ", 10.0F, 20.0F, 0.0F);
/* 209 */     text((int)this.curl_magnitude, 60.0F, 20.0F, 0.0F);
/*     */ 
/* 211 */     this.btnXminus.draw();
/* 212 */     this.btnXplus.draw();
/* 213 */     this.btnYminus.draw();
/* 214 */     this.btnYplus.draw();
/* 215 */     this.rgVectorField.draw();
/*     */ 
/* 218 */     if ((this.btnYplus.value) && 
/* 220 */       (this.curl_y - this.move_speed >= -this.axes_length)) this.curl_y -= this.move_speed;
/*     */ 
/* 222 */     if ((this.btnYminus.value) && 
/* 224 */       (this.curl_y + this.move_speed <= this.axes_length)) this.curl_y += this.move_speed;
/*     */ 
/* 226 */     if ((this.btnXminus.value) && 
/* 228 */       (this.curl_x - this.move_speed >= -this.axes_length)) this.curl_x -= this.move_speed;
/*     */ 
/* 230 */     if ((this.btnXplus.value) && 
/* 232 */       (this.curl_x + this.move_speed <= this.axes_length)) this.curl_x += this.move_speed;
/*     */ 
/* 235 */     this.curl_display = this.rgVectorField._selected;
/* 236 */     switch (this.curl_display)
/*     */     {
/*     */     case 0:
/* 239 */       this.curl_arrow_scale_factor = this.curl_scale_factor;
/* 240 */       break;
/*     */     case 1:
/* 242 */       this.curl_arrow_scale_factor = this.curl_scale_factor1;
/* 243 */       break;
/*     */     case 2:
/* 245 */       this.curl_arrow_scale_factor = this.curl_scale_factor2;
/*     */     }
/*     */ 
/* 250 */     textFont(this.font, 20.0F);
/* 251 */     stroke(0); fill(0);
/* 252 */     translate(this.axes_centre_x, this.axes_centre_y, this.axes_centre_z);
/* 253 */     if (this.rotate_cam_y)
/*     */     {
/* 257 */       this.rotate_y += 3.141593F * (this.mouseX - this.pmouseX) / this.width;
/* 258 */       if (this.rotate_y >= 6.283186F) this.rotate_y -= 6.283186F;
/* 259 */       if (this.rotate_y < 0.0F) this.rotate_y += 6.283186F;
/*     */     }
/* 261 */     if (this.rotate_cam_x)
/*     */     {
/* 265 */       this.rotate_x -= 3.141593F * (this.mouseY - this.pmouseY) / this.height;
/* 266 */       if (this.rotate_x >= 6.283186F) this.rotate_x -= 6.283186F;
/* 267 */       if (this.rotate_x < 0.0F) this.rotate_x += 6.283186F;
/*     */     }
/*     */ 
/* 270 */     rotateX(this.rotate_x);
/* 271 */     rotateZ(-this.rotate_y);
/*     */ 
/* 273 */     line(0.0F, 0.0F, 0.0F, this.axes_length, 0.0F, 0.0F);
/* 274 */     line(0.0F, 0.0F, 0.0F, 0.0F, -this.axes_length, 0.0F);
/* 275 */     line(0.0F, 0.0F, 0.0F, -this.axes_length, 0.0F, 0.0F);
/* 276 */     line(0.0F, 0.0F, 0.0F, 0.0F, this.axes_length, 0.0F);
/* 277 */     text("y", 0.0F, -this.axes_length - 20.0F, 0.0F);
/* 278 */     text("x", this.axes_length + 20.0F, 0.0F, 0.0F);
/*     */ 
/* 282 */     stroke(150);
/* 283 */     for (float f2 = -this.axes_length; f2 <= this.axes_length; f2 += this.surface_res)
/*     */     {
/* 285 */       for (float f3 = -this.axes_length; f3 <= this.axes_length; f3 += this.surface_res)
/*     */       {
/* 287 */         pushMatrix();
/* 288 */         translate(f2, f3, 0.0F);
/* 289 */         rotateZ(atan2(-Q(f2, -f3), P(f2, -f3)));
/* 290 */         f1 = mag(P(f2, -f3), Q(f2, -f3)) * this.scale_factor;
/* 291 */         line(0.0F, 0.0F, 0.0F, f1, 0.0F, 0.0F);
/* 292 */         translate(f1, 0.0F, 0.0F);
/* 293 */         line(0.0F, 0.0F, 0.0F, -f1 / 5, -f1 / 10.0F, 0.0F);
/* 294 */         line(0.0F, 0.0F, 0.0F, -f1 / 5, f1 / 10.0F, 0.0F);
/* 295 */         popMatrix();
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 300 */     this.curl_magnitude = (dQdX(this.curl_x, -this.curl_y) - dPdY(this.curl_x, -this.curl_y));
/* 301 */     if (this.curl_magnitude >= 0.0F) stroke(255.0F, 0.0F, 0.0F); else if (this.curl_magnitude < 0.0F) stroke(0.0F, 255.0F, 0.0F);
/* 302 */     line(this.curl_x, this.curl_y, 0.0F, this.curl_x, this.curl_y, this.curl_magnitude * this.curl_arrow_scale_factor);
/*     */ 
/* 304 */     pushMatrix();
/* 305 */     translate(this.curl_x, this.curl_y, this.curl_magnitude * this.curl_arrow_scale_factor);
/* 306 */     float f1 = this.curl_magnitude * this.curl_arrow_scale_factor / 5;
/* 307 */     line(0.0F, 0.0F, 0.0F, -f1 / 2.0F, 0.0F, -f1);
/* 308 */     line(0.0F, 0.0F, 0.0F, f1 / 2.0F, 0.0F, -f1);
/* 309 */     popMatrix();
/*     */   }
/*     */ 
/*     */   private final void jdMethod_this()
/*     */   {
/*   4 */     this.axes_centre_x = 230.0F;
/*   5 */     this.axes_centre_y = 230.0F;
/*   6 */     this.axes_centre_z = -300.0F;
/*   7 */     this.axes_length = 365.0F;
/*   8 */     this.rotate_cam_y = false;
/*   9 */     this.rotate_cam_x = false;
/*  10 */     this.rotate_y = 0.0F;
/*  11 */     this.rotate_x = 0.0F;
/*  12 */     this.rotate_speed = 0.05F;
/*  13 */     this.surface_res = 30.0F;
/*  14 */     this.scale_factor = 0.1F;
/*  15 */     this.scale_factor1 = 0.005F;
/*  16 */     this.scale_factor2 = 0.1F;
/*  17 */     this.function_factor = 1.0F;
/*  18 */     this.function_factor1 = 0.005F;
/*  19 */     this.function_factor2 = 1.0F;
/*  20 */     this.curl_arrow_scale_factor = 50.0F;
/*  21 */     this.curl_scale_factor = 50.0F;
/*  22 */     this.curl_scale_factor1 = 50.0F;
/*  23 */     this.curl_scale_factor2 = 50.0F;
/*  24 */     this.curl_x = (this.axes_length / 2.0F);
/*  25 */     this.curl_y = (-this.axes_length / 2.0F);
/*  26 */     this.move_speed = 10.0F;
/*  27 */     this.curl_display = 0;
/*  28 */     this.curl_magnitude = 0.0F;
/*     */   }
/*     */ 
/*     */   public Curl()
/*     */   {
/*   1 */     jdMethod_this();
/*     */   }
/*     */ 
/*     */   class RadioGroup
/*     */   {
/*     */     private int _x;
/*     */     private int _y;
/*     */     private int _w;
/*     */     private String[] _options;
/*     */     public int _selected;
/*     */ 
/*     */     public void draw()
/*     */     {
/* 393 */       Curl.this.textFont(Curl.this.font2, 16.0F);
/* 394 */       Curl.this.pushMatrix();
/* 395 */       Curl.this.translate(this._x, this._y);
/* 396 */       for (int i = 0; i < this._options.length; ++i) {
/* 397 */         Curl.this.pushMatrix();
/* 398 */         Curl.this.translate(6.0F, 6 + i * 18);
/* 399 */         Curl.this.ellipseMode(3);
/* 400 */         Curl.this.fill(255.0F, 255.0F, 255.0F);
/* 401 */         Curl.this.stroke(0.0F, 0.0F, 0.0F);
/* 402 */         Curl.this.ellipse(0.0F, 0.0F, 12.0F, 12.0F);
/* 403 */         if (i == this._selected) {
/* 404 */           Curl.this.fill(250.0F, 130.0F, 20.0F);
/* 405 */           Curl.this.noStroke();
/* 406 */           Curl.this.ellipse(0.0F, 0.0F, 8.0F, 8.0F);
/*     */         }
/*     */         else
/*     */         {
/* 410 */           Curl.this.fill(0.0F, 0.0F, 0.0F);
/*     */         }
/* 412 */         Curl.this.pushMatrix();
/* 413 */         Curl.this.translate(10.0F, 6.0F);
/*     */ 
/* 415 */         Curl.this.text(this._options[i], 0.0F, -2.0F);
/* 416 */         Curl.this.popMatrix();
/* 417 */         Curl.this.popMatrix();
/*     */       }
/* 419 */       Curl.this.popMatrix();
/*     */     }
/*     */ 
/*     */     public void processMouseDown() {
/* 423 */       int i = Curl.this.mouseX - this._x;
/* 424 */       int j = Curl.this.mouseY - this._y;
/*     */ 
/* 426 */       if ((i >= 0) && (i <= this._w)) {
/* 427 */         int k = 0;
/* 428 */         if (j <= this._options.length * 18) {
/* 429 */           while (j > 18) {
/* 430 */             ++k;
/* 431 */             j -= 18;
/*     */           }
/* 433 */           if ((j >= 0) && (j <= 12))
/* 434 */             this._selected = k;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     public RadioGroup(int paramInt1, int paramInt2, String[] paramArrayOfString, int paramInt3)
/*     */     {
/* 385 */       this._x = paramInt1;
/* 386 */       this._y = paramInt2;
/* 387 */       this._w = 60;
/* 388 */       this._options = paramArrayOfString;
/* 389 */       this._selected = paramInt3;
/*     */     }
/*     */   }
/*     */ 
/*     */   class Button
/*     */   {
/*     */     public boolean value;
/*     */     public String msg;
/*     */     public int x;
/*     */     public int y;
/*     */     public int w;
/*     */     public int h;
/*     */ 
/*     */     public void draw()
/*     */     {
/* 327 */       Curl.this.rectMode(0);
/* 328 */       Curl.this.pushMatrix();
/* 329 */       Curl.this.translate(this.x, this.y);
/* 330 */       if (this.value) {
/* 331 */         Curl.this.fill(250.0F, 130.0F, 20.0F);
/* 332 */         Curl.this.stroke(0);
/* 333 */         Curl.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/*     */       else
/*     */       {
/* 341 */         Curl.this.fill(255.0F, 255.0F, 255.0F);
/* 342 */         Curl.this.stroke(0);
/* 343 */         Curl.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/* 345 */       Curl.this.rect(0.0F, 0.0F, this.w, this.h);
/* 346 */       Curl.this.noStroke();
/* 347 */       Curl.this.fill(255.0F, 255.0F, 255.0F);
/* 348 */       Curl.this.rect(2.0F, 2.0F, this.w - 4, this.h - 4);
/*     */ 
/* 350 */       Curl.this.fill(0);
/* 351 */       Curl.this.textFont(Curl.this.font, 19.0F);
/* 352 */       Curl.this.text(this.msg, 5, this.h - 8);
/*     */ 
/* 354 */       Curl.this.popMatrix();
/*     */     }
/*     */ 
/*     */     public void processMouseDown() {
/* 358 */       int i = Curl.this.mouseX - this.x;
/* 359 */       int j = Curl.this.mouseY - this.y;
/*     */ 
/* 361 */       if ((i < 0) || (i > this.w) || 
/* 362 */         (j < 0) || (j > this.h)) return;
/* 363 */       this.value = true;
/*     */     }
/*     */ 
/*     */     public void processMouseUp()
/*     */     {
/* 369 */       if (this.value)
/* 370 */         this.value = false;
/*     */     }
/*     */ 
/*     */     private final void jdMethod_this() {
/* 374 */       this.value = false;
/*     */     }
/*     */ 
/*     */     public Button(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString)
/*     */     {
/* 318 */       jdMethod_this();
/* 319 */       this.x = paramInt1;
/* 320 */       this.y = paramInt2;
/* 321 */       this.w = paramInt3;
/* 322 */       this.h = paramInt4;
/* 323 */       this.msg = paramString;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/mfeyereisen/applets-final/classes/
 * Qualified Name:     Curl
 * JD-Core Version:    0.5.3
 */