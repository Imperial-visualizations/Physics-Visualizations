/*     */ import processing.core.PApplet;
/*     */ import processing.core.PFont;
/*     */ 
/*     */ public class vectderiv extends PApplet
/*     */ {
/*     */   float e;
/*     */   float rotZ;
/*     */   float rotX;
/*     */   PFont font;
/*     */   int gridRes;
/*     */   float tMin;
/*     */   float tMax;
/*     */   float tStep;
/*     */   float[] point1;
/*     */   float point1Time;
/*     */   float[] point2;
/*     */   float point2TimeDiff;
/*     */   boolean dragL;
/*     */   boolean dragR;
/*     */   int downL;
/*     */   int downRX;
/*     */   int downRY;
/*     */   boolean running;
/*     */   vectderiv.ParamFunction func;
/*     */   vectderiv.ToggleButton tbRunning;
/*     */   vectderiv.Slider diffSlider;
/*     */   PFont Tahoma14;
/*     */ 
/*     */   public void setup()
/*     */   {
/*  49 */     size(640, 480, "processing.core.PGraphics3");
/*     */ 
/*  54 */     this.point1 = this.func.atTime(this.point1Time);
/*  55 */     this.point2 = this.func.atTime(this.point1Time + this.point2TimeDiff);
/*     */ 
/*  60 */     this.tbRunning = new vectderiv.ToggleButton(520, 10, 110, 20, "Run animation");
/*  61 */     this.diffSlider = new vectderiv.Slider(40, this.height - 40, this.width - 80, 14, 0, 30, 6);
/*     */   }
/*     */ 
/*     */   public void draw()
/*     */   {
/*  66 */     lights();
/*  67 */     background(255);
/*  68 */     this.running = this.tbRunning.value;
/*     */ 
/*  76 */     updateRotation();
/*  77 */     updatePointPos();
/*     */ 
/*  81 */     pushMatrix();
/*     */ 
/*  83 */     translate(this.width / 2, this.height / 2, 0.0F);
/*     */ 
/*  93 */     pushMatrix();
/*     */ 
/* 107 */     rotateX(this.rotX);
/* 108 */     rotateZ(this.rotZ);
/*     */ 
/* 110 */     scale(22.0F, -22.0F, 22.0F);
/*     */ 
/* 112 */     drawAxes();
/* 113 */     drawFunction();
/* 114 */     drawLineThru(this.point1, this.point2);
/* 115 */     drawPoint(this.point1);
/* 116 */     drawPoint(this.point2);
/*     */ 
/* 118 */     popMatrix();
/*     */ 
/* 134 */     popMatrix();
/*     */ 
/* 136 */     this.tbRunning.draw();
/* 137 */     this.diffSlider.draw();
/*     */   }
/*     */ 
/*     */   public void mousePressed() {
/* 141 */     if (this.mouseButton == 37)
/*     */     {
/* 144 */       this.tbRunning.processMouseDown();
/* 145 */       this.diffSlider.processMouseDown();
/*     */     }
/* 147 */     else if (this.mouseButton == 39) {
/* 148 */       this.dragR = true;
/* 149 */       this.downRX = this.mouseX;
/* 150 */       this.downRY = this.mouseY;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void mouseReleased() {
/* 155 */     if (this.mouseButton == 37) {
/* 156 */       this.dragL = false;
/* 157 */       this.diffSlider.processMouseUp();
/*     */     }
/* 159 */     else if (this.mouseButton == 39) {
/* 160 */       this.dragR = false;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void keyPressed() {
/* 165 */     if (this.key == ' ') {
/* 166 */       this.running ^= true;
/* 167 */     } else if (this.key == 'r') {
/* 168 */       reset();
/* 169 */     } else if (this.key == 'x') {
/* 170 */       this.rotZ = 1.570796F;
/* 171 */       this.rotX = 1.570796F;
/* 172 */     } else if (this.key == 'y') {
/* 173 */       this.rotZ = 0.0F;
/* 174 */       this.rotX = 1.570796F;
/* 175 */     } else if (this.key == 'z') {
/* 176 */       this.rotZ = 0.0F;
/* 177 */       this.rotX = 0.0F;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updatePointPos() {
/* 182 */     if ((this.dragL) && (!(this.running))) {
/* 183 */       this.point2TimeDiff += 0.5F * (this.mouseX - this.downL) / this.width;
/*     */ 
/* 185 */       if (this.point2TimeDiff > this.tMax - this.point1Time) {
/* 186 */         this.point2TimeDiff = (this.tMax - this.point1Time);
/*     */       }
/* 188 */       else if (this.point2TimeDiff < 1.0E-04F) {
/* 189 */         this.point2TimeDiff = 1.0E-04F;
/*     */       }
/*     */     }
/* 192 */     else if (this.running) {
/* 193 */       this.point1Time += 0.03F;
/* 194 */       if (this.point1Time + this.point2TimeDiff > this.tMax) {
/* 195 */         this.point1Time = this.tMin;
/*     */       }
/*     */     }
/* 198 */     this.point1 = this.func.atTime(this.point1Time);
/* 199 */     this.point2 = this.func.atTime(this.point1Time + this.point2TimeDiff);
/*     */   }
/*     */ 
/*     */   public void updateRotation() {
/* 203 */     if (this.dragR) {
/* 204 */       this.rotZ -= 6.283186F * (this.mouseX - this.downRX) / this.width;
/*     */ 
/* 206 */       this.rotX -= 3.141593F * (this.mouseY - this.downRY) / this.height;
/*     */ 
/* 211 */       if (this.rotZ > 6.283186F) {
/* 212 */         this.rotZ -= 6.283186F;
/*     */       }
/* 214 */       else if (this.rotZ < 6.283186F) {
/* 215 */         this.rotZ += 6.283186F;
/*     */       }
/*     */ 
/* 219 */       if (this.rotX > 3.141593F) {
/* 220 */         this.rotX = 3.141593F;
/* 221 */         println("0");
/*     */       }
/* 223 */       else if (this.rotX < 0.0F) {
/* 224 */         this.rotX = 0.0F;
/* 225 */         println("pi");
/*     */       }
/*     */ 
/* 238 */       this.downRX = this.mouseX;
/* 239 */       this.downRY = this.mouseY;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void drawAxes() {
/* 244 */     strokeWeight(2.0F);
/* 245 */     stroke(200.0F, 20.0F, 20.0F, 200.0F);
/* 246 */     line(0.0F, 0.0F, 0.0F, 12.0F, 0.0F, 0.0F);
/* 247 */     stroke(20.0F, 200.0F, 20.0F, 200.0F);
/* 248 */     line(0.0F, 0.0F, 0.0F, 0.0F, 12.0F, 0.0F);
/* 249 */     stroke(20.0F, 20.0F, 200.0F, 200.0F);
/* 250 */     line(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 12.0F);
/* 251 */     strokeWeight(1.0F);
/*     */ 
/* 253 */     stroke(0.0F, 0.0F, 0.0F, 50.0F);
/*     */ 
/* 255 */     for (int i = -10 * this.gridRes; i <= 10 * this.gridRes; ++i)
/* 256 */       if (i != 0) {
/* 257 */         if (i % this.gridRes != 0) {
/* 258 */           line(i / this.gridRes, -10.0F, 0.0F, i / this.gridRes, 10.0F, 0.0F);
/* 259 */           line(-10.0F, i / this.gridRes, 0.0F, 10.0F, i / this.gridRes, 0.0F);
/*     */         }
/*     */         else
/*     */         {
/* 263 */           stroke(0.0F, 0.0F, 0.0F, 100.0F);
/* 264 */           line(i / this.gridRes, -10.0F, 0.0F, i / this.gridRes, 10.0F, 0.0F);
/* 265 */           line(-10.0F, i / this.gridRes, 0.0F, 10.0F, i / this.gridRes, 0.0F);
/* 266 */           stroke(0.0F, 0.0F, 0.0F, 50.0F);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 271 */         stroke(0.0F, 0.0F, 0.0F, 100.0F);
/* 272 */         line(i / this.gridRes, -10.0F, 0.0F, i / this.gridRes, 0.0F, 0.0F);
/* 273 */         line(-10.0F, i / this.gridRes, 0.0F, 0.0F, i / this.gridRes, 0.0F);
/* 274 */         stroke(0.0F, 0.0F, 0.0F, 50.0F);
/*     */       }
/*     */   }
/*     */ 
/*     */   public void drawFunction()
/*     */   {
/* 282 */     stroke(0.0F, 0.0F, 0.0F, 200.0F);
/*     */ 
/* 284 */     beginShape(33);
/* 285 */     for (float f1 = this.tMin; f1 < this.tMax; f1 += this.tStep) {
/* 286 */       float f2 = this.func.getX(f1);
/* 287 */       float f3 = this.func.getY(f1);
/* 288 */       float f4 = this.func.getZ(f1);
/* 289 */       curveVertex(f2, f3, f4);
/*     */     }
/* 291 */     endShape();
/*     */   }
/*     */ 
/*     */   public void drawLineThru(float[] paramArrayOfFloat1, float[] paramArrayOfFloat2) {
/* 295 */     float f1 = 10.0F;
/*     */ 
/* 297 */     float[] arrayOfFloat1 = new float[3];
/* 298 */     arrayOfFloat1[0] = ((paramArrayOfFloat2[0] + paramArrayOfFloat1[0]) / 2.0F);
/* 299 */     arrayOfFloat1[1] = ((paramArrayOfFloat2[1] + paramArrayOfFloat1[1]) / 2.0F);
/* 300 */     arrayOfFloat1[2] = ((paramArrayOfFloat2[2] + paramArrayOfFloat1[2]) / 2.0F);
/*     */ 
/* 302 */     float[] arrayOfFloat2 = new float[3];
/* 303 */     arrayOfFloat2[0] = ((paramArrayOfFloat2[0] - paramArrayOfFloat1[0]) / 2.0F);
/* 304 */     arrayOfFloat2[1] = ((paramArrayOfFloat2[1] - paramArrayOfFloat1[1]) / 2.0F);
/* 305 */     arrayOfFloat2[2] = ((paramArrayOfFloat2[2] - paramArrayOfFloat1[2]) / 2.0F);
/*     */ 
/* 307 */     float f2 = sqrt(pow(arrayOfFloat2[0], 2.0F) + pow(arrayOfFloat2[1], 2.0F) + pow(arrayOfFloat2[2], 2.0F));
/* 308 */     for (int i = 0; i <= 2; ++i) {
/* 309 */       arrayOfFloat2[i] /= f2;
/*     */     }
/*     */ 
/* 312 */     float[] arrayOfFloat3 = new float[3];
/* 313 */     arrayOfFloat3[0] = (arrayOfFloat1[0] - (f1 / 2.0F * arrayOfFloat2[0]));
/* 314 */     arrayOfFloat3[1] = (arrayOfFloat1[1] - (f1 / 2.0F * arrayOfFloat2[1]));
/* 315 */     arrayOfFloat3[2] = (arrayOfFloat1[2] - (f1 / 2.0F * arrayOfFloat2[2]));
/*     */ 
/* 317 */     float[] arrayOfFloat4 = new float[3];
/* 318 */     arrayOfFloat4[0] = (arrayOfFloat1[0] + f1 / 2.0F * arrayOfFloat2[0]);
/* 319 */     arrayOfFloat4[1] = (arrayOfFloat1[1] + f1 / 2.0F * arrayOfFloat2[1]);
/* 320 */     arrayOfFloat4[2] = (arrayOfFloat1[2] + f1 / 2.0F * arrayOfFloat2[2]);
/*     */ 
/* 322 */     stroke(255.0F, 100.0F, 0.0F);
/* 323 */     beginShape(33);
/* 324 */     vertex(arrayOfFloat3[0], arrayOfFloat3[1], arrayOfFloat3[2]);
/* 325 */     vertex(arrayOfFloat4[0], arrayOfFloat4[1], arrayOfFloat4[2]);
/* 326 */     endShape();
/*     */   }
/*     */ 
/*     */   public void drawPoint(float[] paramArrayOfFloat) {
/* 330 */     pushMatrix();
/* 331 */     noStroke();
/* 332 */     fill(255.0F, 100.0F, 0.0F);
/* 333 */     translate(paramArrayOfFloat[0], paramArrayOfFloat[1], paramArrayOfFloat[2]);
/* 334 */     sphere(0.1F);
/* 335 */     popMatrix();
/*     */   }
/*     */ 
/*     */   public void reset() {
/* 339 */     this.rotX = 0.0F;
/* 340 */     this.rotZ = 0.0F;
/*     */ 
/* 342 */     this.point1Time = 2.0F;
/* 343 */     this.point2TimeDiff = 0.5F;
/*     */   }
/*     */ 
/*     */   private final void jdMethod_this()
/*     */   {
/*  13 */     this.e = 2.718282F;
/*     */ 
/*  15 */     this.rotZ = 0.0F;
/*  16 */     this.rotX = 0.0F;
/*     */ 
/*  19 */     this.gridRes = 5;
/*     */ 
/*  21 */     this.tMin = 0.0F;
/*  22 */     this.tMax = 10.0F;
/*  23 */     this.tStep = 0.1F;
/*     */ 
/*  25 */     this.point1 = new float[3];
/*  26 */     this.point1Time = 2.0F;
/*  27 */     this.point2 = new float[3];
/*  28 */     this.point2TimeDiff = 0.5F;
/*     */ 
/*  30 */     this.dragL = false;
/*  31 */     this.dragR = false;
/*  32 */     this.downL = 0;
/*  33 */     this.downRX = 0;
/*  34 */     this.downRY = 0;
/*     */ 
/*  36 */     this.running = false;
/*     */ 
/*  38 */     this.func = new vectderiv.ParamFunction();
/*     */ 
/*  43 */     this.Tahoma14 = loadFont("Tahoma-14.vlw");
/*     */   }
/*     */ 
/*     */   public vectderiv()
/*     */   {
/*   1 */     jdMethod_this();
/*     */   }
/*     */ 
/*     */   class ParamFunction
/*     */   {
/*     */     public float getX(float paramFloat)
/*     */     {
/* 348 */       float f = 5 * vectderiv.pow(vectderiv.this.e, -0.4F * paramFloat) * vectderiv.this.cos(3.141593F * paramFloat);
/* 349 */       return f;
/*     */     }
/*     */ 
/*     */     public float getY(float paramFloat) {
/* 353 */       float f = 5 * vectderiv.pow(vectderiv.this.e, -0.4F * paramFloat) * vectderiv.this.sin(3.141593F * paramFloat);
/* 354 */       return f;
/*     */     }
/*     */ 
/*     */     public float getZ(float paramFloat) {
/* 358 */       float f = 0.6F * paramFloat + 2.0F;
/* 359 */       return f;
/*     */     }
/*     */ 
/*     */     public float[] atTime(float paramFloat) {
/* 363 */       float[] arrayOfFloat = new float[3];
/* 364 */       arrayOfFloat[0] = getX(paramFloat);
/* 365 */       arrayOfFloat[1] = getY(paramFloat);
/* 366 */       arrayOfFloat[2] = getZ(paramFloat);
/* 367 */       return arrayOfFloat;
/*     */     }
/*     */   }
/*     */ 
/*     */   class ToggleButton
/*     */   {
/*     */     public boolean value;
/*     */     public String msg;
/*     */     public int x;
/*     */     public int y;
/*     */     public int w;
/*     */     public int h;
/*     */ 
/*     */     public void draw()
/*     */     {
/* 382 */       vectderiv.this.rectMode(0);
/* 383 */       vectderiv.this.pushMatrix();
/* 384 */       vectderiv.this.translate(this.x, this.y);
/* 385 */       if (this.value) {
/* 386 */         vectderiv.this.fill(250.0F, 130.0F, 20.0F);
/* 387 */         vectderiv.this.stroke(0);
/* 388 */         vectderiv.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/*     */       else {
/* 391 */         vectderiv.this.fill(255.0F, 255.0F, 255.0F);
/* 392 */         vectderiv.this.stroke(0);
/* 393 */         vectderiv.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/* 395 */       vectderiv.this.rect(0.0F, 0.0F, this.w, this.h);
/* 396 */       vectderiv.this.noStroke();
/* 397 */       vectderiv.this.fill(255.0F, 255.0F, 255.0F);
/* 398 */       vectderiv.this.rect(2.0F, 2.0F, this.w - 4, this.h - 4);
/*     */ 
/* 400 */       vectderiv.this.fill(0);
/* 401 */       vectderiv.this.textFont(vectderiv.this.Tahoma14, 14.0F);
/* 402 */       vectderiv.this.text(this.msg, 5, this.h - 5);
/*     */ 
/* 404 */       vectderiv.this.popMatrix();
/*     */     }
/*     */ 
/*     */     public void processMouseDown() {
/* 408 */       int i = vectderiv.this.mouseX - this.x;
/* 409 */       int j = vectderiv.this.mouseY - this.y;
/*     */ 
/* 411 */       if ((i < 0) || (i > this.w) || 
/* 412 */         (j < 0) || (j > this.h)) return;
/* 413 */       this.value ^= true;
/*     */     }
/*     */ 
/*     */     private final void jdMethod_this()
/*     */     {
/* 418 */       this.value = false;
/*     */     }
/*     */ 
/*     */     public ToggleButton(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString)
/*     */     {
/* 372 */       jdMethod_this();
/* 373 */       this.x = paramInt1;
/* 374 */       this.y = paramInt2;
/* 375 */       this.w = paramInt3;
/* 376 */       paramInt4 = 20;
/* 377 */       this.h = paramInt4;
/* 378 */       this.msg = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */   class Slider
/*     */   {
/*     */     private int _x;
/*     */     private int _y;
/*     */     private int _w;
/*     */     private int _h;
/*     */     private int _minValue;
/*     */     private int _maxValue;
/*     */     private int _pos;
/*     */     private float _frac;
/*     */     private boolean _dragging;
/*     */ 
/*     */     public void draw()
/*     */     {
/* 437 */       if (this._dragging) {
/* 438 */         int i = vectderiv.this.mouseX - this._x;
/* 439 */         if (i < 0) {
/* 440 */           i = 0;
/*     */         }
/* 442 */         else if (i > this._w) {
/* 443 */           i = this._w;
/*     */         }
/* 445 */         this._frac = (i / this._w);
/* 446 */         updatePosition((int)(i / this._w * (this._maxValue - this._minValue)));
/*     */       }
/*     */ 
/* 449 */       vectderiv.this.pushMatrix();
/* 450 */       vectderiv.this.translate(this._x, this._y);
/* 451 */       vectderiv.this.stroke(50.0F, 50.0F, 50.0F);
/* 452 */       vectderiv.this.line(0.0F, 0.0F, this._w, 0.0F);
/* 453 */       vectderiv.this.pushMatrix();
/* 454 */       vectderiv.this.translate(this._w * this._pos / (this._maxValue - this._minValue), 0.0F);
/*     */ 
/* 456 */       vectderiv.this.fill(250.0F, 130.0F, 20.0F);
/* 457 */       vectderiv.this.rectMode(3);
/* 458 */       vectderiv.this.rect(0.0F, 0.0F, this._h, this._h);
/* 459 */       vectderiv.this.popMatrix();
/* 460 */       vectderiv.this.popMatrix();
/*     */     }
/*     */ 
/*     */     public void updatePosition(int paramInt) {
/* 464 */       this._pos = paramInt;
/*     */ 
/* 467 */       vectderiv.this.point2TimeDiff = (this._minValue + paramInt / 30.0F + 1.0E-04F);
/*     */     }
/*     */ 
/*     */     public void processMouseDown() {
/* 471 */       int i = vectderiv.this.mouseX - this._x;
/* 472 */       int j = vectderiv.this.mouseY - this._y;
/* 473 */       if (vectderiv.mag(i - (this._w * this._pos / (this._maxValue - this._minValue)), j) <= this._h)
/* 474 */         this._dragging = true;
/*     */     }
/*     */ 
/*     */     public void processMouseUp()
/*     */     {
/* 479 */       this._dragging = false;
/*     */     }
/*     */ 
/*     */     private final void jdMethod_this()
/*     */     {
/* 491 */       this._dragging = false;
/*     */     }
/*     */ 
/*     */     public Slider(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7)
/*     */     {
/* 426 */       jdMethod_this();
/* 427 */       this._x = paramInt1;
/* 428 */       this._y = paramInt2;
/* 429 */       this._w = paramInt3;
/* 430 */       this._h = paramInt4;
/* 431 */       this._minValue = paramInt5;
/* 432 */       this._maxValue = paramInt6;
/* 433 */       updatePosition(paramInt7);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/mfeyereisen/applets-final/classes/
 * Qualified Name:     vectderiv
 * JD-Core Version:    0.5.3
 */