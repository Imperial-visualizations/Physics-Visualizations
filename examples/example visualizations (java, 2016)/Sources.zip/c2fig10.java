/*     */ import processing.core.PApplet;
/*     */ 
/*     */ public class c2fig10 extends PApplet
/*     */ {
/*     */   float rotZ;
/*     */   float rotX;
/*     */   int gridRes;
/*     */   boolean dragL;
/*     */   boolean dragR;
/*     */   int downLX;
/*     */   int downLY;
/*     */   int downRX;
/*     */   int downRY;
/*     */   boolean shifted;
/*     */   float rMax;
/*     */   float rMin;
/*     */   float theta0;
/*     */   float theta1;
/*     */   float thetaStep;
/*     */   boolean running;
/*     */ 
/*     */   public void setup()
/*     */   {
/*  39 */     size(640, 480, "processing.core.PGraphics3");
/*     */   }
/*     */ 
/*     */   public void draw()
/*     */   {
/*  44 */     lights();
/*  45 */     background(255);
/*     */ 
/*  47 */     updateRotation();
/*  48 */     updateParams();
/*  49 */     pushMatrix();
/*     */ 
/*  51 */     translate(this.width / 2, this.height / 2, 0.0F);
/*     */ 
/*  53 */     beginCamera();
/*  54 */     resetMatrix();
/*  55 */     camera(0.0F, 0.0F, 200.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.0F, 0.0F);
/*  56 */     endCamera();
/*     */ 
/*  63 */     pushMatrix();
/*  64 */     scale(0.95F, 0.95F, 0.95F);
/*     */ 
/*  66 */     rotateX(this.rotX);
/*  67 */     rotateZ(this.rotZ);
/*     */ 
/*  69 */     scale(12.0F, -12.0F, 12.0F);
/*     */ 
/*  71 */     drawAxes();
/*  72 */     drawRegion();
/*     */ 
/*  74 */     popMatrix();
/*     */ 
/*  76 */     popMatrix();
/*     */   }
/*     */ 
/*     */   public void mousePressed() {
/*  80 */     if (this.mouseButton == 37) {
/*  81 */       this.dragL = true;
/*  82 */       this.downLX = this.mouseX;
/*  83 */       this.downLY = this.mouseY;
/*     */     }
/*  85 */     else if (this.mouseButton == 39) {
/*  86 */       this.dragR = true;
/*  87 */       this.downRX = this.mouseX;
/*  88 */       this.downRY = this.mouseY;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void mouseReleased() {
/*  93 */     if (this.mouseButton == 37) {
/*  94 */       this.dragL = false;
/*     */     }
/*  96 */     else if (this.mouseButton == 39)
/*  97 */       this.dragR = false;
/*     */   }
/*     */ 
/*     */   public void keyPressed()
/*     */   {
/* 102 */     if (this.key == ' ') {
/* 103 */       this.running ^= true;
/*     */     }
/* 105 */     else if (this.keyCode == 16) {
/* 106 */       this.shifted = true;
/* 107 */     } else if (this.key == 'x') {
/* 108 */       this.rotZ = -1.570796F;
/* 109 */       this.rotX = -1.570796F;
/* 110 */     } else if (this.key == 'y') {
/* 111 */       this.rotZ = 3.141593F;
/* 112 */       this.rotX = -1.570796F;
/* 113 */     } else if (this.key == 'z') {
/* 114 */       this.rotZ = 3.141593F;
/* 115 */       this.rotX = 0.0F;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void keyReleased() {
/* 120 */     if (this.keyCode == 16)
/* 121 */       this.shifted = false;
/*     */   }
/*     */ 
/*     */   public void updateRotation()
/*     */   {
/* 126 */     if (this.dragR) {
/* 127 */       this.rotZ -= 6.283186F * (this.mouseX - this.downRX) / this.width;
/* 128 */       this.rotX += 3.141593F * (this.mouseY - this.downRY) / this.height;
/*     */ 
/* 130 */       if (this.rotZ > 6.283186F) {
/* 131 */         this.rotZ -= 6.283186F;
/*     */       }
/* 133 */       else if (this.rotZ < 6.283186F) {
/* 134 */         this.rotZ += 6.283186F;
/*     */       }
/*     */ 
/* 137 */       if (this.rotX > 0.0F) {
/* 138 */         this.rotX = 0.0F;
/*     */       }
/* 140 */       else if (this.rotX < -3.141593F) {
/* 141 */         this.rotX = -3.141593F;
/*     */       }
/*     */ 
/* 144 */       this.downRX = this.mouseX;
/* 145 */       this.downRY = this.mouseY;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updateParams() {
/* 150 */     if (!(this.dragL)) {
/*     */       return;
/*     */     }
/*     */ 
/* 154 */     float f1 = this.width / 2 - this.mouseX;
/* 155 */     float f2 = this.mouseY - (this.height / 2);
/*     */ 
/* 160 */     float f3 = atan2(f2, f1);
/*     */ 
/* 169 */     if (this.shifted)
/* 170 */       this.theta0 = (f3 + 3.141593F);
/*     */     else {
/* 172 */       this.theta1 = (f3 + 3.141593F);
/*     */     }
/*     */ 
/* 176 */     if (this.theta1 > 6.283186F)
/* 177 */       this.theta1 = 6.283186F;
/* 178 */     else if (this.theta1 < 0.0F) {
/* 179 */       this.theta1 = 0.0F;
/*     */     }
/* 181 */     this.downLX = this.mouseX;
/* 182 */     this.downLY = this.mouseY;
/*     */ 
/* 187 */     float f4 = sqrt(f1 * f1 + f2 * f2) / 25.0F;
/*     */ 
/* 190 */     if (this.shifted)
/* 191 */       this.rMax = f4;
/*     */     else {
/* 193 */       this.rMin = f4;
/*     */     }
/*     */ 
/* 197 */     if (this.rMin > this.rMax)
/* 198 */       this.rMin = this.rMax;
/* 199 */     else if (this.rMin < 0.0F) {
/* 200 */       this.rMin = 0.0F;
/*     */     }
/* 202 */     this.downLY = this.mouseY;
/*     */   }
/*     */ 
/*     */   public void drawAxes()
/*     */   {
/* 208 */     strokeWeight(2.0F);
/* 209 */     stroke(200.0F, 20.0F, 20.0F, 200.0F);
/* 210 */     line(0.0F, 0.0F, 0.0F, 12.0F, 0.0F, 0.0F);
/* 211 */     stroke(20.0F, 200.0F, 20.0F, 200.0F);
/* 212 */     line(0.0F, 0.0F, 0.0F, 0.0F, 12.0F, 0.0F);
/* 213 */     stroke(20.0F, 20.0F, 200.0F, 200.0F);
/* 214 */     line(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 12.0F);
/* 215 */     strokeWeight(1.0F);
/*     */ 
/* 217 */     stroke(0.0F, 0.0F, 0.0F, 50.0F);
/*     */ 
/* 219 */     for (int i = -10 * this.gridRes; i <= 10 * this.gridRes; ++i)
/* 220 */       if (i != 0) {
/* 221 */         if (i % this.gridRes != 0) {
/* 222 */           line(i / this.gridRes, -10.0F, 0.0F, i / this.gridRes, 10.0F, 0.0F);
/* 223 */           line(-10.0F, i / this.gridRes, 0.0F, 10.0F, i / this.gridRes, 0.0F);
/*     */         }
/*     */         else
/*     */         {
/* 227 */           stroke(0.0F, 0.0F, 0.0F, 100.0F);
/* 228 */           line(i / this.gridRes, -10.0F, 0.0F, i / this.gridRes, 10.0F, 0.0F);
/* 229 */           line(-10.0F, i / this.gridRes, 0.0F, 10.0F, i / this.gridRes, 0.0F);
/* 230 */           stroke(0.0F, 0.0F, 0.0F, 50.0F);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 235 */         stroke(0.0F, 0.0F, 0.0F, 100.0F);
/* 236 */         line(i / this.gridRes, -10.0F, 0.0F, i / this.gridRes, 0.0F, 0.0F);
/* 237 */         line(-10.0F, i / this.gridRes, 0.0F, 0.0F, i / this.gridRes, 0.0F);
/* 238 */         stroke(0.0F, 0.0F, 0.0F, 50.0F);
/*     */       }
/*     */   }
/*     */ 
/*     */   public void drawRegion()
/*     */   {
/* 255 */     for (float f1 = this.theta0; f1 < this.theta1 - this.thetaStep; f1 += this.thetaStep) {
/* 256 */       float f2 = f1;
/* 257 */       float f3 = f1 + this.thetaStep;
/*     */ 
/* 259 */       float f4 = this.rMin;
/* 260 */       float f5 = this.rMax;
/*     */ 
/* 263 */       float f6 = f4 * cos(f2);
/* 264 */       float f7 = f4 * sin(f2);
/*     */ 
/* 266 */       float f8 = f4 * cos(f3);
/* 267 */       float f9 = f4 * sin(f3);
/*     */ 
/* 269 */       float f10 = f5 * cos(f3);
/* 270 */       float f11 = f5 * sin(f3);
/*     */ 
/* 272 */       float f12 = f5 * cos(f2);
/* 273 */       float f13 = f5 * sin(f2);
/*     */ 
/* 275 */       noStroke();
/* 276 */       fill(50.0F, 50.0F, 50.0F, 150.0F);
/*     */ 
/* 278 */       beginShape(128);
/* 279 */       vertex(f6, f7, 0.0F);
/* 280 */       vertex(f8, f9, 0.0F);
/* 281 */       vertex(f10, f11, 0.0F);
/* 282 */       vertex(f12, f13, 0.0F);
/* 283 */       endShape();
/*     */     }
/*     */   }
/*     */ 
/*     */   private final void jdMethod_this()
/*     */   {
/*  12 */     this.rotZ = 3.141593F;
/*  13 */     this.rotX = 0.0F;
/*     */ 
/*  15 */     this.gridRes = 5;
/*     */ 
/*  17 */     this.dragL = false;
/*  18 */     this.dragR = false;
/*  19 */     this.downLX = 0;
/*  20 */     this.downLY = 0;
/*  21 */     this.downRX = 0;
/*  22 */     this.downRY = 0;
/*     */ 
/*  24 */     this.shifted = false;
/*     */ 
/*  26 */     this.rMax = 3;
/*  27 */     this.rMin = 0.0F;
/*     */ 
/*  29 */     this.theta0 = 0.0F;
/*  30 */     this.theta1 = 6.283186F;
/*  31 */     this.thetaStep = 0.08726647F;
/*     */ 
/*  33 */     this.running = false;
/*     */   }
/*     */ 
/*     */   public c2fig10()
/*     */   {
/*   1 */     jdMethod_this();
/*     */   }
/*     */ }

/* Location:           /Users/mfeyereisen/applets-final/classes/
 * Qualified Name:     c2fig10
 * JD-Core Version:    0.5.3
 */