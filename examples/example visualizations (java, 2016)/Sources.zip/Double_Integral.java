/*     */ import processing.core.PApplet;
/*     */ import processing.core.PFont;
/*     */ 
/*     */ public class Double_Integral extends PApplet
/*     */ {
/*     */   float axes_centre_x;
/*     */   float axes_centre_y;
/*     */   float axes_centre_z;
/*     */   float x_axes_length;
/*     */   float y_axes_length;
/*     */   float z_axes_length;
/*     */   boolean rotate_cam_y;
/*     */   boolean rotate_cam_x;
/*     */   float rotate_y;
/*     */   float rotate_x;
/*     */   float rotate_speed;
/*     */   float surface_res;
/*     */   float stretchFactor;
/*     */   float transformx;
/*     */   float transformy;
/*     */   float transformz;
/*     */   float area_pos_x;
/*     */   float area_pos_y;
/*     */   float area_size;
/*     */   float speed;
/*     */   float scale_speed;
/*     */   float dotted_line_length;
/*     */   PFont font;
/*     */   boolean const_surface;
/*     */   float surface_height;
/*     */   float animate_speed;
/*     */   Double_Integral.ToggleButton tbAnimate;
/*     */   Double_Integral.Button btnXminus;
/*     */   Double_Integral.Button btnXplus;
/*     */   Double_Integral.Button btnYminus;
/*     */   Double_Integral.Button btnYplus;
/*     */ 
/*     */   public void reset()
/*     */   {
/*  39 */     this.rotate_cam_y = false;
/*  40 */     this.rotate_cam_x = false;
/*  41 */     this.rotate_y = 0.0F;
/*  42 */     this.rotate_x = 0.0F;
/*  43 */     this.area_pos_x = (this.x_axes_length / 2.0F);
/*  44 */     this.area_pos_y = (this.y_axes_length / 2.0F);
/*  45 */     this.area_size = 80.0F;
/*  46 */     this.const_surface = false;
/*  47 */     this.surface_height = 200.0F;
/*  48 */     this.tbAnimate.value = false;
/*     */   }
/*     */ 
/*     */   public void setup()
/*     */   {
/*  54 */     size(640, 480, "processing.core.PGraphics3");
/*  55 */     background(255.0F, 255.0F, 255.0F);
/*  56 */     stroke(0.0F, 0.0F, 0.0F);
/*  57 */     framerate(60.0F);
/*  58 */     this.font = loadFont("Arial-Black-20.vlw");
/*  59 */     textFont(this.font, 20.0F);
/*     */ 
/*  61 */     this.tbAnimate = new Double_Integral.ToggleButton(400, 10, 200, 20, "Animate f(x,y) = ");
/*  62 */     this.btnXminus = new Double_Integral.Button(510, 370, 30, 30, "-x");
/*  63 */     this.btnXplus = new Double_Integral.Button(575, 370, 30, 30, "+x");
/*  64 */     this.btnYplus = new Double_Integral.Button(542, 330, 30, 30, "+y");
/*  65 */     this.btnYminus = new Double_Integral.Button(542, 410, 30, 30, "-y");
/*     */   }
/*     */ 
/*     */   public void keyPressed()
/*     */   {
/*  70 */     if (this.key == 'r')
/*     */     {
/*  72 */       reset();
/*     */     }
/*  74 */     if ((this.keyCode == 40) && 
/*  76 */       (this.area_pos_y + this.area_size + this.speed <= this.y_axes_length)) this.area_pos_y += this.speed;
/*     */ 
/*  78 */     if ((this.keyCode == 38) && 
/*  80 */       (this.area_pos_y - this.speed >= 0.0F)) this.area_pos_y -= this.speed;
/*     */ 
/*  82 */     if ((this.keyCode == 39) && 
/*  84 */       (this.area_pos_x + this.area_size + this.speed <= this.x_axes_length)) this.area_pos_x += this.speed;
/*     */ 
/*  86 */     if ((this.keyCode == 37) && 
/*  88 */       (this.area_pos_x - this.speed >= 0.0F)) this.area_pos_x -= this.speed;
/*     */ 
/*  90 */     if (this.keyCode != 10)
/*     */       return;
/*  92 */     if (this.const_surface) { this.const_surface = false; } else { this.const_surface = true; this.surface_height = 200.0F;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void mousePressed()
/*     */   {
/*  98 */     if (this.mouseButton == 39)
/*     */     {
/* 100 */       this.rotate_cam_y = true;
/* 101 */       this.rotate_cam_x = true;
/*     */     }
/*     */ 
/* 104 */     if (this.mouseButton != 37)
/*     */       return;
/* 106 */     this.tbAnimate.processMouseDown();
/* 107 */     this.btnXminus.processMouseDown();
/* 108 */     this.btnXplus.processMouseDown();
/* 109 */     this.btnYplus.processMouseDown();
/* 110 */     this.btnYminus.processMouseDown();
/*     */   }
/*     */ 
/*     */   public void mouseReleased()
/*     */   {
/* 116 */     this.rotate_cam_y = false;
/* 117 */     this.rotate_cam_x = false;
/*     */ 
/* 119 */     if (this.mouseButton != 37)
/*     */       return;
/* 121 */     this.btnXminus.processMouseUp();
/* 122 */     this.btnXplus.processMouseUp();
/* 123 */     this.btnYplus.processMouseUp();
/* 124 */     this.btnYminus.processMouseUp();
/*     */   }
/*     */ 
/*     */   public float actualFunction(float paramFloat1, float paramFloat2)
/*     */   {
/* 131 */     return (-paramFloat1 * paramFloat1 * 3 * paramFloat2);
/*     */   }
/*     */ 
/*     */   public float f(float paramFloat1, float paramFloat2)
/*     */   {
/* 136 */     if (this.const_surface)
/*     */     {
/* 138 */       return this.surface_height;
/*     */     }
/*     */ 
/* 142 */     return (this.stretchFactor * actualFunction(paramFloat1 + this.transformx, paramFloat2 + this.transformy) + this.transformz);
/*     */   }
/*     */ 
/*     */   public void draw()
/*     */   {
/* 148 */     background(255.0F, 255.0F, 255.0F);
/*     */ 
/* 150 */     this.tbAnimate.draw();
/* 151 */     textSize(13.0F);
/* 152 */     stroke(0);
/* 153 */     fill(0);
/* 154 */     this.const_surface = this.tbAnimate.value;
/* 155 */     if (this.const_surface) text((int)this.surface_height, 530.0F, 25.0F, 0.0F); else text("constant", 530.0F, 25.0F, 0.0F);
/*     */ 
/* 157 */     this.btnXminus.draw();
/* 158 */     this.btnXplus.draw();
/* 159 */     this.btnYminus.draw();
/* 160 */     this.btnYplus.draw();
/*     */ 
/* 162 */     if ((this.btnYminus.value) && 
/* 164 */       (this.area_pos_y + this.area_size + this.speed <= this.y_axes_length)) this.area_pos_y += this.speed;
/*     */ 
/* 166 */     if ((this.btnYplus.value) && 
/* 168 */       (this.area_pos_y - this.speed >= 0.0F)) this.area_pos_y -= this.speed;
/*     */ 
/* 170 */     if ((this.btnXplus.value) && 
/* 172 */       (this.area_pos_x + this.area_size + this.speed <= this.x_axes_length)) this.area_pos_x += this.speed;
/*     */ 
/* 174 */     if ((this.btnXminus.value) && 
/* 176 */       (this.area_pos_x - this.speed >= 0.0F)) this.area_pos_x -= this.speed;
/*     */ 
/* 180 */     stroke(0); fill(0);
/* 181 */     translate(this.axes_centre_x, this.axes_centre_y, this.axes_centre_z);
/* 182 */     translate(this.x_axes_length / 2.0F, -this.y_axes_length / 2.0F, this.z_axes_length / 2.0F);
/* 183 */     if (this.rotate_cam_y)
/*     */     {
/* 185 */       if (this.mouseX - this.pmouseX > 0.0F) this.rotate_y += this.rotate_speed;
/* 186 */       if (this.mouseX - this.pmouseX < 0.0F) this.rotate_y -= this.rotate_speed;
/* 187 */       if (this.rotate_y >= 6.283186F) this.rotate_y = 0.0F;
/*     */     }
/* 189 */     if (this.rotate_cam_x)
/*     */     {
/* 191 */       if (this.mouseY - this.pmouseY > 0.0F) this.rotate_x -= this.rotate_speed;
/* 192 */       if (this.mouseY - this.pmouseY < 0.0F) this.rotate_x += this.rotate_speed;
/* 193 */       if (this.rotate_x >= 6.283186F) this.rotate_x = 0.0F;
/*     */     }
/* 195 */     rotateX(this.rotate_x);
/* 196 */     rotateY(this.rotate_y);
/* 197 */     translate(-this.x_axes_length / 2.0F, this.y_axes_length / 2.0F, -this.z_axes_length / 2.0F);
/* 198 */     line(0.0F, 0.0F, 0.0F, this.x_axes_length, 0.0F, 0.0F);
/* 199 */     line(0.0F, 0.0F, 0.0F, 0.0F, -this.y_axes_length, 0.0F);
/* 200 */     line(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, this.z_axes_length);
/* 201 */     text("z", 0.0F, -this.y_axes_length - 20.0F, 0.0F);
/* 202 */     text("x", this.x_axes_length + 20.0F, 0.0F, 0.0F);
/* 203 */     text("y", 0.0F, 0.0F, this.z_axes_length + 20.0F);
/*     */ 
/* 206 */     if ((this.const_surface) && (this.surface_height > 1.0F)) this.surface_height -= this.animate_speed;
/* 207 */     stroke(100.0F, 100.0F, 100.0F, 70.0F);
/* 208 */     for (float f1 = 0.0F; f1 < this.x_axes_length; f1 += this.surface_res)
/*     */     {
/* 210 */       for (float f2 = 0.0F; f2 < this.y_axes_length; f2 += this.surface_res)
/*     */       {
/* 213 */         line(f1, -f(f1, f2), f2, f1 + this.surface_res, -f(f1 + this.surface_res, f2), f2);
/* 214 */         line(f1, -f(f1, f2), f2, f1, -f(f1, f2 + this.surface_res), f2 + this.surface_res);
/* 215 */         line(f1 + this.surface_res, -f(f1 + this.surface_res, f2), f2, f1 + this.surface_res, -f(f1 + this.surface_res, f2 + this.surface_res), f2 + this.surface_res);
/* 216 */         line(f1, -f(f1, f2 + this.surface_res), f2 + this.surface_res, f1 + this.surface_res, -f(f1 + this.surface_res, f2 + this.surface_res), f2 + this.surface_res);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 225 */     stroke(0.0F, 0.0F, 0.0F);
/* 226 */     line(this.area_pos_x, 0.0F, this.area_pos_y, this.area_pos_x + this.area_size, 0.0F, this.area_pos_y);
/* 227 */     line(this.area_pos_x, 0.0F, this.area_pos_y, this.area_pos_x, 0.0F, this.area_pos_y + this.area_size);
/* 228 */     line(this.area_pos_x + this.area_size, 0.0F, this.area_pos_y, this.area_pos_x + this.area_size, 0.0F, this.area_pos_y + this.area_size);
/* 229 */     line(this.area_pos_x, 0.0F, this.area_pos_y + this.area_size, this.area_pos_x + this.area_size, 0.0F, this.area_pos_y + this.area_size);
/*     */ 
/* 232 */     stroke(0);
/* 233 */     f1 = 0.0F;
/* 234 */     f1 = this.area_pos_x;
/* 235 */     while (f1 > 0.0F)
/*     */     {
/* 237 */       line(f1, 0.0F, this.area_pos_y, f1 - this.dotted_line_length, 0.0F, this.area_pos_y);
/* 238 */       line(f1, 0.0F, this.area_pos_y + this.area_size, f1 - this.dotted_line_length, 0.0F, this.area_pos_y + this.area_size);
/* 239 */       f1 -= this.dotted_line_length * 2.0F;
/*     */     }
/* 241 */     f1 = this.area_pos_y;
/* 242 */     while (f1 > 0.0F)
/*     */     {
/* 244 */       line(this.area_pos_x, 0.0F, f1, this.area_pos_x, 0.0F, f1 - this.dotted_line_length);
/* 245 */       line(this.area_pos_x + this.area_size, 0.0F, f1, this.area_pos_x + this.area_size, 0.0F, f1 - this.dotted_line_length);
/* 246 */       f1 -= this.dotted_line_length * 2.0F;
/*     */     }
/*     */ 
/* 250 */     stroke(0);
/* 251 */     f1 = f(this.area_pos_x, this.area_pos_y);
/* 252 */     while (f1 > 0.0F)
/*     */     {
/* 254 */       line(this.area_pos_x, -f1, this.area_pos_y, this.area_pos_x, -f1 + this.dotted_line_length, this.area_pos_y);
/* 255 */       f1 -= this.dotted_line_length * 2.0F;
/*     */     }
/* 257 */     f1 = f(this.area_pos_x + this.area_size, this.area_pos_y);
/* 258 */     while (f1 > 0.0F)
/*     */     {
/* 260 */       line(this.area_pos_x + this.area_size, -f1, this.area_pos_y, this.area_pos_x + this.area_size, -f1 + this.dotted_line_length, this.area_pos_y);
/* 261 */       f1 -= this.dotted_line_length * 2.0F;
/*     */     }
/* 263 */     f1 = f(this.area_pos_x, this.area_pos_y + this.area_size);
/* 264 */     while (f1 > 0.0F)
/*     */     {
/* 266 */       line(this.area_pos_x, -f1, this.area_pos_y + this.area_size, this.area_pos_x, -f1 + this.dotted_line_length, this.area_pos_y + this.area_size);
/* 267 */       f1 -= this.dotted_line_length * 2.0F;
/*     */     }
/* 269 */     f1 = f(this.area_pos_x + this.area_size, this.area_pos_y + this.area_size);
/* 270 */     while (f1 > 0.0F)
/*     */     {
/* 272 */       line(this.area_pos_x + this.area_size, -f1, this.area_pos_y + this.area_size, this.area_pos_x + this.area_size, -f1 + this.dotted_line_length, this.area_pos_y + this.area_size);
/* 273 */       f1 -= this.dotted_line_length * 2.0F;
/*     */     }
/*     */ 
/* 277 */     for (f1 = this.area_pos_x; f1 < this.area_pos_x + this.area_size; f1 += this.surface_res)
/*     */     {
/* 279 */       line(f1, -f(f1, this.area_pos_y), this.area_pos_y, f1 + this.surface_res, -f(f1 + this.surface_res, this.area_pos_y), this.area_pos_y);
/* 280 */       line(f1, -f(f1, this.area_pos_y + this.area_size), this.area_pos_y + this.area_size, f1 + this.surface_res, -f(f1 + this.surface_res, this.area_pos_y + this.area_size), this.area_pos_y + this.area_size);
/*     */     }
/* 282 */     for (f1 = this.area_pos_y; f1 < this.area_pos_y + this.area_size; f1 += this.surface_res)
/*     */     {
/* 284 */       line(this.area_pos_x, -f(this.area_pos_x, f1), f1, this.area_pos_x, -f(this.area_pos_x, f1 + this.surface_res), f1 + this.surface_res);
/* 285 */       line(this.area_pos_x + this.area_size, -f(this.area_pos_x + this.area_size, f1), f1, this.area_pos_x + this.area_size, -f(this.area_pos_x + this.area_size, f1 + this.surface_res), f1 + this.surface_res);
/*     */     }
/*     */   }
/*     */ 
/*     */   private final void jdMethod_this()
/*     */   {
/*   4 */     this.axes_centre_x = 150.0F;
/*   5 */     this.axes_centre_y = 400.0F;
/*   6 */     this.axes_centre_z = -300.0F;
/*   7 */     this.x_axes_length = 365.0F;
/*   8 */     this.y_axes_length = 365.0F;
/*   9 */     this.z_axes_length = 365.0F;
/*  10 */     this.rotate_cam_y = false;
/*  11 */     this.rotate_cam_x = false;
/*  12 */     this.rotate_y = 0.0F;
/*  13 */     this.rotate_x = 0.0F;
/*  14 */     this.rotate_speed = 0.05F;
/*  15 */     this.surface_res = 10.0F;
/*  16 */     this.stretchFactor = 7.E-06F;
/*  17 */     this.transformx = -150.0F;
/*  18 */     this.transformy = -140.0F;
/*  19 */     this.transformz = 150.0F;
/*  20 */     this.area_pos_x = (this.x_axes_length / 2.0F);
/*  21 */     this.area_pos_y = (this.y_axes_length / 2.0F);
/*  22 */     this.area_size = 80.0F;
/*  23 */     this.speed = 10.1F;
/*  24 */     this.scale_speed = 2.0F;
/*  25 */     this.dotted_line_length = 5;
/*     */ 
/*  27 */     this.const_surface = false;
/*  28 */     this.surface_height = 200.0F;
/*  29 */     this.animate_speed = 1.0F;
/*     */   }
/*     */ 
/*     */   public Double_Integral()
/*     */   {
/*   1 */     jdMethod_this();
/*     */   }
/*     */ 
/*     */   class ToggleButton
/*     */   {
/*     */     public boolean value;
/*     */     public String msg;
/*     */     public int x;
/*     */     public int y;
/*     */     public int w;
/*     */     public int h;
/*     */ 
/*     */     public void draw()
/*     */     {
/* 299 */       Double_Integral.this.pushMatrix();
/* 300 */       Double_Integral.this.translate(this.x, this.y);
/* 301 */       if (this.value) {
/* 302 */         Double_Integral.this.fill(250.0F, 130.0F, 20.0F);
/* 303 */         Double_Integral.this.stroke(0);
/* 304 */         Double_Integral.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/*     */       else
/*     */       {
/* 312 */         Double_Integral.this.fill(255.0F, 255.0F, 255.0F);
/* 313 */         Double_Integral.this.stroke(0);
/* 314 */         Double_Integral.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/* 316 */       Double_Integral.this.rect(0.0F, 0.0F, this.w, this.h);
/* 317 */       Double_Integral.this.noStroke();
/* 318 */       Double_Integral.this.fill(255.0F, 255.0F, 255.0F);
/* 319 */       Double_Integral.this.rect(2.0F, 2.0F, this.w - 4, this.h - 4);
/*     */ 
/* 321 */       Double_Integral.this.fill(0);
/*     */ 
/* 323 */       Double_Integral.this.textSize(13.0F);
/* 324 */       Double_Integral.this.text(this.msg, 5, this.h - 5);
/*     */ 
/* 326 */       Double_Integral.this.popMatrix();
/*     */     }
/*     */ 
/*     */     public void processMouseDown() {
/* 330 */       int i = Double_Integral.this.mouseX - this.x;
/* 331 */       int j = Double_Integral.this.mouseY - this.y;
/*     */ 
/* 333 */       if ((i < 0) || (i > this.w) || 
/* 334 */         (j < 0) || (j > this.h)) return;
/* 335 */       this.value ^= true;
/*     */ 
/* 337 */       if (!(this.value)) return; Double_Integral.this.surface_height = 200.0F;
/*     */     }
/*     */ 
/*     */     private final void jdMethod_this()
/*     */     {
/* 342 */       this.value = false;
/*     */     }
/*     */ 
/*     */     public ToggleButton(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString)
/*     */     {
/* 290 */       jdMethod_this();
/* 291 */       this.x = paramInt1;
/* 292 */       this.y = paramInt2;
/* 293 */       this.w = paramInt3;
/* 294 */       this.h = paramInt4;
/* 295 */       this.msg = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */   class Button
/*     */   {
/*     */     public boolean value;
/*     */     public String msg;
/*     */     public int x;
/*     */     public int y;
/*     */     public int w;
/*     */     public int h;
/*     */ 
/*     */     public void draw()
/*     */     {
/* 362 */       Double_Integral.this.rectMode(0);
/* 363 */       Double_Integral.this.pushMatrix();
/* 364 */       Double_Integral.this.translate(this.x, this.y);
/* 365 */       if (this.value) {
/* 366 */         Double_Integral.this.fill(250.0F, 130.0F, 20.0F);
/* 367 */         Double_Integral.this.stroke(0);
/* 368 */         Double_Integral.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/*     */       else
/*     */       {
/* 376 */         Double_Integral.this.fill(255.0F, 255.0F, 255.0F);
/* 377 */         Double_Integral.this.stroke(0);
/* 378 */         Double_Integral.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/* 380 */       Double_Integral.this.rect(0.0F, 0.0F, this.w, this.h);
/* 381 */       Double_Integral.this.noStroke();
/* 382 */       Double_Integral.this.fill(255.0F, 255.0F, 255.0F);
/* 383 */       Double_Integral.this.rect(2.0F, 2.0F, this.w - 4, this.h - 4);
/*     */ 
/* 385 */       Double_Integral.this.fill(0);
/*     */ 
/* 387 */       Double_Integral.this.textSize(19.0F);
/* 388 */       Double_Integral.this.text(this.msg, 5, this.h - 8);
/*     */ 
/* 390 */       Double_Integral.this.popMatrix();
/*     */     }
/*     */ 
/*     */     public void processMouseDown() {
/* 394 */       int i = Double_Integral.this.mouseX - this.x;
/* 395 */       int j = Double_Integral.this.mouseY - this.y;
/*     */ 
/* 397 */       if ((i < 0) || (i > this.w) || 
/* 398 */         (j < 0) || (j > this.h)) return;
/* 399 */       this.value = true;
/*     */     }
/*     */ 
/*     */     public void processMouseUp()
/*     */     {
/* 405 */       if (this.value)
/* 406 */         this.value = false;
/*     */     }
/*     */ 
/*     */     private final void jdMethod_this() {
/* 410 */       this.value = false;
/*     */     }
/*     */ 
/*     */     public Button(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString)
/*     */     {
/* 353 */       jdMethod_this();
/* 354 */       this.x = paramInt1;
/* 355 */       this.y = paramInt2;
/* 356 */       this.w = paramInt3;
/* 357 */       this.h = paramInt4;
/* 358 */       this.msg = paramString;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/mfeyereisen/applets-final/classes/
 * Qualified Name:     Double_Integral
 * JD-Core Version:    0.5.3
 */