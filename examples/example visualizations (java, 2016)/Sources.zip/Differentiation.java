/*     */ import processing.core.PApplet;
/*     */ 
/*     */ public class Differentiation extends PApplet
/*     */ {
/*     */   float stretchFactor;
/*     */   float transformx;
/*     */   float transformy;
/*     */   float x_axes_length;
/*     */   float y_axes_length;
/*     */   float axes_centre_x;
/*     */   float axes_centre_y;
/*     */   float line_smoothness;
/*     */   float grad_x_coord;
/*     */   float lineGradient;
/*     */   float curveGradient;
/*     */   float deltaX;
/*     */   float infinitesimal_x;
/*     */   float tangent_length;
/*     */   float dotted_line_length;
/*     */   float move_speed;
/*     */   float scale_speed;
/*     */   int draggable;
/*     */   int dragging;
/*     */ 
/*     */   public void setup()
/*     */   {
/*  32 */     size(640, 480, "processing.core.PGraphics3");
/*  33 */     background(255.0F, 255.0F, 255.0F);
/*  34 */     stroke(0.0F, 0.0F, 0.0F);
/*  35 */     framerate(60.0F);
/*     */   }
/*     */ 
/*     */   public float actualFunction(float paramFloat)
/*     */   {
/*  43 */     return (paramFloat * paramFloat * paramFloat);
/*     */   }
/*     */ 
/*     */   public float f(float paramFloat)
/*     */   {
/*  49 */     return (this.stretchFactor * actualFunction(paramFloat + this.transformx) + this.transformy);
/*     */   }
/*     */ 
/*     */   public boolean inBounds(float paramFloat)
/*     */   {
/*  57 */     return ((paramFloat >= 0.0F) && (paramFloat <= this.x_axes_length) && (f(paramFloat) >= 0.0F) && (f(paramFloat) <= this.y_axes_length));
/*     */   }
/*     */ 
/*     */   public float fgrad(float paramFloat)
/*     */   {
/*  68 */     float f = f(this.grad_x_coord) - (this.lineGradient * this.grad_x_coord);
/*     */ 
/*  70 */     return (this.lineGradient * paramFloat + f);
/*     */   }
/*     */ 
/*     */   public void keyPressed()
/*     */   {
/*  75 */     if (this.key == ' ') {
/*  76 */       println(mag(this.mouseX - this.grad_x_coord + this.deltaX - this.axes_centre_x, this.mouseY + f(this.grad_x_coord + this.deltaX) - this.axes_centre_y));
/*     */     }
/*  78 */     else if (this.keyCode == 39)
/*     */     {
/*  80 */       if ((inBounds(this.grad_x_coord + this.move_speed)) && (inBounds(this.grad_x_coord + this.deltaX + this.move_speed)))
/*     */       {
/*  82 */         this.grad_x_coord += this.move_speed;
/*     */       }
/*     */     }
/*  85 */     else if (this.keyCode == 37)
/*     */     {
/*  87 */       if ((inBounds(this.grad_x_coord - this.move_speed)) && (inBounds(this.grad_x_coord + this.deltaX - this.move_speed)))
/*     */       {
/*  89 */         this.grad_x_coord -= this.move_speed;
/*     */       }
/*     */     }
/*  92 */     else if (this.keyCode == 40)
/*     */     {
/*  94 */       if (this.deltaX - this.scale_speed > 0.0F)
/*     */       {
/*  96 */         this.deltaX -= this.scale_speed;
/*     */       }
/*     */     } else {
/*  99 */       if ((this.keyCode != 38) || 
/* 101 */         (!(inBounds(this.grad_x_coord + this.deltaX + this.scale_speed))))
/*     */         return;
/* 103 */       this.deltaX += this.scale_speed;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void checkDraggable()
/*     */   {
/* 111 */     if (mag(this.mouseX - this.grad_x_coord - this.axes_centre_x, this.mouseY + f(this.grad_x_coord) - this.axes_centre_y) < 8.0F) {
/* 112 */       this.draggable = -1;
/*     */     }
/* 114 */     else if (mag(this.mouseX - this.grad_x_coord - this.deltaX - this.axes_centre_x, this.mouseY + f(this.grad_x_coord + this.deltaX) - this.axes_centre_y) < 8.0F)
/* 115 */       this.draggable = 1;
/*     */     else
/* 117 */       this.draggable = 0;
/*     */   }
/*     */ 
/*     */   public void updateCursor()
/*     */   {
/* 122 */     if (this.draggable != 0) {
/* 123 */       cursor(12);
/*     */     }
/*     */     else
/*     */     {
/* 127 */       cursor(0);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void mousePressed() {
/* 132 */     if (this.draggable != 0)
/* 133 */       this.dragging = this.draggable;
/*     */   }
/*     */ 
/*     */   public void mouseReleased()
/*     */   {
/* 138 */     this.dragging = 0;
/*     */   }
/*     */ 
/*     */   public void updatePositions() {
/* 142 */     if (this.dragging != 0) {
/* 143 */       float f1 = this.mouseX - this.axes_centre_x;
/* 144 */       float f2 = this.grad_x_coord + this.deltaX;
/* 145 */       if ((this.dragging == -1) && 
/* 146 */         (inBounds(f1)) && (f1 < f2)) {
/* 147 */         this.grad_x_coord = f1;
/* 148 */         this.deltaX = (f2 - this.grad_x_coord);
/*     */       }
/*     */ 
/* 152 */       if ((this.dragging != 1) || 
/* 153 */         (!(inBounds(f1))) || (f1 <= this.grad_x_coord)) return;
/* 154 */       this.deltaX = (f1 - this.grad_x_coord);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void draw()
/*     */   {
/* 162 */     background(255.0F, 255.0F, 255.0F);
/*     */ 
/* 164 */     checkDraggable();
/* 165 */     updateCursor();
/* 166 */     updatePositions();
/*     */ 
/* 173 */     translate(this.axes_centre_x, this.axes_centre_y, 0.0F);
/* 174 */     stroke(20.0F, 200.0F, 20.0F);
/* 175 */     line(0.0F, -this.y_axes_length, 0.0F, 0.0F, 0.0F, 0.0F);
/* 176 */     stroke(200.0F, 20.0F, 20.0F);
/* 177 */     line(0.0F, 0.0F, 0.0F, this.x_axes_length, 0.0F, 0.0F);
/*     */ 
/* 179 */     stroke(0);
/*     */ 
/* 181 */     float f1 = 0.0F;
/* 182 */     float f2 = this.x_axes_length / this.line_smoothness;
/* 183 */     while ((f(f1) < this.y_axes_length) && (f1 < this.x_axes_length))
/*     */     {
/* 185 */       if ((inBounds(f1)) && (inBounds(f1 + f2)))
/*     */       {
/* 187 */         line(f1, -f(f1), 0.0F, f1 + f2, -f(f1 + f2), 0.0F);
/*     */       }
/* 189 */       f1 += f2;
/*     */     }
/*     */ 
/* 193 */     this.lineGradient = ((f(this.grad_x_coord + this.deltaX) - f(this.grad_x_coord)) / this.deltaX);
/* 194 */     this.curveGradient = ((f(this.grad_x_coord + this.infinitesimal_x) - f(this.grad_x_coord)) / this.infinitesimal_x);
/*     */ 
/* 197 */     stroke(0.0F, 0.0F, 255.0F);
/* 198 */     line(this.grad_x_coord, -f(this.grad_x_coord), 0.0F, this.grad_x_coord + this.deltaX, -f(this.grad_x_coord + this.deltaX), 0.0F);
/*     */ 
/* 200 */     stroke(0);
/*     */ 
/* 202 */     line(this.grad_x_coord + this.deltaX, -f(this.grad_x_coord + this.deltaX), 0.0F, this.grad_x_coord + this.deltaX, -f(this.grad_x_coord), 0.0F);
/*     */ 
/* 205 */     line(this.grad_x_coord + this.deltaX, -f(this.grad_x_coord), 0.0F, this.grad_x_coord, -f(this.grad_x_coord), 0.0F);
/*     */ 
/* 208 */     stroke(20.0F, 20.0F, 200.0F);
/* 209 */     line(this.grad_x_coord + this.deltaX + this.tangent_length, -fgrad(this.grad_x_coord + this.deltaX + this.tangent_length), 0.0F, this.grad_x_coord + this.deltaX, -f(this.grad_x_coord + this.deltaX), 0.0F);
/* 210 */     line(this.grad_x_coord - this.tangent_length, -fgrad(this.grad_x_coord - this.tangent_length), 0.0F, this.grad_x_coord, -f(this.grad_x_coord), 0.0F);
/* 211 */     stroke(0);
/*     */ 
/* 214 */     float f3 = this.grad_x_coord;
/* 215 */     while (f3 >= 0.0F)
/*     */     {
/* 217 */       line(f3, -f(this.grad_x_coord), 0.0F, f3 - this.dotted_line_length, -f(this.grad_x_coord), 0.0F);
/* 218 */       f3 -= this.dotted_line_length * 2.0F;
/*     */     }
/*     */ 
/* 221 */     f3 = this.grad_x_coord + this.deltaX;
/* 222 */     while (f3 >= 0.0F)
/*     */     {
/* 224 */       line(f3, -f(this.grad_x_coord + this.deltaX), 0.0F, f3 - this.dotted_line_length, -f(this.grad_x_coord + this.deltaX), 0.0F);
/* 225 */       f3 -= this.dotted_line_length * 2.0F;
/*     */     }
/*     */ 
/* 228 */     f3 = f(this.grad_x_coord);
/* 229 */     while (f3 >= 0.0F)
/*     */     {
/* 231 */       line(this.grad_x_coord, -f3, 0.0F, this.grad_x_coord, -(f3 - this.dotted_line_length), 0.0F);
/* 232 */       f3 -= this.dotted_line_length * 2.0F;
/*     */     }
/*     */ 
/* 235 */     f3 = f(this.grad_x_coord + this.deltaX);
/* 236 */     while (f3 >= 0.0F)
/*     */     {
/* 238 */       line(this.grad_x_coord + this.deltaX, -f3, 0.0F, this.grad_x_coord + this.deltaX, -(f3 - this.dotted_line_length), 0.0F);
/* 239 */       f3 -= this.dotted_line_length * 2.0F;
/*     */     }
/*     */   }
/*     */ 
/*     */   private final void jdMethod_this()
/*     */   {
/*   4 */     this.stretchFactor = 5.0E-05F;
/*   5 */     this.transformx = -150.0F;
/*   6 */     this.transformy = 140.0F;
/*   7 */     this.x_axes_length = 365.0F;
/*   8 */     this.y_axes_length = 350.0F;
/*   9 */     this.axes_centre_x = 140.0F;
/*  10 */     this.axes_centre_y = 410.0F;
/*  11 */     this.line_smoothness = 500.0F;
/*  12 */     this.grad_x_coord = (this.x_axes_length / 2.0F);
/*  13 */     this.lineGradient = 0.0F;
/*  14 */     this.curveGradient = 0.0F;
/*  15 */     this.deltaX = 80.0F;
/*  16 */     this.infinitesimal_x = 1.0E-04F;
/*  17 */     this.tangent_length = 100.0F;
/*  18 */     this.dotted_line_length = 5;
/*  19 */     this.move_speed = 2.1F;
/*  20 */     this.scale_speed = 2.0F;
/*     */ 
/*  27 */     this.draggable = 0;
/*  28 */     this.dragging = 0;
/*     */   }
/*     */ 
/*     */   public Differentiation()
/*     */   {
/*   1 */     jdMethod_this();
/*     */   }
/*     */ }

/* Location:           /Users/mfeyereisen/applets-final/classes/
 * Qualified Name:     Differentiation
 * JD-Core Version:    0.5.3
 */