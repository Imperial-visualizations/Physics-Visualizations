/*     */ import processing.core.PApplet;
/*     */ import processing.core.PFont;
/*     */ 
/*     */ public class c2fig29 extends PApplet
/*     */ {
/*     */   float rotZ;
/*     */   float rotX;
/*     */   PFont font;
/*     */   int gridRes;
/*     */   boolean dragL;
/*     */   boolean dragR;
/*     */   int downL;
/*     */   int downRX;
/*     */   int downRY;
/*     */   boolean running;
/*     */   float zoom;
/*     */   boolean XThenY;
/*     */   boolean persp;
/*     */   float t;
/*     */   float minX;
/*     */   float maxX;
/*     */   float minY;
/*     */   float maxY;
/*     */   float dx;
/*     */   float dy;
/*     */   c2fig29.RadioGroup rgOrder;
/*     */   c2fig29.ToggleButton tbRunning;
/*     */   c2fig29.Button btnReset;
/*     */   PFont Tahoma14;
/*     */ 
/*     */   public void setup()
/*     */   {
/*  49 */     this.Tahoma14 = loadFont("Tahoma-14.vlw");
/*     */ 
/*  52 */     size(640, 480, "processing.core.PGraphics3");
/*  53 */     String[] arrayOfString = { "X, then Y", "Y, then X" };
/*     */ 
/*  56 */     this.rgOrder = new c2fig29.RadioGroup(520, 30, arrayOfString, 0);
/*  57 */     this.tbRunning = new c2fig29.ToggleButton(520, 70, 110, 20, "Run animation");
/*  58 */     this.btnReset = new c2fig29.Button(520, 100, 110, 20, "Reset");
/*  59 */     reset();
/*     */   }
/*     */ 
/*     */   public void draw()
/*     */   {
/*  64 */     this.running = this.tbRunning.value;
/*  65 */     lights();
/*  66 */     background(255);
/*     */ 
/*  68 */     updateRotation();
/*  69 */     updateTime();
/*  70 */     updateOrder();
/*     */ 
/*  72 */     pushMatrix();
/*     */ 
/*  74 */     translate(this.width / 2, this.height / 2);
/*     */ 
/*  76 */     int i = -1;
/*     */ 
/*  97 */     pushMatrix();
/*     */ 
/* 102 */     pushMatrix();
/*     */ 
/* 105 */     scale(42.0F, -42.0F, 42.0F);
/*     */ 
/* 108 */     rotateX(this.rotX);
/* 109 */     rotateZ(this.rotZ);
/*     */ 
/* 111 */     translate(0.0F, 0.0F, -2.0F);
/*     */ 
/* 113 */     drawAxes();
/* 114 */     drawSurface();
/* 115 */     drawTiles();
/*     */ 
/* 117 */     popMatrix();
/* 118 */     popMatrix();
/* 119 */     popMatrix();
/*     */ 
/* 121 */     this.rgOrder.draw();
/* 122 */     this.tbRunning.draw();
/* 123 */     this.btnReset.draw();
/*     */ 
/* 125 */     textFont(this.Tahoma14, 14.0F);
/* 126 */     fill(0);
/* 127 */     stroke(0);
/* 128 */     text("Integration order:", 520.0F, 20.0F);
/* 129 */     stroke(0);
/* 130 */     line(520.0F, 25.0F, 630.0F, 25.0F);
/*     */   }
/*     */ 
/*     */   public void updateOrder()
/*     */   {
/* 135 */     if (this.rgOrder._selected == 0) {
/* 136 */       this.XThenY = true;
/*     */     }
/*     */     else
/* 139 */       this.XThenY = false;
/*     */   }
/*     */ 
/*     */   public void mousePressed()
/*     */   {
/* 144 */     if (this.mouseButton == 37) {
/* 145 */       this.dragL = true;
/* 146 */       this.downL = this.mouseX;
/* 147 */       this.rgOrder.processMouseDown();
/* 148 */       this.tbRunning.processMouseDown();
/* 149 */       this.btnReset.processMouseDown();
/*     */     }
/* 151 */     else if (this.mouseButton == 39) {
/* 152 */       this.dragR = true;
/* 153 */       this.downRX = this.mouseX;
/* 154 */       this.downRY = this.mouseY;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void mouseReleased() {
/* 159 */     if (this.mouseButton == 37) {
/* 160 */       this.dragL = false;
/*     */ 
/* 162 */       this.btnReset.processMouseUp();
/*     */     }
/* 164 */     else if (this.mouseButton == 39) {
/* 165 */       this.dragR = false;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void keyPressed()
/*     */   {
/* 175 */     if (this.key == 'r') {
/* 176 */       reset();
/*     */     }
/* 178 */     else if (this.key == 'x') {
/* 179 */       this.rotZ = 1.570796F;
/* 180 */       this.rotX = -1.570796F;
/*     */     }
/* 182 */     else if (this.key == 'y') {
/* 183 */       this.rotZ = 3.141593F;
/* 184 */       this.rotX = -1.570796F;
/*     */     }
/* 186 */     else if (this.key == 'z') {
/* 187 */       this.rotZ = 0.0F;
/* 188 */       this.rotX = 0.0F;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updateRotation() {
/* 193 */     if (this.dragR) {
/* 194 */       this.rotZ += 6.283186F * (this.mouseX - this.downRX) / this.width;
/*     */ 
/* 196 */       this.rotX += 3.141593F * (this.mouseY - this.downRY) / this.height;
/*     */ 
/* 201 */       if (this.rotZ > 6.283186F) {
/* 202 */         this.rotZ -= 6.283186F;
/*     */       }
/* 204 */       else if (this.rotZ < 6.283186F) {
/* 205 */         this.rotZ += 6.283186F;
/*     */       }
/*     */ 
/* 209 */       if (this.rotX > 0.0F) {
/* 210 */         this.rotX = 0.0F;
/*     */       }
/* 212 */       else if (this.rotX < -3.141593F) {
/* 213 */         this.rotX = -3.141593F;
/*     */       }
/*     */ 
/* 226 */       this.downRX = this.mouseX;
/* 227 */       this.downRY = this.mouseY;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updateTime() {
/* 232 */     if (this.running)
/* 233 */       this.t += 0.2F;
/*     */   }
/*     */ 
/*     */   public void drawAxes()
/*     */   {
/* 238 */     strokeWeight(2.0F);
/* 239 */     stroke(200.0F, 20.0F, 20.0F, 200.0F);
/* 240 */     line(0.0F, 0.0F, 0.0F, 12.0F, 0.0F, 0.0F);
/* 241 */     stroke(0.0F, 150.0F, 0.0F, 200.0F);
/* 242 */     line(0.0F, 0.0F, 0.0F, 0.0F, 12.0F, 0.0F);
/* 243 */     stroke(20.0F, 20.0F, 200.0F, 200.0F);
/* 244 */     line(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 12.0F);
/* 245 */     strokeWeight(1.0F);
/*     */ 
/* 247 */     stroke(0.0F, 0.0F, 0.0F, 50.0F);
/*     */ 
/* 249 */     for (int i = -10 * this.gridRes; i <= 10 * this.gridRes; ++i)
/* 250 */       if (i != 0) {
/* 251 */         if (i % this.gridRes != 0) {
/* 252 */           line(i / this.gridRes, -10.0F, 0.0F, i / this.gridRes, 10.0F, 0.0F);
/* 253 */           line(-10.0F, i / this.gridRes, 0.0F, 10.0F, i / this.gridRes, 0.0F);
/*     */         }
/*     */         else
/*     */         {
/* 257 */           stroke(0.0F, 0.0F, 0.0F, 100.0F);
/* 258 */           line(i / this.gridRes, -10.0F, 0.0F, i / this.gridRes, 10.0F, 0.0F);
/* 259 */           line(-10.0F, i / this.gridRes, 0.0F, 10.0F, i / this.gridRes, 0.0F);
/* 260 */           stroke(0.0F, 0.0F, 0.0F, 50.0F);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 265 */         stroke(0.0F, 0.0F, 0.0F, 100.0F);
/* 266 */         line(i / this.gridRes, -10.0F, 0.0F, i / this.gridRes, 0.0F, 0.0F);
/* 267 */         line(-10.0F, i / this.gridRes, 0.0F, 0.0F, i / this.gridRes, 0.0F);
/* 268 */         stroke(0.0F, 0.0F, 0.0F, 50.0F);
/*     */       }
/*     */   }
/*     */ 
/*     */   public float surfaceFunction(float paramFloat1, float paramFloat2)
/*     */   {
/* 274 */     float f = 4 - (0.3F * paramFloat1 * paramFloat1) - (0.3F * paramFloat2 * paramFloat2);
/*     */ 
/* 276 */     return f;
/*     */   }
/*     */ 
/*     */   public int colorWheel(float paramFloat) {
/* 280 */     float f1 = 7.0F;
/* 281 */     float f2 = paramFloat / f1;
/* 282 */     float f3 = 255.0F;
/*     */ 
/* 284 */     float f4 = f2 * f3;
/*     */ 
/* 286 */     colorMode(3, 255.0F);
/* 287 */     int i = color(f4, 255.0F, 240.0F, 100.0F);
/* 288 */     colorMode(1, 255.0F);
/*     */ 
/* 290 */     return i;
/*     */   }
/*     */ 
/*     */   public void drawSurface() {
/* 294 */     strokeWeight(2.0F);
/* 295 */     stroke(0.0F, 0.0F, 0.0F, 100.0F);
/*     */ 
/* 297 */     for (float f1 = this.minY; f1 < this.maxY + this.dy; f1 += this.dy) {
/* 298 */       beginShape(33);
/*     */       float f3;
/* 299 */       for (float f2 = this.minX; f2 < this.maxX + this.dx; f2 += this.dx) {
/* 300 */         f3 = surfaceFunction(f2, f1);
/* 301 */         stroke(colorWheel(6.0F - f3));
/* 302 */         vertex(f2, f1, f3);
/*     */       }
/* 304 */       endShape();
/*     */ 
/* 306 */       beginShape(33);
/* 307 */       for (f2 = -2.0F; f2 < 2.1F; f2 += 0.1F) {
/* 308 */         f3 = surfaceFunction(f2, f1);
/* 309 */         stroke(colorWheel(6.0F - f3));
/* 310 */         vertex(f1, f2, f3);
/*     */       }
/* 312 */       endShape();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void drawTiles()
/*     */   {
/* 318 */     float f1 = (this.maxX - this.minX) / this.dx;
/*     */ 
/* 328 */     fill(50.0F, 50.0F, 50.0F, 150.0F);
/* 329 */     noStroke();
/*     */     int i;
/*     */     float f4;
/*     */     float f5;
/* 331 */     if ((int)this.t < f1 - 1.0F) {
/* 332 */       for (i = 0; i <= (int)this.t; ++i) {
/* 333 */         float f2 = this.minX + i * this.dx;
/* 334 */         float f3 = this.minX + (i + 1) * this.dx;
/* 335 */         f4 = this.minY;
/* 336 */         f5 = this.minY + this.dy;
/*     */ 
/* 338 */         beginShape(128);
/*     */ 
/* 340 */         if (this.XThenY) {
/* 341 */           vertex(f2, f4, surfaceFunction(f2, f4) - 0.05F);
/* 342 */           vertex(f2, f5, surfaceFunction(f2, f5) - 0.05F);
/* 343 */           vertex(f3, f5, surfaceFunction(f3, f5) - 0.05F);
/* 344 */           vertex(f3, f4, surfaceFunction(f3, f4) - 0.05F);
/*     */         }
/*     */         else {
/* 347 */           vertex(f4, f2, surfaceFunction(f4, f2) - 0.05F);
/* 348 */           vertex(f4, f3, surfaceFunction(f4, f3) - 0.05F);
/* 349 */           vertex(f5, f3, surfaceFunction(f5, f3) - 0.05F);
/* 350 */           vertex(f5, f2, surfaceFunction(f5, f2) - 0.05F);
/*     */         }
/* 352 */         endShape();
/*     */       }
/*     */     }
/*     */     else {
/* 356 */       i = (int)this.t - (int)f1 + 1;
/*     */ 
/* 358 */       if (i + 1 > (this.maxY - this.minY) / this.dy) {
/* 359 */         i = (int)((this.maxY - this.minY) / this.dy) - 1;
/* 360 */         this.running = false;
/*     */       }
/*     */ 
/* 363 */       for (int j = 0; j <= i; ++j)
/* 364 */         for (int k = 0; k < f1; ++k) {
/* 365 */           f4 = this.minX + k * this.dx;
/* 366 */           f5 = this.minX + (k + 1) * this.dx;
/* 367 */           float f6 = this.minY + j * this.dy;
/* 368 */           float f7 = this.minY + (j + 1) * this.dy;
/*     */ 
/* 370 */           beginShape(128);
/* 371 */           if (this.XThenY) {
/* 372 */             vertex(f4, f6, surfaceFunction(f4, f6) - 0.05F);
/* 373 */             vertex(f4, f7, surfaceFunction(f4, f7) - 0.05F);
/* 374 */             vertex(f5, f7, surfaceFunction(f5, f7) - 0.05F);
/* 375 */             vertex(f5, f6, surfaceFunction(f5, f6) - 0.05F);
/*     */           }
/*     */           else {
/* 378 */             vertex(f6, f4, surfaceFunction(f6, f4) - 0.05F);
/* 379 */             vertex(f6, f5, surfaceFunction(f6, f5) - 0.05F);
/* 380 */             vertex(f7, f5, surfaceFunction(f7, f5) - 0.05F);
/* 381 */             vertex(f7, f4, surfaceFunction(f7, f4) - 0.05F);
/*     */           }
/* 383 */           endShape();
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void reset()
/*     */   {
/* 390 */     this.rotZ = 0.5235988F;
/* 391 */     this.rotX = -0.7853982F;
/* 392 */     resetAnimation();
/* 393 */     this.rgOrder._selected = 0;
/* 394 */     this.tbRunning.value = false;
/*     */   }
/*     */ 
/*     */   public void resetAnimation() {
/* 398 */     this.t = 0.0F;
/*     */   }
/*     */ 
/*     */   private final void jdMethod_this()
/*     */   {
/*  12 */     this.rotZ = 3.141593F;
/*  13 */     this.rotX = 3.141593F;
/*     */ 
/*  16 */     this.gridRes = 5;
/*     */ 
/*  18 */     this.dragL = false;
/*  19 */     this.dragR = false;
/*  20 */     this.downL = 0;
/*  21 */     this.downRX = 0;
/*  22 */     this.downRY = 0;
/*     */ 
/*  24 */     this.running = false;
/*  25 */     this.zoom = 2.0F;
/*     */ 
/*  27 */     this.XThenY = true;
/*     */ 
/*  29 */     this.persp = false;
/*     */ 
/*  33 */     this.t = 0.0F;
/*  34 */     this.minX = -2.0F;
/*  35 */     this.maxX = 2.0F;
/*  36 */     this.minY = -2.0F;
/*  37 */     this.maxY = 2.0F;
/*  38 */     this.dx = 0.1F;
/*  39 */     this.dy = 0.1F;
/*     */   }
/*     */ 
/*     */   public c2fig29()
/*     */   {
/*   1 */     jdMethod_this();
/*     */   }
/*     */ 
/*     */   class RadioGroup
/*     */   {
/*     */     private int _x;
/*     */     private int _y;
/*     */     private int _w;
/*     */     private String[] _options;
/*     */     public int _selected;
/*     */ 
/*     */     public void draw()
/*     */     {
/* 411 */       c2fig29.this.textFont(c2fig29.this.Tahoma14, 14.0F);
/* 412 */       c2fig29.this.pushMatrix();
/* 413 */       c2fig29.this.translate(this._x, this._y);
/* 414 */       for (int i = 0; i < this._options.length; ++i) {
/* 415 */         c2fig29.this.pushMatrix();
/* 416 */         c2fig29.this.translate(6.0F, 6 + i * 18);
/* 417 */         c2fig29.this.ellipseMode(3);
/* 418 */         c2fig29.this.fill(255.0F, 255.0F, 255.0F);
/* 419 */         c2fig29.this.stroke(0.0F, 0.0F, 0.0F);
/* 420 */         c2fig29.this.ellipse(0.0F, 0.0F, 12.0F, 12.0F);
/* 421 */         if (i == this._selected) {
/* 422 */           c2fig29.this.fill(250.0F, 130.0F, 20.0F);
/* 423 */           c2fig29.this.noStroke();
/* 424 */           c2fig29.this.ellipse(0.0F, 0.0F, 8.0F, 8.0F);
/*     */         }
/*     */         else
/*     */         {
/* 428 */           c2fig29.this.fill(0.0F, 0.0F, 0.0F);
/*     */         }
/* 430 */         c2fig29.this.pushMatrix();
/* 431 */         c2fig29.this.translate(10.0F, 6.0F);
/*     */ 
/* 433 */         c2fig29.this.text(this._options[i], 0.0F, -2.0F);
/* 434 */         c2fig29.this.popMatrix();
/* 435 */         c2fig29.this.popMatrix();
/*     */       }
/* 437 */       c2fig29.this.popMatrix();
/*     */     }
/*     */ 
/*     */     public void processMouseDown() {
/* 441 */       int i = c2fig29.this.mouseX - this._x;
/* 442 */       int j = c2fig29.this.mouseY - this._y;
/*     */ 
/* 444 */       if ((i >= 0) && (i <= this._w)) {
/* 445 */         int k = 0;
/* 446 */         if (j <= this._options.length * 18) {
/* 447 */           while (j > 18) {
/* 448 */             ++k;
/* 449 */             j -= 18;
/*     */           }
/* 451 */           if ((j >= 0) && (j <= 12))
/* 452 */             this._selected = k;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     public RadioGroup(int paramInt1, int paramInt2, String[] paramArrayOfString, int paramInt3)
/*     */     {
/* 403 */       this._x = paramInt1;
/* 404 */       this._y = paramInt2;
/* 405 */       this._w = 60;
/* 406 */       this._options = paramArrayOfString;
/* 407 */       this._selected = paramInt3;
/*     */     }
/*     */   }
/*     */ 
/*     */   class ToggleButton
/*     */   {
/*     */     public boolean value;
/*     */     public String msg;
/*     */     public int x;
/*     */     public int y;
/*     */     public int w;
/*     */     public int h;
/*     */ 
/*     */     public void draw()
/*     */     {
/* 476 */       c2fig29.this.pushMatrix();
/* 477 */       c2fig29.this.translate(this.x, this.y);
/* 478 */       if (this.value) {
/* 479 */         c2fig29.this.fill(250.0F, 130.0F, 20.0F);
/* 480 */         c2fig29.this.stroke(0);
/* 481 */         c2fig29.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/*     */       else
/*     */       {
/* 489 */         c2fig29.this.fill(255.0F, 255.0F, 255.0F);
/* 490 */         c2fig29.this.stroke(0);
/* 491 */         c2fig29.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/* 493 */       c2fig29.this.rect(0.0F, 0.0F, this.w, this.h);
/* 494 */       c2fig29.this.noStroke();
/* 495 */       c2fig29.this.fill(255.0F, 255.0F, 255.0F);
/* 496 */       c2fig29.this.rect(2.0F, 2.0F, this.w - 4, this.h - 4);
/*     */ 
/* 498 */       c2fig29.this.fill(0);
/* 499 */       c2fig29.this.textFont(c2fig29.this.Tahoma14, 14.0F);
/* 500 */       c2fig29.this.text(this.msg, 5, this.h - 5);
/*     */ 
/* 502 */       c2fig29.this.popMatrix();
/*     */     }
/*     */ 
/*     */     public void processMouseDown() {
/* 506 */       int i = c2fig29.this.mouseX - this.x;
/* 507 */       int j = c2fig29.this.mouseY - this.y;
/*     */ 
/* 509 */       if ((i < 0) || (i > this.w) || 
/* 510 */         (j < 0) || (j > this.h)) return;
/* 511 */       this.value ^= true;
/*     */     }
/*     */ 
/*     */     private final void jdMethod_this()
/*     */     {
/* 516 */       this.value = false;
/*     */     }
/*     */ 
/*     */     public ToggleButton(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString)
/*     */     {
/* 466 */       jdMethod_this();
/* 467 */       this.x = paramInt1;
/* 468 */       this.y = paramInt2;
/* 469 */       this.w = paramInt3;
/* 470 */       paramInt4 = 20;
/* 471 */       this.h = paramInt4;
/* 472 */       this.msg = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */   class Button
/*     */   {
/*     */     public boolean value;
/*     */     public String msg;
/*     */     public int x;
/*     */     public int y;
/*     */     public int w;
/*     */     public int h;
/*     */ 
/*     */     public void draw()
/*     */     {
/* 535 */       c2fig29.this.pushMatrix();
/* 536 */       c2fig29.this.translate(this.x, this.y);
/* 537 */       if (this.value) {
/* 538 */         c2fig29.this.fill(250.0F, 130.0F, 20.0F);
/* 539 */         c2fig29.this.stroke(0);
/* 540 */         c2fig29.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/*     */       else
/*     */       {
/* 548 */         c2fig29.this.fill(255.0F, 255.0F, 255.0F);
/* 549 */         c2fig29.this.stroke(0);
/* 550 */         c2fig29.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/* 552 */       c2fig29.this.rect(0.0F, 0.0F, this.w, this.h);
/* 553 */       c2fig29.this.noStroke();
/* 554 */       c2fig29.this.fill(255.0F, 255.0F, 255.0F);
/* 555 */       c2fig29.this.rect(2.0F, 2.0F, this.w - 4, this.h - 4);
/*     */ 
/* 557 */       c2fig29.this.fill(0);
/* 558 */       c2fig29.this.textFont(c2fig29.this.Tahoma14, 14.0F);
/* 559 */       c2fig29.this.text(this.msg, 5, this.h - 5);
/*     */ 
/* 561 */       c2fig29.this.popMatrix();
/*     */     }
/*     */ 
/*     */     public void processMouseDown() {
/* 565 */       int i = c2fig29.this.mouseX - this.x;
/* 566 */       int j = c2fig29.this.mouseY - this.y;
/*     */ 
/* 568 */       if ((i < 0) || (i > this.w) || 
/* 569 */         (j < 0) || (j > this.h)) return;
/* 570 */       this.value = true;
/*     */     }
/*     */ 
/*     */     public void processMouseUp()
/*     */     {
/* 576 */       if (this.value) {
/* 577 */         this.value = false;
/* 578 */         c2fig29.this.resetAnimation();
/* 579 */         c2fig29.this.tbRunning.value = false; }
/*     */     }
/*     */ 
/*     */     private final void jdMethod_this() {
/* 583 */       this.value = false;
/*     */     }
/*     */ 
/*     */     public Button(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString)
/*     */     {
/* 525 */       jdMethod_this();
/* 526 */       this.x = paramInt1;
/* 527 */       this.y = paramInt2;
/* 528 */       this.w = paramInt3;
/* 529 */       paramInt4 = 20;
/* 530 */       this.h = paramInt4;
/* 531 */       this.msg = paramString;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/mfeyereisen/applets-final/classes/
 * Qualified Name:     c2fig29
 * JD-Core Version:    0.5.3
 */