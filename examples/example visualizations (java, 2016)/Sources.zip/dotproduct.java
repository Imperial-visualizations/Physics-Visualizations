/*     */ import processing.core.PApplet;
/*     */ 
/*     */ public class dotproduct extends PApplet
/*     */ {
/*     */   dotproduct.VectorArrow vectA;
/*     */   dotproduct.VectorArrow vectB;
/*     */   dotproduct.VectorArrow vectC;
/*     */   int dragging;
/*     */ 
/*     */   public void setup()
/*     */   {
/*  11 */     size(640, 480, "processing.core.PGraphics3");
/*     */ 
/*  14 */     this.vectA = new dotproduct.VectorArrow(0.0F, 0.0F, 1.0F, 3, 200, 20, 20);
/*  15 */     this.vectB = new dotproduct.VectorArrow(0.0F, 0.0F, 6.0F, 2.0F, 20, 200, 20);
/*     */   }
/*     */ 
/*     */   public void draw() {
/*  19 */     background(255.0F, 255.0F, 255.0F);
/*  20 */     pushMatrix();
/*  21 */     translate(this.width / 2, this.height / 2);
/*  22 */     scale(20.0F, -20.0F);
/*     */ 
/*  24 */     if (this.dragging == 1)
/*  25 */       this.vectA = new dotproduct.VectorArrow(0.0F, 0.0F, 0.05F * (this.mouseX - (this.width / 2.0F)), -0.05F * (this.mouseY - (this.height / 2.0F)), 200, 20, 20);
/*  26 */     else if (this.dragging == 2) {
/*  27 */       this.vectB = new dotproduct.VectorArrow(0.0F, 0.0F, 0.05F * (this.mouseX - (this.width / 2.0F)), -0.05F * (this.mouseY - (this.height / 2.0F)), 20, 200, 20);
/*     */     }
/*     */ 
/*  31 */     this.vectA.drawVector();
/*  32 */     this.vectB.drawVector();
/*     */ 
/*  34 */     float f1 = atan2(this.vectA.j(), this.vectA.i()) - atan2(this.vectB.j(), this.vectB.i());
/*  35 */     float f2 = this.vectA.getMag() * cos(f1) * cos(this.vectB.getTheta());
/*  36 */     float f3 = this.vectA.getMag() * cos(f1) * sin(this.vectB.getTheta());
/*  37 */     stroke(20.0F, 20.0F, 200.0F);
/*  38 */     line(0.0F, 0.0F, f2, f3);
/*  39 */     this.vectC = new dotproduct.VectorArrow(this.vectA.getMag() * cos(f1), this.vectB.getTheta() - 1.570796F, 20, 20, 200);
/*  40 */     this.vectC.drawVector();
/*     */ 
/*  42 */     pushMatrix();
/*  43 */     translate(f2, f3);
/*  44 */     rotateZ(this.vectB.getTheta() + 1.570796F);
/*     */ 
/*  46 */     for (float f4 = 0.0F; f4 < this.vectA.getMag() * sin(f1) - 0.6F; f4 += 0.6F) {
/*  47 */       line(f4, 0.0F, f4 + 0.3F, 0.0F);
/*     */     }
/*     */ 
/*  50 */     popMatrix();
/*     */ 
/*  52 */     noStroke();
/*     */ 
/*  54 */     fill(235.0F, 220.0F, 135.0F);
/*  55 */     pushMatrix();
/*  56 */     translate(0.0F, 0.0F, -0.1F);
/*  57 */     quad(0.0F, 0.0F, this.vectB.i(), this.vectB.j(), this.vectB.i() + this.vectC.i(), this.vectB.j() + this.vectC.j(), this.vectC.i(), this.vectC.j());
/*  58 */     popMatrix();
/*     */ 
/*  60 */     popMatrix();
/*     */   }
/*     */ 
/*     */   public void mousePressed() {
/*  64 */     if (this.mouseButton == 37) {
/*  65 */       float f1 = 0.05F * (this.mouseX - (this.width / 2.0F));
/*  66 */       float f2 = -0.05F * (this.mouseY - (this.height / 2.0F));
/*     */ 
/*  68 */       if (mag(f1 - this.vectA.i(), f2 - this.vectA.j()) < 0.5F) {
/*  69 */         this.dragging = 1;
/*     */       }
/*     */ 
/*  72 */       if (mag(f1 - this.vectB.i(), f2 - this.vectB.j()) < 0.5F)
/*  73 */         this.dragging = 2;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void mouseReleased()
/*     */   {
/*  79 */     this.dragging = 0;
/*     */   }
/*     */ 
/*     */   private final void jdMethod_this()
/*     */   {
/*   8 */     this.dragging = 0;
/*     */   }
/*     */ 
/*     */   public dotproduct()
/*     */   {
/*   1 */     jdMethod_this();
/*     */   }
/*     */ 
/*     */   class VectorArrow
/*     */   {
/*     */     float ax;
/*     */     float ay;
/*     */     float bx;
/*     */     float by;
/*     */     int r;
/*     */     int g;
/*     */     int b;
/*     */ 
/*     */     public void drawVector()
/*     */     {
/* 104 */       dotproduct.this.pushMatrix();
/* 105 */       dotproduct.this.stroke(this.r, this.g, this.b);
/* 106 */       dotproduct.this.fill(this.r, this.g, this.b);
/* 107 */       float f = dotproduct.this.atan2(this.by - this.ay, this.bx - this.ax);
/* 108 */       dotproduct.this.line(this.ax, this.ay, this.bx, this.by);
/* 109 */       dotproduct.this.translate(this.bx, this.by);
/* 110 */       dotproduct.this.rotateZ(f);
/* 111 */       dotproduct.this.beginShape(64);
/* 112 */       dotproduct.this.vertex(-0.5F, 0.2F);
/* 113 */       dotproduct.this.vertex(0.0F, 0.0F);
/* 114 */       dotproduct.this.vertex(-0.5F, -0.2F);
/* 115 */       dotproduct.this.endShape();
/* 116 */       dotproduct.this.popMatrix();
/*     */     }
/*     */ 
/*     */     public float i() {
/* 120 */       return (this.bx - this.ax);
/*     */     }
/*     */ 
/*     */     public float j() {
/* 124 */       return (this.by - this.ay);
/*     */     }
/*     */ 
/*     */     public float getMag() {
/* 128 */       return dotproduct.mag(this.bx - this.ax, this.by - this.ay);
/*     */     }
/*     */ 
/*     */     public float getTheta() {
/* 132 */       return dotproduct.this.atan2(this.by, this.bx);
/*     */     }
/*     */ 
/*     */     VectorArrow(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt1, int paramInt2, int paramInt3)
/*     */     {
/*  84 */       this.ax = paramFloat1;
/*  85 */       this.ay = paramFloat2;
/*  86 */       this.bx = paramFloat3;
/*  87 */       this.by = paramFloat4;
/*  88 */       this.r = paramInt1;
/*  89 */       this.g = paramInt2;
/*  90 */       this.b = paramInt3;
/*     */     }
/*     */ 
/*     */     VectorArrow(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2, int paramInt3) {
/*  94 */       this.ax = 0.0F;
/*  95 */       this.ay = 0.0F;
/*  96 */       this.bx = (paramFloat1 * dotproduct.this.cos(paramFloat2));
/*  97 */       this.by = (paramFloat1 * dotproduct.this.sin(paramFloat2));
/*  98 */       this.r = paramInt1;
/*  99 */       this.g = paramInt2;
/* 100 */       this.b = paramInt3;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/mfeyereisen/applets-final/classes/
 * Qualified Name:     dotproduct
 * JD-Core Version:    0.5.3
 */