/*     */ import processing.core.PApplet;
/*     */ import processing.core.PFont;
/*     */ 
/*     */ public class c6fig7 extends PApplet
/*     */ {
/*     */   float minX;
/*     */   float maxX;
/*     */   float stepX;
/*     */   float minY;
/*     */   float maxY;
/*     */   float stepY;
/*     */   float dx;
/*     */   float dy;
/*     */   float scalefactor;
/*     */   boolean fadingOut;
/*     */   int internalAlpha;
/*     */   c6fig7.Button btnDecrease;
/*     */   c6fig7.Button btnIncrease;
/*     */   PFont Tahoma14;
/*     */ 
/*     */   public void setup()
/*     */   {
/*  24 */     size(640, 480, "processing.core.PGraphics3");
/*     */ 
/*  26 */     this.btnDecrease = new c6fig7.Button(510, 10, 120, 20, "Decrease grid size");
/*  27 */     this.btnIncrease = new c6fig7.Button(510, 35, 120, 20, "Increase grid size");
/*     */ 
/*  29 */     reset();
/*     */   }
/*     */ 
/*     */   public void draw() {
/*  33 */     pushMatrix();
/*  34 */     translate(this.width / 2.0F, this.height / 2.0F);
/*  35 */     scale(35.0F, -35.0F, 35.0F);
/*     */ 
/*  37 */     scale(10.0F, 10.0F, 10.0F);
/*     */ 
/*  39 */     translate(-0.55F, -0.55F);
/*     */ 
/*  41 */     background(255);
/*     */ 
/*  43 */     if (this.fadingOut) {
/*  44 */       if (this.internalAlpha > 0) {
/*  45 */         this.internalAlpha -= 15;
/*  46 */         if (this.internalAlpha < 0) {
/*  47 */           this.internalAlpha = 0;
/*     */         }
/*     */       }
/*     */     }
/*  51 */     else if (this.internalAlpha < 255) {
/*  52 */       this.internalAlpha += 10;
/*  53 */       if (this.internalAlpha > 255) {
/*  54 */         this.internalAlpha = 255;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  59 */     drawAxes();
/*  60 */     drawField();
/*  61 */     stroke(0.0F, 0.0F, 0.0F);
/*  62 */     drawCircle();
/*  63 */     pushMatrix();
/*  64 */     translate(-0.5F, -0.5F);
/*     */ 
/*  66 */     drawCarpet();
/*  67 */     popMatrix();
/*     */ 
/*  70 */     stroke(0.0F, 0.0F, 0.0F, 255 - this.internalAlpha);
/*  71 */     pushMatrix();
/*  72 */     translate(0.6F, 0.6F);
/*  73 */     scale(0.6F, 0.6F);
/*     */ 
/*  82 */     for (int i = 0; i <= 3; ++i) {
/*  83 */       beginShape(32);
/*     */ 
/*  85 */       vertex(0.0F, 0.5F);
/*  86 */       vertex(0.0F, 1.0F);
/*  87 */       vertex(-0.05F, 0.9F);
/*  88 */       vertex(0.0F, 1.0F);
/*  89 */       vertex(0.05F, 0.9F);
/*  90 */       vertex(0.0F, 1.0F);
/*  91 */       endShape();
/*     */ 
/*  93 */       rotateZ(1.570796F);
/*     */     }
/*  95 */     popMatrix();
/*     */ 
/*  97 */     popMatrix();
/*     */ 
/*  99 */     this.btnDecrease.draw();
/* 100 */     this.btnIncrease.draw();
/*     */   }
/*     */ 
/*     */   public void drawField() {
/* 104 */     stroke(0.0F, 0.0F, 0.0F, 50.0F);
/* 105 */     for (float f1 = this.minX; f1 <= this.maxX; f1 += this.stepX)
/* 106 */       for (float f2 = this.minY; f2 <= this.maxY; f2 += this.stepY)
/* 107 */         drawArrow(f1, f2, fieldI(f1, f2), fieldJ(f1, f2));
/*     */   }
/*     */ 
/*     */   public void drawAxes()
/*     */   {
/* 113 */     stroke(200.0F, 20.0F, 20.0F);
/* 114 */     drawArrowU(0.55F, 0.0F, 1.1F, 0.0F);
/* 115 */     stroke(20.0F, 200.0F, 20.0F);
/* 116 */     drawArrowU(0.0F, 0.55F, 0.0F, 1.1F);
/* 117 */     stroke(0.0F, 0.0F, 0.0F);
/*     */   }
/*     */ 
/*     */   public void drawCircle() {
/* 121 */     float f = 0.0F;
/*     */ 
/* 123 */     pushMatrix();
/* 124 */     translate(0.6F, 0.6F);
/*     */ 
/* 127 */     beginShape(34);
/* 128 */     while (f < 6.283186F) {
/* 129 */       f += 0.1745329F;
/* 130 */       vertex(0.3F * cos(f), 0.3F * sin(f));
/*     */     }
/* 132 */     endShape();
/*     */ 
/* 134 */     popMatrix();
/*     */   }
/*     */ 
/*     */   public void drawCarpet() {
/* 138 */     float f1 = this.minX;
/* 139 */     while (f1 <= this.maxX) {
/* 140 */       float f2 = this.minY;
/* 141 */       while (f2 <= this.maxY) {
/* 142 */         if (closeEnoughToCurve(f1, f2)) {
/* 143 */           drawSquare(f1, f2, this.dx, this.dy);
/*     */         }
/*     */ 
/* 146 */         f2 += this.dy;
/*     */       }
/*     */ 
/* 149 */       f1 += this.dx;
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean closeEnoughToCurve(float paramFloat1, float paramFloat2) {
/* 154 */     float f1 = paramFloat1 - 0.6F;
/* 155 */     float f2 = paramFloat2 - 0.6F;
/*     */ 
/* 157 */     float f3 = mag(f1, f2);
/*     */ 
/* 160 */     return (f3 < 0.3F);
/*     */   }
/*     */ 
/*     */   public void drawSquare(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*     */   {
/* 169 */     pushMatrix();
/* 170 */     translate(paramFloat1, paramFloat2);
/* 171 */     translate(0.5F, 0.5F);
/* 172 */     scale(paramFloat3, paramFloat4);
/*     */ 
/* 174 */     stroke(100);
/* 175 */     fill(0.0F, 0.0F, 0.0F, 100.0F);
/* 176 */     beginShape(128);
/* 177 */     vertex(-0.5F, 0.5F);
/* 178 */     vertex(0.5F, 0.5F);
/* 179 */     vertex(0.5F, -0.5F);
/* 180 */     vertex(-0.5F, -0.5F);
/* 181 */     endShape();
/*     */ 
/* 183 */     stroke(0.0F, 0.0F, 0.0F, this.internalAlpha);
/* 184 */     pushMatrix();
/* 185 */     for (int i = 0; i <= 3; ++i) {
/* 186 */       beginShape(32);
/* 187 */       translate(-0.1F, -0.25F);
/* 188 */       vertex(0.0F, 0.5F);
/* 189 */       vertex(0.0F, 1.0F);
/* 190 */       vertex(-0.05F, 0.9F);
/* 191 */       vertex(0.0F, 1.0F);
/* 192 */       vertex(0.05F, 0.9F);
/* 193 */       vertex(0.0F, 1.0F);
/* 194 */       endShape();
/* 195 */       translate(0.1F, 0.25F);
/* 196 */       rotateZ(1.570796F);
/*     */     }
/* 198 */     popMatrix();
/* 199 */     popMatrix();
/*     */   }
/*     */ 
/*     */   public float fieldI(float paramFloat1, float paramFloat2) {
/* 203 */     return (-paramFloat2);
/*     */   }
/*     */ 
/*     */   public float fieldJ(float paramFloat1, float paramFloat2) {
/* 207 */     return paramFloat1;
/*     */   }
/*     */ 
/*     */   public void drawArrow(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 211 */     pushMatrix();
/* 212 */     translate(paramFloat1, paramFloat2);
/* 213 */     rotateZ(atan2(paramFloat4, paramFloat3));
/* 214 */     float f = this.scalefactor * mag(paramFloat3, paramFloat4);
/* 215 */     line(-f / 2.0F, 0.0F, f / 2.0F, 0.0F);
/* 216 */     translate(f / 2.0F, 0.0F);
/* 217 */     line(-0.2F * this.scalefactor, 0.1F * this.scalefactor, 0.0F, 0.0F);
/* 218 */     line(-0.2F * this.scalefactor, -0.1F * this.scalefactor, 0.0F, 0.0F);
/* 219 */     popMatrix();
/*     */   }
/*     */ 
/*     */   public void drawArrowU(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 223 */     pushMatrix();
/* 224 */     translate(paramFloat1, paramFloat2);
/* 225 */     rotateZ(atan2(paramFloat4, paramFloat3));
/* 226 */     float f = mag(paramFloat3, paramFloat4);
/* 227 */     line(-f / 2.0F, 0.0F, f / 2.0F, 0.0F);
/* 228 */     translate(f / 2.0F, 0.0F);
/* 229 */     line(-0.4F * this.scalefactor, 0.2F * this.scalefactor, 0.0F, 0.0F);
/* 230 */     line(-0.4F * this.scalefactor, -0.2F * this.scalefactor, 0.0F, 0.0F);
/* 231 */     popMatrix();
/*     */   }
/*     */ 
/*     */   public void keyPressed()
/*     */   {
/* 245 */     if (this.key == 'r')
/* 246 */       reset();
/*     */   }
/*     */ 
/*     */   public void mousePressed()
/*     */   {
/* 251 */     if (this.mouseButton == 37) {
/* 252 */       this.btnDecrease.processMouseDown();
/* 253 */       this.btnIncrease.processMouseDown();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void mouseReleased() {
/* 258 */     if (this.mouseButton == 37) {
/* 259 */       this.btnDecrease.processMouseUp();
/* 260 */       this.btnIncrease.processMouseUp();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void reset() {
/* 265 */     this.dx = 0.5F;
/* 266 */     this.dy = 0.5F;
/*     */ 
/* 268 */     this.internalAlpha = 255;
/* 269 */     this.fadingOut = false;
/*     */   }
/*     */ 
/*     */   private final void jdMethod_this()
/*     */   {
/*   1 */     this.minX = 0.1F;
/*   2 */     this.maxX = 1.0F;
/*   3 */     this.stepX = 0.1F;
/*     */ 
/*   5 */     this.minY = 0.1F;
/*   6 */     this.maxY = 1.0F;
/*   7 */     this.stepY = 0.1F;
/*     */ 
/*   9 */     this.dx = 0.05F;
/*  10 */     this.dy = 0.05F;
/*     */ 
/*  12 */     this.scalefactor = 0.1F;
/*     */ 
/*  14 */     this.fadingOut = false;
/*     */ 
/*  16 */     this.internalAlpha = 255;
/*     */ 
/*  21 */     this.Tahoma14 = loadFont("Tahoma-14.vlw");
/*     */   }
/*     */ 
/*     */   public c6fig7()
/*     */   {
/*   1 */     jdMethod_this();
/*     */   }
/*     */ 
/*     */   class Button
/*     */   {
/*     */     public boolean value;
/*     */     public String msg;
/*     */     public int x;
/*     */     public int y;
/*     */     public int w;
/*     */     public int h;
/*     */ 
/*     */     public void draw()
/*     */     {
/* 283 */       c6fig7.this.pushMatrix();
/* 284 */       c6fig7.this.translate(this.x, this.y);
/* 285 */       if (this.value) {
/* 286 */         c6fig7.this.fill(250.0F, 130.0F, 20.0F);
/* 287 */         c6fig7.this.stroke(0);
/* 288 */         c6fig7.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/*     */       else
/*     */       {
/* 296 */         c6fig7.this.fill(255.0F, 255.0F, 255.0F);
/* 297 */         c6fig7.this.stroke(0);
/* 298 */         c6fig7.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/* 300 */       c6fig7.this.rect(0.0F, 0.0F, this.w, this.h);
/* 301 */       c6fig7.this.noStroke();
/* 302 */       c6fig7.this.fill(255.0F, 255.0F, 255.0F);
/* 303 */       c6fig7.this.rect(2.0F, 2.0F, this.w - 4, this.h - 4);
/*     */ 
/* 305 */       c6fig7.this.fill(0);
/* 306 */       c6fig7.this.textFont(c6fig7.this.Tahoma14, 14.0F);
/* 307 */       c6fig7.this.text(this.msg, 5, this.h - 5);
/*     */ 
/* 309 */       c6fig7.this.popMatrix();
/*     */     }
/*     */ 
/*     */     public void processMouseDown() {
/* 313 */       int i = c6fig7.this.mouseX - this.x;
/* 314 */       int j = c6fig7.this.mouseY - this.y;
/*     */ 
/* 316 */       if ((i < 0) || (i > this.w) || 
/* 317 */         (j < 0) || (j > this.h)) return;
/* 318 */       this.value = true;
/*     */     }
/*     */ 
/*     */     public void processMouseUp()
/*     */     {
/* 324 */       if (this.value) {
/* 325 */         this.value = false;
/*     */ 
/* 327 */         if (this.msg == "Decrease grid size") {
/* 328 */           c6fig7.this.dx *= 0.8F;
/* 329 */           c6fig7.this.dy *= 0.8F;
/*     */         }
/* 331 */         else if (this.msg == "Increase grid size") {
/* 332 */           c6fig7.this.dx *= 1.25F;
/* 333 */           c6fig7.this.dy *= 1.25F;
/*     */         }
/* 335 */         if (c6fig7.this.dx < 0.013F) {
/* 336 */           c6fig7.this.fadingOut = true;
/*     */         }
/*     */         else
/* 339 */           c6fig7.this.fadingOut = false;
/*     */       }
/*     */     }
/*     */ 
/*     */     private final void jdMethod_this() {
/* 344 */       this.value = false;
/*     */     }
/*     */ 
/*     */     public Button(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString)
/*     */     {
/* 273 */       jdMethod_this();
/* 274 */       this.x = paramInt1;
/* 275 */       this.y = paramInt2;
/* 276 */       this.w = paramInt3;
/* 277 */       paramInt4 = 20;
/* 278 */       this.h = paramInt4;
/* 279 */       this.msg = paramString;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/mfeyereisen/applets-final/classes/
 * Qualified Name:     c6fig7
 * JD-Core Version:    0.5.3
 */