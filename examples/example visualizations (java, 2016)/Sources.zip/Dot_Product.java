/*     */ import processing.core.PApplet;
/*     */ import processing.core.PFont;
/*     */ 
/*     */ public class Dot_Product extends PApplet
/*     */ {
/*     */   float axes_centre_x;
/*     */   float axes_centre_y;
/*     */   float a;
/*     */   float b;
/*     */   float scale_factor;
/*     */   float normalised_a;
/*     */   float normalised_b;
/*     */   float angle;
/*     */   float arc_size;
/*     */   float scale_speed;
/*     */   float angle_speed;
/*     */   float rect_size;
/*     */   float rect_a_minus_pos_x;
/*     */   float rect_a_minus_pos_y;
/*     */   float rect_a_plus_pos_x;
/*     */   float rect_a_plus_pos_y;
/*     */   boolean rect_a_minus;
/*     */   boolean rect_a_plus;
/*     */   float rect_b_minus_pos_x;
/*     */   float rect_b_minus_pos_y;
/*     */   float rect_b_plus_pos_x;
/*     */   float rect_b_plus_pos_y;
/*     */   boolean rect_b_minus;
/*     */   boolean rect_b_plus;
/*     */   float rect_angle_minus_pos_x;
/*     */   float rect_angle_minus_pos_y;
/*     */   float rect_angle_plus_pos_x;
/*     */   float rect_angle_plus_pos_y;
/*     */   boolean rect_angle_minus;
/*     */   boolean rect_angle_plus;
/*     */   int rect_color;
/*     */   int rect_highlight_color;
/*     */   boolean mouse_over_button;
/*     */   float arrowhead_length;
/*     */   PFont font;
/*     */ 
/*     */   public void reset()
/*     */   {
/*  42 */     this.a = 2.0F;
/*  43 */     this.b = 2.0F;
/*  44 */     this.normalised_a = (this.a * this.scale_factor);
/*  45 */     this.normalised_b = (this.b * this.scale_factor);
/*  46 */     this.angle = 1.570796F;
/*  47 */     this.arc_size = 70.0F;
/*     */   }
/*     */ 
/*     */   public void setup()
/*     */   {
/*  52 */     size(640, 480);
/*  53 */     background(255);
/*  54 */     stroke(0);
/*  55 */     framerate(60.0F);
/*  56 */     this.font = loadFont("Arial-Black-20.vlw");
/*  57 */     textFont(this.font, 20.0F);
/*     */   }
/*     */ 
/*     */   public boolean mouseOverRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*     */   {
/*  64 */     return ((this.mouseX >= paramFloat1) && (this.mouseX <= paramFloat1 + paramFloat3) && (this.mouseY >= paramFloat2) && (this.mouseY <= paramFloat2 + paramFloat4));
/*     */   }
/*     */ 
/*     */   public void keyPressed()
/*     */   {
/*  72 */     if (this.key == 'r') reset();
/*  73 */     if (this.keyCode == 39)
/*     */     {
/*  75 */       this.angle -= this.angle_speed;
/*     */     }
/*  77 */     if (this.keyCode != 37)
/*     */       return;
/*  79 */     this.angle += this.angle_speed;
/*  80 */     if (this.angle <= 6.283186F) return; this.angle = 0.0F;
/*     */   }
/*     */ 
/*     */   public void checkMouse(float paramFloat1, float paramFloat2)
/*     */   {
/*  86 */     this.mouse_over_button = false;
/*     */ 
/*  88 */     if (mouseOverRect(this.rect_a_minus_pos_x, this.rect_a_minus_pos_y, this.rect_size, this.rect_size)) { this.rect_a_minus = true; this.mouse_over_button = true; } else { this.rect_a_minus = false; }
/*  89 */     if (mouseOverRect(this.rect_a_plus_pos_x, this.rect_a_plus_pos_y, this.rect_size, this.rect_size)) { this.rect_a_plus = true; this.mouse_over_button = true; } else { this.rect_a_plus = false; }
/*  90 */     if (mouseOverRect(this.rect_b_minus_pos_x, this.rect_b_minus_pos_y, this.rect_size, this.rect_size)) { this.rect_b_minus = true; this.mouse_over_button = true; } else { this.rect_b_minus = false; }
/*  91 */     if (mouseOverRect(this.rect_b_plus_pos_x, this.rect_b_plus_pos_y, this.rect_size, this.rect_size)) { this.rect_b_plus = true; this.mouse_over_button = true; } else { this.rect_b_plus = false; }
/*  92 */     if (mouseOverRect(this.rect_angle_minus_pos_x, this.rect_angle_minus_pos_y, this.rect_size, this.rect_size)) { this.rect_angle_minus = true; this.mouse_over_button = true; } else { this.rect_angle_minus = false; }
/*  93 */     if (mouseOverRect(this.rect_angle_plus_pos_x, this.rect_angle_plus_pos_y, this.rect_size, this.rect_size)) { this.rect_angle_plus = true; this.mouse_over_button = true; } else { this.rect_angle_plus = false;
/*     */     }
/*     */   }
/*     */ 
/*     */   public float dotProduct(float paramFloat1, float paramFloat2, float paramFloat3) {
/*  98 */     return (paramFloat1 * paramFloat2 * cos(this.angle));
/*     */   }
/*     */ 
/*     */   public void draw()
/*     */   {
/* 103 */     background(255);
/* 104 */     checkMouse(this.mouseX, this.mouseY);
/*     */ 
/* 107 */     stroke(0);
/* 108 */     if (this.rect_a_minus) fill(this.rect_highlight_color); else fill(this.rect_color);
/* 109 */     rect(this.rect_a_minus_pos_x, this.rect_a_minus_pos_y, this.rect_size, this.rect_size);
/* 110 */     if (this.rect_a_plus) fill(this.rect_highlight_color); else fill(this.rect_color);
/* 111 */     rect(this.rect_a_plus_pos_x, this.rect_a_plus_pos_y, this.rect_size, this.rect_size);
/* 112 */     if (this.rect_b_minus) fill(this.rect_highlight_color); else fill(this.rect_color);
/* 113 */     rect(this.rect_b_minus_pos_x, this.rect_b_minus_pos_y, this.rect_size, this.rect_size);
/* 114 */     if (this.rect_b_plus) fill(this.rect_highlight_color); else fill(this.rect_color);
/* 115 */     rect(this.rect_b_plus_pos_x, this.rect_b_plus_pos_y, this.rect_size, this.rect_size);
/* 116 */     if (this.rect_angle_minus) fill(this.rect_highlight_color); else fill(this.rect_color);
/* 117 */     rect(this.rect_angle_minus_pos_x, this.rect_angle_minus_pos_y, this.rect_size, this.rect_size);
/* 118 */     if (this.rect_angle_plus) fill(this.rect_highlight_color); else fill(this.rect_color);
/* 119 */     rect(this.rect_angle_plus_pos_x, this.rect_angle_plus_pos_y, this.rect_size, this.rect_size);
/* 120 */     fill(0);
/* 121 */     textSize(40.0F);
/* 122 */     text("-", this.rect_a_minus_pos_x + 10.0F, this.rect_a_minus_pos_y + this.rect_size - 4);
/* 123 */     text("+", this.rect_a_plus_pos_x + 3.2F, this.rect_a_plus_pos_y + this.rect_size);
/* 124 */     textSize(20.0F);
/* 125 */     text("|A| = ", this.rect_a_minus_pos_x - 10.0F, this.rect_a_minus_pos_y + this.rect_size + 26.0F);
/* 126 */     text(this.a, this.rect_a_minus_pos_x + 40.0F, this.rect_a_minus_pos_y + this.rect_size + 26.0F);
/* 127 */     textSize(40.0F);
/* 128 */     text("-", this.rect_b_minus_pos_x + 10.0F, this.rect_b_minus_pos_y + this.rect_size - 4);
/* 129 */     text("+", this.rect_b_plus_pos_x + 3.2F, this.rect_b_plus_pos_y + this.rect_size);
/* 130 */     textSize(20.0F);
/* 131 */     text("|B| = ", this.rect_b_minus_pos_x - 10.0F, this.rect_b_minus_pos_y + this.rect_size + 26.0F);
/* 132 */     text(this.b, this.rect_b_minus_pos_x + 40.0F, this.rect_b_minus_pos_y + this.rect_size + 26.0F);
/* 133 */     textSize(40.0F);
/* 134 */     text("-", this.rect_angle_minus_pos_x + 10.0F, this.rect_angle_minus_pos_y + this.rect_size - 4);
/* 135 */     text("+", this.rect_angle_plus_pos_x + 3.2F, this.rect_angle_plus_pos_y + this.rect_size);
/* 136 */     textSize(20.0F);
/* 137 */     text("Angle (rad)", this.rect_angle_minus_pos_x - 20.0F, this.rect_angle_minus_pos_y + this.rect_size + 26.0F);
/* 138 */     text("=", this.rect_angle_minus_pos_x + 25.0F, this.rect_angle_minus_pos_y + this.rect_size + 53.0F);
/* 139 */     text(this.angle, this.rect_angle_minus_pos_x + 40.0F, this.rect_angle_minus_pos_y + this.rect_size + 53.0F);
/* 140 */     textSize(20.0F);
/* 141 */     text("A.B =    |B|                  = ", 250.0F, 460.0F);
/* 142 */     fill(255.0F, 0.0F, 0.0F);
/* 143 */     text("        |A|    cos(angle)", 255.0F, 460.0F);
/* 144 */     fill(0);
/* 145 */     text(dotProduct(this.a, this.b, this.angle), 520.0F, 460.0F);
/*     */ 
/* 147 */     if (this.mousePressed)
/*     */     {
/* 149 */       if (this.rect_a_minus) this.a -= this.scale_speed;
/* 150 */       if (this.rect_a_plus) this.a += this.scale_speed;
/* 151 */       if (this.rect_b_minus) this.b -= this.scale_speed;
/* 152 */       if (this.rect_b_plus) this.b += this.scale_speed;
/* 153 */       if (this.rect_angle_minus) this.angle -= this.angle_speed;
/* 154 */       if (this.rect_angle_plus) this.angle += this.angle_speed;
/*     */ 
/*     */     }
/*     */ 
/* 158 */     translate(this.axes_centre_x, this.axes_centre_y);
/* 159 */     stroke(0);
/* 160 */     fill(0);
/* 161 */     this.normalised_a = (this.a * this.scale_factor);
/* 162 */     this.normalised_b = (this.b * this.scale_factor);
/* 163 */     line(0.0F, 0.0F, this.normalised_b, 0.0F);
/* 164 */     text("B", this.normalised_b / 2.0F, 20.0F);
/* 165 */     line(0.0F, 0.0F, this.normalised_a * cos(this.angle), -this.normalised_a * sin(this.angle));
/* 166 */     text("A", this.normalised_a * cos(this.angle) / 2.0F - 20.0F, -this.normalised_a * sin(this.angle) / 2.0F);
/*     */ 
/* 169 */     stroke(0);
/* 170 */     line(this.normalised_b, 0.0F, this.normalised_b - (this.arrowhead_length * 2.0F), -this.arrowhead_length);
/* 171 */     line(this.normalised_b, 0.0F, this.normalised_b - (this.arrowhead_length * 2.0F), this.arrowhead_length);
/* 172 */     pushMatrix();
/* 173 */     translate(this.normalised_a * cos(this.angle), -this.normalised_a * sin(this.angle));
/* 174 */     line(0.0F, 0.0F, -this.arrowhead_length * 2.0F * sin(0.7853982F - this.angle), this.arrowhead_length * 2.0F * cos(0.7853982F - this.angle));
/* 175 */     line(0.0F, 0.0F, -this.arrowhead_length * 2.0F * sin(radians(135.0F) - this.angle), this.arrowhead_length * 2.0F * cos(radians(135.0F) - this.angle));
/* 176 */     popMatrix();
/*     */ 
/* 179 */     stroke(0);
/* 180 */     fill(0.0F, 0.0F, 0.0F, 50.0F);
/* 181 */     arc(0.0F, 0.0F, this.arc_size, this.arc_size, -this.angle, 0.0F);
/*     */ 
/* 184 */     stroke(255.0F, 0.0F, 0.0F);
/* 185 */     line(0.0F, 0.0F, this.normalised_a * cos(this.angle), 0.0F);
/* 186 */     stroke(100);
/* 187 */     float f1 = 10.0F;
/* 188 */     float f2 = 0.0F;
/*     */     float f3;
/* 189 */     if (-this.normalised_a * sin(this.angle) < 0.0F)
/*     */     {
/* 191 */       for (f3 = -this.normalised_a * sin(this.angle); f3 < -f1; f3 += f1 * 2.0F)
/*     */       {
/* 193 */         line(this.normalised_a * cos(this.angle), f3, this.normalised_a * cos(this.angle), f3 + f1);
/* 194 */         f2 = f3;
/*     */       }
/*     */     }
/* 197 */     else if (-this.normalised_a * sin(this.angle) > 0.0F)
/*     */     {
/* 199 */       for (f3 = -this.normalised_a * sin(this.angle); f3 > f1; f3 -= f1 * 2.0F)
/*     */       {
/* 201 */         line(this.normalised_a * cos(this.angle), f3, this.normalised_a * cos(this.angle), f3 - f1);
/* 202 */         f2 = f3;
/*     */       }
/*     */     }
/*     */ 
/* 206 */     line(this.normalised_a * cos(this.angle), f2, this.normalised_a * cos(this.angle), 0.0F);
/*     */   }
/*     */ 
/*     */   private final void jdMethod_this()
/*     */   {
/*   4 */     this.axes_centre_x = 280.0F;
/*   5 */     this.axes_centre_y = 350.0F;
/*   6 */     this.a = 2.0F;
/*   7 */     this.b = 2.0F;
/*   8 */     this.scale_factor = 100.0F;
/*   9 */     this.normalised_a = (this.a * this.scale_factor);
/*  10 */     this.normalised_b = (this.b * this.scale_factor);
/*  11 */     this.angle = 1.570796F;
/*  12 */     this.arc_size = 70.0F;
/*  13 */     this.scale_speed = 0.05F;
/*  14 */     this.angle_speed = 0.03F;
/*  15 */     this.rect_size = 30.0F;
/*  16 */     this.rect_a_minus_pos_x = 520.0F;
/*  17 */     this.rect_a_minus_pos_y = 10.0F;
/*  18 */     this.rect_a_plus_pos_x = (this.rect_a_minus_pos_x + this.rect_size + 10.0F);
/*  19 */     this.rect_a_plus_pos_y = this.rect_a_minus_pos_y;
/*  20 */     this.rect_a_minus = false;
/*  21 */     this.rect_a_plus = false;
/*  22 */     this.rect_b_minus_pos_x = 520.0F;
/*  23 */     this.rect_b_minus_pos_y = 90.0F;
/*  24 */     this.rect_b_plus_pos_x = (this.rect_b_minus_pos_x + this.rect_size + 10.0F);
/*  25 */     this.rect_b_plus_pos_y = this.rect_b_minus_pos_y;
/*  26 */     this.rect_b_minus = false;
/*  27 */     this.rect_b_plus = false;
/*  28 */     this.rect_angle_minus_pos_x = 520.0F;
/*  29 */     this.rect_angle_minus_pos_y = 170.0F;
/*  30 */     this.rect_angle_plus_pos_x = (this.rect_angle_minus_pos_x + this.rect_size + 10.0F);
/*  31 */     this.rect_angle_plus_pos_y = this.rect_angle_minus_pos_y;
/*  32 */     this.rect_angle_minus = false;
/*  33 */     this.rect_angle_plus = false;
/*  34 */     this.rect_color = color(200);
/*  35 */     this.rect_highlight_color = color(255);
/*  36 */     this.mouse_over_button = false;
/*  37 */     this.arrowhead_length = 5;
/*     */   }
/*     */ 
/*     */   public Dot_Product()
/*     */   {
/*   1 */     jdMethod_this();
/*     */   }
/*     */ }

/* Location:           /Users/mfeyereisen/applets-final/classes/
 * Qualified Name:     Dot_Product
 * JD-Core Version:    0.5.3
 */