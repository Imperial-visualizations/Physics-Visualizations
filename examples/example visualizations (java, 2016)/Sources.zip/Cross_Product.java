/*     */ import processing.core.PApplet;
/*     */ import processing.core.PFont;
/*     */ 
/*     */ public class Cross_Product extends PApplet
/*     */ {
/*     */   float axes_centre_x;
/*     */   float axes_centre_y;
/*     */   float axes_centre_z;
/*     */   float rotate_y;
/*     */   float rotate_x;
/*     */   float rotate_speed;
/*     */   boolean rotate_cam_y;
/*     */   boolean rotate_cam_x;
/*     */   float length_a;
/*     */   float length_b;
/*     */   float length_c;
/*     */   float scale_multiplier;
/*     */   float normalised_a;
/*     */   float normalised_b;
/*     */   float normalised_c;
/*     */   float angle;
/*     */   float scale_speed;
/*     */   float angle_scale_speed;
/*     */   PFont font;
/*     */   float rect_size;
/*     */   float rect_a_minus_pos_x;
/*     */   float rect_a_minus_pos_y;
/*     */   float rect_a_plus_pos_x;
/*     */   float rect_a_plus_pos_y;
/*     */   boolean rect_a_minus;
/*     */   boolean rect_a_plus;
/*     */   float rect_b_minus_pos_x;
/*     */   float rect_b_minus_pos_y;
/*     */   float rect_b_plus_pos_x;
/*     */   float rect_b_plus_pos_y;
/*     */   boolean rect_b_minus;
/*     */   boolean rect_b_plus;
/*     */   float rect_angle_minus_pos_x;
/*     */   float rect_angle_minus_pos_y;
/*     */   float rect_angle_plus_pos_x;
/*     */   float rect_angle_plus_pos_y;
/*     */   boolean rect_angle_minus;
/*     */   boolean rect_angle_plus;
/*     */   int rect_color;
/*     */   int rect_highlight_color;
/*     */   boolean mouse_over_button;
/*     */   float arc_size;
/*     */   float arrowhead_size;
/*     */ 
/*     */   public void reset()
/*     */   {
/*  50 */     this.rotate_y = 0.0F;
/*  51 */     this.rotate_x = 0.0F;
/*  52 */     this.rotate_cam_y = false;
/*  53 */     this.rotate_cam_x = false;
/*  54 */     this.length_a = 2.5F;
/*  55 */     this.length_b = 2.0F;
/*  56 */     this.length_c = 0.0F;
/*  57 */     this.normalised_a = (this.length_a * this.scale_multiplier);
/*  58 */     this.normalised_b = (this.length_b * this.scale_multiplier);
/*  59 */     this.normalised_c = (this.length_c * this.scale_multiplier);
/*  60 */     this.angle = 1.570796F;
/*     */   }
/*     */ 
/*     */   public void setup()
/*     */   {
/*  65 */     size(640, 480, "processing.core.PGraphics3");
/*  66 */     background(255);
/*  67 */     stroke(0.0F, 0.0F, 0.0F);
/*  68 */     framerate(60.0F);
/*  69 */     this.font = loadFont("Arial-Black-20.vlw");
/*  70 */     textFont(this.font, 23.0F);
/*     */   }
/*     */ 
/*     */   public float cross(float paramFloat1, float paramFloat2, float paramFloat3)
/*     */   {
/*  75 */     return (paramFloat1 * paramFloat2 * sin(paramFloat3));
/*     */   }
/*     */ 
/*     */   public boolean mouseOverRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*     */   {
/*  82 */     return ((this.mouseX >= paramFloat1) && (this.mouseX <= paramFloat1 + paramFloat3) && (this.mouseY >= paramFloat2) && (this.mouseY <= paramFloat2 + paramFloat4));
/*     */   }
/*     */ 
/*     */   public void mousePressed()
/*     */   {
/*  90 */     if (this.mouse_over_button)
/*     */       return;
/*  92 */     this.rotate_cam_y = true;
/*  93 */     this.rotate_cam_x = true;
/*     */   }
/*     */ 
/*     */   public void mouseReleased()
/*     */   {
/*  99 */     this.rotate_cam_y = false;
/* 100 */     this.rotate_cam_x = false;
/*     */   }
/*     */ 
/*     */   public void keyPressed()
/*     */   {
/* 105 */     if (this.key != 'r') return; reset();
/*     */   }
/*     */ 
/*     */   public void checkMouse(float paramFloat1, float paramFloat2)
/*     */   {
/* 110 */     this.mouse_over_button = false;
/*     */ 
/* 112 */     if (mouseOverRect(this.rect_a_minus_pos_x, this.rect_a_minus_pos_y, this.rect_size, this.rect_size)) { this.rect_a_minus = true; this.mouse_over_button = true; } else { this.rect_a_minus = false; }
/* 113 */     if (mouseOverRect(this.rect_a_plus_pos_x, this.rect_a_plus_pos_y, this.rect_size, this.rect_size)) { this.rect_a_plus = true; this.mouse_over_button = true; } else { this.rect_a_plus = false; }
/* 114 */     if (mouseOverRect(this.rect_b_minus_pos_x, this.rect_b_minus_pos_y, this.rect_size, this.rect_size)) { this.rect_b_minus = true; this.mouse_over_button = true; } else { this.rect_b_minus = false; }
/* 115 */     if (mouseOverRect(this.rect_b_plus_pos_x, this.rect_b_plus_pos_y, this.rect_size, this.rect_size)) { this.rect_b_plus = true; this.mouse_over_button = true; } else { this.rect_b_plus = false; }
/* 116 */     if (mouseOverRect(this.rect_angle_minus_pos_x, this.rect_angle_minus_pos_y, this.rect_size, this.rect_size)) { this.rect_angle_minus = true; this.mouse_over_button = true; } else { this.rect_angle_minus = false; }
/* 117 */     if (mouseOverRect(this.rect_angle_plus_pos_x, this.rect_angle_plus_pos_y, this.rect_size, this.rect_size)) { this.rect_angle_plus = true; this.mouse_over_button = true; } else { this.rect_angle_plus = false;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void draw() {
/* 122 */     background(255);
/* 123 */     checkMouse(this.mouseX, this.mouseY);
/*     */ 
/* 126 */     if (this.rect_a_minus) fill(this.rect_highlight_color); else fill(this.rect_color);
/* 127 */     rect(this.rect_a_minus_pos_x, this.rect_a_minus_pos_y, this.rect_size, this.rect_size);
/* 128 */     if (this.rect_a_plus) fill(this.rect_highlight_color); else fill(this.rect_color);
/* 129 */     rect(this.rect_a_plus_pos_x, this.rect_a_plus_pos_y, this.rect_size, this.rect_size);
/* 130 */     if (this.rect_b_minus) fill(this.rect_highlight_color); else fill(this.rect_color);
/* 131 */     rect(this.rect_b_minus_pos_x, this.rect_b_minus_pos_y, this.rect_size, this.rect_size);
/* 132 */     if (this.rect_b_plus) fill(this.rect_highlight_color); else fill(this.rect_color);
/* 133 */     rect(this.rect_b_plus_pos_x, this.rect_b_plus_pos_y, this.rect_size, this.rect_size);
/* 134 */     if (this.rect_angle_minus) fill(this.rect_highlight_color); else fill(this.rect_color);
/* 135 */     rect(this.rect_angle_minus_pos_x, this.rect_angle_minus_pos_y, this.rect_size, this.rect_size);
/* 136 */     if (this.rect_angle_plus) fill(this.rect_highlight_color); else fill(this.rect_color);
/* 137 */     rect(this.rect_angle_plus_pos_x, this.rect_angle_plus_pos_y, this.rect_size, this.rect_size);
/* 138 */     fill(0);
/* 139 */     textSize(40.0F);
/* 140 */     text("-", this.rect_a_minus_pos_x + 10.0F, this.rect_a_minus_pos_y + this.rect_size - 4);
/* 141 */     text("+", this.rect_a_plus_pos_x + 3.2F, this.rect_a_plus_pos_y + this.rect_size);
/* 142 */     textSize(20.0F);
/* 143 */     text("|A| = ", this.rect_a_minus_pos_x - 10.0F, this.rect_a_minus_pos_y + this.rect_size + 26.0F);
/* 144 */     text(this.length_a, this.rect_a_minus_pos_x + 40.0F, this.rect_a_minus_pos_y + this.rect_size + 26.0F);
/* 145 */     textSize(40.0F);
/* 146 */     text("-", this.rect_b_minus_pos_x + 10.0F, this.rect_b_minus_pos_y + this.rect_size - 4);
/* 147 */     text("+", this.rect_b_plus_pos_x + 3.2F, this.rect_b_plus_pos_y + this.rect_size);
/* 148 */     textSize(20.0F);
/* 149 */     text("|B| = ", this.rect_b_minus_pos_x - 10.0F, this.rect_b_minus_pos_y + this.rect_size + 26.0F);
/* 150 */     text(this.length_b, this.rect_b_minus_pos_x + 40.0F, this.rect_b_minus_pos_y + this.rect_size + 26.0F);
/* 151 */     textSize(40.0F);
/* 152 */     text("-", this.rect_angle_minus_pos_x + 10.0F, this.rect_angle_minus_pos_y + this.rect_size - 4);
/* 153 */     text("+", this.rect_angle_plus_pos_x + 3.2F, this.rect_angle_plus_pos_y + this.rect_size);
/* 154 */     textSize(20.0F);
/* 155 */     text("Angle (rad)", this.rect_angle_minus_pos_x - 20.0F, this.rect_angle_minus_pos_y + this.rect_size + 26.0F);
/* 156 */     text("=", this.rect_angle_minus_pos_x + 25.0F, this.rect_angle_minus_pos_y + this.rect_size + 53.0F);
/* 157 */     text(this.angle, this.rect_angle_minus_pos_x + 40.0F, this.rect_angle_minus_pos_y + this.rect_size + 53.0F);
/* 158 */     textSize(20.0F);
/* 159 */     text("|A x B| = |A||B|sin(angle) = ", 250.0F, 460.0F);
/* 160 */     text(this.length_c, 540.0F, 460.0F);
/*     */ 
/* 162 */     if (this.mousePressed)
/*     */     {
/* 164 */       if (this.rect_a_minus) this.length_a -= this.scale_speed;
/* 165 */       if (this.rect_a_plus) this.length_a += this.scale_speed;
/* 166 */       if (this.rect_b_minus) this.length_b -= this.scale_speed;
/* 167 */       if (this.rect_b_plus) this.length_b += this.scale_speed;
/* 168 */       if (this.rect_angle_minus) this.angle -= this.angle_scale_speed;
/* 169 */       if (this.rect_angle_plus) this.angle += this.angle_scale_speed;
/*     */ 
/*     */     }
/*     */ 
/* 173 */     this.length_c = cross(this.length_a, this.length_b, this.angle);
/* 174 */     this.normalised_a = (this.length_a * this.scale_multiplier);
/* 175 */     this.normalised_b = (this.length_b * this.scale_multiplier);
/* 176 */     this.normalised_c = (this.length_c * this.scale_multiplier);
/*     */ 
/* 178 */     translate(this.axes_centre_x, this.axes_centre_y, this.axes_centre_z);
/* 179 */     translate(this.normalised_b / 2.0F, -this.normalised_c / 2.0F, this.normalised_a / 2.0F);
/* 180 */     if (this.rotate_cam_y)
/*     */     {
/* 182 */       if (this.mouseX - this.pmouseX > 0.0F) this.rotate_y += this.rotate_speed;
/* 183 */       if (this.mouseX - this.pmouseX < 0.0F) this.rotate_y -= this.rotate_speed;
/* 184 */       if (this.rotate_y >= 6.283186F) this.rotate_y = 0.0F;
/*     */     }
/* 186 */     if (this.rotate_cam_x)
/*     */     {
/* 188 */       if (this.mouseY - this.pmouseY > 0.0F) this.rotate_x -= this.rotate_speed;
/* 189 */       if (this.mouseY - this.pmouseY < 0.0F) this.rotate_x += this.rotate_speed;
/* 190 */       if (this.rotate_x >= 6.283186F) this.rotate_x = 0.0F;
/*     */     }
/* 192 */     rotateX(this.rotate_x);
/* 193 */     rotateY(this.rotate_y);
/* 194 */     translate(-this.normalised_b / 2.0F, this.normalised_c / 2.0F, -this.normalised_a / 2.0F);
/*     */ 
/* 196 */     stroke(0);
/* 197 */     fill(0);
/* 198 */     line(0.0F, 0.0F, 0.0F, this.normalised_b, 0.0F, 0.0F);
/* 199 */     line(0.0F, 0.0F, 0.0F, this.normalised_a * cos(this.angle), 0.0F, this.normalised_a * sin(this.angle));
/* 200 */     line(0.0F, 0.0F, 0.0F, 0.0F, -this.normalised_c, 0.0F);
/* 201 */     stroke(190);
/* 202 */     line(this.normalised_b, 0.0F, 0.0F, this.normalised_a * cos(this.angle) + this.normalised_b, 0.0F, this.normalised_a * sin(this.angle));
/* 203 */     line(this.normalised_a * cos(this.angle) + this.normalised_b, 0.0F, this.normalised_a * sin(this.angle), this.normalised_a * cos(this.angle), 0.0F, this.normalised_a * sin(this.angle));
/* 204 */     textSize(23.0F);
/* 205 */     text("B", this.normalised_b / 2.0F, -10.0F, 0.0F);
/* 206 */     text("A", this.normalised_a * cos(this.angle) / 2.0F, -10.0F, this.normalised_a * sin(this.angle) / 2.0F);
/* 207 */     text("A x B", 10.0F, -this.normalised_c / 2.0F, 10.0F);
/*     */ 
/* 209 */     stroke(0);
/* 210 */     float f1 = this.arc_size;
/* 211 */     float f2 = 0.0F;
/* 212 */     float f3 = 0.0F;
/* 213 */     float f4 = 0.0F;
/* 214 */     float f5 = 0.1F;
/* 215 */     if (this.angle < 0.0F) f5 = -f5;
/* 216 */     for (float f6 = 0.0F; abs(f6) <= abs(this.angle); f6 += f5)
/*     */     {
/* 218 */       f3 = this.arc_size * cos(f6);
/* 219 */       f4 = this.arc_size * sin(f6);
/* 220 */       line(f1, 0.0F, f2, f3, 0.0F, f4);
/* 221 */       f1 = f3;
/* 222 */       f2 = f4;
/*     */     }
/*     */ 
/* 226 */     stroke(0);
/*     */ 
/* 228 */     pushMatrix();
/* 229 */     translate(this.normalised_a * cos(this.angle), 0.0F, this.normalised_a * sin(this.angle));
/* 230 */     line(0.0F, 0.0F, 0.0F, -this.arrowhead_size * 2.0F * sin(1.570796F - this.angle), this.arrowhead_size, -this.arrowhead_size * 2.0F * cos(1.570796F - this.angle));
/* 231 */     line(0.0F, 0.0F, 0.0F, this.arrowhead_size * 2.0F * sin(this.angle - 0.7853982F), -this.arrowhead_size, -this.arrowhead_size * 2.0F * cos(this.angle - 0.7853982F));
/* 232 */     line(0.0F, 0.0F, 0.0F, -this.arrowhead_size * 2.0F * sin(radians(135.0F) - this.angle), -this.arrowhead_size, -this.arrowhead_size * 2.0F * cos(radians(135.0F) - this.angle));
/* 233 */     line(-this.arrowhead_size * 2.0F * sin(1.570796F - this.angle), this.arrowhead_size, -this.arrowhead_size * 2.0F * cos(1.570796F - this.angle), this.arrowhead_size * 2.0F * sin(this.angle - 0.7853982F), -this.arrowhead_size, -this.arrowhead_size * 2.0F * cos(this.angle - 0.7853982F));
/* 234 */     line(this.arrowhead_size * 2.0F * sin(this.angle - 0.7853982F), -this.arrowhead_size, -this.arrowhead_size * 2.0F * cos(this.angle - 0.7853982F), -this.arrowhead_size * 2.0F * sin(radians(135.0F) - this.angle), -this.arrowhead_size, -this.arrowhead_size * 2.0F * cos(radians(135.0F) - this.angle));
/* 235 */     line(-this.arrowhead_size * 2.0F * sin(radians(135.0F) - this.angle), -this.arrowhead_size, -this.arrowhead_size * 2.0F * cos(radians(135.0F) - this.angle), -this.arrowhead_size * 2.0F * sin(1.570796F - this.angle), this.arrowhead_size, -this.arrowhead_size * 2.0F * cos(1.570796F - this.angle));
/*     */ 
/* 237 */     popMatrix();
/*     */ 
/* 239 */     line(this.normalised_b, 0.0F, 0.0F, this.normalised_b - (this.arrowhead_size * 2.0F), -this.arrowhead_size, -this.arrowhead_size);
/* 240 */     line(this.normalised_b, 0.0F, 0.0F, this.normalised_b - (this.arrowhead_size * 2.0F), -this.arrowhead_size, this.arrowhead_size);
/* 241 */     line(this.normalised_b, 0.0F, 0.0F, this.normalised_b - (this.arrowhead_size * 2.0F), this.arrowhead_size, 0.0F);
/* 242 */     line(this.normalised_b - (this.arrowhead_size * 2.0F), -this.arrowhead_size, -this.arrowhead_size, this.normalised_b - (this.arrowhead_size * 2.0F), -this.arrowhead_size, this.arrowhead_size);
/* 243 */     line(this.normalised_b - (this.arrowhead_size * 2.0F), -this.arrowhead_size, this.arrowhead_size, this.normalised_b - (this.arrowhead_size * 2.0F), this.arrowhead_size, 0.0F);
/* 244 */     line(this.normalised_b - (this.arrowhead_size * 2.0F), this.arrowhead_size, 0.0F, this.normalised_b - (this.arrowhead_size * 2.0F), -this.arrowhead_size, -this.arrowhead_size);
/*     */ 
/* 246 */     f6 = this.arrowhead_size;
/* 247 */     if (this.normalised_c < 0.0F) this.arrowhead_size = (-this.arrowhead_size);
/* 248 */     line(0.0F, -this.normalised_c, 0.0F, -this.arrowhead_size, -this.normalised_c + this.arrowhead_size * 2.0F, -this.arrowhead_size);
/* 249 */     line(0.0F, -this.normalised_c, 0.0F, this.arrowhead_size, -this.normalised_c + this.arrowhead_size * 2.0F, -this.arrowhead_size);
/* 250 */     line(0.0F, -this.normalised_c, 0.0F, 0.0F, -this.normalised_c + this.arrowhead_size * 2.0F, this.arrowhead_size);
/* 251 */     line(-this.arrowhead_size, -this.normalised_c + this.arrowhead_size * 2.0F, -this.arrowhead_size, this.arrowhead_size, -this.normalised_c + this.arrowhead_size * 2.0F, -this.arrowhead_size);
/* 252 */     line(this.arrowhead_size, -this.normalised_c + this.arrowhead_size * 2.0F, -this.arrowhead_size, 0.0F, -this.normalised_c + this.arrowhead_size * 2.0F, this.arrowhead_size);
/* 253 */     line(0.0F, -this.normalised_c + this.arrowhead_size * 2.0F, this.arrowhead_size, -this.arrowhead_size, -this.normalised_c + this.arrowhead_size * 2.0F, -this.arrowhead_size);
/* 254 */     this.arrowhead_size = f6;
/*     */   }
/*     */ 
/*     */   private final void jdMethod_this()
/*     */   {
/*   4 */     this.axes_centre_x = 150.0F;
/*   5 */     this.axes_centre_y = 400.0F;
/*   6 */     this.axes_centre_z = -300.0F;
/*   7 */     this.rotate_y = 0.0F;
/*   8 */     this.rotate_x = 0.0F;
/*   9 */     this.rotate_speed = 0.05F;
/*  10 */     this.rotate_cam_y = false;
/*  11 */     this.rotate_cam_x = false;
/*  12 */     this.length_a = 2.5F;
/*  13 */     this.length_b = 2.0F;
/*  14 */     this.length_c = 0.0F;
/*  15 */     this.scale_multiplier = 100.0F;
/*  16 */     this.normalised_a = (this.length_a * this.scale_multiplier);
/*  17 */     this.normalised_b = (this.length_b * this.scale_multiplier);
/*  18 */     this.normalised_c = (this.length_c * this.scale_multiplier);
/*  19 */     this.angle = 1.570796F;
/*  20 */     this.scale_speed = 0.05F;
/*  21 */     this.angle_scale_speed = 0.01F;
/*     */ 
/*  23 */     this.rect_size = 30.0F;
/*  24 */     this.rect_a_minus_pos_x = 520.0F;
/*  25 */     this.rect_a_minus_pos_y = 10.0F;
/*  26 */     this.rect_a_plus_pos_x = (this.rect_a_minus_pos_x + this.rect_size + 10.0F);
/*  27 */     this.rect_a_plus_pos_y = this.rect_a_minus_pos_y;
/*  28 */     this.rect_a_minus = false;
/*  29 */     this.rect_a_plus = false;
/*  30 */     this.rect_b_minus_pos_x = 520.0F;
/*  31 */     this.rect_b_minus_pos_y = 90.0F;
/*  32 */     this.rect_b_plus_pos_x = (this.rect_b_minus_pos_x + this.rect_size + 10.0F);
/*  33 */     this.rect_b_plus_pos_y = this.rect_b_minus_pos_y;
/*  34 */     this.rect_b_minus = false;
/*  35 */     this.rect_b_plus = false;
/*  36 */     this.rect_angle_minus_pos_x = 520.0F;
/*  37 */     this.rect_angle_minus_pos_y = 170.0F;
/*  38 */     this.rect_angle_plus_pos_x = (this.rect_angle_minus_pos_x + this.rect_size + 10.0F);
/*  39 */     this.rect_angle_plus_pos_y = this.rect_angle_minus_pos_y;
/*  40 */     this.rect_angle_minus = false;
/*  41 */     this.rect_angle_plus = false;
/*  42 */     this.rect_color = color(200);
/*  43 */     this.rect_highlight_color = color(255);
/*  44 */     this.mouse_over_button = false;
/*  45 */     this.arc_size = 50.0F;
/*  46 */     this.arrowhead_size = 7.0F;
/*     */   }
/*     */ 
/*     */   public Cross_Product()
/*     */   {
/*   1 */     jdMethod_this();
/*     */   }
/*     */ }

/* Location:           /Users/mfeyereisen/applets-final/classes/
 * Qualified Name:     Cross_Product
 * JD-Core Version:    0.5.3
 */