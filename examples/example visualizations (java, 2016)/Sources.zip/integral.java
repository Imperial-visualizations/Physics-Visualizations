/*     */ import processing.core.PApplet;
/*     */ import processing.core.PFont;
/*     */ 
/*     */ public class integral extends PApplet
/*     */ {
/*     */   int resolution;
/*     */   float w;
/*     */   int bars;
/*     */   int minBars;
/*     */   int maxBars;
/*     */   int downX;
/*     */   boolean drag;
/*     */   int origin;
/*     */   integral.Slider resSlider;
/*     */   integral.RadioGroup rgOrigin;
/*     */   PFont Tahoma14;
/*     */ 
/*     */   public void setup()
/*     */   {
/*  33 */     size(640, 480, "processing.core.PGraphics3");
/*     */ 
/*  35 */     this.resSlider = new integral.Slider(40, this.height - 40, this.width - 80, 14, this.minBars, this.maxBars, 6);
/*  36 */     String[] arrayOfString = { "Left", "Centre", "Right" };
/*  37 */     this.rgOrigin = new integral.RadioGroup(540, 50, arrayOfString, 0);
/*     */   }
/*     */ 
/*     */   public void draw()
/*     */   {
/*  42 */     this.origin = (this.rgOrigin._selected - 1);
/*  43 */     background(255);
/*     */ 
/*  46 */     pushMatrix();
/*  47 */     translate(this.width / 2, this.height / 2);
/*  48 */     scale(100.0F, -60.0F);
/*  49 */     translate(-2.0F, -2.5F);
/*     */ 
/*  53 */     stroke(255.0F, 50.0F, 50.0F);
/*  54 */     line(0.0F, 0.0F, 4, 0.0F);
/*     */ 
/*  59 */     stroke(50.0F, 255.0F, 50.0F);
/*  60 */     line(0.0F, 0.0F, 0.0F, 6.0F);
/*     */ 
/*  64 */     stroke(0);
/*     */ 
/*  67 */     beginShape(33);
/*  68 */     for (int i = 0; i <= this.resolution; ++i) {
/*  69 */       float f1 = i * this.w / this.resolution;
/*  70 */       float f2 = value(f1);
/*  71 */       vertex(f1, f2);
/*     */     }
/*  73 */     endShape();
/*     */ 
/*  76 */     drawBars();
/*     */ 
/*  78 */     popMatrix();
/*     */ 
/*  81 */     this.resSlider.draw();
/*  82 */     this.rgOrigin.draw();
/*  83 */     fill(0);
/*  84 */     text("Bar origin:", 540.0F, 40.0F);
/*  85 */     stroke(0);
/*  86 */     line(540.0F, 45.0F, 600.0F, 45.0F);
/*     */   }
/*     */ 
/*     */   public float value(float paramFloat) {
/*  90 */     float f = paramFloat * paramFloat * paramFloat - (3 * paramFloat * paramFloat) + 2.0F * paramFloat + 1.0F;
/*     */ 
/*  92 */     return f;
/*     */   }
/*     */ 
/*     */   public void drawBars()
/*     */   {
/*  97 */     stroke(150);
/*  98 */     fill(0.0F, 0.0F, 0.0F, 80.0F);
/*     */ 
/* 100 */     if (this.drag)
/*     */     {
/*     */       integral tmp24_23 = this; tmp24_23.bars = (int)(tmp24_23.bars + 0.6F * (this.maxBars - this.minBars) * (this.downX - this.mouseX) / this.width);
/* 102 */       if (this.bars < this.minBars) {
/* 103 */         this.bars = this.minBars;
/*     */       }
/* 105 */       else if (this.bars > this.maxBars) {
/* 106 */         this.bars = this.maxBars;
/*     */       }
/* 108 */       this.downX = this.mouseX;
/*     */     }
/*     */ 
/* 111 */     for (int i = 1; i <= this.bars; ++i) {
/* 112 */       float f1 = this.w * (i - 1) / this.bars;
/* 113 */       float f2 = this.w * i / this.bars;
/* 114 */       float f3 = (f1 + f2) / 2.0F;
/*     */ 
/* 116 */       float f4 = 0.0F;
/*     */ 
/* 118 */       if (this.origin < 0) {
/* 119 */         f4 = value(f1);
/*     */       }
/* 121 */       else if (this.origin == 0) {
/* 122 */         f4 = value(f3);
/*     */       }
/* 124 */       else if (this.origin > 0) {
/* 125 */         f4 = value(f2);
/*     */       }
/*     */ 
/* 128 */       beginShape(128);
/* 129 */       vertex(f1, 0.0F, -0.1F);
/* 130 */       vertex(f1, f4, -0.1F);
/* 131 */       vertex(f2, f4, -0.1F);
/* 132 */       vertex(f2, 0.0F, -0.1F);
/* 133 */       endShape();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void mousePressed() {
/* 138 */     if (this.mouseButton == 39) {
/* 139 */       this.origin += 1;
/* 140 */       if (this.origin > 1) {
/* 141 */         this.origin = -1;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 146 */     if (this.mouseButton == 37) {
/* 147 */       this.resSlider.processMouseDown();
/* 148 */       this.rgOrigin.processMouseDown();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void mouseReleased()
/*     */   {
/* 163 */     if (this.mouseButton == 37)
/* 164 */       this.resSlider.processMouseUp();
/*     */   }
/*     */ 
/*     */   public void keyPressed()
/*     */   {
/* 176 */     if (this.key == ' ') {
/* 177 */       this.origin += 1;
/* 178 */       if (this.origin > 1) {
/* 179 */         this.origin = -1;
/*     */       }
/*     */     }
/* 182 */     else if (this.key == 'r') {
/* 183 */       this.resSlider.updatePosition(6);
/* 184 */       this.origin = -1;
/*     */     }
/*     */ 
/* 188 */     if (this.bars < this.minBars) {
/* 189 */       this.bars = this.minBars;
/*     */     }
/* 191 */     else if (this.bars > this.maxBars) {
/* 192 */       this.bars = this.maxBars;
/*     */     }
/*     */ 
/* 195 */     redraw();
/*     */   }
/*     */ 
/*     */   private final void jdMethod_this()
/*     */   {
/*  12 */     this.resolution = 100;
/*  13 */     this.w = 2.8F;
/*  14 */     this.bars = 4;
/*  15 */     this.minBars = 4;
/*  16 */     this.maxBars = 50;
/*  17 */     this.downX = 0;
/*  18 */     this.drag = false;
/*     */ 
/*  24 */     this.origin = -1;
/*     */ 
/*  29 */     this.Tahoma14 = loadFont("Tahoma-14.vlw");
/*     */   }
/*     */ 
/*     */   public integral()
/*     */   {
/*   1 */     jdMethod_this();
/*     */   }
/*     */ 
/*     */   class Slider
/*     */   {
/*     */     private int _x;
/*     */     private int _y;
/*     */     private int _w;
/*     */     private int _h;
/*     */     private int _minValue;
/*     */     private int _maxValue;
/*     */     private int _pos;
/*     */     private float _frac;
/*     */     private boolean _dragging;
/*     */ 
/*     */     public void draw()
/*     */     {
/* 198 */       if (this._dragging) {
/* 199 */         int i = integral.this.mouseX - this._x;
/* 200 */         if (i < 0)
/* 201 */           i = 0;
/* 202 */         else if (i > this._w) {
/* 203 */           i = this._w;
/*     */         }
/* 205 */         this._frac = (i / this._w);
/* 206 */         updatePosition((int)(i / this._w * (this._maxValue - this._minValue)));
/*     */       }
/*     */ 
/* 209 */       integral.this.pushMatrix();
/* 210 */       integral.this.translate(this._x, this._y);
/* 211 */       integral.this.stroke(50.0F, 50.0F, 50.0F);
/* 212 */       integral.this.line(0.0F, 0.0F, this._w, 0.0F);
/* 213 */       integral.this.pushMatrix();
/* 214 */       integral.this.translate(this._w * this._pos / (this._maxValue - this._minValue), 0.0F);
/*     */ 
/* 216 */       integral.this.fill(250.0F, 130.0F, 20.0F);
/* 217 */       integral.this.rectMode(3);
/* 218 */       integral.this.rect(0.0F, 0.0F, this._h, this._h);
/* 219 */       integral.this.popMatrix();
/* 220 */       integral.this.popMatrix();
/*     */     }
/*     */ 
/*     */     public void updatePosition(int paramInt) {
/* 224 */       this._pos = paramInt;
/*     */ 
/* 226 */       integral.this.bars = (this._minValue + (int)(paramInt + 0.0025F * paramInt * paramInt * paramInt));
/*     */     }
/*     */ 
/*     */     public void processMouseDown() {
/* 230 */       int i = integral.this.mouseX - this._x;
/* 231 */       int j = integral.this.mouseY - this._y;
/* 232 */       if (integral.mag(i - (this._w * this._pos / (this._maxValue - this._minValue)), j) <= this._h)
/* 233 */         this._dragging = true;
/*     */     }
/*     */ 
/*     */     public void processMouseUp()
/*     */     {
/* 238 */       this._dragging = false;
/*     */     }
/*     */ 
/*     */     private final void jdMethod_this()
/*     */     {
/* 250 */       this._dragging = false;
/*     */     }
/*     */ 
/*     */     public Slider(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7)
/*     */     {
/* 187 */       jdMethod_this();
/* 188 */       this._x = paramInt1;
/* 189 */       this._y = paramInt2;
/* 190 */       this._w = paramInt3;
/* 191 */       this._h = paramInt4;
/* 192 */       this._minValue = paramInt5;
/* 193 */       this._maxValue = paramInt6;
/* 194 */       updatePosition(paramInt7);
/*     */     }
/*     */   }
/*     */ 
/*     */   class RadioGroup
/*     */   {
/*     */     private int _x;
/*     */     private int _y;
/*     */     private int _w;
/*     */     private String[] _options;
/*     */     public int _selected;
/*     */ 
/*     */     public void draw()
/*     */     {
/* 275 */       integral.this.textFont(integral.this.Tahoma14, 14.0F);
/* 276 */       integral.this.pushMatrix();
/* 277 */       integral.this.translate(this._x, this._y);
/* 278 */       for (int i = 0; i < this._options.length; ++i) {
/* 279 */         integral.this.pushMatrix();
/* 280 */         integral.this.translate(6.0F, 6 + i * 18);
/* 281 */         integral.this.ellipseMode(3);
/* 282 */         integral.this.fill(255.0F, 255.0F, 255.0F);
/* 283 */         integral.this.stroke(0.0F, 0.0F, 0.0F);
/* 284 */         integral.this.ellipse(0.0F, 0.0F, 12.0F, 12.0F);
/* 285 */         if (i == this._selected) {
/* 286 */           integral.this.fill(250.0F, 130.0F, 20.0F);
/* 287 */           integral.this.noStroke();
/* 288 */           integral.this.ellipse(0.0F, 0.0F, 8.0F, 8.0F);
/*     */         }
/*     */         else
/*     */         {
/* 292 */           integral.this.fill(0.0F, 0.0F, 0.0F);
/*     */         }
/* 294 */         integral.this.pushMatrix();
/* 295 */         integral.this.translate(10.0F, 6.0F);
/*     */ 
/* 297 */         integral.this.text(this._options[i], 0.0F, -2.0F);
/* 298 */         integral.this.popMatrix();
/* 299 */         integral.this.popMatrix();
/*     */       }
/* 301 */       integral.this.popMatrix();
/*     */     }
/*     */ 
/*     */     public void processMouseDown() {
/* 305 */       int i = integral.this.mouseX - this._x;
/* 306 */       int j = integral.this.mouseY - this._y;
/*     */ 
/* 308 */       if ((i >= 0) && (i <= this._w)) {
/* 309 */         int k = 0;
/* 310 */         while (j > 18) {
/* 311 */           ++k;
/* 312 */           j -= 18;
/*     */         }
/* 314 */         if ((j >= 0) && (j <= 12))
/* 315 */           this._selected = k;
/*     */       }
/*     */     }
/*     */ 
/*     */     public RadioGroup(int paramInt1, int paramInt2, String[] paramArrayOfString, int paramInt3)
/*     */     {
/* 267 */       this._x = paramInt1;
/* 268 */       this._y = paramInt2;
/* 269 */       this._w = 60;
/* 270 */       this._options = paramArrayOfString;
/* 271 */       this._selected = paramInt3;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/mfeyereisen/applets-final/classes/
 * Qualified Name:     integral
 * JD-Core Version:    0.5.3
 */