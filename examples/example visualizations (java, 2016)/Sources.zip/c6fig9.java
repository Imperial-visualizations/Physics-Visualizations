/*     */ import processing.core.PApplet;
/*     */ import processing.core.PFont;
/*     */ 
/*     */ public class c6fig9 extends PApplet
/*     */ {
/*     */   float thetaStep;
/*     */   float[][] segPositions;
/*     */   boolean[][] drawing;
/*     */   int userCell;
/*     */   int dragging;
/*     */   int draggable;
/*     */   float dragMargin;
/*     */   int start;
/*     */   int end;
/*     */   boolean drawSmooth;
/*     */   c6fig9.ToggleButton btnSmooth;
/*     */   PFont Tahoma14;
/*     */ 
/*     */   public void setup()
/*     */   {
/*  22 */     size(640, 480, "processing.core.PGraphics3");
/*  23 */     framerate(30.0F);
/*     */ 
/*  25 */     for (int i = 0; i <= 15; ++i) {
/*  26 */       this.segPositions[i][0] = 2.0F;
/*  27 */       this.segPositions[i][1] = 4;
/*     */ 
/*  29 */       this.drawing[i][0] = 0;
/*  30 */       this.drawing[i][1] = 0;
/*     */     }
/*     */ 
/*  33 */     for (i = 2; i <= 10; ++i) {
/*  34 */       this.drawing[i][0] = 1;
/*  35 */       this.drawing[i][1] = 1;
/*     */     }
/*     */ 
/*  38 */     this.btnSmooth = new c6fig9.ToggleButton(520, 10, 110, 20, "Smooth");
/*     */ 
/*  44 */     textFont(this.Tahoma14, 14.0F);
/*     */   }
/*     */ 
/*     */   public void draw() {
/*  48 */     pushMatrix();
/*  49 */     translate(this.width / 2.0F, this.height / 2.0F);
/*  50 */     calcCell();
/*  51 */     this.drawSmooth = this.btnSmooth.value;
/*  52 */     setCursor();
/*  53 */     scale(35.0F, -35.0F, 35.0F);
/*  54 */     background(255);
/*  55 */     drawGrid();
/*  56 */     drawArea();
/*     */ 
/*  58 */     drawArc();
/*  59 */     popMatrix();
/*     */ 
/*  61 */     this.btnSmooth.draw();
/*     */   }
/*     */ 
/*     */   public void drawGrid() {
/*  65 */     pushMatrix();
/*  66 */     stroke(200.0F, 200.0F, 200.0F);
/*  67 */     for (float f1 = 0.0F; f1 < 3.141593F - this.thetaStep; f1 += this.thetaStep) {
/*  68 */       line(-6.2F, 0.0F, 6.2F, 0.0F);
/*  69 */       rotateZ(this.thetaStep);
/*     */     }
/*  71 */     popMatrix();
/*     */ 
/*  73 */     pushMatrix();
/*  74 */     for (int i = 1; i <= 6; ++i) {
/*  75 */       beginShape(34);
/*  76 */       for (float f2 = 0.0F; f2 < 6.283186F; f2 += this.thetaStep / 3) {
/*  77 */         vertex(i * cos(f2), i * sin(f2));
/*     */       }
/*  79 */       endShape();
/*     */     }
/*  81 */     popMatrix();
/*     */   }
/*     */ 
/*     */   public void drawArea() {
/*  85 */     stroke(0);
/*     */     int k;
/*     */     int l;
/*     */     int j;
/*  86 */     if (!(this.drawSmooth)) {
/*  87 */       for (int i = 0; i < 16; ++i) {
/*  88 */         pushMatrix();
/*  89 */         rotateZ(i * this.thetaStep);
/*     */         float f2;
/*  91 */         if (this.drawing[i][0] != 0) {
/*  92 */           beginShape(33);
/*  93 */           for (f2 = 0.0F; f2 <= this.thetaStep; f2 += this.thetaStep / 3) {
/*  94 */             vertex(this.segPositions[i][0] * cos(f2), this.segPositions[i][0] * sin(f2), 0.01F);
/*     */           }
/*  96 */           endShape();
/*     */         }
/*     */ 
/*  99 */         if (this.drawing[i][1] != 0) {
/* 100 */           beginShape(33);
/* 101 */           for (f2 = 0.0F; f2 <= this.thetaStep; f2 += this.thetaStep / 3) {
/* 102 */             vertex(this.segPositions[i][1] * cos(f2), this.segPositions[i][1] * sin(f2), 0.01F);
/*     */           }
/* 104 */           endShape();
/*     */         }
/* 106 */         popMatrix();
/*     */       }
/*     */ 
/* 111 */       k = 0;
/*     */ 
/* 113 */       for (l = 0; l < 16; ++l) {
/* 114 */         pushMatrix();
/* 115 */         rotateZ(l * this.thetaStep);
/* 116 */         if (l < 1) {
/* 117 */           i = 15;
/* 118 */           j = 0;
/* 119 */           k = 1;
/*     */         }
/*     */         else {
/* 122 */           i = l - 1;
/* 123 */           j = l;
/* 124 */           k = 0;
/*     */         }
/*     */ 
/* 129 */         if ((this.drawing[i][1] != 0) && (this.drawing[j][1] != 0)) {
/* 130 */           if (this.segPositions[i][1] != this.segPositions[j][1]) {
/* 131 */             line(this.segPositions[i][1], 0.0F, this.segPositions[j][1], 0.0F);
/*     */           }
/*     */ 
/* 134 */           if ((((this.drawing[0][1] == 0) || (this.drawing[15][1] == 0))) && 
/* 135 */             (this.segPositions[i][0] != this.segPositions[j][0])) {
/* 136 */             line(this.segPositions[i][0], 0.0F, this.segPositions[j][0], 0.0F);
/*     */           }
/*     */ 
/*     */         }
/* 140 */         else if ((this.drawing[i][1] == 0) && (this.drawing[j][1] != 0)) {
/* 141 */           line(this.segPositions[j][1], 0.0F, this.segPositions[j][0], 0.0F);
/*     */         }
/* 143 */         else if ((this.drawing[j][1] == 0) && (this.drawing[i][1] != 0)) {
/* 144 */           line(this.segPositions[i][1], 0.0F, this.segPositions[i][0], 0.0F);
/*     */         }
/*     */ 
/* 147 */         popMatrix();
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 152 */       beginShape(34);
/*     */ 
/* 154 */       j = 16;
/* 155 */       k = 0;
/*     */ 
/* 157 */       stroke(0);
/* 158 */       fill(0.0F, 0.0F, 0.0F, 150.0F);
/*     */ 
/* 160 */       for (l = 0; l < 16; ++l) {
/* 161 */         f1 = (l + 0.5F) * this.thetaStep;
/* 162 */         if (this.drawing[l][1] != 0) {
/* 163 */           if (l < j) {
/* 164 */             j = l;
/*     */           }
/* 166 */           k = l;
/* 167 */           curveVertex(this.segPositions[l][1] * cos(f1), this.segPositions[l][1] * sin(f1), 0.1F);
/*     */         }
/*     */       }
/*     */ 
/* 171 */       if ((this.drawing[0][1] == 0) || (this.drawing[15][1] == 0)) {
/* 172 */         for (l = k; l >= j; --l) {
/* 173 */           f1 = (l + 0.5F) * this.thetaStep;
/* 174 */           if (this.drawing[l][1] != 0) {
/* 175 */             if (l < j) {
/* 176 */               j = l;
/*     */             }
/* 178 */             k = l;
/* 179 */             curveVertex(this.segPositions[l][0] * cos(f1), this.segPositions[l][0] * sin(f1), 0.1F);
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 186 */       float f1 = (j + 0.5F) * this.thetaStep;
/* 187 */       curveVertex(this.segPositions[j][1] * cos(f1), this.segPositions[j][1] * sin(f1), 0.1F);
/* 188 */       f1 = (j + 1.5F) * this.thetaStep;
/* 189 */       curveVertex(this.segPositions[(j + 1)][1] * cos(f1), this.segPositions[(j + 1)][1] * sin(f1), 0.1F);
/*     */ 
/* 193 */       endShape();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void drawHint() {
/* 198 */     pushMatrix();
/*     */ 
/* 200 */     rotateZ(this.userCell * this.thetaStep + this.thetaStep / 2.0F);
/*     */ 
/* 202 */     stroke(200.0F, 20.0F, 20.0F);
/* 203 */     line(0.0F, 0.0F, 4, 0.0F);
/*     */ 
/* 205 */     popMatrix();
/*     */   }
/*     */ 
/*     */   public void drawArc() {
/* 209 */     if (this.dragging == 2) {
/* 210 */       float f1 = 0.02857143F * (this.mouseX - (this.width / 2.0F));
/* 211 */       float f2 = -0.02857143F * (this.mouseY - (this.height / 2.0F));
/*     */ 
/* 213 */       float f3 = mag(f1, f2);
/*     */ 
/* 215 */       float f4 = atan2(f2, f1);
/*     */ 
/* 217 */       if (f4 < 0.0F) {
/* 218 */         f4 += 6.283186F;
/*     */       }
/*     */ 
/* 221 */       int i = 0;
/* 222 */       float f5 = f4;
/*     */ 
/* 224 */       while (f5 > this.thetaStep) {
/* 225 */         ++i;
/* 226 */         f5 -= this.thetaStep;
/*     */       }
/*     */ 
/* 229 */       pushMatrix();
/*     */ 
/* 231 */       float f6 = 0.0F;
/*     */ 
/* 233 */       stroke(250.0F, 130.0F, 20.0F);
/*     */ 
/* 235 */       float f7 = this.thetaStep / 12.0F;
/*     */ 
/* 237 */       if (i > this.userCell) {
/* 238 */         this.start = this.userCell;
/* 239 */         this.end = i;
/*     */       }
/*     */       else {
/* 242 */         this.start = i;
/* 243 */         this.end = this.userCell;
/*     */       }
/*     */ 
/* 246 */       rotateZ((this.start + 0.5F) * this.thetaStep);
/*     */ 
/* 248 */       beginShape(33);
/* 249 */       while (f6 <= (this.end - this.start) * this.thetaStep) {
/* 250 */         vertex(6.2F * cos(f6), 6.2F * sin(f6), 0.0F);
/*     */ 
/* 252 */         f6 += f7;
/*     */       }
/* 254 */       endShape();
/*     */ 
/* 256 */       popMatrix();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setCursor() {
/* 261 */     if (this.draggable > -1) {
/* 262 */       cursor(12);
/*     */     }
/*     */     else
/* 265 */       cursor(0);
/*     */   }
/*     */ 
/*     */   public void calcCell()
/*     */   {
/* 270 */     float f1 = 0.02857143F * (this.mouseX - (this.width / 2.0F));
/* 271 */     float f2 = -0.02857143F * (this.mouseY - (this.height / 2.0F));
/*     */ 
/* 273 */     float f3 = mag(f1, f2);
/*     */ 
/* 275 */     float f4 = atan2(f2, f1);
/*     */ 
/* 277 */     int i = 1;
/*     */ 
/* 279 */     if (f4 < 0.0F)
/*     */     {
/* 281 */       f4 = 6.283186F + f4;
/* 282 */       i = 1;
/*     */     }
/*     */ 
/* 285 */     int j = 0;
/* 286 */     float f5 = f4;
/*     */ 
/* 288 */     while (f5 > this.thetaStep) {
/* 289 */       ++j;
/* 290 */       f5 -= this.thetaStep;
/*     */     }
/*     */ 
/* 294 */     if (this.dragging == -1) {
/* 295 */       this.userCell = j;
/*     */ 
/* 297 */       if ((f3 >= this.segPositions[this.userCell][1] - this.dragMargin) && (f3 <= this.segPositions[this.userCell][1] + this.dragMargin)) {
/* 298 */         this.draggable = 1;
/*     */       }
/* 300 */       else if ((f3 >= this.segPositions[this.userCell][0] - this.dragMargin) && (f3 <= this.segPositions[this.userCell][0] + this.dragMargin)) {
/* 301 */         if ((this.drawing[0][1] == 0) || (this.drawing[15][1] == 0)) {
/* 302 */           this.draggable = 0;
/*     */         }
/*     */       }
/* 305 */       else if ((f3 > 6.0F) && (f3 < 8.0F)) {
/* 306 */         this.draggable = 2;
/*     */       }
/*     */       else {
/* 309 */         this.draggable = -1;
/*     */       }
/*     */ 
/*     */     }
/* 313 */     else if (this.dragging < 2) {
/* 314 */       this.segPositions[this.userCell][this.dragging] = f3;
/* 315 */       if (this.segPositions[this.userCell][this.dragging] > 6.0F)
/* 316 */         this.segPositions[this.userCell][this.dragging] = 6.0F;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void mousePressed()
/*     */   {
/* 323 */     if (this.mouseButton != 37)
/*     */     {
/*     */       return;
/*     */     }
/*     */ 
/* 328 */     if (this.draggable > -1) {
/* 329 */       this.dragging = this.draggable;
/*     */     }
/*     */ 
/* 332 */     this.btnSmooth.processMouseDown();
/*     */   }
/*     */ 
/*     */   public void mouseReleased()
/*     */   {
/* 338 */     if (this.dragging == 2)
/*     */     {
/* 340 */       for (int i = 0; i < 16; ++i) {
/* 341 */         this.drawing[i][1] = 0;
/* 342 */         this.drawing[i][0] = 0;
/*     */       }
/*     */ 
/* 348 */       if (this.end - this.start == 15) {
/* 349 */         i = 0;
/*     */       }
/*     */       else {
/* 352 */         i = 1;
/*     */       }
/*     */ 
/* 355 */       for (int j = this.start; j <= this.end; ++j) {
/* 356 */         this.drawing[j][1] = 1;
/* 357 */         this.drawing[j][0] = i;
/*     */       }
/*     */     }
/*     */ 
/* 361 */     if (this.mouseButton == 37)
/* 362 */       this.dragging = -1;
/*     */   }
/*     */ 
/*     */   private final void jdMethod_this()
/*     */   {
/*   1 */     this.thetaStep = 0.3926991F;
/*   2 */     this.segPositions = new float[16][2];
/*   3 */     this.drawing = new boolean[16][2];
/*     */ 
/*   5 */     this.userCell = 0;
/*     */ 
/*   7 */     this.dragging = -1;
/*   8 */     this.draggable = -1;
/*   9 */     this.dragMargin = 0.075F;
/*     */ 
/*  14 */     this.drawSmooth = false;
/*     */ 
/*  19 */     this.Tahoma14 = loadFont("Tahoma-14.vlw");
/*     */   }
/*     */ 
/*     */   public c6fig9()
/*     */   {
/*   1 */     jdMethod_this();
/*     */   }
/*     */ 
/*     */   class ToggleButton
/*     */   {
/*     */     public boolean value;
/*     */     public String msg;
/*     */     public int x;
/*     */     public int y;
/*     */     public int w;
/*     */     public int h;
/*     */ 
/*     */     public void draw()
/*     */     {
/* 377 */       c6fig9.this.pushMatrix();
/* 378 */       c6fig9.this.translate(this.x, this.y);
/* 379 */       if (this.value) {
/* 380 */         c6fig9.this.fill(250.0F, 130.0F, 20.0F);
/* 381 */         c6fig9.this.stroke(0);
/* 382 */         c6fig9.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/*     */       else
/*     */       {
/* 390 */         c6fig9.this.fill(255.0F, 255.0F, 255.0F);
/* 391 */         c6fig9.this.stroke(0);
/* 392 */         c6fig9.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/* 394 */       c6fig9.this.rect(0.0F, 0.0F, this.w, this.h);
/* 395 */       c6fig9.this.noStroke();
/* 396 */       c6fig9.this.fill(255.0F, 255.0F, 255.0F);
/* 397 */       c6fig9.this.rect(2.0F, 2.0F, this.w - 4, this.h - 4);
/*     */ 
/* 399 */       c6fig9.this.fill(0);
/* 400 */       c6fig9.this.textFont(c6fig9.this.Tahoma14, 14.0F);
/* 401 */       c6fig9.this.text(this.msg, 5, this.h - 5);
/*     */ 
/* 403 */       c6fig9.this.popMatrix();
/*     */     }
/*     */ 
/*     */     public void processMouseDown() {
/* 407 */       int i = c6fig9.this.mouseX - this.x;
/* 408 */       int j = c6fig9.this.mouseY - this.y;
/*     */ 
/* 410 */       if ((i < 0) || (i > this.w) || 
/* 411 */         (j < 0) || (j > this.h)) return;
/* 412 */       this.value ^= true;
/*     */     }
/*     */ 
/*     */     private final void jdMethod_this()
/*     */     {
/* 417 */       this.value = false;
/*     */     }
/*     */ 
/*     */     public ToggleButton(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString)
/*     */     {
/* 367 */       jdMethod_this();
/* 368 */       this.x = paramInt1;
/* 369 */       this.y = paramInt2;
/* 370 */       this.w = paramInt3;
/* 371 */       paramInt4 = 20;
/* 372 */       this.h = paramInt4;
/* 373 */       this.msg = paramString;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/mfeyereisen/applets-final/classes/
 * Qualified Name:     c6fig9
 * JD-Core Version:    0.5.3
 */