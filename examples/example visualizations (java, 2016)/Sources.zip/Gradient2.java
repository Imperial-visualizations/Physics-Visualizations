/*     */ import processing.core.PApplet;
/*     */ import processing.core.PFont;
/*     */ 
/*     */ public class Gradient2 extends PApplet
/*     */ {
/*     */   float axes_centre_x;
/*     */   float axes_centre_y;
/*     */   float axes_centre_z;
/*     */   float axes_length;
/*     */   boolean rotate_cam_y;
/*     */   boolean rotate_cam_x;
/*     */   float rotate_y;
/*     */   float rotate_x;
/*     */   float rotate_speed;
/*     */   float surface_res;
/*     */   float scale_factor;
/*     */   float surface_alpha_value;
/*     */   float ball_x;
/*     */   float ball_y;
/*     */   float ball_z;
/*     */   float initial_z;
/*     */   float ball_size;
/*     */   float ball_step;
/*     */   float arrow_scale_factor;
/*     */   float v_x;
/*     */   float v_y;
/*     */   float gradient_res;
/*     */   int surface;
/*     */   boolean show_gradient_map;
/*     */   PFont font;
/*     */   Gradient2.Button btnXminus;
/*     */   Gradient2.Button btnXplus;
/*     */   Gradient2.Button btnYminus;
/*     */   Gradient2.Button btnYplus;
/*     */   Gradient2.ToggleButton tbAnimate;
/*     */   Gradient2.ToggleButton tbShowGradient;
/*     */ 
/*     */   public void reset()
/*     */   {
/*  39 */     this.rotate_cam_y = false;
/*  40 */     this.rotate_cam_x = false;
/*  41 */     this.rotate_y = 0.0F;
/*  42 */     this.rotate_x = 0.0F;
/*  43 */     this.surface_alpha_value = 30.0F;
/*  44 */     this.ball_x = (this.axes_length - 50.0F);
/*  45 */     this.ball_y = (this.axes_length - 50.0F);
/*  46 */     this.ball_z = 0.0F;
/*  47 */     this.initial_z = (f(this.ball_x / this.scale_factor, this.ball_y / this.scale_factor) * this.scale_factor);
/*  48 */     this.v_x = 0.0F;
/*  49 */     this.v_y = 0.0F;
/*  50 */     this.surface = 0;
/*  51 */     this.show_gradient_map = false;
/*  52 */     this.tbAnimate.value = false;
/*  53 */     this.tbShowGradient.value = false;
/*     */   }
/*     */ 
/*     */   public void setup()
/*     */   {
/*  58 */     size(640, 480, "processing.core.PGraphics3");
/*  59 */     framerate(60.0F);
/*  60 */     this.font = loadFont("Arial-Black-20.vlw");
/*  61 */     textFont(this.font, 20.0F);
/*     */ 
/*  63 */     this.btnXminus = new Gradient2.Button(510, 370, 30, 30, "-x");
/*  64 */     this.btnXplus = new Gradient2.Button(575, 370, 30, 30, "+x");
/*  65 */     this.btnYplus = new Gradient2.Button(542, 330, 30, 30, "+y");
/*  66 */     this.btnYminus = new Gradient2.Button(542, 410, 30, 30, "-y");
/*  67 */     this.tbAnimate = new Gradient2.ToggleButton(540, 50, 80, 20, "Animate");
/*  68 */     this.tbShowGradient = new Gradient2.ToggleButton(500, 10, 135, 20, "Show Gradient");
/*     */   }
/*     */ 
/*     */   public void mousePressed()
/*     */   {
/*  73 */     if (this.mouseButton == 37)
/*     */     {
/*  75 */       this.btnXminus.processMouseDown();
/*  76 */       this.btnXplus.processMouseDown();
/*  77 */       this.btnYplus.processMouseDown();
/*  78 */       this.btnYminus.processMouseDown();
/*  79 */       this.tbAnimate.processMouseDown();
/*  80 */       this.tbShowGradient.processMouseDown();
/*     */     }
/*     */     else
/*     */     {
/*  85 */       this.rotate_cam_y = true;
/*  86 */       this.rotate_cam_x = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void mouseReleased()
/*     */   {
/*  92 */     this.rotate_cam_y = false;
/*  93 */     this.rotate_cam_x = false;
/*     */ 
/*  95 */     if (this.mouseButton != 37)
/*     */       return;
/*  97 */     this.btnXminus.processMouseUp();
/*  98 */     this.btnXplus.processMouseUp();
/*  99 */     this.btnYplus.processMouseUp();
/* 100 */     this.btnYminus.processMouseUp();
/*     */   }
/*     */ 
/*     */   public void keyPressed()
/*     */   {
/* 106 */     if (this.key == 'r') reset();
/* 107 */     if (this.keyCode == 37)
/*     */     {
/* 109 */       this.ball_x -= this.ball_step;
/* 110 */       if (this.ball_x < -this.axes_length) this.ball_x = (-this.axes_length);
/* 111 */       this.v_x = 0.0F;
/* 112 */       this.v_y = 0.0F;
/*     */     }
/* 114 */     if (this.keyCode == 39)
/*     */     {
/* 116 */       this.ball_x += this.ball_step;
/* 117 */       if (this.ball_x > this.axes_length) this.ball_x = this.axes_length;
/* 118 */       this.v_x = 0.0F;
/* 119 */       this.v_y = 0.0F;
/*     */     }
/* 121 */     if (this.keyCode == 38)
/*     */     {
/* 123 */       this.ball_y -= this.ball_step;
/* 124 */       if (this.ball_y < -this.axes_length) this.ball_y = (-this.axes_length);
/* 125 */       this.v_x = 0.0F;
/* 126 */       this.v_y = 0.0F;
/*     */     }
/* 128 */     if (this.keyCode == 40)
/*     */     {
/* 130 */       this.ball_y += this.ball_step;
/* 131 */       if (this.ball_y > this.axes_length) this.ball_y = this.axes_length;
/* 132 */       this.v_x = 0.0F;
/* 133 */       this.v_y = 0.0F;
/*     */     }
/* 135 */     if (this.keyCode == 16)
/*     */     {
/* 137 */       this.surface += 1;
/* 138 */       if (this.surface > 1) this.surface = 0;
/*     */     }
/* 140 */     if (this.keyCode != 10)
/*     */       return;
/* 142 */     if (this.show_gradient_map) this.show_gradient_map = false; else this.show_gradient_map = true;
/*     */   }
/*     */ 
/*     */   public float f(float paramFloat1, float paramFloat2)
/*     */   {
/* 148 */     if (this.surface == 0) return (paramFloat1 * paramFloat1 + paramFloat2 * paramFloat2);
/* 149 */     return (-paramFloat1 * paramFloat1 + paramFloat2 * paramFloat2);
/*     */   }
/*     */ 
/*     */   public float df_dx(float paramFloat)
/*     */   {
/* 154 */     if (this.surface == 0) return (2.0F * paramFloat);
/* 155 */     return (-2.0F * paramFloat);
/*     */   }
/*     */ 
/*     */   public float df_dy(float paramFloat)
/*     */   {
/* 160 */     if (this.surface == 0) return (2.0F * paramFloat);
/* 161 */     return (2.0F * paramFloat);
/*     */   }
/*     */ 
/*     */   public void draw()
/*     */   {
/* 166 */     background(255);
/*     */ 
/* 168 */     this.btnXminus.draw();
/* 169 */     this.btnXplus.draw();
/* 170 */     this.btnYminus.draw();
/* 171 */     this.btnYplus.draw();
/* 172 */     this.tbAnimate.draw();
/* 173 */     this.tbShowGradient.draw();
/* 174 */     this.show_gradient_map = this.tbShowGradient.value;
/*     */ 
/* 176 */     if (this.tbAnimate.value)
/*     */     {
/* 178 */       this.v_x -= df_dx(this.ball_x / this.scale_factor);
/* 179 */       this.v_y -= df_dy(this.ball_y / this.scale_factor);
/* 180 */       this.ball_x += this.v_x;
/* 181 */       this.ball_y += this.v_y;
/* 182 */       if (this.ball_x < -this.axes_length) this.ball_x = (-this.axes_length);
/* 183 */       if (this.ball_x > this.axes_length) this.ball_x = this.axes_length;
/* 184 */       if (this.ball_y < -this.axes_length) this.ball_y = (-this.axes_length);
/* 185 */       if (this.ball_y > this.axes_length) this.ball_y = this.axes_length;
/*     */     }
/*     */ 
/* 188 */     if (this.btnXminus.value)
/*     */     {
/* 190 */       this.ball_x -= this.ball_step;
/* 191 */       if (this.ball_x < -this.axes_length) this.ball_x = (-this.axes_length);
/* 192 */       this.v_x = 0.0F;
/* 193 */       this.v_y = 0.0F;
/*     */     }
/* 195 */     if (this.btnXplus.value)
/*     */     {
/* 197 */       this.ball_x += this.ball_step;
/* 198 */       if (this.ball_x > this.axes_length) this.ball_x = this.axes_length;
/* 199 */       this.v_x = 0.0F;
/* 200 */       this.v_y = 0.0F;
/*     */     }
/* 202 */     if (this.btnYplus.value)
/*     */     {
/* 204 */       this.ball_y -= this.ball_step;
/* 205 */       if (this.ball_y < -this.axes_length) this.ball_y = (-this.axes_length);
/* 206 */       this.v_x = 0.0F;
/* 207 */       this.v_y = 0.0F;
/*     */     }
/* 209 */     if (this.btnYminus.value)
/*     */     {
/* 211 */       this.ball_y += this.ball_step;
/* 212 */       if (this.ball_y > this.axes_length) this.ball_y = this.axes_length;
/* 213 */       this.v_x = 0.0F;
/* 214 */       this.v_y = 0.0F;
/*     */     }
/*     */ 
/* 218 */     stroke(0); fill(0);
/* 219 */     translate(this.axes_centre_x, this.axes_centre_y, this.axes_centre_z);
/*     */ 
/* 221 */     if (this.rotate_cam_y)
/*     */     {
/* 223 */       if (this.mouseX - this.pmouseX > 0.0F) this.rotate_y += this.rotate_speed;
/* 224 */       if (this.mouseX - this.pmouseX < 0.0F) this.rotate_y -= this.rotate_speed;
/* 225 */       if (this.rotate_y >= 6.283186F) this.rotate_y = 0.0F;
/*     */     }
/* 227 */     if (this.rotate_cam_x)
/*     */     {
/* 229 */       if (this.mouseY - this.pmouseY > 0.0F) this.rotate_x -= this.rotate_speed;
/* 230 */       if (this.mouseY - this.pmouseY < 0.0F) this.rotate_x += this.rotate_speed;
/* 231 */       if (this.rotate_x >= 6.283186F) this.rotate_x = 0.0F;
/*     */     }
/* 233 */     rotateX(this.rotate_x);
/* 234 */     rotateY(this.rotate_y);
/*     */ 
/* 236 */     line(0.0F, 0.0F, 0.0F, this.axes_length, 0.0F, 0.0F);
/* 237 */     line(0.0F, 0.0F, 0.0F, 0.0F, -this.axes_length, 0.0F);
/* 238 */     line(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, this.axes_length);
/* 239 */     text("z", 0.0F, -this.axes_length - 20.0F, 0.0F);
/* 240 */     text("x", this.axes_length + 20.0F, 0.0F, 0.0F);
/* 241 */     text("y", 0.0F, 0.0F, this.axes_length + 20.0F);
/*     */ 
/* 244 */     if (this.show_gradient_map) this.surface_alpha_value = 30.0F; else this.surface_alpha_value = 50.0F;
/* 245 */     stroke(100.0F, 100.0F, 100.0F, this.surface_alpha_value);
/* 246 */     fill(100.0F, 100.0F, 100.0F, this.surface_alpha_value);
/* 247 */     float f1 = this.axes_length / this.scale_factor / this.surface_res;
/*     */ 
/* 249 */     for (float f4 = -this.axes_length / this.scale_factor; f4 < this.axes_length / this.scale_factor; f4 += f1)
/*     */     {
/* 251 */       for (f5 = -this.axes_length / this.scale_factor; f5 < this.axes_length / this.scale_factor; f5 += f1)
/*     */       {
/* 254 */         beginShape(128);
/* 255 */         float f2 = f4 * this.scale_factor;
/* 256 */         float f3 = f5 * this.scale_factor;
/* 257 */         vertex(f2, -f(f4, f5) * this.scale_factor, f3);
/* 258 */         f2 = (f4 + f1) * this.scale_factor;
/* 259 */         vertex(f2, -f(f4 + f1, f5) * this.scale_factor, f3);
/* 260 */         f3 = (f5 + f1) * this.scale_factor;
/* 261 */         vertex(f2, -f(f4 + f1, f5 + f1) * this.scale_factor, f3);
/* 262 */         f2 = f4 * this.scale_factor;
/* 263 */         vertex(f2, -f(f4, f5 + f1) * this.scale_factor, f3);
/* 264 */         endShape();
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 272 */     stroke(0);
/* 273 */     line(this.ball_x, 0.0F, this.ball_y, this.ball_x - (df_dx(this.ball_x) * this.arrow_scale_factor), 0.0F, this.ball_y - (df_dy(this.ball_y) * this.arrow_scale_factor));
/* 274 */     pushMatrix();
/* 275 */     translate(this.ball_x - (df_dx(this.ball_x) * this.arrow_scale_factor), 0.0F, this.ball_y - (df_dy(this.ball_y) * this.arrow_scale_factor));
/* 276 */     f4 = sqrt(sq(df_dx(this.ball_x) * this.arrow_scale_factor) + sq(df_dy(this.ball_y) * this.arrow_scale_factor));
/* 277 */     float f5 = f4 / 5;
/* 278 */     float f6 = atan(this.ball_x / this.ball_y);
/* 279 */     float f7 = 1.0F;
/* 280 */     if (this.ball_y < 0.0F) f7 = -1.0F;
/* 281 */     if (this.surface == 0)
/*     */     {
/* 283 */       line(0.0F, 0.0F, 0.0F, f7 * -f5 * sin(0.7853982F - f6), 0.0F, f7 * f5 * cos(0.7853982F - f6));
/* 284 */       line(0.0F, 0.0F, 0.0F, f7 * f5 * sin(radians(135.0F) - f6), 0.0F, f7 * -f5 * cos(radians(135.0F) - f6));
/*     */     }
/* 286 */     popMatrix();
/*     */ 
/* 289 */     float f8 = this.arrow_scale_factor;
/* 290 */     this.arrow_scale_factor = 0.05F;
/* 291 */     if (!(this.show_gradient_map)) stroke(0.0F, 0.0F, 0.0F, 50.0F); else stroke(0.0F, 0.0F, 0.0F, 150.0F);
/* 292 */     for (float f9 = -this.axes_length; f9 <= this.axes_length; f9 += this.gradient_res)
/*     */     {
/* 294 */       for (f10 = -this.axes_length; f10 <= this.axes_length; f10 += this.gradient_res)
/*     */       {
/* 296 */         line(f9, 0.0F, f10, f9 - (df_dx(f9) * this.arrow_scale_factor), 0.0F, f10 - (df_dy(f10) * this.arrow_scale_factor));
/* 297 */         pushMatrix();
/* 298 */         translate(f9 - (df_dx(f9) * this.arrow_scale_factor), 0.0F, f10 - (df_dy(f10) * this.arrow_scale_factor));
/* 299 */         f4 = sqrt(sq(df_dx(f9) * this.arrow_scale_factor) + sq(df_dy(f10) * this.arrow_scale_factor));
/* 300 */         f5 = f4 / 5;
/* 301 */         f6 = atan(f9 / f10);
/* 302 */         f7 = 1.0F;
/* 303 */         if (f10 < 0.0F) f7 = -1.0F;
/* 304 */         if (this.surface == 0)
/*     */         {
/* 306 */           line(0.0F, 0.0F, 0.0F, f7 * -f5 * sin(0.7853982F - f6), 0.0F, f7 * f5 * cos(0.7853982F - f6));
/* 307 */           line(0.0F, 0.0F, 0.0F, f7 * f5 * sin(radians(135.0F) - f6), 0.0F, f7 * -f5 * cos(radians(135.0F) - f6));
/*     */         }
/* 309 */         popMatrix();
/*     */       }
/*     */     }
/* 312 */     this.arrow_scale_factor = f8;
/*     */ 
/* 316 */     if (!(this.show_gradient_map)) this.surface_alpha_value = 30.0F; else this.surface_alpha_value = 2.0F;
/* 317 */     stroke(255.0F, 0.0F, 0.0F, this.surface_alpha_value);
/* 318 */     fill(255.0F, 0.0F, 0.0F, this.surface_alpha_value);
/* 319 */     this.ball_z = (f(this.ball_x / this.scale_factor, this.ball_y / this.scale_factor) * this.scale_factor);
/* 320 */     translate(this.ball_x, -this.ball_z, this.ball_y);
/* 321 */     sphere(this.ball_size);
/*     */ 
/* 324 */     translate(0.0F, this.ball_z, 0.0F);
/* 325 */     stroke(255.0F, 0.0F, 0.0F);
/* 326 */     fill(0);
/* 327 */     f9 = this.ball_size;
/* 328 */     float f10 = f9;
/* 329 */     float f11 = 0.0F;
/* 330 */     float f12 = 0.0F;
/* 331 */     float f13 = 0.0F;
/* 332 */     beginShape(256);
/* 333 */     for (float f14 = 0.0F; f14 <= 6.283186F; f14 += 0.05F)
/*     */     {
/* 335 */       f12 = f9 * cos(f14);
/* 336 */       f13 = f9 * sin(f14);
/* 337 */       vertex(f12, 0.0F, f13);
/* 338 */       f10 = f12;
/* 339 */       f11 = f13;
/*     */     }
/*     */ 
/* 342 */     endShape();
/*     */   }
/*     */ 
/*     */   private final void jdMethod_this()
/*     */   {
/*   4 */     this.axes_centre_x = 180.0F;
/*   5 */     this.axes_centre_y = 400.0F;
/*   6 */     this.axes_centre_z = -550.0F;
/*   7 */     this.axes_length = 365.0F;
/*   8 */     this.rotate_cam_y = false;
/*   9 */     this.rotate_cam_x = false;
/*  10 */     this.rotate_y = 0.0F;
/*  11 */     this.rotate_x = 0.0F;
/*  12 */     this.rotate_speed = 0.05F;
/*  13 */     this.surface_res = 10.0F;
/*  14 */     this.scale_factor = 500.0F;
/*  15 */     this.surface_alpha_value = 30.0F;
/*  16 */     this.ball_x = (this.axes_length - 50.0F);
/*  17 */     this.ball_y = (this.axes_length - 50.0F);
/*  18 */     this.ball_z = 0.0F;
/*  19 */     this.initial_z = (f(this.ball_x / this.scale_factor, this.ball_y / this.scale_factor) * this.scale_factor);
/*  20 */     this.ball_size = 20.0F;
/*  21 */     this.ball_step = 15.0F;
/*  22 */     this.arrow_scale_factor = 0.2F;
/*  23 */     this.v_x = 0.0F;
/*  24 */     this.v_y = 0.0F;
/*  25 */     this.gradient_res = 50.0F;
/*  26 */     this.surface = 0;
/*  27 */     this.show_gradient_map = false;
/*     */   }
/*     */ 
/*     */   public Gradient2()
/*     */   {
/*   1 */     jdMethod_this();
/*     */   }
/*     */ 
/*     */   class ToggleButton
/*     */   {
/*     */     public boolean value;
/*     */     public String msg;
/*     */     public int x;
/*     */     public int y;
/*     */     public int w;
/*     */     public int h;
/*     */ 
/*     */     public void draw()
/*     */     {
/* 426 */       Gradient2.this.pushMatrix();
/* 427 */       Gradient2.this.translate(this.x, this.y);
/* 428 */       if (this.value) {
/* 429 */         Gradient2.this.fill(250.0F, 130.0F, 20.0F);
/* 430 */         Gradient2.this.stroke(0);
/* 431 */         Gradient2.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/*     */       else
/*     */       {
/* 439 */         Gradient2.this.fill(255.0F, 255.0F, 255.0F);
/* 440 */         Gradient2.this.stroke(0);
/* 441 */         Gradient2.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/* 443 */       Gradient2.this.rect(0.0F, 0.0F, this.w, this.h);
/* 444 */       Gradient2.this.noStroke();
/* 445 */       Gradient2.this.fill(255.0F, 255.0F, 255.0F);
/* 446 */       Gradient2.this.rect(2.0F, 2.0F, this.w - 4, this.h - 4);
/*     */ 
/* 448 */       Gradient2.this.fill(0);
/*     */ 
/* 450 */       Gradient2.this.textSize(16.0F);
/* 451 */       Gradient2.this.text(this.msg, 5, this.h - 5);
/*     */ 
/* 453 */       Gradient2.this.popMatrix();
/*     */     }
/*     */ 
/*     */     public void processMouseDown() {
/* 457 */       int i = Gradient2.this.mouseX - this.x;
/* 458 */       int j = Gradient2.this.mouseY - this.y;
/*     */ 
/* 460 */       if ((i < 0) || (i > this.w) || 
/* 461 */         (j < 0) || (j > this.h)) return;
/* 462 */       this.value ^= true;
/*     */     }
/*     */ 
/*     */     private final void jdMethod_this()
/*     */     {
/* 467 */       this.value = false;
/*     */     }
/*     */ 
/*     */     public ToggleButton(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString)
/*     */     {
/* 417 */       jdMethod_this();
/* 418 */       this.x = paramInt1;
/* 419 */       this.y = paramInt2;
/* 420 */       this.w = paramInt3;
/* 421 */       this.h = paramInt4;
/* 422 */       this.msg = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */   class Button
/*     */   {
/*     */     public boolean value;
/*     */     public String msg;
/*     */     public int x;
/*     */     public int y;
/*     */     public int w;
/*     */     public int h;
/*     */ 
/*     */     public void draw()
/*     */     {
/* 358 */       Gradient2.this.rectMode(0);
/* 359 */       Gradient2.this.pushMatrix();
/* 360 */       Gradient2.this.translate(this.x, this.y);
/* 361 */       if (this.value) {
/* 362 */         Gradient2.this.fill(250.0F, 130.0F, 20.0F);
/* 363 */         Gradient2.this.stroke(0);
/* 364 */         Gradient2.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/*     */       else
/*     */       {
/* 372 */         Gradient2.this.fill(255.0F, 255.0F, 255.0F);
/* 373 */         Gradient2.this.stroke(0);
/* 374 */         Gradient2.this.rect(0.0F, 0.0F, this.w, this.h);
/*     */       }
/* 376 */       Gradient2.this.rect(0.0F, 0.0F, this.w, this.h);
/* 377 */       Gradient2.this.noStroke();
/* 378 */       Gradient2.this.fill(255.0F, 255.0F, 255.0F);
/* 379 */       Gradient2.this.rect(2.0F, 2.0F, this.w - 4, this.h - 4);
/*     */ 
/* 381 */       Gradient2.this.fill(0);
/*     */ 
/* 383 */       Gradient2.this.textSize(19.0F);
/* 384 */       Gradient2.this.text(this.msg, 5, this.h - 8);
/*     */ 
/* 386 */       Gradient2.this.popMatrix();
/*     */     }
/*     */ 
/*     */     public void processMouseDown() {
/* 390 */       int i = Gradient2.this.mouseX - this.x;
/* 391 */       int j = Gradient2.this.mouseY - this.y;
/*     */ 
/* 393 */       if ((i < 0) || (i > this.w) || 
/* 394 */         (j < 0) || (j > this.h)) return;
/* 395 */       this.value = true;
/*     */     }
/*     */ 
/*     */     public void processMouseUp()
/*     */     {
/* 401 */       if (this.value)
/* 402 */         this.value = false;
/*     */     }
/*     */ 
/*     */     private final void jdMethod_this() {
/* 406 */       this.value = false;
/*     */     }
/*     */ 
/*     */     public Button(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString)
/*     */     {
/* 349 */       jdMethod_this();
/* 350 */       this.x = paramInt1;
/* 351 */       this.y = paramInt2;
/* 352 */       this.w = paramInt3;
/* 353 */       this.h = paramInt4;
/* 354 */       this.msg = paramString;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/mfeyereisen/applets-final/classes/
 * Qualified Name:     Gradient2
 * JD-Core Version:    0.5.3
 */