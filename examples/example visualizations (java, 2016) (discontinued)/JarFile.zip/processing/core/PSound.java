/*     */ package processing.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Method;
/*     */ import sun.audio.AudioPlayer;
/*     */ 
/*     */ public class PSound
/*     */ {
/*     */   public static final int SAMPLING_RATE = 8000;
/*     */   static final short BIAS = 132;
/*     */   static final int CLIP = 32635;
/* 191 */   static final int[] LINEAR_LUT = { 0, 132, 396, 924, 1980, 4092, 8316, 16764 };
/*     */ 
/* 195 */   static final int[] LAW_LUT = { 0, 0, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7 };
/*     */   PApplet parent;
/*     */   Method soundEventMethod;
/*     */   InputStream stream;
/*     */   boolean loop;
/*     */   float volume;
/*     */   int position;
/*     */   int[] data;
/*     */   static Class class$processing$core$PSound;
/*     */ 
/*     */   public void play()
/*     */   {
/*  73 */     AudioPlayer.player.start(this.stream);
/*     */   }
/*     */ 
/*     */   public void loop()
/*     */   {
/*  81 */     this.loop = true;
/*     */   }
/*     */ 
/*     */   public void noLoop()
/*     */   {
/*  91 */     this.loop = false;
/*     */   }
/*     */ 
/*     */   public void pause()
/*     */   {
/*  96 */     AudioPlayer.player.stop(this.stream);
/*     */   }
/*     */ 
/*     */   public void stop()
/*     */   {
/* 104 */     AudioPlayer.player.stop(this.stream);
/*     */   }
/*     */ 
/*     */   public float time()
/*     */   {
/* 114 */     return (this.position / 8000.0F);
/*     */   }
/*     */ 
/*     */   public float duration()
/*     */   {
/* 122 */     return 0.0F;
/*     */   }
/*     */ 
/*     */   public void volume(float paramFloat)
/*     */   {
/* 127 */     this.volume = paramFloat;
/*     */   }
/*     */ 
/*     */   protected void error(String paramString, Exception paramException)
/*     */   {
/* 136 */     this.parent.die("Error inside PSound." + paramString + "()", paramException);
/*     */   }
/*     */ 
/*     */   static byte linear2ulaw(int paramInt)
/*     */   {
/* 222 */     if (paramInt > 32767)
/* 223 */       paramInt = 32767;
/* 224 */     else if (paramInt < -32768) {
/* 225 */       paramInt = -32768;
/*     */     }
/*     */ 
/* 228 */     int i = paramInt >> 8 & 0x80;
/* 229 */     if (i != 0) paramInt = -paramInt;
/* 230 */     if (paramInt > 32635) paramInt = 32635;
/*     */ 
/* 232 */     paramInt += 132;
/* 233 */     int j = LAW_LUT[(paramInt >> 7 & 0xFF)];
/* 234 */     int k = paramInt >> j + 3 & 0xF;
/* 235 */     int l = (byte)((i | j << 4 | k) ^ 0xFFFFFFFF);
/* 236 */     if (l == 0) l = 2;
/*     */ 
/* 238 */     return l;
/*     */   }
/*     */ 
/*     */   static int ulaw2linear(int paramInt)
/*     */   {
/* 245 */     paramInt ^= -1;
/*     */ 
/* 247 */     int i = paramInt & 0x80;
/* 248 */     int j = paramInt >> 4 & 0x7;
/* 249 */     int k = paramInt & 0xF;
/* 250 */     int l = LINEAR_LUT[j] + (k << j + 3);
/*     */ 
/* 252 */     return (short)((i != 0) ? -l : l);
/*     */   }
/*     */ 
/*     */   static int[] resample(int[] paramArrayOfInt, int paramInt1, int paramInt2)
/*     */   {
/* 260 */     int[] arrayOfInt = null;
/* 261 */     float f = 0.0F;
/*     */     int i;
/*     */     int j;
/* 264 */     if (paramInt1 > paramInt2) {
/* 265 */       f = paramInt1 / paramInt2;
/* 266 */       i = (int)(paramArrayOfInt.length / f);
/* 267 */       arrayOfInt = new int[i];
/*     */ 
/* 269 */       j = 0; break label53:
/*     */       while (true) { arrayOfInt[j] = paramArrayOfInt[(int)(j * f)];
/*     */ 
/* 269 */         ++j; if (j >= i)
/*     */         {
/* 272 */           label53: return arrayOfInt; } }
/*     */     }
/* 274 */     if (paramInt1 < paramInt2) {
/* 275 */       f = paramInt2 / paramInt1;
/* 276 */       i = (int)(paramArrayOfInt.length * f);
/* 277 */       arrayOfInt = new int[i];
/*     */ 
/* 279 */       j = 0; break label110:
/*     */       while (true) { arrayOfInt[j] = paramArrayOfInt[(int)(j * f)];
/*     */ 
/* 279 */         ++j; if (j >= i)
/*     */         {
/* 282 */           label110: return arrayOfInt; } }
/*     */     }
/* 284 */     return paramArrayOfInt;
/*     */   }
/*     */ 
/*     */   static Class jdMethod_class(String paramString, boolean paramBoolean)
/*     */   {
/*     */     try
/*     */     {
/*     */       if (!(paramBoolean));
/*     */       return Class.forName(paramString).getComponentType();
/*     */     }
/*     */     catch (ClassNotFoundException localClassNotFoundException)
/*     */     {
/*     */       throw new NoClassDefFoundError(localClassNotFoundException.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   private final void jdMethod_this()
/*     */   {
/*  46 */     this.volume = 1.0F;
/*     */   }
/*     */ 
/*     */   public PSound()
/*     */   {
/*  53 */     jdMethod_this();
/*     */   }
/*     */ 
/*     */   // ERROR //
/*     */   public PSound(PApplet paramPApplet, InputStream paramInputStream)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokespecial 125	java/lang/Object:<init>	()V
/*     */     //   4: aload_0
/*     */     //   5: invokespecial 127	processing/core/PSound:this	()V
/*     */     //   8: aload_0
/*     */     //   9: aload_1
/*     */     //   10: putfield 67	processing/core/PSound:parent	Lprocessing/core/PApplet;
/*     */     //   13: aload_1
/*     */     //   14: aload_0
/*     */     //   15: invokevirtual 132	processing/core/PApplet:registerDispose	(Ljava/lang/Object;)V
/*     */     //   18: aload_0
/*     */     //   19: aload_1
/*     */     //   20: invokevirtual 135	java/lang/Object:getClass	()Ljava/lang/Class;
/*     */     //   23: ldc 137
/*     */     //   25: iconst_1
/*     */     //   26: anewarray 107	java/lang/Class
/*     */     //   29: dup
/*     */     //   30: iconst_0
/*     */     //   31: getstatic 139	processing/core/PSound:class$processing$core$PSound	Ljava/lang/Class;
/*     */     //   34: dup
/*     */     //   35: ifnonnull +14 -> 49
/*     */     //   38: pop
/*     */     //   39: ldc 141
/*     */     //   41: iconst_0
/*     */     //   42: invokestatic 143	processing/core/PSound:class	(Ljava/lang/String;Z)Ljava/lang/Class;
/*     */     //   45: dup
/*     */     //   46: putstatic 139	processing/core/PSound:class$processing$core$PSound	Ljava/lang/Class;
/*     */     //   49: aastore
/*     */     //   50: invokevirtual 147	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*     */     //   53: putfield 149	processing/core/PSound:soundEventMethod	Ljava/lang/reflect/Method;
/*     */     //   56: goto +4 -> 60
/*     */     //   59: pop
/*     */     //   60: return
/*     */     //
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   18	56	59	java/lang/Exception
/*     */   }
/*     */ 
/*     */   class Stream extends InputStream
/*     */   {
/*     */     int index;
/*     */ 
/*     */     public int available()
/*     */       throws IOException
/*     */     {
/* 148 */       return (PSound.this.data.length - PSound.this.position); }
/*     */ 
/*     */     public void close() throws IOException { }
/*     */ 
/*     */     public synchronized void mark() {
/*     */     }
/*     */ 
/*     */     public boolean markSupported() {
/* 156 */       return false;
/*     */     }
/*     */ 
/*     */     public int read() throws IOException {
/* 160 */       return 0;
/*     */     }
/*     */ 
/*     */     public int read(byte[] paramArrayOfByte) throws IOException {
/* 164 */       return 0;
/*     */     }
/*     */ 
/*     */     public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException {
/* 168 */       return 0;
/*     */     }
/*     */ 
/*     */     public synchronized void reset() {
/* 172 */       PSound.this.position = 0;
/*     */     }
/*     */ 
/*     */     public long skip(long paramLong) {
/* 176 */       PSound.this.position = ((PSound.this.position + (int)paramLong) % PSound.this.data.length);
/* 177 */       return paramLong;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/mfeyereisen/Desktop/Sources 2/common/
 * Qualified Name:     processing.core.PSound
 * JD-Core Version:    0.5.3
 */