/*     */ package processing.core;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.Clip;
/*     */ import javax.sound.sampled.FloatControl;
/*     */ import javax.sound.sampled.LineEvent;
/*     */ import javax.sound.sampled.LineEvent.Type;
/*     */ import javax.sound.sampled.LineListener;
/*     */ 
/*     */ public class PSound2 extends PSound
/*     */ {
/*     */   Clip clip;
/*     */   FloatControl gainControl;
/*     */   static Class class$javax$sound$sampled$Clip;
/*     */   static Class class$processing$core$PSound;
/*     */ 
/*     */   public void play()
/*     */   {
/* 136 */     this.clip.start();
/*     */   }
/*     */ 
/*     */   public void loop()
/*     */   {
/* 144 */     this.clip.loop(-1);
/*     */   }
/*     */ 
/*     */   public void noLoop()
/*     */   {
/* 154 */     this.clip.loop(0);
/*     */   }
/*     */ 
/*     */   public void pause()
/*     */   {
/* 164 */     this.clip.stop();
/*     */   }
/*     */ 
/*     */   public void stop()
/*     */   {
/* 175 */     this.clip.stop();
/* 176 */     this.clip.setFramePosition(0);
/*     */   }
/*     */ 
/*     */   public void dispose()
/*     */   {
/* 185 */     stop();
/* 186 */     this.clip = null;
/*     */   }
/*     */ 
/*     */   public float time()
/*     */   {
/* 194 */     return (float)(this.clip.getMicrosecondPosition() / 1000000.0D);
/*     */   }
/*     */ 
/*     */   public float duration()
/*     */   {
/* 202 */     return (this.clip.getBufferSize() / this.clip.getFormat().getFrameSize() * this.clip.getFormat().getFrameRate());
/*     */   }
/*     */ 
/*     */   public void volume(float paramFloat)
/*     */   {
/* 212 */     if (this.gainControl != null) {
/* 213 */       float f = (float)(Math.log(paramFloat) / Math.log(10.0D) * 20.0D);
/* 214 */       this.gainControl.setValue(f);
/*     */     } else {
/* 216 */       System.err.println("Cannot set the volume for this sound.");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void error(String paramString, Exception paramException)
/*     */   {
/* 226 */     this.parent.die("Error inside PSound2." + paramString + "()", paramException);
/*     */   }
/*     */ 
/*     */   static Class jdMethod_class(String paramString, boolean paramBoolean)
/*     */   {
/*     */     try
/*     */     {
/*     */       if (!(paramBoolean));
/*     */       return Class.forName(paramString).getComponentType();
/*     */     }
/*     */     catch (ClassNotFoundException localClassNotFoundException)
/*     */     {
/*     */       throw new NoClassDefFoundError(localClassNotFoundException.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   // ERROR //
/*     */   public PSound2(PApplet paramPApplet, java.io.InputStream paramInputStream)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokespecial 148	processing/core/PSound:<init>	()V
/*     */     //   4: aload_0
/*     */     //   5: aload_1
/*     */     //   6: putfield 101	processing/core/PSound2:parent	Lprocessing/core/PApplet;
/*     */     //   9: aload_2
/*     */     //   10: invokestatic 154	javax/sound/sampled/AudioSystem:getAudioInputStream	(Ljava/io/InputStream;)Ljavax/sound/sampled/AudioInputStream;
/*     */     //   13: astore_3
/*     */     //   14: aload_3
/*     */     //   15: invokevirtual 157	javax/sound/sampled/AudioInputStream:getFormat	()Ljavax/sound/sampled/AudioFormat;
/*     */     //   18: astore 4
/*     */     //   20: aload 4
/*     */     //   22: invokevirtual 161	javax/sound/sampled/AudioFormat:getEncoding	()Ljavax/sound/sampled/AudioFormat$Encoding;
/*     */     //   25: getstatic 169	javax/sound/sampled/AudioFormat$Encoding:PCM_SIGNED	Ljavax/sound/sampled/AudioFormat$Encoding;
/*     */     //   28: if_acmpeq +52 -> 80
/*     */     //   31: new 58	javax/sound/sampled/AudioFormat
/*     */     //   34: dup
/*     */     //   35: getstatic 169	javax/sound/sampled/AudioFormat$Encoding:PCM_SIGNED	Ljavax/sound/sampled/AudioFormat$Encoding;
/*     */     //   38: aload 4
/*     */     //   40: invokevirtual 172	javax/sound/sampled/AudioFormat:getSampleRate	()F
/*     */     //   43: aload 4
/*     */     //   45: invokevirtual 175	javax/sound/sampled/AudioFormat:getSampleSizeInBits	()I
/*     */     //   48: iconst_2
/*     */     //   49: imul
/*     */     //   50: aload 4
/*     */     //   52: invokevirtual 178	javax/sound/sampled/AudioFormat:getChannels	()I
/*     */     //   55: aload 4
/*     */     //   57: invokevirtual 59	javax/sound/sampled/AudioFormat:getFrameSize	()I
/*     */     //   60: iconst_2
/*     */     //   61: imul
/*     */     //   62: aload 4
/*     */     //   64: invokevirtual 62	javax/sound/sampled/AudioFormat:getFrameRate	()F
/*     */     //   67: iconst_1
/*     */     //   68: invokespecial 181	javax/sound/sampled/AudioFormat:<init>	(Ljavax/sound/sampled/AudioFormat$Encoding;FIIIFZ)V
/*     */     //   71: astore 4
/*     */     //   73: aload 4
/*     */     //   75: aload_3
/*     */     //   76: invokestatic 184	javax/sound/sampled/AudioSystem:getAudioInputStream	(Ljavax/sound/sampled/AudioFormat;Ljavax/sound/sampled/AudioInputStream;)Ljavax/sound/sampled/AudioInputStream;
/*     */     //   79: astore_3
/*     */     //   80: aload_3
/*     */     //   81: invokevirtual 187	javax/sound/sampled/AudioInputStream:getFrameLength	()J
/*     */     //   84: l2i
/*     */     //   85: istore 5
/*     */     //   87: aload 4
/*     */     //   89: invokevirtual 59	javax/sound/sampled/AudioFormat:getFrameSize	()I
/*     */     //   92: istore 6
/*     */     //   94: new 189	javax/sound/sampled/DataLine$Info
/*     */     //   97: dup
/*     */     //   98: getstatic 194	processing/core/PSound2:class$javax$sound$sampled$Clip	Ljava/lang/Class;
/*     */     //   101: dup
/*     */     //   102: ifnonnull +14 -> 116
/*     */     //   105: pop
/*     */     //   106: ldc 196
/*     */     //   108: iconst_0
/*     */     //   109: invokestatic 198	processing/core/PSound2:class	(Ljava/lang/String;Z)Ljava/lang/Class;
/*     */     //   112: dup
/*     */     //   113: putstatic 194	processing/core/PSound2:class$javax$sound$sampled$Clip	Ljava/lang/Class;
/*     */     //   116: aload_3
/*     */     //   117: invokevirtual 157	javax/sound/sampled/AudioInputStream:getFormat	()Ljavax/sound/sampled/AudioFormat;
/*     */     //   120: iload 5
/*     */     //   122: iload 6
/*     */     //   124: imul
/*     */     //   125: invokespecial 201	javax/sound/sampled/DataLine$Info:<init>	(Ljava/lang/Class;Ljavax/sound/sampled/AudioFormat;I)V
/*     */     //   128: astore 7
/*     */     //   130: aload_0
/*     */     //   131: aload 7
/*     */     //   133: invokestatic 205	javax/sound/sampled/AudioSystem:getLine	(Ljavax/sound/sampled/Line$Info;)Ljavax/sound/sampled/Line;
/*     */     //   136: checkcast 22	javax/sound/sampled/Clip
/*     */     //   139: putfield 18	processing/core/PSound2:clip	Ljavax/sound/sampled/Clip;
/*     */     //   142: aload_0
/*     */     //   143: aload_0
/*     */     //   144: getfield 18	processing/core/PSound2:clip	Ljavax/sound/sampled/Clip;
/*     */     //   147: getstatic 212	javax/sound/sampled/FloatControl$Type:MASTER_GAIN	Ljavax/sound/sampled/FloatControl$Type;
/*     */     //   150: invokeinterface 216 2 0
/*     */     //   155: checkcast 80	javax/sound/sampled/FloatControl
/*     */     //   158: putfield 66	processing/core/PSound2:gainControl	Ljavax/sound/sampled/FloatControl;
/*     */     //   161: goto +18 -> 179
/*     */     //   164: astore 8
/*     */     //   166: getstatic 87	java/lang/System:err	Ljava/io/PrintStream;
/*     */     //   169: ldc 220
/*     */     //   171: invokevirtual 95	java/io/PrintStream:println	(Ljava/lang/String;)V
/*     */     //   174: aload 8
/*     */     //   176: invokevirtual 223	java/lang/Exception:printStackTrace	()V
/*     */     //   179: aload_0
/*     */     //   180: getfield 18	processing/core/PSound2:clip	Ljavax/sound/sampled/Clip;
/*     */     //   183: aload_3
/*     */     //   184: invokeinterface 227 2 0
/*     */     //   189: aload_0
/*     */     //   190: getfield 101	processing/core/PSound2:parent	Lprocessing/core/PApplet;
/*     */     //   193: aload_0
/*     */     //   194: invokevirtual 231	processing/core/PApplet:registerDispose	(Ljava/lang/Object;)V
/*     */     //   197: aload_0
/*     */     //   198: aload_0
/*     */     //   199: getfield 101	processing/core/PSound2:parent	Lprocessing/core/PApplet;
/*     */     //   202: invokevirtual 236	java/lang/Object:getClass	()Ljava/lang/Class;
/*     */     //   205: ldc 238
/*     */     //   207: iconst_1
/*     */     //   208: anewarray 130	java/lang/Class
/*     */     //   211: dup
/*     */     //   212: iconst_0
/*     */     //   213: getstatic 240	processing/core/PSound2:class$processing$core$PSound	Ljava/lang/Class;
/*     */     //   216: dup
/*     */     //   217: ifnonnull +14 -> 231
/*     */     //   220: pop
/*     */     //   221: ldc 242
/*     */     //   223: iconst_0
/*     */     //   224: invokestatic 198	processing/core/PSound2:class	(Ljava/lang/String;Z)Ljava/lang/Class;
/*     */     //   227: dup
/*     */     //   228: putstatic 240	processing/core/PSound2:class$processing$core$PSound	Ljava/lang/Class;
/*     */     //   231: aastore
/*     */     //   232: invokevirtual 246	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*     */     //   235: putfield 250	processing/core/PSound2:soundEventMethod	Ljava/lang/reflect/Method;
/*     */     //   238: aload_0
/*     */     //   239: getfield 18	processing/core/PSound2:clip	Ljavax/sound/sampled/Clip;
/*     */     //   242: new 252	processing/core/PSound2$1
/*     */     //   245: dup
/*     */     //   246: aload_0
/*     */     //   247: invokespecial 255	processing/core/PSound2$1:<init>	(Lprocessing/core/PSound2;)V
/*     */     //   250: invokeinterface 259 2 0
/*     */     //   255: goto +4 -> 259
/*     */     //   258: pop
/*     */     //   259: goto +12 -> 271
/*     */     //   262: astore_3
/*     */     //   263: aload_0
/*     */     //   264: ldc_w 260
/*     */     //   267: aload_3
/*     */     //   268: invokevirtual 262	processing/core/PSound2:error	(Ljava/lang/String;Ljava/lang/Exception;)V
/*     */     //   271: return
/*     */     //
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   142	161	164	java/lang/Exception
/*     */     //   197	255	258	java/lang/Exception
/*     */     //   9	259	262	java/lang/Exception
/*     */   }
/*     */ }

/* Location:           /Users/mfeyereisen/Desktop/Sources 2/common/
 * Qualified Name:     processing.core.PSound2
 * JD-Core Version:    0.5.3
 */