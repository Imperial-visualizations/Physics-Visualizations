/*     */ package processing.core;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Toolkit;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ public class PFont
/*     */   implements PConstants
/*     */ {
/* 587 */   static final char[] EXTRA_CHARS = { 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 180, 181, 182, 183, 184, 186, 187, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 255, 258, 259, 260, 261, 262, 263, 268, 269, 270, 271, 272, 273, 280, 281, 282, 283, 305, 313, 314, 317, 318, 321, 322, 323, 324, 327, 328, 336, 337, 338, 339, 340, 341, 344, 345, 346, 347, 350, 351, 352, 353, 354, 355, 356, 357, 366, 367, 368, 369, 376, 377, 378, 379, 380, 381, 382, 402, 710, 711, 728, 729, 730, 731, 732, 733, 937, 960, 8211, 8212, 8216, 8217, 8218, 8220, 8221, 8222, 8224, 8225, 8226, 8230, 8240, 8249, 8250, 8260, 8364, 8482, 8706, 8710, 8719, 8721, 8730, 8734, 8747, 8776, 8800, 8804, 8805, 9674, 63743, 64257, 64258 };
/*     */ 
/* 636 */   public static char[] DEFAULT_CHARSET = new char[94 + EXTRA_CHARS.length];
/*     */   public int charCount;
/*     */   public PImage[] images;
/*     */   public String name;
/*     */   public String psname;
/*     */   public int size;
/*     */   public int mbox2;
/*     */   protected float fwidth;
/*     */   protected float fheight;
/*     */   public int twidth;
/*     */   public int theight;
/*     */   public int[] value;
/*     */   public int[] height;
/*     */   public int[] width;
/*     */   public int[] setWidth;
/*     */   public int[] topExtent;
/*     */   public int[] leftExtent;
/*     */   public int ascent;
/*     */   public int descent;
/*     */   protected int[] ascii;
/*     */   protected char[] textBuffer;
/*     */   protected char[] widthBuffer;
/*     */   static Class class$java$lang$Object;
/*     */   static Class class$java$awt$Font;
/*     */ 
/*     */   public void save(OutputStream paramOutputStream)
/*     */     throws IOException
/*     */   {
/* 233 */     DataOutputStream localDataOutputStream = new DataOutputStream(paramOutputStream);
/*     */ 
/* 235 */     localDataOutputStream.writeInt(this.charCount);
/*     */ 
/* 238 */     localDataOutputStream.writeInt((this.name != null) ? 10 : 8);
/*     */ 
/* 240 */     localDataOutputStream.writeInt(this.size);
/* 241 */     localDataOutputStream.writeInt(this.mbox2);
/* 242 */     localDataOutputStream.writeInt(this.ascent);
/* 243 */     localDataOutputStream.writeInt(this.descent);
/*     */ 
/* 245 */     for (int i = 0; i < this.charCount; ++i) {
/* 246 */       localDataOutputStream.writeInt(this.value[i]);
/* 247 */       localDataOutputStream.writeInt(this.height[i]);
/* 248 */       localDataOutputStream.writeInt(this.width[i]);
/* 249 */       localDataOutputStream.writeInt(this.setWidth[i]);
/* 250 */       localDataOutputStream.writeInt(this.topExtent[i]);
/* 251 */       localDataOutputStream.writeInt(this.leftExtent[i]);
/* 252 */       localDataOutputStream.writeInt(0);
/*     */     }
/*     */ 
/* 255 */     for (i = 0; i < this.charCount; ++i) {
/* 256 */       for (int j = 0; j < this.height[i]; ++j) {
/* 257 */         for (int k = 0; k < this.width[i]; ++k) {
/* 258 */           localDataOutputStream.write(this.images[i].pixels[(j * this.mbox2 + k)] & 0xFF);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 263 */     if (this.name != null) {
/* 264 */       localDataOutputStream.writeUTF(this.name);
/* 265 */       localDataOutputStream.writeUTF(this.psname);
/*     */     }
/*     */ 
/* 268 */     localDataOutputStream.flush();
/*     */   }
/*     */ 
/*     */   public int index(char paramChar)
/*     */   {
/* 279 */     if (this.value.length == 0) return -1;
/*     */ 
/* 282 */     if (paramChar < 128) return this.ascii[paramChar];
/*     */ 
/* 285 */     return index_hunt(paramChar, 0, this.value.length - 1);
/*     */   }
/*     */ 
/*     */   protected int index_hunt(int paramInt1, int paramInt2, int paramInt3)
/*     */   {
/* 290 */     int i = (paramInt2 + paramInt3) / 2;
/*     */ 
/* 293 */     if (paramInt1 == this.value[i]) return i;
/*     */ 
/* 297 */     if (paramInt2 >= paramInt3) return -1;
/*     */ 
/* 300 */     if (paramInt1 < this.value[i]) return index_hunt(paramInt1, paramInt2, i - 1);
/*     */ 
/* 303 */     return index_hunt(paramInt1, i + 1, paramInt3);
/*     */   }
/*     */ 
/*     */   public float kern(char paramChar1, char paramChar2)
/*     */   {
/* 312 */     return 0.0F;
/*     */   }
/*     */ 
/*     */   public float ascent()
/*     */   {
/* 321 */     return (this.ascent / this.fheight);
/*     */   }
/*     */ 
/*     */   public float descent()
/*     */   {
/* 330 */     return (this.descent / this.fheight);
/*     */   }
/*     */ 
/*     */   public float width(char paramChar)
/*     */   {
/* 338 */     if (paramChar == ' ') return width('i');
/*     */ 
/* 340 */     int i = index(paramChar);
/* 341 */     if (i == -1) return 0.0F;
/*     */ 
/* 343 */     return (this.setWidth[i] / this.fwidth);
/*     */   }
/*     */ 
/*     */   public float width(String paramString)
/*     */   {
/* 352 */     int i = paramString.length();
/* 353 */     if (i > this.widthBuffer.length) {
/* 354 */       this.widthBuffer = new char[i + 10];
/*     */     }
/* 356 */     paramString.getChars(0, i, this.widthBuffer, 0);
/*     */ 
/* 358 */     float f = 0.0F;
/* 359 */     int j = 0;
/* 360 */     int k = 0;
/*     */ 
/* 362 */     while (j < i) {
/* 363 */       if (this.widthBuffer[j] == '\n') {
/* 364 */         f = Math.max(f, calcWidth(this.widthBuffer, k, j));
/* 365 */         k = j + 1;
/*     */       }
/* 367 */       ++j;
/*     */     }
/* 369 */     if (k < i) {
/* 370 */       f = Math.max(f, calcWidth(this.widthBuffer, k, j));
/*     */     }
/* 372 */     return f;
/*     */   }
/*     */ 
/*     */   private final float calcWidth(char[] paramArrayOfChar, int paramInt1, int paramInt2)
/*     */   {
/* 377 */     float f = 0.0F;
/* 378 */     for (int i = paramInt1; i < paramInt2; ++i) {
/* 379 */       f += width(paramArrayOfChar[i]);
/*     */     }
/* 381 */     return f;
/*     */   }
/*     */ 
/*     */   public void text(char paramChar, float paramFloat1, float paramFloat2, PGraphics paramPGraphics)
/*     */   {
/* 389 */     text(paramChar, paramFloat1, paramFloat2, 0.0F, paramPGraphics);
/*     */   }
/*     */ 
/*     */   public void text(char paramChar, float paramFloat1, float paramFloat2, float paramFloat3, PGraphics paramPGraphics)
/*     */   {
/* 397 */     if (paramPGraphics.textAlign == 3) {
/* 398 */       paramFloat1 -= paramPGraphics.textSize * width(paramChar) / 2.0F;
/*     */     }
/* 400 */     else if (paramPGraphics.textAlign == 39) {
/* 401 */       paramFloat1 -= paramPGraphics.textSize * width(paramChar);
/*     */     }
/*     */ 
/* 405 */     if (paramFloat3 != 0.0F) paramPGraphics.translate(0.0F, 0.0F, paramFloat3);
/* 406 */     paramPGraphics.textImpl(paramChar, paramFloat1, paramFloat2, paramFloat3);
/* 407 */     if (paramFloat3 == 0.0F) return; paramPGraphics.translate(0.0F, 0.0F, -paramFloat3);
/*     */   }
/*     */ 
/*     */   public void text(String paramString, float paramFloat1, float paramFloat2, PGraphics paramPGraphics)
/*     */   {
/* 412 */     text(paramString, paramFloat1, paramFloat2, 0.0F, paramPGraphics);
/*     */   }
/*     */ 
/*     */   public void text(String paramString, float paramFloat1, float paramFloat2, float paramFloat3, PGraphics paramPGraphics)
/*     */   {
/* 417 */     if (paramFloat3 != 0.0F) paramPGraphics.translate(0.0F, 0.0F, paramFloat3);
/*     */ 
/* 419 */     int i = paramString.length();
/* 420 */     if (i > this.textBuffer.length) {
/* 421 */       this.textBuffer = new char[i + 10];
/*     */     }
/* 423 */     paramString.getChars(0, i, this.textBuffer, 0);
/*     */ 
/* 425 */     int j = 0;
/* 426 */     int k = 0;
/* 427 */     while (k < i) {
/* 428 */       if (this.textBuffer[k] == '\n') {
/* 429 */         textLine(j, k, paramFloat1, paramFloat2, paramFloat3, paramPGraphics);
/* 430 */         j = k + 1;
/* 431 */         paramFloat2 += paramPGraphics.textLeading;
/*     */       }
/* 433 */       ++k;
/*     */     }
/* 435 */     if (j < i) {
/* 436 */       textLine(j, k, paramFloat1, paramFloat2, paramFloat3, paramPGraphics);
/*     */     }
/* 438 */     if (paramFloat3 == 0.0F) return; paramPGraphics.translate(0.0F, 0.0F, -paramFloat3);
/*     */   }
/*     */ 
/*     */   protected void textLine(int paramInt1, int paramInt2, float paramFloat1, float paramFloat2, float paramFloat3, PGraphics paramPGraphics)
/*     */   {
/* 445 */     if (paramPGraphics.textAlign == 3) {
/* 446 */       paramFloat1 -= paramPGraphics.textSize * calcWidth(this.textBuffer, paramInt1, paramInt2) / 2.0F;
/*     */     }
/* 448 */     else if (paramPGraphics.textAlign == 39) {
/* 449 */       paramFloat1 -= paramPGraphics.textSize * calcWidth(this.textBuffer, paramInt1, paramInt2);
/*     */     }
/*     */ 
/* 452 */     for (int i = paramInt1; i < paramInt2; ++i)
/*     */     {
/* 456 */       paramPGraphics.textImpl(this.textBuffer[i], paramFloat1, paramFloat2, 0.0F);
/* 457 */       paramFloat1 += paramPGraphics.textSize * width(this.textBuffer[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void text(String paramString, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, PGraphics paramPGraphics)
/*     */   {
/* 467 */     text(paramString, paramFloat1, paramFloat2, paramFloat3, paramFloat4, 0.0F, paramPGraphics);
/*     */   }
/*     */ 
/*     */   public void text(String paramString, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, PGraphics paramPGraphics)
/*     */   {
/* 483 */     if (paramFloat5 != 0.0F) paramPGraphics.translate(0.0F, 0.0F, paramFloat5);
/*     */ 
/* 485 */     float f1 = width(' ') * paramPGraphics.textSize;
/* 486 */     float f2 = paramFloat1;
/* 487 */     float f3 = paramFloat2;
/* 488 */     float f4 = paramFloat3 - paramFloat1;
/*     */ 
/* 490 */     float f5 = paramFloat1;
/* 491 */     if (paramPGraphics.textAlign == 3)
/* 492 */       f5 += f4 / 2.0F;
/* 493 */     else if (paramPGraphics.textAlign == 39) {
/* 494 */       f5 = paramFloat3;
/*     */     }
/*     */ 
/* 498 */     f3 += ascent() * paramPGraphics.textSize;
/*     */ 
/* 500 */     if (f3 > paramFloat4) return;
/*     */ 
/* 502 */     int i = paramString.length();
/* 503 */     if (i > this.textBuffer.length) {
/* 504 */       this.textBuffer = new char[i + 10];
/*     */     }
/* 506 */     paramString.getChars(0, i, this.textBuffer, 0);
/*     */ 
/* 508 */     int j = 0;
/* 509 */     int k = 0;
/* 510 */     int l = 0;
/* 511 */     int i1 = 0;
/* 512 */     while (i1 < i) {
/* 513 */       if ((this.textBuffer[i1] == ' ') || (i1 == i - 1))
/*     */       {
/* 515 */         float f6 = paramPGraphics.textSize * calcWidth(this.textBuffer, j, i1);
/*     */ 
/* 518 */         if (f2 + f6 > paramFloat3) {
/* 519 */           if (f2 == paramFloat1)
/*     */           {
/*     */             do
/*     */             {
/* 525 */               --i1;
/* 526 */               if (i1 == j)
/*     */               {
/* 529 */                 return;
/*     */               }
/* 531 */               f6 = paramPGraphics.textSize * calcWidth(this.textBuffer, j, i1);
/*     */             }
/* 533 */             while (f6 > f4);
/* 534 */             textLine(l, i1, f5, f3, paramFloat5, paramPGraphics);
/*     */           }
/*     */           else
/*     */           {
/* 539 */             textLine(l, k, f5, f3, paramFloat5, paramPGraphics);
/*     */ 
/* 545 */             i1 = k;
/* 546 */             while ((i1 < i) && (this.textBuffer[i1] == ' '))
/*     */             {
/* 548 */               ++i1;
/*     */             }
/*     */           }
/* 551 */           l = i1;
/* 552 */           j = i1;
/* 553 */           k = i1;
/* 554 */           f2 = paramFloat1;
/* 555 */           f3 += paramPGraphics.textLeading;
/* 556 */           if (f3 > paramFloat4) return;
/*     */         }
/*     */         else {
/* 559 */           f2 += f6 + f1;
/*     */ 
/* 561 */           k = i1;
/* 562 */           j = i1 + 1;
/*     */         }
/*     */       }
/* 565 */       else if (this.textBuffer[i1] == '\n') {
/* 566 */         if (l != i1) {
/* 567 */           textLine(l, i1, f5, f3, paramFloat5, paramPGraphics);
/*     */         }
/* 569 */         l = i1 + 1;
/* 570 */         j = l;
/* 571 */         f3 += paramPGraphics.textLeading;
/* 572 */         if (f3 > paramFloat4) return;
/*     */       }
/* 574 */       ++i1;
/*     */     }
/* 576 */     if ((l < i) && (l != i1)) {
/* 577 */       textLine(l, i1, f5, f3, paramFloat5, paramPGraphics);
/*     */     }
/*     */ 
/* 580 */     if (paramFloat5 == 0.0F) return; paramPGraphics.translate(0.0F, 0.0F, -paramFloat5);
/*     */   }
/*     */ 
/*     */   public static String[] list()
/*     */   {
/* 974 */     if (PApplet.javaVersion < 1.3F) {
/* 975 */       return Toolkit.getDefaultToolkit().getFontList();
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 982 */       Class localClass = Class.forName("java.awt.GraphicsEnvironment");
/* 983 */       Method localMethod1 = localClass.getMethod("getLocalGraphicsEnvironment", null);
/*     */ 
/* 985 */       Object localObject = localMethod1.invoke(null, null);
/*     */ 
/* 987 */       Method localMethod2 = localClass.getMethod("getAllFonts", null);
/* 988 */       Font[] arrayOfFont = (Font[])localMethod2.invoke(localObject, null);
/* 989 */       String[] arrayOfString = new String[arrayOfFont.length];
/* 990 */       for (int i = 0; i < arrayOfString.length; ++i) {
/* 991 */         arrayOfString[i] = arrayOfFont[i].getName();
/*     */       }
/* 993 */       return arrayOfString;
/*     */     }
/*     */     catch (Exception localException) {
/* 996 */       localException.printStackTrace();
/* 997 */       throw new RuntimeException("Error inside PFont.list()");
/*     */     }
/*     */   }
/*     */ 
/*     */   static Class jdMethod_class(String paramString, boolean paramBoolean)
/*     */   {
/*     */     try
/*     */     {
/*     */       if (!(paramBoolean));
/*     */       return Class.forName(paramString).getComponentType();
/*     */     }
/*     */     catch (ClassNotFoundException localClassNotFoundException)
/*     */     {
/*     */       throw new NoClassDefFoundError(localClassNotFoundException.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   private final void jdMethod_this()
/*     */   {
/* 102 */     this.textBuffer = new char[8192];
/* 103 */     this.widthBuffer = new char[8192]; }
/*     */ 
/*     */   public PFont() {
/* 106 */     jdMethod_this(); }
/*     */ 
/*     */   public PFont(InputStream paramInputStream) throws IOException {
/* 109 */     jdMethod_this();
/* 110 */     DataInputStream localDataInputStream = new DataInputStream(paramInputStream);
/*     */ 
/* 113 */     this.charCount = localDataInputStream.readInt();
/*     */ 
/* 120 */     int i = localDataInputStream.readInt();
/*     */ 
/* 124 */     this.size = localDataInputStream.readInt();
/*     */ 
/* 128 */     this.mbox2 = localDataInputStream.readInt();
/*     */ 
/* 130 */     this.fwidth = this.size;
/* 131 */     this.fheight = this.size;
/*     */ 
/* 139 */     this.mbox2 = (int)Math.pow(2, Math.ceil(Math.log(this.mbox2) / Math.log(2)));
/*     */ 
/* 141 */     this.twidth = (this.theight = this.mbox2);
/*     */ 
/* 143 */     this.ascent = localDataInputStream.readInt();
/* 144 */     this.descent = localDataInputStream.readInt();
/*     */ 
/* 147 */     this.value = new int[this.charCount];
/* 148 */     this.height = new int[this.charCount];
/* 149 */     this.width = new int[this.charCount];
/* 150 */     this.setWidth = new int[this.charCount];
/* 151 */     this.topExtent = new int[this.charCount];
/* 152 */     this.leftExtent = new int[this.charCount];
/*     */ 
/* 154 */     this.ascii = new int[128];
/* 155 */     for (int j = 0; j < 128; ++j) this.ascii[j] = -1;
/*     */ 
/* 158 */     for (j = 0; j < this.charCount; ++j) {
/* 159 */       this.value[j] = localDataInputStream.readInt();
/* 160 */       this.height[j] = localDataInputStream.readInt();
/* 161 */       this.width[j] = localDataInputStream.readInt();
/* 162 */       this.setWidth[j] = localDataInputStream.readInt();
/* 163 */       this.topExtent[j] = localDataInputStream.readInt();
/* 164 */       this.leftExtent[j] = localDataInputStream.readInt();
/*     */ 
/* 167 */       localDataInputStream.readInt();
/*     */ 
/* 170 */       if (this.value[j] < 128) this.ascii[this.value[j]] = j;
/*     */ 
/* 175 */       if ((this.value[j] == 100) && 
/* 176 */         (this.ascent == 0)) this.ascent = this.topExtent[j];
/*     */ 
/* 178 */       if ((this.value[j] == 112) && 
/* 179 */         (this.descent == 0)) this.descent = (-this.topExtent[j] + this.height[j]);
/*     */ 
/*     */     }
/*     */ 
/* 185 */     if ((this.ascent == 0) && (this.descent == 0)) {
/* 186 */       throw new RuntimeException("Please use \"Create Font\" to re-create this font.");
/*     */     }
/*     */ 
/* 190 */     this.images = new PImage[this.charCount];
/* 191 */     for (j = 0; j < this.charCount; ++j) {
/* 192 */       int[] arrayOfInt = new int[this.twidth * this.theight];
/* 193 */       this.images[j] = new PImage(arrayOfInt, this.twidth, this.theight, 4);
/* 194 */       int k = this.height[j] * this.width[j];
/*     */ 
/* 196 */       byte[] arrayOfByte = new byte[k];
/* 197 */       localDataInputStream.readFully(arrayOfByte);
/*     */ 
/* 200 */       int l = this.width[j];
/* 201 */       int i1 = this.height[j];
/* 202 */       for (int i2 = 0; i2 < i1; ++i2) {
/* 203 */         for (int i3 = 0; i3 < l; ++i3) {
/* 204 */           int i4 = arrayOfByte[(i2 * l + i3)] & 0xFF;
/* 205 */           this.images[j].pixels[(i2 * this.twidth + i3)] = i4;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 216 */     if (i == 10) {
/* 217 */       this.name = localDataInputStream.readUTF();
/* 218 */       this.psname = localDataInputStream.readUTF(); }  } 
/*     */   public PFont(Font paramFont, boolean paramBoolean, char[] paramArrayOfChar) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokespecial 259	java/lang/Object:<init>	()V
/*     */     //   4: aload_0
/*     */     //   5: invokespecial 261	processing/core/PFont:this	()V
/*     */     //   8: getstatic 189	processing/core/PApplet:javaVersion	F
/*     */     //   11: ldc 190
/*     */     //   13: fcmpg
/*     */     //   14: ifge +14 -> 28
/*     */     //   17: new 236	java/lang/RuntimeException
/*     */     //   20: dup
/*     */     //   21: ldc_w 299
/*     */     //   24: invokespecial 240	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
/*     */     //   27: athrow
/*     */     //   28: aload_0
/*     */     //   29: aload_1
/*     */     //   30: invokevirtual 229	java/awt/Font:getName	()Ljava/lang/String;
/*     */     //   33: putfield 59	processing/core/PFont:name	Ljava/lang/String;
/*     */     //   36: aload_0
/*     */     //   37: aload_1
/*     */     //   38: invokevirtual 302	java/awt/Font:getPSName	()Ljava/lang/String;
/*     */     //   41: putfield 95	processing/core/PFont:psname	Ljava/lang/String;
/*     */     //   44: aload_0
/*     */     //   45: aload_3
/*     */     //   46: ifnonnull +9 -> 55
/*     */     //   49: ldc_w 303
/*     */     //   52: goto +5 -> 57
/*     */     //   55: aload_3
/*     */     //   56: arraylength
/*     */     //   57: putfield 53	processing/core/PFont:charCount	I
/*     */     //   60: aload_0
/*     */     //   61: aload_1
/*     */     //   62: invokevirtual 306	java/awt/Font:getSize	()I
/*     */     //   65: putfield 61	processing/core/PFont:size	I
/*     */     //   68: aload_0
/*     */     //   69: aload_0
/*     */     //   70: aload_0
/*     */     //   71: getfield 61	processing/core/PFont:size	I
/*     */     //   74: i2f
/*     */     //   75: dup_x1
/*     */     //   76: putfield 112	processing/core/PFont:fheight	F
/*     */     //   79: putfield 119	processing/core/PFont:fwidth	F
/*     */     //   82: aload_0
/*     */     //   83: getfield 53	processing/core/PFont:charCount	I
/*     */     //   86: anewarray 85	processing/core/PImage
/*     */     //   89: astore 4
/*     */     //   91: aload_0
/*     */     //   92: aload_0
/*     */     //   93: getfield 53	processing/core/PFont:charCount	I
/*     */     //   96: newarray int
/*     */     //   98: putfield 69	processing/core/PFont:value	[I
/*     */     //   101: aload_0
/*     */     //   102: aload_0
/*     */     //   103: getfield 53	processing/core/PFont:charCount	I
/*     */     //   106: newarray int
/*     */     //   108: putfield 71	processing/core/PFont:height	[I
/*     */     //   111: aload_0
/*     */     //   112: aload_0
/*     */     //   113: getfield 53	processing/core/PFont:charCount	I
/*     */     //   116: newarray int
/*     */     //   118: putfield 73	processing/core/PFont:width	[I
/*     */     //   121: aload_0
/*     */     //   122: aload_0
/*     */     //   123: getfield 53	processing/core/PFont:charCount	I
/*     */     //   126: newarray int
/*     */     //   128: putfield 75	processing/core/PFont:setWidth	[I
/*     */     //   131: aload_0
/*     */     //   132: aload_0
/*     */     //   133: getfield 53	processing/core/PFont:charCount	I
/*     */     //   136: newarray int
/*     */     //   138: putfield 77	processing/core/PFont:topExtent	[I
/*     */     //   141: aload_0
/*     */     //   142: aload_0
/*     */     //   143: getfield 53	processing/core/PFont:charCount	I
/*     */     //   146: newarray int
/*     */     //   148: putfield 79	processing/core/PFont:leftExtent	[I
/*     */     //   151: aload_0
/*     */     //   152: sipush 128
/*     */     //   155: newarray int
/*     */     //   157: putfield 103	processing/core/PFont:ascii	[I
/*     */     //   160: iconst_0
/*     */     //   161: istore 5
/*     */     //   163: goto +14 -> 177
/*     */     //   166: aload_0
/*     */     //   167: getfield 103	processing/core/PFont:ascii	[I
/*     */     //   170: iload 5
/*     */     //   172: iconst_m1
/*     */     //   173: iastore
/*     */     //   174: iinc 5 1
/*     */     //   177: iload 5
/*     */     //   179: sipush 128
/*     */     //   182: if_icmplt -16 -> 166
/*     */     //   185: aload_0
/*     */     //   186: getfield 61	processing/core/PFont:size	I
/*     */     //   189: iconst_3
/*     */     //   190: imul
/*     */     //   191: istore 5
/*     */     //   193: ldc_w 308
/*     */     //   196: invokestatic 207	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
/*     */     //   199: astore 6
/*     */     //   201: aload 6
/*     */     //   203: iconst_3
/*     */     //   204: anewarray 206	java/lang/Class
/*     */     //   207: dup
/*     */     //   208: iconst_0
/*     */     //   209: getstatic 313	java/lang/Integer:TYPE	Ljava/lang/Class;
/*     */     //   212: aastore
/*     */     //   213: dup
/*     */     //   214: iconst_1
/*     */     //   215: getstatic 313	java/lang/Integer:TYPE	Ljava/lang/Class;
/*     */     //   218: aastore
/*     */     //   219: dup
/*     */     //   220: iconst_2
/*     */     //   221: getstatic 313	java/lang/Integer:TYPE	Ljava/lang/Class;
/*     */     //   224: aastore
/*     */     //   225: invokevirtual 317	java/lang/Class:getConstructor	([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
/*     */     //   228: astore 7
/*     */     //   230: aload 6
/*     */     //   232: ldc_w 319
/*     */     //   235: invokevirtual 323	java/lang/Class:getField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
/*     */     //   238: astore 8
/*     */     //   240: aload 8
/*     */     //   242: aload 8
/*     */     //   244: invokevirtual 329	java/lang/reflect/Field:getInt	(Ljava/lang/Object;)I
/*     */     //   247: istore 9
/*     */     //   249: aload 7
/*     */     //   251: iconst_3
/*     */     //   252: anewarray 4	java/lang/Object
/*     */     //   255: dup
/*     */     //   256: iconst_0
/*     */     //   257: new 312	java/lang/Integer
/*     */     //   260: dup
/*     */     //   261: iload 5
/*     */     //   263: invokespecial 331	java/lang/Integer:<init>	(I)V
/*     */     //   266: aastore
/*     */     //   267: dup
/*     */     //   268: iconst_1
/*     */     //   269: new 312	java/lang/Integer
/*     */     //   272: dup
/*     */     //   273: iload 5
/*     */     //   275: invokespecial 331	java/lang/Integer:<init>	(I)V
/*     */     //   278: aastore
/*     */     //   279: dup
/*     */     //   280: iconst_2
/*     */     //   281: new 312	java/lang/Integer
/*     */     //   284: dup
/*     */     //   285: iload 9
/*     */     //   287: invokespecial 331	java/lang/Integer:<init>	(I)V
/*     */     //   290: aastore
/*     */     //   291: invokevirtual 337	java/lang/reflect/Constructor:newInstance	([Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   294: astore 10
/*     */     //   296: ldc_w 339
/*     */     //   299: invokestatic 207	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
/*     */     //   302: astore 11
/*     */     //   304: aload 6
/*     */     //   306: ldc_w 341
/*     */     //   309: iconst_0
/*     */     //   310: anewarray 206	java/lang/Class
/*     */     //   313: invokevirtual 213	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*     */     //   316: astore 12
/*     */     //   318: aload 12
/*     */     //   320: aload 10
/*     */     //   322: iconst_0
/*     */     //   323: anewarray 4	java/lang/Object
/*     */     //   326: invokevirtual 219	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   329: checkcast 343	java/awt/Graphics
/*     */     //   332: astore 13
/*     */     //   334: ldc_w 345
/*     */     //   337: invokestatic 207	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
/*     */     //   340: astore 14
/*     */     //   342: ldc_w 347
/*     */     //   345: invokestatic 207	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
/*     */     //   348: astore 15
/*     */     //   350: aload 14
/*     */     //   352: ldc_w 349
/*     */     //   355: invokevirtual 352	java/lang/Class:getDeclaredField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
/*     */     //   358: astore 16
/*     */     //   360: aload 16
/*     */     //   362: aload 14
/*     */     //   364: invokevirtual 356	java/lang/reflect/Field:get	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   367: astore 17
/*     */     //   369: iload_2
/*     */     //   370: ifeq +14 -> 384
/*     */     //   373: aload 14
/*     */     //   375: ldc_w 358
/*     */     //   378: invokevirtual 323	java/lang/Class:getField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
/*     */     //   381: goto +11 -> 392
/*     */     //   384: aload 14
/*     */     //   386: ldc_w 360
/*     */     //   389: invokevirtual 323	java/lang/Class:getField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
/*     */     //   392: astore 18
/*     */     //   394: aload 18
/*     */     //   396: aload 14
/*     */     //   398: invokevirtual 356	java/lang/reflect/Field:get	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   401: astore 19
/*     */     //   403: aload 11
/*     */     //   405: ldc_w 362
/*     */     //   408: iconst_2
/*     */     //   409: anewarray 206	java/lang/Class
/*     */     //   412: dup
/*     */     //   413: iconst_0
/*     */     //   414: aload 15
/*     */     //   416: aastore
/*     */     //   417: dup
/*     */     //   418: iconst_1
/*     */     //   419: getstatic 364	processing/core/PFont:class$java$lang$Object	Ljava/lang/Class;
/*     */     //   422: dup
/*     */     //   423: ifnonnull +15 -> 438
/*     */     //   426: pop
/*     */     //   427: ldc_w 366
/*     */     //   430: iconst_0
/*     */     //   431: invokestatic 368	processing/core/PFont:class	(Ljava/lang/String;Z)Ljava/lang/Class;
/*     */     //   434: dup
/*     */     //   435: putstatic 364	processing/core/PFont:class$java$lang$Object	Ljava/lang/Class;
/*     */     //   438: aastore
/*     */     //   439: invokevirtual 213	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*     */     //   442: astore 20
/*     */     //   444: aload 20
/*     */     //   446: aload 13
/*     */     //   448: iconst_2
/*     */     //   449: anewarray 4	java/lang/Object
/*     */     //   452: dup
/*     */     //   453: iconst_0
/*     */     //   454: aload 17
/*     */     //   456: aastore
/*     */     //   457: dup
/*     */     //   458: iconst_1
/*     */     //   459: aload 19
/*     */     //   461: aastore
/*     */     //   462: invokevirtual 219	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   465: pop
/*     */     //   466: aload 13
/*     */     //   468: aload_1
/*     */     //   469: invokevirtual 372	java/awt/Graphics:setFont	(Ljava/awt/Font;)V
/*     */     //   472: aload 13
/*     */     //   474: invokevirtual 376	java/awt/Graphics:getFontMetrics	()Ljava/awt/FontMetrics;
/*     */     //   477: astore 21
/*     */     //   479: aconst_null
/*     */     //   480: astore 22
/*     */     //   482: aconst_null
/*     */     //   483: astore 23
/*     */     //   485: aconst_null
/*     */     //   486: astore 24
/*     */     //   488: iload 5
/*     */     //   490: iload 5
/*     */     //   492: imul
/*     */     //   493: newarray int
/*     */     //   495: astore 25
/*     */     //   497: getstatic 378	processing/core/PFont:class$java$awt$Font	Ljava/lang/Class;
/*     */     //   500: dup
/*     */     //   501: ifnonnull +15 -> 516
/*     */     //   504: pop
/*     */     //   505: ldc_w 380
/*     */     //   508: iconst_0
/*     */     //   509: invokestatic 368	processing/core/PFont:class	(Ljava/lang/String;Z)Ljava/lang/Class;
/*     */     //   512: dup
/*     */     //   513: putstatic 378	processing/core/PFont:class$java$awt$Font	Ljava/lang/Class;
/*     */     //   516: ldc_w 382
/*     */     //   519: iconst_1
/*     */     //   520: anewarray 206	java/lang/Class
/*     */     //   523: dup
/*     */     //   524: iconst_0
/*     */     //   525: getstatic 385	java/lang/Character:TYPE	Ljava/lang/Class;
/*     */     //   528: aastore
/*     */     //   529: invokevirtual 213	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*     */     //   532: astore 22
/*     */     //   534: aload 6
/*     */     //   536: ldc_w 387
/*     */     //   539: iconst_0
/*     */     //   540: anewarray 206	java/lang/Class
/*     */     //   543: invokevirtual 213	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*     */     //   546: astore 23
/*     */     //   548: ldc_w 389
/*     */     //   551: invokestatic 207	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
/*     */     //   554: astore 26
/*     */     //   556: aload 26
/*     */     //   558: ldc_w 391
/*     */     //   561: bipush 6
/*     */     //   563: anewarray 206	java/lang/Class
/*     */     //   566: dup
/*     */     //   567: iconst_0
/*     */     //   568: getstatic 313	java/lang/Integer:TYPE	Ljava/lang/Class;
/*     */     //   571: aastore
/*     */     //   572: dup
/*     */     //   573: iconst_1
/*     */     //   574: getstatic 313	java/lang/Integer:TYPE	Ljava/lang/Class;
/*     */     //   577: aastore
/*     */     //   578: dup
/*     */     //   579: iconst_2
/*     */     //   580: getstatic 313	java/lang/Integer:TYPE	Ljava/lang/Class;
/*     */     //   583: aastore
/*     */     //   584: dup
/*     */     //   585: iconst_3
/*     */     //   586: getstatic 313	java/lang/Integer:TYPE	Ljava/lang/Class;
/*     */     //   589: aastore
/*     */     //   590: dup
/*     */     //   591: iconst_4
/*     */     //   592: getstatic 313	java/lang/Integer:TYPE	Ljava/lang/Class;
/*     */     //   595: aastore
/*     */     //   596: dup
/*     */     //   597: iconst_5
/*     */     //   598: aload 25
/*     */     //   600: invokevirtual 394	java/lang/Object:getClass	()Ljava/lang/Class;
/*     */     //   603: aastore
/*     */     //   604: invokevirtual 213	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*     */     //   607: astore 24
/*     */     //   609: iconst_0
/*     */     //   610: istore 27
/*     */     //   612: iconst_0
/*     */     //   613: istore 28
/*     */     //   615: iconst_0
/*     */     //   616: istore 29
/*     */     //   618: goto +671 -> 1289
/*     */     //   621: aload_3
/*     */     //   622: ifnonnull +9 -> 631
/*     */     //   625: iload 29
/*     */     //   627: i2c
/*     */     //   628: goto +7 -> 635
/*     */     //   631: aload_3
/*     */     //   632: iload 29
/*     */     //   634: caload
/*     */     //   635: istore 30
/*     */     //   637: new 384	java/lang/Character
/*     */     //   640: dup
/*     */     //   641: iload 30
/*     */     //   643: invokespecial 397	java/lang/Character:<init>	(C)V
/*     */     //   646: astore 31
/*     */     //   648: aload 22
/*     */     //   650: aload_1
/*     */     //   651: iconst_1
/*     */     //   652: anewarray 4	java/lang/Object
/*     */     //   655: dup
/*     */     //   656: iconst_0
/*     */     //   657: aload 31
/*     */     //   659: aastore
/*     */     //   660: invokevirtual 219	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   663: checkcast 399	java/lang/Boolean
/*     */     //   666: astore 32
/*     */     //   668: aload 32
/*     */     //   670: invokevirtual 403	java/lang/Boolean:booleanValue	()Z
/*     */     //   673: ifne +6 -> 679
/*     */     //   676: goto +610 -> 1286
/*     */     //   679: goto +11 -> 690
/*     */     //   682: astore 31
/*     */     //   684: aload 31
/*     */     //   686: invokevirtual 234	java/lang/Exception:printStackTrace	()V
/*     */     //   689: return
/*     */     //   690: aload 13
/*     */     //   692: getstatic 409	java/awt/Color:white	Ljava/awt/Color;
/*     */     //   695: invokevirtual 413	java/awt/Graphics:setColor	(Ljava/awt/Color;)V
/*     */     //   698: aload 13
/*     */     //   700: iconst_0
/*     */     //   701: iconst_0
/*     */     //   702: iload 5
/*     */     //   704: iload 5
/*     */     //   706: invokevirtual 417	java/awt/Graphics:fillRect	(IIII)V
/*     */     //   709: aload 13
/*     */     //   711: getstatic 420	java/awt/Color:black	Ljava/awt/Color;
/*     */     //   714: invokevirtual 413	java/awt/Graphics:setColor	(Ljava/awt/Color;)V
/*     */     //   717: aload 13
/*     */     //   719: iload 30
/*     */     //   721: invokestatic 424	java/lang/String:valueOf	(C)Ljava/lang/String;
/*     */     //   724: aload_0
/*     */     //   725: getfield 61	processing/core/PFont:size	I
/*     */     //   728: aload_0
/*     */     //   729: getfield 61	processing/core/PFont:size	I
/*     */     //   732: iconst_2
/*     */     //   733: imul
/*     */     //   734: invokevirtual 428	java/awt/Graphics:drawString	(Ljava/lang/String;II)V
/*     */     //   737: aload 23
/*     */     //   739: aload 10
/*     */     //   741: iconst_0
/*     */     //   742: anewarray 4	java/lang/Object
/*     */     //   745: invokevirtual 219	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   748: astore 31
/*     */     //   750: aload 24
/*     */     //   752: aload 31
/*     */     //   754: bipush 6
/*     */     //   756: anewarray 4	java/lang/Object
/*     */     //   759: dup
/*     */     //   760: iconst_0
/*     */     //   761: new 312	java/lang/Integer
/*     */     //   764: dup
/*     */     //   765: iconst_0
/*     */     //   766: invokespecial 331	java/lang/Integer:<init>	(I)V
/*     */     //   769: aastore
/*     */     //   770: dup
/*     */     //   771: iconst_1
/*     */     //   772: new 312	java/lang/Integer
/*     */     //   775: dup
/*     */     //   776: iconst_0
/*     */     //   777: invokespecial 331	java/lang/Integer:<init>	(I)V
/*     */     //   780: aastore
/*     */     //   781: dup
/*     */     //   782: iconst_2
/*     */     //   783: new 312	java/lang/Integer
/*     */     //   786: dup
/*     */     //   787: iload 5
/*     */     //   789: invokespecial 331	java/lang/Integer:<init>	(I)V
/*     */     //   792: aastore
/*     */     //   793: dup
/*     */     //   794: iconst_3
/*     */     //   795: new 312	java/lang/Integer
/*     */     //   798: dup
/*     */     //   799: iload 5
/*     */     //   801: invokespecial 331	java/lang/Integer:<init>	(I)V
/*     */     //   804: aastore
/*     */     //   805: dup
/*     */     //   806: iconst_4
/*     */     //   807: new 312	java/lang/Integer
/*     */     //   810: dup
/*     */     //   811: iconst_0
/*     */     //   812: invokespecial 331	java/lang/Integer:<init>	(I)V
/*     */     //   815: aastore
/*     */     //   816: dup
/*     */     //   817: iconst_5
/*     */     //   818: aload 25
/*     */     //   820: aastore
/*     */     //   821: invokevirtual 219	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   824: pop
/*     */     //   825: sipush 1000
/*     */     //   828: istore 32
/*     */     //   830: iconst_0
/*     */     //   831: istore 33
/*     */     //   833: sipush 1000
/*     */     //   836: istore 34
/*     */     //   838: iconst_0
/*     */     //   839: istore 35
/*     */     //   841: iconst_0
/*     */     //   842: istore 36
/*     */     //   844: iconst_0
/*     */     //   845: istore 37
/*     */     //   847: goto +94 -> 941
/*     */     //   850: iconst_0
/*     */     //   851: istore 38
/*     */     //   853: goto +78 -> 931
/*     */     //   856: aload 25
/*     */     //   858: iload 37
/*     */     //   860: iload 5
/*     */     //   862: imul
/*     */     //   863: iload 38
/*     */     //   865: iadd
/*     */     //   866: iaload
/*     */     //   867: sipush 255
/*     */     //   870: iand
/*     */     //   871: istore 39
/*     */     //   873: iload 39
/*     */     //   875: sipush 255
/*     */     //   878: if_icmpeq +50 -> 928
/*     */     //   881: iload 38
/*     */     //   883: iload 32
/*     */     //   885: if_icmpge +7 -> 892
/*     */     //   888: iload 38
/*     */     //   890: istore 32
/*     */     //   892: iload 37
/*     */     //   894: iload 34
/*     */     //   896: if_icmpge +7 -> 903
/*     */     //   899: iload 37
/*     */     //   901: istore 34
/*     */     //   903: iload 38
/*     */     //   905: iload 33
/*     */     //   907: if_icmple +7 -> 914
/*     */     //   910: iload 38
/*     */     //   912: istore 33
/*     */     //   914: iload 37
/*     */     //   916: iload 35
/*     */     //   918: if_icmple +7 -> 925
/*     */     //   921: iload 37
/*     */     //   923: istore 35
/*     */     //   925: iconst_1
/*     */     //   926: istore 36
/*     */     //   928: iinc 38 1
/*     */     //   931: iload 38
/*     */     //   933: iload 5
/*     */     //   935: if_icmplt -79 -> 856
/*     */     //   938: iinc 37 1
/*     */     //   941: iload 37
/*     */     //   943: iload 5
/*     */     //   945: if_icmplt -95 -> 850
/*     */     //   948: iload 36
/*     */     //   950: ifne +15 -> 965
/*     */     //   953: iconst_0
/*     */     //   954: dup
/*     */     //   955: istore 34
/*     */     //   957: istore 32
/*     */     //   959: iconst_0
/*     */     //   960: dup
/*     */     //   961: istore 35
/*     */     //   963: istore 33
/*     */     //   965: aload_0
/*     */     //   966: getfield 69	processing/core/PFont:value	[I
/*     */     //   969: iload 28
/*     */     //   971: iload 30
/*     */     //   973: iastore
/*     */     //   974: aload_0
/*     */     //   975: getfield 71	processing/core/PFont:height	[I
/*     */     //   978: iload 28
/*     */     //   980: iload 35
/*     */     //   982: iload 34
/*     */     //   984: isub
/*     */     //   985: iconst_1
/*     */     //   986: iadd
/*     */     //   987: iastore
/*     */     //   988: aload_0
/*     */     //   989: getfield 73	processing/core/PFont:width	[I
/*     */     //   992: iload 28
/*     */     //   994: iload 33
/*     */     //   996: iload 32
/*     */     //   998: isub
/*     */     //   999: iconst_1
/*     */     //   1000: iadd
/*     */     //   1001: iastore
/*     */     //   1002: aload_0
/*     */     //   1003: getfield 75	processing/core/PFont:setWidth	[I
/*     */     //   1006: iload 28
/*     */     //   1008: aload 21
/*     */     //   1010: iload 30
/*     */     //   1012: invokevirtual 433	java/awt/FontMetrics:charWidth	(C)I
/*     */     //   1015: iastore
/*     */     //   1016: iload 30
/*     */     //   1018: sipush 128
/*     */     //   1021: if_icmpge +12 -> 1033
/*     */     //   1024: aload_0
/*     */     //   1025: getfield 103	processing/core/PFont:ascii	[I
/*     */     //   1028: iload 30
/*     */     //   1030: iload 28
/*     */     //   1032: iastore
/*     */     //   1033: aload_0
/*     */     //   1034: getfield 77	processing/core/PFont:topExtent	[I
/*     */     //   1037: iload 28
/*     */     //   1039: aload_0
/*     */     //   1040: getfield 61	processing/core/PFont:size	I
/*     */     //   1043: iconst_2
/*     */     //   1044: imul
/*     */     //   1045: iload 34
/*     */     //   1047: isub
/*     */     //   1048: iastore
/*     */     //   1049: aload_0
/*     */     //   1050: getfield 79	processing/core/PFont:leftExtent	[I
/*     */     //   1053: iload 28
/*     */     //   1055: iload 32
/*     */     //   1057: aload_0
/*     */     //   1058: getfield 61	processing/core/PFont:size	I
/*     */     //   1061: isub
/*     */     //   1062: iastore
/*     */     //   1063: iload 30
/*     */     //   1065: bipush 100
/*     */     //   1067: if_icmpne +14 -> 1081
/*     */     //   1070: aload_0
/*     */     //   1071: aload_0
/*     */     //   1072: getfield 77	processing/core/PFont:topExtent	[I
/*     */     //   1075: iload 28
/*     */     //   1077: iaload
/*     */     //   1078: putfield 65	processing/core/PFont:ascent	I
/*     */     //   1081: iload 30
/*     */     //   1083: bipush 112
/*     */     //   1085: if_icmpne +23 -> 1108
/*     */     //   1088: aload_0
/*     */     //   1089: aload_0
/*     */     //   1090: getfield 77	processing/core/PFont:topExtent	[I
/*     */     //   1093: iload 28
/*     */     //   1095: iaload
/*     */     //   1096: ineg
/*     */     //   1097: aload_0
/*     */     //   1098: getfield 71	processing/core/PFont:height	[I
/*     */     //   1101: iload 28
/*     */     //   1103: iaload
/*     */     //   1104: iadd
/*     */     //   1105: putfield 67	processing/core/PFont:descent	I
/*     */     //   1108: aload_0
/*     */     //   1109: getfield 73	processing/core/PFont:width	[I
/*     */     //   1112: iload 28
/*     */     //   1114: iaload
/*     */     //   1115: iload 27
/*     */     //   1117: if_icmple +12 -> 1129
/*     */     //   1120: aload_0
/*     */     //   1121: getfield 73	processing/core/PFont:width	[I
/*     */     //   1124: iload 28
/*     */     //   1126: iaload
/*     */     //   1127: istore 27
/*     */     //   1129: aload_0
/*     */     //   1130: getfield 71	processing/core/PFont:height	[I
/*     */     //   1133: iload 28
/*     */     //   1135: iaload
/*     */     //   1136: iload 27
/*     */     //   1138: if_icmple +12 -> 1150
/*     */     //   1141: aload_0
/*     */     //   1142: getfield 71	processing/core/PFont:height	[I
/*     */     //   1145: iload 28
/*     */     //   1147: iaload
/*     */     //   1148: istore 27
/*     */     //   1150: aload 4
/*     */     //   1152: iload 28
/*     */     //   1154: new 85	processing/core/PImage
/*     */     //   1157: dup
/*     */     //   1158: aload_0
/*     */     //   1159: getfield 73	processing/core/PFont:width	[I
/*     */     //   1162: iload 28
/*     */     //   1164: iaload
/*     */     //   1165: aload_0
/*     */     //   1166: getfield 71	processing/core/PFont:height	[I
/*     */     //   1169: iload 28
/*     */     //   1171: iaload
/*     */     //   1172: imul
/*     */     //   1173: newarray int
/*     */     //   1175: aload_0
/*     */     //   1176: getfield 73	processing/core/PFont:width	[I
/*     */     //   1179: iload 28
/*     */     //   1181: iaload
/*     */     //   1182: aload_0
/*     */     //   1183: getfield 71	processing/core/PFont:height	[I
/*     */     //   1186: iload 28
/*     */     //   1188: iaload
/*     */     //   1189: iconst_4
/*     */     //   1190: invokespecial 289	processing/core/PImage:<init>	([IIII)V
/*     */     //   1193: aastore
/*     */     //   1194: iload 34
/*     */     //   1196: istore 37
/*     */     //   1198: goto +78 -> 1276
/*     */     //   1201: iload 32
/*     */     //   1203: istore 38
/*     */     //   1205: goto +61 -> 1266
/*     */     //   1208: sipush 255
/*     */     //   1211: aload 25
/*     */     //   1213: iload 37
/*     */     //   1215: iload 5
/*     */     //   1217: imul
/*     */     //   1218: iload 38
/*     */     //   1220: iadd
/*     */     //   1221: iaload
/*     */     //   1222: sipush 255
/*     */     //   1225: iand
/*     */     //   1226: isub
/*     */     //   1227: istore 39
/*     */     //   1229: iload 37
/*     */     //   1231: iload 34
/*     */     //   1233: isub
/*     */     //   1234: aload_0
/*     */     //   1235: getfield 73	processing/core/PFont:width	[I
/*     */     //   1238: iload 28
/*     */     //   1240: iaload
/*     */     //   1241: imul
/*     */     //   1242: iload 38
/*     */     //   1244: iload 32
/*     */     //   1246: isub
/*     */     //   1247: iadd
/*     */     //   1248: istore 40
/*     */     //   1250: aload 4
/*     */     //   1252: iload 28
/*     */     //   1254: aaload
/*     */     //   1255: getfield 86	processing/core/PImage:pixels	[I
/*     */     //   1258: iload 40
/*     */     //   1260: iload 39
/*     */     //   1262: iastore
/*     */     //   1263: iinc 38 1
/*     */     //   1266: iload 38
/*     */     //   1268: iload 33
/*     */     //   1270: if_icmple -62 -> 1208
/*     */     //   1273: iinc 37 1
/*     */     //   1276: iload 37
/*     */     //   1278: iload 35
/*     */     //   1280: if_icmple -79 -> 1201
/*     */     //   1283: iinc 28 1
/*     */     //   1286: iinc 29 1
/*     */     //   1289: iload 29
/*     */     //   1291: aload_0
/*     */     //   1292: getfield 53	processing/core/PFont:charCount	I
/*     */     //   1295: if_icmplt -674 -> 621
/*     */     //   1298: aload_0
/*     */     //   1299: iload 28
/*     */     //   1301: putfield 53	processing/core/PFont:charCount	I
/*     */     //   1304: aload_0
/*     */     //   1305: getfield 65	processing/core/PFont:ascent	I
/*     */     //   1308: ifne +131 -> 1439
/*     */     //   1311: aload_0
/*     */     //   1312: getfield 67	processing/core/PFont:descent	I
/*     */     //   1315: ifne +124 -> 1439
/*     */     //   1318: iconst_0
/*     */     //   1319: istore 29
/*     */     //   1321: goto +109 -> 1430
/*     */     //   1324: aload_0
/*     */     //   1325: getfield 69	processing/core/PFont:value	[I
/*     */     //   1328: iload 29
/*     */     //   1330: iaload
/*     */     //   1331: i2c
/*     */     //   1332: istore 30
/*     */     //   1334: iload 30
/*     */     //   1336: invokestatic 437	java/lang/Character:isWhitespace	(C)Z
/*     */     //   1339: ifne +27 -> 1366
/*     */     //   1342: iload 30
/*     */     //   1344: sipush 160
/*     */     //   1347: if_icmpeq +19 -> 1366
/*     */     //   1350: iload 30
/*     */     //   1352: sipush 8199
/*     */     //   1355: if_icmpeq +11 -> 1366
/*     */     //   1358: iload 30
/*     */     //   1360: sipush 8239
/*     */     //   1363: if_icmpne +6 -> 1369
/*     */     //   1366: goto +61 -> 1427
/*     */     //   1369: aload_0
/*     */     //   1370: getfield 77	processing/core/PFont:topExtent	[I
/*     */     //   1373: iload 29
/*     */     //   1375: iaload
/*     */     //   1376: aload_0
/*     */     //   1377: getfield 65	processing/core/PFont:ascent	I
/*     */     //   1380: if_icmple +14 -> 1394
/*     */     //   1383: aload_0
/*     */     //   1384: aload_0
/*     */     //   1385: getfield 77	processing/core/PFont:topExtent	[I
/*     */     //   1388: iload 29
/*     */     //   1390: iaload
/*     */     //   1391: putfield 65	processing/core/PFont:ascent	I
/*     */     //   1394: aload_0
/*     */     //   1395: getfield 77	processing/core/PFont:topExtent	[I
/*     */     //   1398: iload 29
/*     */     //   1400: iaload
/*     */     //   1401: ineg
/*     */     //   1402: aload_0
/*     */     //   1403: getfield 71	processing/core/PFont:height	[I
/*     */     //   1406: iload 29
/*     */     //   1408: iaload
/*     */     //   1409: iadd
/*     */     //   1410: istore 31
/*     */     //   1412: iload 31
/*     */     //   1414: aload_0
/*     */     //   1415: getfield 67	processing/core/PFont:descent	I
/*     */     //   1418: if_icmple +9 -> 1427
/*     */     //   1421: aload_0
/*     */     //   1422: iload 31
/*     */     //   1424: putfield 67	processing/core/PFont:descent	I
/*     */     //   1427: iinc 29 1
/*     */     //   1430: iload 29
/*     */     //   1432: aload_0
/*     */     //   1433: getfield 53	processing/core/PFont:charCount	I
/*     */     //   1436: if_icmplt -112 -> 1324
/*     */     //   1439: aload_0
/*     */     //   1440: iconst_2
/*     */     //   1441: i2d
/*     */     //   1442: iload 27
/*     */     //   1444: i2d
/*     */     //   1445: invokestatic 273	java/lang/Math:log	(D)D
/*     */     //   1448: iconst_2
/*     */     //   1449: i2d
/*     */     //   1450: invokestatic 273	java/lang/Math:log	(D)D
/*     */     //   1453: ddiv
/*     */     //   1454: invokestatic 276	java/lang/Math:ceil	(D)D
/*     */     //   1457: invokestatic 280	java/lang/Math:pow	(DD)D
/*     */     //   1460: d2i
/*     */     //   1461: putfield 63	processing/core/PFont:mbox2	I
/*     */     //   1464: aload_0
/*     */     //   1465: aload_0
/*     */     //   1466: aload_0
/*     */     //   1467: getfield 63	processing/core/PFont:mbox2	I
/*     */     //   1470: dup_x1
/*     */     //   1471: putfield 282	processing/core/PFont:theight	I
/*     */     //   1474: putfield 284	processing/core/PFont:twidth	I
/*     */     //   1477: aload_0
/*     */     //   1478: aload_0
/*     */     //   1479: getfield 53	processing/core/PFont:charCount	I
/*     */     //   1482: anewarray 85	processing/core/PImage
/*     */     //   1485: putfield 81	processing/core/PFont:images	[Lprocessing/core/PImage;
/*     */     //   1488: iconst_0
/*     */     //   1489: istore 29
/*     */     //   1491: goto +112 -> 1603
/*     */     //   1494: aload_0
/*     */     //   1495: getfield 81	processing/core/PFont:images	[Lprocessing/core/PImage;
/*     */     //   1498: iload 29
/*     */     //   1500: new 85	processing/core/PImage
/*     */     //   1503: dup
/*     */     //   1504: aload_0
/*     */     //   1505: getfield 63	processing/core/PFont:mbox2	I
/*     */     //   1508: aload_0
/*     */     //   1509: getfield 63	processing/core/PFont:mbox2	I
/*     */     //   1512: imul
/*     */     //   1513: newarray int
/*     */     //   1515: aload_0
/*     */     //   1516: getfield 63	processing/core/PFont:mbox2	I
/*     */     //   1519: aload_0
/*     */     //   1520: getfield 63	processing/core/PFont:mbox2	I
/*     */     //   1523: iconst_4
/*     */     //   1524: invokespecial 289	processing/core/PImage:<init>	([IIII)V
/*     */     //   1527: aastore
/*     */     //   1528: iconst_0
/*     */     //   1529: istore 30
/*     */     //   1531: goto +51 -> 1582
/*     */     //   1534: aload 4
/*     */     //   1536: iload 29
/*     */     //   1538: aaload
/*     */     //   1539: getfield 86	processing/core/PImage:pixels	[I
/*     */     //   1542: iload 30
/*     */     //   1544: aload_0
/*     */     //   1545: getfield 73	processing/core/PFont:width	[I
/*     */     //   1548: iload 29
/*     */     //   1550: iaload
/*     */     //   1551: imul
/*     */     //   1552: aload_0
/*     */     //   1553: getfield 81	processing/core/PFont:images	[Lprocessing/core/PImage;
/*     */     //   1556: iload 29
/*     */     //   1558: aaload
/*     */     //   1559: getfield 86	processing/core/PImage:pixels	[I
/*     */     //   1562: iload 30
/*     */     //   1564: aload_0
/*     */     //   1565: getfield 63	processing/core/PFont:mbox2	I
/*     */     //   1568: imul
/*     */     //   1569: aload_0
/*     */     //   1570: getfield 73	processing/core/PFont:width	[I
/*     */     //   1573: iload 29
/*     */     //   1575: iaload
/*     */     //   1576: invokestatic 443	java/lang/System:arraycopy	(Ljava/lang/Object;ILjava/lang/Object;II)V
/*     */     //   1579: iinc 30 1
/*     */     //   1582: iload 30
/*     */     //   1584: aload_0
/*     */     //   1585: getfield 71	processing/core/PFont:height	[I
/*     */     //   1588: iload 29
/*     */     //   1590: iaload
/*     */     //   1591: if_icmplt -57 -> 1534
/*     */     //   1594: aload 4
/*     */     //   1596: iload 29
/*     */     //   1598: aconst_null
/*     */     //   1599: aastore
/*     */     //   1600: iinc 29 1
/*     */     //   1603: iload 29
/*     */     //   1605: aload_0
/*     */     //   1606: getfield 53	processing/core/PFont:charCount	I
/*     */     //   1609: if_icmplt -115 -> 1494
/*     */     //   1612: goto +23 -> 1635
/*     */     //   1615: astore 4
/*     */     //   1617: aload 4
/*     */     //   1619: invokevirtual 234	java/lang/Exception:printStackTrace	()V
/*     */     //   1622: new 236	java/lang/RuntimeException
/*     */     //   1625: dup
/*     */     //   1626: aload 4
/*     */     //   1628: invokevirtual 444	java/lang/Exception:getMessage	()Ljava/lang/String;
/*     */     //   1631: invokespecial 240	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
/*     */     //   1634: athrow
/*     */     //   1635: return
/*     */     //
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   637	676	682	java/lang/Exception
/*     */     //   44	689	1615	java/lang/Exception
/*     */     //   690	1612	1615	java/lang/Exception } 
/*     */   static { int i = 0;
/* 638 */     for (int j = 33; j <= 126; ++j) {
/* 639 */       DEFAULT_CHARSET[(i++)] = (char)j;
/*     */     }
/* 641 */     for (j = 0; j < EXTRA_CHARS.length; ++j)
/* 642 */       DEFAULT_CHARSET[(i++)] = EXTRA_CHARS[j];
/*     */   }
/*     */ }

/* Location:           /Users/mfeyereisen/Desktop/Sources 2/common/
 * Qualified Name:     processing.core.PFont
 * JD-Core Version:    0.5.3
 */