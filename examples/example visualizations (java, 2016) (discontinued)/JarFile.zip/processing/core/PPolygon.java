/*     */ package processing.core;
/*     */ 
/*     */ public class PPolygon
/*     */   implements PConstants
/*     */ {
/*     */   static final int DEFAULT_SIZE = 64;
/*     */   static final boolean FRY = 0;
/*     */   static final int SUBXRES = 8;
/*     */   static final int SUBXRES1 = 7;
/*     */   static final int SUBYRES = 8;
/*     */   static final int SUBYRES1 = 7;
/*     */   static final int MAX_COVERAGE = 64;
/*     */   float[][] vertices;
/*     */   int vertexCount;
/*     */   float[] r;
/*     */   float[] dr;
/*     */   float[] l;
/*     */   float[] dl;
/*     */   float[] sp;
/*     */   float[] sdp;
/*     */   boolean interpX;
/*     */   boolean interpZ;
/*     */   boolean interpUV;
/*     */   boolean interpARGB;
/*     */   int rgba;
/*     */   int r2;
/*     */   int g2;
/*     */   int b2;
/*     */   int a2;
/*     */   int a2orig;
/*     */   boolean noDepthTest;
/*     */   PGraphics parent;
/*     */   int[] pixels;
/*     */   int width;
/*     */   int height;
/*     */   int width1;
/*     */   int height1;
/*     */   PImage timage;
/*     */   int[] tpixels;
/*     */   int theight;
/*     */   int twidth;
/*     */   int theight1;
/*     */   int twidth1;
/*     */   int tformat;
/*     */   boolean texture_smooth;
/*     */   boolean smoothing;
/*     */   int firstModY;
/*     */   int lastModY;
/*     */   int lastY;
/*     */   int[] aaleft;
/*     */   int[] aaright;
/*     */   int aaleftmin;
/*     */   int aarightmin;
/*     */   int aaleftmax;
/*     */   int aarightmax;
/*     */   int aaleftfull;
/*     */   int aarightfull;
/*     */ 
/*     */   private final int MODYRES(int paramInt)
/*     */   {
/*  98 */     return (paramInt & 0x7);
/*     */   }
/*     */ 
/*     */   public void reset(int paramInt)
/*     */   {
/* 109 */     this.vertexCount = paramInt;
/* 110 */     this.interpX = true;
/* 111 */     this.interpZ = true;
/* 112 */     this.interpUV = false;
/* 113 */     this.interpARGB = true;
/* 114 */     this.timage = null;
/*     */   }
/*     */ 
/*     */   public float[] nextVertex()
/*     */   {
/* 119 */     if (this.vertexCount == this.vertices.length)
/*     */     {
/* 122 */       float[][] arrayOfFloat = new float[this.vertexCount << 1][36];
/* 123 */       System.arraycopy(this.vertices, 0, arrayOfFloat, 0, this.vertexCount);
/* 124 */       this.vertices = arrayOfFloat;
/*     */ 
/* 126 */       this.r = new float[this.vertices.length];
/* 127 */       this.dr = new float[this.vertices.length];
/* 128 */       this.l = new float[this.vertices.length];
/* 129 */       this.dl = new float[this.vertices.length];
/* 130 */       this.sp = new float[this.vertices.length];
/* 131 */       this.sdp = new float[this.vertices.length];
/*     */     }
/* 133 */     return this.vertices[(this.vertexCount++)];
/*     */   }
/*     */ 
/*     */   public void texture(PImage paramPImage)
/*     */   {
/* 160 */     this.timage = paramPImage;
/* 161 */     this.tpixels = paramPImage.pixels;
/* 162 */     this.twidth = paramPImage.width;
/* 163 */     this.theight = paramPImage.height;
/* 164 */     this.tformat = paramPImage.format;
/*     */ 
/* 166 */     this.twidth1 = (this.twidth - 1);
/* 167 */     this.theight1 = (this.theight - 1);
/* 168 */     this.interpUV = true;
/*     */   }
/*     */ 
/*     */   public void render()
/*     */   {
/* 173 */     if (this.vertexCount < 3) return;
/*     */ 
/* 177 */     this.pixels = this.parent.pixels;
/*     */ 
/* 180 */     this.noDepthTest = this.parent.hints[5];
/* 181 */     this.smoothing = this.parent.smooth;
/*     */ 
/* 186 */     this.texture_smooth = (this.parent.hints[3] ^ 0x1);
/*     */ 
/* 189 */     this.width = ((this.smoothing) ? this.parent.width * 8 : this.parent.width);
/* 190 */     this.height = ((this.smoothing) ? this.parent.height * 8 : this.parent.height);
/*     */ 
/* 192 */     this.width1 = (this.width - 1);
/* 193 */     this.height1 = (this.height - 1);
/*     */ 
/* 195 */     if (!(this.interpARGB)) {
/* 196 */       this.r2 = (int)(this.vertices[0][3] * 255.0F);
/* 197 */       this.g2 = (int)(this.vertices[0][4] * 255.0F);
/* 198 */       this.b2 = (int)(this.vertices[0][5] * 255.0F);
/* 199 */       this.a2 = (int)(this.vertices[0][6] * 255.0F);
/* 200 */       this.a2orig = this.a2;
/* 201 */       this.rgba = (0xFF000000 | this.r2 << 16 | this.g2 << 8 | this.b2);
/*     */     }
/*     */ 
/* 204 */     for (int i = 0; i < this.vertexCount; ++i) {
/* 205 */       this.r[i] = 0.0F; this.dr[i] = 0.0F; this.l[i] = 0.0F; this.dl[i] = 0.0F;
/*     */     }
/*     */ 
/* 209 */     if (this.parent.hints[6] != 0) {
/* 210 */       float f1 = -this.width * 2;
/* 211 */       f2 = -this.height * 2;
/* 212 */       f3 = this.width * 2;
/* 213 */       float f4 = this.height * 2;
/* 214 */       for (i1 = 0; i1 < this.vertexCount; ++i1) {
/* 215 */         if ((this.vertices[i1][0] < f1) || (this.vertices[i1][0] > f3) || (this.vertices[i1][1] < f2) || (this.vertices[i1][1] > f4))
/*     */         {
/* 219 */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 224 */     if (this.smoothing) {
/* 225 */       for (j = 0; j < this.vertexCount; ++j) {
/* 226 */         this.vertices[j][0] *= 8.0F;
/* 227 */         this.vertices[j][1] *= 8.0F;
/*     */       }
/* 229 */       this.firstModY = -1;
/*     */     }
/*     */ 
/* 233 */     int j = 0;
/* 234 */     float f2 = this.vertices[0][1];
/* 235 */     float f3 = this.vertices[0][1];
/* 236 */     for (int k = 1; k < this.vertexCount; ++k) {
/* 237 */       if (this.vertices[k][1] < f2) {
/* 238 */         f2 = this.vertices[k][1];
/* 239 */         j = k;
/*     */       }
/* 241 */       if (this.vertices[k][1] <= f3) continue; f3 = this.vertices[k][1];
/*     */     }
/*     */ 
/* 251 */     this.lastY = (int)(f3 - 0.5F);
/*     */ 
/* 253 */     k = j;
/* 254 */     int i1 = j;
/* 255 */     int i2 = (int)(f2 + 0.5F);
/* 256 */     int i3 = i2 - 1;
/* 257 */     int i4 = i2 - 1;
/*     */ 
/* 259 */     this.interpX = true;
/*     */ 
/* 261 */     int i5 = this.vertexCount;
/*     */ 
/* 265 */     while (i5 > 0)
/*     */     {
/*     */       int i6;
/* 267 */       while ((i3 <= i2) && (i5 > 0)) {
/* 268 */         --i5;
/*     */ 
/* 270 */         i6 = (k != 0) ? k - 1 : this.vertexCount - 1;
/* 271 */         incrementalize_y(this.vertices[k], this.vertices[i6], this.l, this.dl, i2);
/* 272 */         i3 = (int)(this.vertices[i6][1] + 0.5F);
/* 273 */         k = i6;
/*     */       }
/*     */ 
/* 277 */       while ((i4 <= i2) && (i5 > 0)) {
/* 278 */         --i5;
/*     */ 
/* 280 */         if (i1 != this.vertexCount - 1) 0; i6 = i1 + 1;
/* 281 */         incrementalize_y(this.vertices[i1], this.vertices[i6], this.r, this.dr, i2);
/* 282 */         i4 = (int)(this.vertices[i6][1] + 0.5F);
/* 283 */         i1 = i6;
/*     */       }
/*     */ 
/* 287 */       while ((i2 < i3) && (i2 < i4))
/*     */       {
/* 294 */         if ((i2 >= 0) && (i2 < this.height))
/*     */         {
/* 296 */           if (this.l[0] <= this.r[0]) scanline(i2, this.l, this.r);
/*     */           else scanline(i2, this.r, this.l);
/*     */ 
/*     */         }
/*     */ 
/* 302 */         ++i2;
/*     */ 
/* 305 */         increment(this.l, this.dl);
/* 306 */         increment(this.r, this.dr);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void unexpand()
/*     */   {
/* 316 */     if (this.smoothing)
/* 317 */       for (int i = 0; i < this.vertexCount; ++i) {
/* 318 */         this.vertices[i][0] /= 8.0F;
/* 319 */         this.vertices[i][1] /= 8.0F;
/*     */       }
/*     */   }
/*     */ 
/*     */   private final void scanline(int paramInt, float[] paramArrayOfFloat1, float[] paramArrayOfFloat2)
/*     */   {
/* 327 */     for (int i = 0; i < this.vertexCount; ++i) {
/* 328 */       this.sp[i] = 0.0F; this.sdp[i] = 0.0F;
/*     */     }
/*     */ 
/* 332 */     i = (int)(paramArrayOfFloat1[0] + 0.49999F);
/* 333 */     if (i < 0) i = 0;
/* 334 */     int j = (int)(paramArrayOfFloat2[0] - 0.5F);
/* 335 */     if (j > this.width1) j = this.width1;
/*     */ 
/* 337 */     if (i > j) return;
/*     */ 
/* 339 */     if (this.smoothing) {
/* 340 */       k = MODYRES(paramInt);
/*     */ 
/* 342 */       this.aaleft[k] = i;
/* 343 */       this.aaright[k] = j;
/*     */ 
/* 345 */       if (this.firstModY == -1) {
/* 346 */         this.firstModY = k;
/* 347 */         this.aaleftmin = i; this.aaleftmax = i;
/* 348 */         this.aarightmin = j; this.aarightmax = j;
/*     */       }
/*     */       else {
/* 351 */         if (this.aaleftmin > this.aaleft[k]) this.aaleftmin = this.aaleft[k];
/* 352 */         if (this.aaleftmax < this.aaleft[k]) this.aaleftmax = this.aaleft[k];
/* 353 */         if (this.aarightmin > this.aaright[k]) this.aarightmin = this.aaright[k];
/* 354 */         if (this.aarightmax < this.aaright[k]) this.aarightmax = this.aaright[k];
/*     */       }
/*     */ 
/* 357 */       this.lastModY = k;
/*     */ 
/* 359 */       if ((k != 7) && (paramInt != this.lastY)) return;
/*     */ 
/* 367 */       this.aaleftfull = (this.aaleftmax / 8 + 1);
/* 368 */       this.aarightfull = (this.aarightmin / 8 - 1);
/*     */     }
/*     */ 
/* 372 */     incrementalize_x(paramArrayOfFloat1, paramArrayOfFloat2, this.sp, this.sdp, i);
/*     */ 
/* 377 */     int k = (this.smoothing) ? this.parent.width * paramInt / 8 : this.parent.width * paramInt;
/*     */ 
/* 379 */     int i1 = 0; int i2 = 0;
/* 380 */     if (this.smoothing) {
/* 381 */       i1 = i / 8;
/* 382 */       i2 = (j + 7) / 8;
/*     */ 
/* 384 */       i = this.aaleftmin / 8;
/* 385 */       j = (this.aarightmax + 7) / 8;
/* 386 */       if (i < 0) i = 0;
/* 387 */       if (j > this.parent.width1) j = this.parent.width1;
/*     */     }
/*     */ 
/* 390 */     this.interpX = false;
/*     */ 
/* 393 */     for (int i7 = i; i7 <= j; ++i7)
/*     */     {
/*     */       int i8;
/*     */       int i9;
/*     */       int i10;
/*     */       int i11;
/*     */       int i12;
/* 400 */       if (this.interpUV) {
/* 401 */         i8 = (int)this.sp[7];
/* 402 */         i9 = (int)this.sp[8];
/*     */ 
/* 404 */         if (i8 > this.twidth1) i8 = this.twidth1;
/* 405 */         if (i9 > this.theight1) i9 = this.theight1;
/* 406 */         if (i8 < 0) i8 = 0;
/* 407 */         if (i9 < 0) i9 = 0;
/*     */ 
/* 409 */         i10 = i9 * this.twidth + i8;
/*     */         int i13;
/*     */         int i14;
/*     */         int i6;
/*     */         int i3;
/*     */         int i4;
/*     */         int i5;
/* 411 */         if ((this.smoothing) || (this.texture_smooth))
/*     */         {
/* 416 */           i11 = (int)(255.0F * (this.sp[7] - i8));
/* 417 */           i12 = (int)(255.0F * (this.sp[8] - i9));
/*     */ 
/* 421 */           i13 = 255 - i11;
/* 422 */           i14 = 255 - i12;
/*     */ 
/* 425 */           int i15 = this.tpixels[i10];
/* 426 */           int i16 = (i9 < this.theight1) ? this.tpixels[(i10 + this.twidth)] : this.tpixels[i10];
/*     */ 
/* 428 */           int i17 = (i8 < this.twidth1) ? this.tpixels[(i10 + 1)] : this.tpixels[i10];
/*     */ 
/* 430 */           int i18 = ((i9 < this.theight1) && (i8 < this.twidth1)) ? this.tpixels[(i10 + this.twidth + 1)] : this.tpixels[i10];
/*     */           int i23;
/*     */           int i24;
/*     */           int i19;
/*     */           int i20;
/*     */           int i21;
/*     */           int i22;
/* 436 */           if (this.tformat == 4) {
/* 437 */             i23 = i15 * i13 + i17 * i11 >> 8;
/* 438 */             i24 = i16 * i13 + i18 * i11 >> 8;
/* 439 */             i6 = (i23 * i14 + i24 * i12 >> 8) * ((this.interpARGB) ? (int)(this.sp[6] * 255.0F) : this.a2orig) >> 8;
/*     */           }
/* 442 */           else if (this.tformat == 2) {
/* 443 */             i19 = i15 >> 24 & 0xFF;
/* 444 */             i20 = i16 >> 24 & 0xFF;
/* 445 */             i21 = i17 >> 24 & 0xFF;
/* 446 */             i22 = i18 >> 24 & 0xFF;
/*     */ 
/* 448 */             i23 = i19 * i13 + i21 * i11 >> 8;
/* 449 */             i24 = i20 * i13 + i22 * i11 >> 8;
/* 450 */             i6 = (i23 * i14 + i24 * i12 >> 8) * ((this.interpARGB) ? (int)(this.sp[6] * 255.0F) : this.a2orig) >> 8;
/*     */           }
/*     */           else
/*     */           {
/* 454 */             i6 = (this.interpARGB) ? (int)(this.sp[6] * 255.0F) : this.a2orig;
/*     */           }
/*     */ 
/* 457 */           if ((this.tformat == 1) || (this.tformat == 2)) {
/* 458 */             i19 = i15 >> 16 & 0xFF;
/* 459 */             i20 = i16 >> 16 & 0xFF;
/* 460 */             i21 = i17 >> 16 & 0xFF;
/* 461 */             i22 = i18 >> 16 & 0xFF;
/*     */ 
/* 463 */             i23 = i19 * i13 + i21 * i11 >> 8;
/* 464 */             i24 = i20 * i13 + i22 * i11 >> 8;
/* 465 */             i3 = (i23 * i14 + i24 * i12 >> 8) * ((this.interpARGB) ? (int)this.sp[3] * 255 : this.r2) >> 8;
/*     */ 
/* 469 */             i19 = i15 >> 8 & 0xFF;
/* 470 */             i20 = i16 >> 8 & 0xFF;
/* 471 */             i21 = i17 >> 8 & 0xFF;
/* 472 */             i22 = i18 >> 8 & 0xFF;
/*     */ 
/* 474 */             i23 = i19 * i13 + i21 * i11 >> 8;
/* 475 */             i24 = i20 * i13 + i22 * i11 >> 8;
/* 476 */             i4 = (i23 * i14 + i24 * i12 >> 8) * ((this.interpARGB) ? (int)this.sp[4] * 255 : this.g2) >> 8;
/*     */ 
/* 480 */             i19 = i15 & 0xFF;
/* 481 */             i20 = i16 & 0xFF;
/* 482 */             i21 = i17 & 0xFF;
/* 483 */             i22 = i18 & 0xFF;
/*     */ 
/* 485 */             i23 = i19 * i13 + i21 * i11 >> 8;
/* 486 */             i24 = i20 * i13 + i22 * i11 >> 8;
/* 487 */             i5 = (i23 * i14 + i24 * i12 >> 8) * ((this.interpARGB) ? (int)this.sp[5] * 255 : this.b2) >> 8;
/*     */           }
/* 491 */           else if (this.interpARGB) {
/* 492 */             i3 = (int)(this.sp[3] * 255.0F);
/* 493 */             i4 = (int)(this.sp[4] * 255.0F);
/* 494 */             i5 = (int)(this.sp[5] * 255.0F);
/*     */           }
/*     */           else {
/* 497 */             i3 = this.r2;
/* 498 */             i4 = this.g2;
/* 499 */             i5 = this.b2;
/*     */           }
/*     */ 
/* 506 */           int i25 = (this.smoothing) ? coverage(i7) : 255;
/* 507 */           if (i25 != 255) i6 = i6 * i25 >> 8;
/*     */         }
/*     */         else {
/* 510 */           i11 = this.tpixels[i10];
/*     */ 
/* 514 */           if (this.tformat == 4) {
/* 515 */             i6 = i11;
/*     */ 
/* 517 */             if (this.interpARGB) {
/* 518 */               i3 = (int)this.sp[3] * 255;
/* 519 */               i4 = (int)this.sp[4] * 255;
/* 520 */               i5 = (int)this.sp[5] * 255;
/* 521 */               if (this.sp[6] != 1.0F)
/* 522 */                 i6 = (int)this.sp[6] * 255 * i6 >> 8;
/*     */             }
/*     */             else
/*     */             {
/* 526 */               i3 = this.r2;
/* 527 */               i4 = this.g2;
/* 528 */               i5 = this.b2;
/* 529 */               i6 = this.a2orig * i6 >> 8;
/*     */             }
/*     */           }
/*     */           else {
/* 533 */             i6 = (this.tformat == 1) ? 255 : i11 >> 24 & 0xFF;
/*     */ 
/* 535 */             if (this.interpARGB) {
/* 536 */               i3 = (int)this.sp[3] * 255 * (i11 >> 16 & 0xFF) >> 8;
/* 537 */               i4 = (int)this.sp[4] * 255 * (i11 >> 8 & 0xFF) >> 8;
/* 538 */               i5 = (int)this.sp[5] * 255 * (i11 & 0xFF) >> 8;
/* 539 */               i6 = (int)this.sp[6] * 255 * i6 >> 8;
/*     */             }
/*     */             else {
/* 542 */               i3 = this.r2 * (i11 >> 16 & 0xFF) >> 8;
/* 543 */               i4 = this.g2 * (i11 >> 8 & 0xFF) >> 8;
/* 544 */               i5 = this.b2 * (i11 & 0xFF) >> 8;
/* 545 */               i6 = this.a2orig * i6 >> 8;
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 550 */         if ((i6 == 254) || (i6 == 255))
/*     */         {
/* 552 */           this.pixels[(k + i7)] = (0xFF000000 | i3 << 16 | i4 << 8 | i5);
/*     */         }
/*     */         else
/*     */         {
/* 557 */           i11 = 255 - i6;
/* 558 */           i12 = this.pixels[(k + i7)] >> 16 & 0xFF;
/* 559 */           i13 = this.pixels[(k + i7)] >> 8 & 0xFF;
/* 560 */           i14 = this.pixels[(k + i7)] & 0xFF;
/*     */ 
/* 562 */           this.pixels[(k + i7)] = (0xFF000000 | i3 * i6 + i12 * i11 >> 8 << 16 | i4 * i6 + i13 * i11 & 0xFF00 | i5 * i6 + i14 * i11 >> 8);
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 570 */         i8 = (this.smoothing) ? coverage(i7) : 255;
/*     */ 
/* 572 */         if (this.interpARGB) {
/* 573 */           this.r2 = (int)(this.sp[3] * 255.0F);
/* 574 */           this.g2 = (int)(this.sp[4] * 255.0F);
/* 575 */           this.b2 = (int)(this.sp[5] * 255.0F);
/* 576 */           if (this.sp[6] != 1.0F) i8 = i8 * (int)(this.sp[6] * 255.0F) >> 8;
/* 577 */           if (i8 == 255) {
/* 578 */             this.rgba = (0xFF000000 | this.r2 << 16 | this.g2 << 8 | this.b2);
/*     */           }
/*     */         }
/* 581 */         else if (this.a2orig != 255) { i8 = i8 * this.a2orig >> 8;
/*     */         }
/*     */ 
/* 584 */         if (i8 == 255)
/*     */         {
/* 586 */           this.pixels[(k + i7)] = this.rgba;
/*     */         }
/*     */         else
/*     */         {
/* 590 */           i9 = this.pixels[(k + i7)] >> 16 & 0xFF;
/* 591 */           i10 = this.pixels[(k + i7)] >> 8 & 0xFF;
/* 592 */           i11 = this.pixels[(k + i7)] & 0xFF;
/* 593 */           this.a2 = i8;
/*     */ 
/* 595 */           i12 = 255 - this.a2;
/* 596 */           this.pixels[(k + i7)] = (0xFF000000 | i9 * i12 + this.r2 * this.a2 >> 8 << 16 | i10 * i12 + this.g2 * this.a2 >> 8 << 8 | i11 * i12 + this.b2 * this.a2 >> 8);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 609 */       if ((!(this.smoothing)) || ((i7 >= i1) && (i7 <= i2))) {
/* 610 */         increment(this.sp, this.sdp);
/*     */       }
/*     */     }
/* 613 */     this.firstModY = -1;
/* 614 */     this.interpX = true;
/*     */   }
/*     */ 
/*     */   private final int coverage(int paramInt)
/*     */   {
/* 620 */     if ((paramInt >= this.aaleftfull) && (paramInt <= this.aarightfull) && (this.firstModY == 0) && (this.lastModY == 7))
/*     */     {
/* 623 */       return 255;
/*     */     }
/*     */ 
/* 626 */     int i = paramInt * 8;
/* 627 */     int j = i + 8;
/*     */ 
/* 629 */     int k = 0;
/* 630 */     for (int i1 = this.firstModY; i1 <= this.lastModY; ++i1) {
/* 631 */       if ((this.aaleft[i1] > j) || (this.aaright[i1] < i)) {
/*     */         continue;
/*     */       }
/*     */ 
/* 635 */       k += ((this.aaright[i1] < j) ? this.aaright[i1] : j) - ((this.aaleft[i1] > i) ? this.aaleft[i1] : i);
/*     */     }
/*     */ 
/* 638 */     k <<= 2;
/* 639 */     return ((k == 256) ? 255 : k);
/*     */   }
/*     */ 
/*     */   private final void incrementalize_y(float[] paramArrayOfFloat1, float[] paramArrayOfFloat2, float[] paramArrayOfFloat3, float[] paramArrayOfFloat4, int paramInt)
/*     */   {
/* 645 */     float f1 = paramArrayOfFloat2[1] - paramArrayOfFloat1[1];
/* 646 */     if (f1 == 0.0F) f1 = 1.0F;
/* 647 */     float f2 = paramInt + 0.5F - paramArrayOfFloat1[1];
/*     */ 
/* 649 */     if (this.interpX) {
/* 650 */       paramArrayOfFloat4[0] = ((paramArrayOfFloat2[0] - paramArrayOfFloat1[0]) / f1);
/* 651 */       paramArrayOfFloat3[0] = (paramArrayOfFloat1[0] + paramArrayOfFloat4[0] * f2);
/*     */     }
/* 653 */     if (this.interpZ) {
/* 654 */       paramArrayOfFloat4[2] = ((paramArrayOfFloat2[2] - paramArrayOfFloat1[2]) / f1);
/* 655 */       paramArrayOfFloat3[2] = (paramArrayOfFloat1[2] + paramArrayOfFloat4[2] * f2);
/*     */     }
/*     */ 
/* 658 */     if (this.interpARGB) {
/* 659 */       paramArrayOfFloat4[3] = ((paramArrayOfFloat2[3] - paramArrayOfFloat1[3]) / f1);
/* 660 */       paramArrayOfFloat4[4] = ((paramArrayOfFloat2[4] - paramArrayOfFloat1[4]) / f1);
/* 661 */       paramArrayOfFloat4[5] = ((paramArrayOfFloat2[5] - paramArrayOfFloat1[5]) / f1);
/* 662 */       paramArrayOfFloat4[6] = ((paramArrayOfFloat2[6] - paramArrayOfFloat1[6]) / f1);
/* 663 */       paramArrayOfFloat3[3] = (paramArrayOfFloat1[3] + paramArrayOfFloat4[3] * f2);
/* 664 */       paramArrayOfFloat3[4] = (paramArrayOfFloat1[4] + paramArrayOfFloat4[4] * f2);
/* 665 */       paramArrayOfFloat3[5] = (paramArrayOfFloat1[5] + paramArrayOfFloat4[5] * f2);
/* 666 */       paramArrayOfFloat3[6] = (paramArrayOfFloat1[6] + paramArrayOfFloat4[6] * f2);
/*     */     }
/*     */ 
/* 669 */     if (this.interpUV) {
/* 670 */       paramArrayOfFloat4[7] = ((paramArrayOfFloat2[7] - paramArrayOfFloat1[7]) / f1);
/* 671 */       paramArrayOfFloat4[8] = ((paramArrayOfFloat2[8] - paramArrayOfFloat1[8]) / f1);
/*     */ 
/* 678 */       paramArrayOfFloat3[7] = (paramArrayOfFloat1[7] + paramArrayOfFloat4[7] * f2);
/* 679 */       paramArrayOfFloat3[8] = (paramArrayOfFloat1[8] + paramArrayOfFloat4[8] * f2);
/*     */     }
/*     */   }
/*     */ 
/*     */   private final void incrementalize_x(float[] paramArrayOfFloat1, float[] paramArrayOfFloat2, float[] paramArrayOfFloat3, float[] paramArrayOfFloat4, int paramInt)
/*     */   {
/* 688 */     float f1 = paramArrayOfFloat2[0] - paramArrayOfFloat1[0];
/* 689 */     if (f1 == 0.0F) f1 = 1.0F;
/* 690 */     float f2 = paramInt + 0.5F - paramArrayOfFloat1[0];
/* 691 */     if (this.smoothing) {
/* 692 */       f1 /= 8.0F;
/* 693 */       f2 /= 8.0F;
/*     */     }
/*     */ 
/* 696 */     if (this.interpX) {
/* 697 */       paramArrayOfFloat4[0] = ((paramArrayOfFloat2[0] - paramArrayOfFloat1[0]) / f1);
/* 698 */       paramArrayOfFloat3[0] = (paramArrayOfFloat1[0] + paramArrayOfFloat4[0] * f2);
/*     */     }
/* 700 */     if (this.interpZ) {
/* 701 */       paramArrayOfFloat4[2] = ((paramArrayOfFloat2[2] - paramArrayOfFloat1[2]) / f1);
/* 702 */       paramArrayOfFloat3[2] = (paramArrayOfFloat1[2] + paramArrayOfFloat4[2] * f2);
/*     */     }
/*     */ 
/* 705 */     if (this.interpARGB) {
/* 706 */       paramArrayOfFloat4[3] = ((paramArrayOfFloat2[3] - paramArrayOfFloat1[3]) / f1);
/* 707 */       paramArrayOfFloat4[4] = ((paramArrayOfFloat2[4] - paramArrayOfFloat1[4]) / f1);
/* 708 */       paramArrayOfFloat4[5] = ((paramArrayOfFloat2[5] - paramArrayOfFloat1[5]) / f1);
/* 709 */       paramArrayOfFloat4[6] = ((paramArrayOfFloat2[6] - paramArrayOfFloat1[6]) / f1);
/* 710 */       paramArrayOfFloat3[3] = (paramArrayOfFloat1[3] + paramArrayOfFloat4[3] * f2);
/* 711 */       paramArrayOfFloat3[4] = (paramArrayOfFloat1[4] + paramArrayOfFloat4[4] * f2);
/* 712 */       paramArrayOfFloat3[5] = (paramArrayOfFloat1[5] + paramArrayOfFloat4[5] * f2);
/* 713 */       paramArrayOfFloat3[6] = (paramArrayOfFloat1[6] + paramArrayOfFloat4[6] * f2);
/*     */     }
/*     */ 
/* 716 */     if (!(this.interpUV))
/*     */       return;
/* 718 */     paramArrayOfFloat4[7] = ((paramArrayOfFloat2[7] - paramArrayOfFloat1[7]) / f1);
/* 719 */     paramArrayOfFloat4[8] = ((paramArrayOfFloat2[8] - paramArrayOfFloat1[8]) / f1);
/*     */ 
/* 731 */     paramArrayOfFloat3[7] = (paramArrayOfFloat1[7] + paramArrayOfFloat4[7] * f2);
/* 732 */     paramArrayOfFloat3[8] = (paramArrayOfFloat1[8] + paramArrayOfFloat4[8] * f2);
/*     */   }
/*     */ 
/*     */   private final void increment(float[] paramArrayOfFloat1, float[] paramArrayOfFloat2)
/*     */   {
/* 739 */     if (this.interpX) paramArrayOfFloat1[0] += paramArrayOfFloat2[0];
/* 740 */     if (this.interpZ) paramArrayOfFloat1[2] += paramArrayOfFloat2[2];
/*     */ 
/* 742 */     if (this.interpARGB) {
/* 743 */       paramArrayOfFloat1[3] += paramArrayOfFloat2[3];
/* 744 */       paramArrayOfFloat1[4] += paramArrayOfFloat2[4];
/* 745 */       paramArrayOfFloat1[5] += paramArrayOfFloat2[5];
/* 746 */       paramArrayOfFloat1[6] += paramArrayOfFloat2[6];
/*     */     }
/*     */ 
/* 749 */     if (!(this.interpUV))
/*     */       return;
/* 751 */     paramArrayOfFloat1[7] += paramArrayOfFloat2[7];
/* 752 */     paramArrayOfFloat1[8] += paramArrayOfFloat2[8];
/*     */   }
/*     */ 
/*     */   private final void jdMethod_this()
/*     */   {
/*  35 */     this.vertices = new float[64][36];
/*     */ 
/*  44 */     this.r = new float[64];
/*  45 */     this.dr = new float[64];
/*  46 */     this.l = new float[64];
/*  47 */     this.dl = new float[64];
/*  48 */     this.sp = new float[64];
/*  49 */     this.sdp = new float[64];
/*     */ 
/*  91 */     this.aaleft = new int[8];
/*  92 */     this.aaright = new int[8];
/*     */   }
/*     */ 
/*     */   public PPolygon(PGraphics paramPGraphics)
/*     */   {
/* 102 */     jdMethod_this();
/* 103 */     this.parent = paramPGraphics;
/* 104 */     reset(0);
/*     */   }
/*     */ }

/* Location:           /Users/mfeyereisen/Desktop/Sources 2/common/
 * Qualified Name:     processing.core.PPolygon
 * JD-Core Version:    0.5.3
 */