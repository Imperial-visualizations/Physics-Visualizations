/*      */ package processing.core;
/*      */ 
/*      */ import java.awt.Image;
/*      */ import java.awt.image.PixelGrabber;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ 
/*      */ public class PImage
/*      */   implements PConstants, Cloneable
/*      */ {
/*      */   static final int PRECISIONB = 15;
/*      */   static final int PRECISIONF = 32768;
/*      */   static final int PREC_MAXVAL = 32767;
/*      */   static final int PREC_ALPHA_SHIFT = 9;
/*      */   static final int PREC_RED_SHIFT = 1;
/* 1357 */   static byte[] tiff_header = { 77, 77, 0, 42, 0, 0, 0, 8, 0, 9, 0, -2, 0, 4, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 3, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 3, 0, 0, 0, 1, 0, 0, 0, 0, 1, 2, 0, 3, 0, 0, 0, 3, 0, 0, 0, 122, 1, 6, 0, 3, 0, 0, 0, 1, 0, 2, 0, 0, 1, 17, 0, 4, 0, 0, 0, 1, 0, 0, 3, 0, 1, 21, 0, 3, 0, 0, 0, 1, 0, 3, 0, 0, 1, 22, 0, 3, 0, 0, 0, 1, 0, 0, 0, 0, 1, 23, 0, 4, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 8, 0, 8 };
/*      */   public int format;
/*      */   public int[] pixels;
/*      */   public int width;
/*      */   public int height;
/*      */   public int imageMode;
/*      */   public boolean smooth;
/*      */   public Object cache;
/*      */   public boolean modified;
/*      */   public int mx1;
/*      */   public int my1;
/*      */   public int mx2;
/*      */   public int my2;
/*      */   private int fracU;
/*      */   private int ifU;
/*      */   private int fracV;
/*      */   private int ifV;
/*      */   private int u1;
/*      */   private int u2;
/*      */   private int v1;
/*      */   private int v2;
/*      */   private int sX;
/*      */   private int sY;
/*      */   private int iw;
/*      */   private int iw1;
/*      */   private int ih1;
/*      */   private int ul;
/*      */   private int ll;
/*      */   private int ur;
/*      */   private int lr;
/*      */   private int cUL;
/*      */   private int cLL;
/*      */   private int cUR;
/*      */   private int cLR;
/*      */   private int srcXOffset;
/*      */   private int srcYOffset;
/*      */   private int r;
/*      */   private int g;
/*      */   private int b;
/*      */   private int a;
/*      */   private int[] srcBuffer;
/*      */   int blurRadius;
/*      */   int blurKernelSize;
/*      */   int[] blurKernel;
/*      */   int[][] blurMult;
/*      */ 
/*      */   public void init(int paramInt1, int paramInt2, int paramInt3)
/*      */   {
/*  135 */     this.width = paramInt1;
/*  136 */     this.height = paramInt2;
/*  137 */     this.pixels = new int[paramInt1 * paramInt2];
/*  138 */     this.format = paramInt3;
/*  139 */     this.cache = null;
/*      */   }
/*      */ 
/*      */   public void imageMode(int paramInt)
/*      */   {
/*  174 */     if ((paramInt == 0) || (paramInt == 1))
/*  175 */       this.imageMode = paramInt;
/*      */     else
/*  177 */       throw new RuntimeException("imageMode() only works with CORNER or CORNERS");
/*      */   }
/*      */ 
/*      */   public void smooth()
/*      */   {
/*  187 */     this.smooth = true;
/*      */   }
/*      */ 
/*      */   public void noSmooth()
/*      */   {
/*  195 */     this.smooth = false;
/*      */   }
/*      */ 
/*      */   public void loadPixels()
/*      */   {
/*      */   }
/*      */ 
/*      */   public void updatePixels()
/*      */   {
/*  287 */     updatePixels(0, 0, this.width, this.height);
/*      */   }
/*      */ 
/*      */   public void updatePixels(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*      */   {
/*  303 */     if (this.imageMode == 0) {
/*  304 */       paramInt3 += paramInt1;
/*  305 */       paramInt4 += paramInt2;
/*      */     }
/*      */ 
/*  308 */     if (!(this.modified)) {
/*  309 */       this.mx1 = paramInt1;
/*  310 */       this.mx2 = paramInt3;
/*  311 */       this.my1 = paramInt2;
/*  312 */       this.my2 = paramInt4;
/*  313 */       this.modified = true;
/*      */     }
/*      */     else {
/*  316 */       if (paramInt1 < this.mx1) this.mx1 = paramInt1;
/*  317 */       if (paramInt1 > this.mx2) this.mx2 = paramInt1;
/*  318 */       if (paramInt2 < this.my1) this.my1 = paramInt2;
/*  319 */       if (paramInt2 > this.my2) this.my2 = paramInt2;
/*      */ 
/*  321 */       if (paramInt3 < this.mx1) this.mx1 = paramInt3;
/*  322 */       if (paramInt3 > this.mx2) this.mx2 = paramInt3;
/*  323 */       if (paramInt4 < this.my1) this.my1 = paramInt4;
/*  324 */       if (paramInt4 <= this.my2) return; this.my2 = paramInt4;
/*      */     }
/*      */   }
/*      */ 
/*      */   public int get(int paramInt1, int paramInt2)
/*      */   {
/*  362 */     if ((paramInt1 < 0) || (paramInt2 < 0) || (paramInt1 >= this.width) || (paramInt2 >= this.height)) return 0;
/*      */ 
/*  364 */     switch (this.format)
/*      */     {
/*      */     case 1:
/*  366 */       return (this.pixels[(paramInt2 * this.width + paramInt1)] | 0xFF000000);
/*      */     case 2:
/*  369 */       return this.pixels[(paramInt2 * this.width + paramInt1)];
/*      */     case 4:
/*  372 */       return (this.pixels[(paramInt2 * this.width + paramInt1)] << 24 | 0xFFFFFF);
/*      */     case 3:
/*      */     }
/*  374 */     return 0;
/*      */   }
/*      */ 
/*      */   public PImage get(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*      */   {
/*  383 */     if (this.imageMode == 1)
/*      */     {
/*  386 */       paramInt3 -= paramInt1;
/*  387 */       paramInt4 -= paramInt1;
/*      */     }
/*      */ 
/*  390 */     if (paramInt1 < 0) {
/*  391 */       paramInt3 += paramInt1;
/*  392 */       paramInt1 = 0;
/*      */     }
/*  394 */     if (paramInt2 < 0) {
/*  395 */       paramInt4 += paramInt2;
/*  396 */       paramInt2 = 0;
/*      */     }
/*      */ 
/*  399 */     if (paramInt1 + paramInt3 > this.width) paramInt3 = this.width - paramInt1;
/*  400 */     if (paramInt2 + paramInt4 > this.height) paramInt4 = this.height - paramInt2;
/*      */ 
/*  402 */     PImage localPImage = new PImage(new int[paramInt3 * paramInt4], paramInt3, paramInt4, this.format);
/*      */ 
/*  404 */     int i = paramInt2 * this.width + paramInt1;
/*  405 */     int j = 0;
/*  406 */     for (int k = paramInt2; k < paramInt2 + paramInt4; ++k) {
/*  407 */       System.arraycopy(this.pixels, i, localPImage.pixels, j, paramInt3);
/*      */ 
/*  409 */       i += this.width;
/*  410 */       j += paramInt3;
/*      */     }
/*  412 */     return localPImage;
/*      */   }
/*      */ 
/*      */   public PImage get()
/*      */   {
/*      */     try
/*      */     {
/*  421 */       return ((PImage)clone()); } catch (CloneNotSupportedException localCloneNotSupportedException) {
/*      */     }
/*  423 */     return null;
/*      */   }
/*      */ 
/*      */   public void set(int paramInt1, int paramInt2, int paramInt3)
/*      */   {
/*  432 */     if ((paramInt1 < 0) || (paramInt2 < 0) || (paramInt1 >= this.width) || (paramInt2 >= this.height)) return;
/*  433 */     this.pixels[(paramInt2 * this.width + paramInt1)] = paramInt3;
/*      */   }
/*      */ 
/*      */   public void set(int paramInt1, int paramInt2, PImage paramPImage)
/*      */   {
/*  438 */     int i = 0;
/*  439 */     int j = 0;
/*  440 */     int k = paramPImage.width;
/*  441 */     int l = paramPImage.height;
/*      */ 
/*  443 */     if (paramInt1 < 0) {
/*  444 */       i -= paramInt1;
/*  445 */       k += paramInt1;
/*  446 */       paramInt1 = 0;
/*      */     }
/*  448 */     if (paramInt2 < 0) {
/*  449 */       j -= paramInt2;
/*  450 */       l += paramInt2;
/*  451 */       paramInt2 = 0;
/*      */     }
/*  453 */     if (paramInt1 + k > this.width) {
/*  454 */       k = this.width - paramInt1;
/*      */     }
/*  456 */     if (paramInt2 + l > this.height) {
/*  457 */       l = this.height - paramInt2;
/*      */     }
/*      */ 
/*  461 */     if ((k <= 0) || (l <= 0)) return;
/*      */ 
/*  463 */     setImpl(paramInt1, paramInt2, i, j, k, l, paramPImage);
/*      */   }
/*      */ 
/*      */   protected void setImpl(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, PImage paramPImage)
/*      */   {
/*  473 */     int i = paramInt4 * paramPImage.width + paramInt3;
/*  474 */     int j = paramInt2 * this.width + paramInt1;
/*      */ 
/*  476 */     for (int k = paramInt4; k < paramInt4 + paramInt6; ++k) {
/*  477 */       System.arraycopy(paramPImage.pixels, i, this.pixels, j, paramInt5);
/*  478 */       i += paramPImage.width;
/*  479 */       j += this.width;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void mask(int[] paramArrayOfInt)
/*      */   {
/*  505 */     if (paramArrayOfInt.length != this.pixels.length) {
/*  506 */       throw new RuntimeException("The PImage used with mask() must be the same size as the applet.");
/*      */     }
/*      */ 
/*  509 */     for (int i = 0; i < this.pixels.length; ++i) {
/*  510 */       this.pixels[i] = ((paramArrayOfInt[i] & 0xFF) << 24 | this.pixels[i] & 0xFFFFFF);
/*      */     }
/*  512 */     this.format = 2;
/*      */   }
/*      */ 
/*      */   public void mask(PImage paramPImage)
/*      */   {
/*  520 */     mask(paramPImage.pixels);
/*      */   }
/*      */ 
/*      */   public void filter(int paramInt)
/*      */   {
/*      */     int i;
/*  539 */     switch (paramInt)
/*      */     {
/*      */     case 11:
/*  545 */       filter(11, 1.0F);
/*  546 */       break;
/*      */     case 12:
/*  552 */       for (i = 0; i < this.pixels.length; ++i) {
/*  553 */         int j = this.pixels[i];
/*      */ 
/*  558 */         int k = 77 * (j >> 16 & 0xFF) + 151 * (j >> 8 & 0xFF) + 28 * (j & 0xFF) >> 8;
/*  559 */         this.pixels[i] = (j & 0xFF000000 | k << 16 | k << 8 | k);
/*      */       }
/*  561 */       break;
/*      */     case 13:
/*  564 */       for (i = 0; i < this.pixels.length; ++i)
/*      */       {
/*  566 */         this.pixels[i] ^= 16777215;
/*      */       }
/*  568 */       break;
/*      */     case 15:
/*  571 */       throw new RuntimeException("Use filter(POSTERIZE, int levels) instead of filter(POSTERIZE)");
/*      */     case 1:
/*  575 */       for (i = 0; i < this.pixels.length; ++i) {
/*  576 */         this.pixels[i] |= -16777216; } this.format = 1;
/*  579 */       break;
/*      */     case 16:
/*  582 */       filter(16, 0.5F);
/*      */     case 2:
/*      */     case 3:
/*      */     case 4:
/*      */     case 5:
/*      */     case 6:
/*      */     case 7:
/*      */     case 8:
/*      */     case 9:
/*      */     case 10:
/*      */     case 14: } updatePixels();
/*      */   }
/*      */ 
/*      */   public void filter(int paramInt, float paramFloat)
/*      */   {
/*      */     int l;
/*      */     int i1;
/*      */     int i2;
/*  606 */     switch (paramInt)
/*      */     {
/*      */     case 11:
/*  609 */       blur(paramFloat);
/*  610 */       break;
/*      */     case 12:
/*  613 */       throw new RuntimeException("Use filter(GRAY) instead of filter(GRAY, param)");
/*      */     case 13:
/*  617 */       throw new RuntimeException("Use filter(INVERT) instead of filter(INVERT, param)");
/*      */     case 14:
/*  621 */       throw new RuntimeException("Use filter(OPAQUE) instead of filter(OPAQUE, param)");
/*      */     case 15:
/*  625 */       int i = (int)paramFloat;
/*  626 */       if ((i < 2) || (i > 255)) {
/*  627 */         throw new RuntimeException("Levels must be between 2 and 255 for filter(POSTERIZE, levels)");
/*      */       }
/*      */ 
/*  631 */       int j = 256 / i;
/*  632 */       int k = i - 1;
/*  633 */       for (l = 0; l < this.pixels.length; ++l) {
/*  634 */         i1 = (this.pixels[l] >> 16 & 0xFF) / j;
/*  635 */         i2 = (this.pixels[l] >> 8 & 0xFF) / j;
/*  636 */         int i3 = (this.pixels[l] & 0xFF) / j;
/*      */ 
/*  638 */         i1 = i1 * 255 / k & 0xFF;
/*  639 */         i2 = i2 * 255 / k & 0xFF;
/*  640 */         i3 = i3 * 255 / k & 0xFF;
/*      */ 
/*  642 */         this.pixels[l] = (0xFF000000 & this.pixels[l] | i1 << 16 | i2 << 8 | i3);
/*      */       }
/*      */ 
/*  647 */       break;
/*      */     case 16:
/*  650 */       l = (int)(paramFloat * 255.0F);
/*  651 */       for (i1 = 0; i1 < this.pixels.length; ++i1) {
/*  652 */         i2 = Math.max((this.pixels[i1] & 0xFF0000) >> 16, Math.max((this.pixels[i1] & 0xFF00) >> 8, this.pixels[i1] & 0xFF));
/*      */ 
/*  655 */         this.pixels[i1] = (this.pixels[i1] & 0xFF000000 | ((i2 < l) ? 0 : 16777215));
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  660 */     updatePixels();
/*      */   }
/*      */ 
/*      */   protected void blur(float paramFloat)
/*      */   {
/*  667 */     int i = (int)(paramFloat * 3.5F);
/*  668 */     if (i >= 1) 1; i = (i < 248) ? i : 248;
/*      */     int j;
/*      */     int k;
/*      */     int l;
/*      */     int i1;
/*  670 */     if (this.blurRadius != i)
/*      */     {
/*  675 */       this.blurRadius = i;
/*  676 */       this.blurKernelSize = (1 + i * 2);
/*  677 */       this.blurKernel = new int[this.blurKernelSize];
/*  678 */       this.blurMult = new int[this.blurKernelSize][256];
/*      */ 
/*  680 */       j = 0;
/*  681 */       for (k = 1; k < i; ++k) {
/*  682 */         l = i - k;
/*  683 */         this.blurKernel[(i + k)] = (this.blurKernel[l] = l * l);
/*  684 */         j += this.blurKernel[l] + this.blurKernel[l];
/*  685 */         for (i1 = 0; i1 < 256; ++i1) {
/*  686 */           this.blurMult[(i + k)][i1] = (this.blurMult[l][i1] = this.blurKernel[l] * i1);
/*      */         }
/*      */       }
/*  689 */       this.blurKernel[i] = (i * i);
/*  690 */       j += this.blurKernel[i];
/*  691 */       for (k = 0; k < 256; ++k) {
/*  692 */         this.blurMult[i][k] = (this.blurKernel[i] * k);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  702 */     int i8 = this.width * this.height;
/*  703 */     int[] arrayOfInt1 = new int[i8];
/*  704 */     int[] arrayOfInt2 = new int[i8];
/*  705 */     int[] arrayOfInt3 = new int[i8];
/*      */     int i3;
/*  707 */     for (int i9 = 0; i9 < i8; ++i9) {
/*  708 */       i3 = this.pixels[i9];
/*  709 */       arrayOfInt1[i9] = ((i3 & 0xFF0000) >> 16);
/*  710 */       arrayOfInt2[i9] = ((i3 & 0xFF00) >> 8);
/*  711 */       arrayOfInt3[i9] = (i3 & 0xFF);
/*      */     }
/*      */ 
/*  714 */     int[] arrayOfInt4 = new int[i8];
/*  715 */     int[] arrayOfInt5 = new int[i8];
/*  716 */     int[] arrayOfInt6 = new int[i8];
/*      */ 
/*  718 */     int i10 = 0;
/*  719 */     int i11 = 0;
/*  720 */     int i12 = this.width;
/*  721 */     int i13 = this.height;
/*  722 */     int i14 = i11 * this.width;
/*      */     int i4;
/*      */     int i15;
/*      */     int i2;
/*  724 */     for (int i5 = i11; i5 < i13; ++i5) {
/*  725 */       for (i4 = i10; i4 < i12; ++i4) {
/*  726 */         i1 = l = k = j = 0;
/*  727 */         i3 = i4 - this.blurRadius;
/*  728 */         for (i15 = 0; i15 < this.blurKernelSize; ++i15) {
/*  729 */           i2 = i3 + i15;
/*  730 */           if ((i2 >= i10) && (i2 < i12)) {
/*  731 */             i2 += i14;
/*  732 */             k += this.blurMult[i15][arrayOfInt1[i2]];
/*  733 */             l += this.blurMult[i15][arrayOfInt2[i2]];
/*  734 */             i1 += this.blurMult[i15][arrayOfInt3[i2]];
/*  735 */             j += this.blurKernel[i15];
/*      */           }
/*      */         }
/*  738 */         i3 = i14 + i4;
/*  739 */         arrayOfInt4[i3] = (k / j);
/*  740 */         arrayOfInt5[i3] = (l / j);
/*  741 */         arrayOfInt6[i3] = (i1 / j);
/*      */       }
/*  743 */       i14 += this.width;
/*      */     }
/*  745 */     i14 = i11 * this.width;
/*      */ 
/*  747 */     for (i5 = i11; i5 < i13; ++i5) {
/*  748 */       int i6 = i5 - this.blurRadius;
/*  749 */       int i7 = i6 * this.width;
/*  750 */       for (i4 = i10; i4 < i12; ++i4) {
/*  751 */         i1 = l = k = j = 0;
/*  752 */         i3 = i6;
/*  753 */         i2 = i4 + i7;
/*      */ 
/*  755 */         for (i15 = 0; i15 < this.blurKernelSize; ++i15) {
/*  756 */           if ((i3 < i13) && (i3 >= i11)) {
/*  757 */             k += this.blurMult[i15][arrayOfInt4[i2]];
/*  758 */             l += this.blurMult[i15][arrayOfInt5[i2]];
/*  759 */             i1 += this.blurMult[i15][arrayOfInt6[i2]];
/*  760 */             j += this.blurKernel[i15];
/*      */           }
/*  762 */           ++i3;
/*  763 */           i2 += this.width;
/*      */         }
/*  765 */         this.pixels[(i4 + i14)] = (0xFF000000 | k / j << 16 | l / j << 8 | i1 / j);
/*      */       }
/*  767 */       i14 += this.width;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void copy(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8)
/*      */   {
/*  784 */     copy(this, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8);
/*      */   }
/*      */ 
/*      */   public void copy(PImage paramPImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8)
/*      */   {
/*  794 */     if (this.imageMode == 0) {
/*  795 */       paramInt3 += paramInt1; paramInt4 += paramInt2;
/*  796 */       paramInt7 += paramInt5; paramInt8 += paramInt6;
/*      */     }
/*      */ 
/*  803 */     if ((paramPImage == this) && (intersect(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8)))
/*      */     {
/*  806 */       blit_resize(get(paramInt1, paramInt2, paramInt3 - paramInt1, paramInt4 - paramInt2), 0, 0, paramInt3 - paramInt1 - 1, paramInt4 - paramInt2 - 1, this.pixels, this.width, this.height, paramInt5, paramInt6, paramInt7, paramInt8, 0);
/*      */     }
/*      */     else
/*      */     {
/*  810 */       blit_resize(paramPImage, paramInt1, paramInt2, paramInt3, paramInt4, this.pixels, this.width, this.height, paramInt5, paramInt6, paramInt7, paramInt8, 0);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static int blend(int paramInt1, int paramInt2, int paramInt3)
/*      */   {
/*  828 */     switch (paramInt3) { case 1:
/*  829 */       return blend_multiply(paramInt1, paramInt2);
/*      */     case 2:
/*  830 */       return blend_add_pin(paramInt1, paramInt2);
/*      */     case 4:
/*  831 */       return blend_sub_pin(paramInt1, paramInt2);
/*      */     case 8:
/*  832 */       return blend_lightest(paramInt1, paramInt2);
/*      */     case 16:
/*  833 */       return blend_darkest(paramInt1, paramInt2);
/*      */     case 0:
/*  834 */       return paramInt2;
/*      */     case 3:
/*      */     case 5:
/*      */     case 6:
/*      */     case 7:
/*      */     case 9:
/*      */     case 10:
/*      */     case 11:
/*      */     case 12:
/*      */     case 13:
/*      */     case 14:
/*      */     case 15: } return 0;
/*      */   }
/*      */ 
/*      */   public void blend(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
/*      */   {
/*  844 */     if ((paramInt3 < 0) || (paramInt3 >= this.width) || (paramInt1 < 0) || (paramInt1 >= this.width) || (paramInt4 < 0) || (paramInt4 >= this.height) || (paramInt2 < 0) || (paramInt2 >= this.height))
/*      */       return;
/*  846 */     this.pixels[(paramInt4 * this.width + paramInt3)] = blend(this.pixels[(paramInt4 * this.width + paramInt3)], this.pixels[(paramInt2 * this.width + paramInt1)], paramInt5);
/*      */   }
/*      */ 
/*      */   public void blend(PImage paramPImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
/*      */   {
/*  857 */     if ((paramInt3 < 0) || (paramInt3 >= this.width) || (paramInt1 < 0) || (paramInt1 >= paramPImage.width) || (paramInt4 < 0) || (paramInt4 >= this.height) || (paramInt2 < 0) || (paramInt2 >= paramPImage.height))
/*      */       return;
/*  859 */     this.pixels[(paramInt4 * this.width + paramInt3)] = blend(this.pixels[(paramInt4 * this.width + paramInt3)], paramPImage.pixels[(paramInt2 * paramPImage.width + paramInt1)], paramInt5);
/*      */   }
/*      */ 
/*      */   public void blend(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9)
/*      */   {
/*  871 */     blend(this, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9);
/*      */   }
/*      */ 
/*      */   public void blend(PImage paramPImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9)
/*      */   {
/*  881 */     if (this.imageMode == 0) {
/*  882 */       paramInt3 += paramInt1; paramInt4 += paramInt2;
/*  883 */       paramInt7 += paramInt5; paramInt8 += paramInt6;
/*      */     }
/*      */ 
/*  890 */     if ((paramPImage == this) && (intersect(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8)))
/*      */     {
/*  892 */       blit_resize(get(paramInt1, paramInt2, paramInt3 - paramInt1, paramInt4 - paramInt2), 0, 0, paramInt3 - paramInt1 - 1, paramInt4 - paramInt2 - 1, this.pixels, this.width, this.height, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9);
/*      */     }
/*      */     else
/*      */     {
/*  896 */       blit_resize(paramPImage, paramInt1, paramInt2, paramInt3, paramInt4, this.pixels, this.width, this.height, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected boolean intersect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8)
/*      */   {
/*  907 */     int i = paramInt3 - paramInt1 + 1;
/*  908 */     int j = paramInt4 - paramInt2 + 1;
/*  909 */     int k = paramInt7 - paramInt5 + 1;
/*  910 */     int l = paramInt8 - paramInt6 + 1;
/*      */     int i1;
/*  912 */     if (paramInt5 < paramInt1) {
/*  913 */       k += paramInt5 - paramInt1;
/*  914 */       if (k > i)
/*  915 */         k = i;
/*      */     }
/*      */     else {
/*  918 */       i1 = i + paramInt1 - paramInt5;
/*  919 */       if (k > i1) {
/*  920 */         k = i1;
/*      */       }
/*      */     }
/*  923 */     if (paramInt6 < paramInt2) {
/*  924 */       l += paramInt6 - paramInt2;
/*  925 */       if (l > j)
/*  926 */         l = j;
/*      */     }
/*      */     else {
/*  929 */       i1 = j + paramInt2 - paramInt6;
/*  930 */       if (l > i1) {
/*  931 */         l = i1;
/*      */       }
/*      */     }
/*  934 */     if ((k <= 0) || (l <= 0)) 0; return (0x1 ^ 0x1);
/*      */   }
/*      */ 
/*      */   public Object clone()
/*      */     throws CloneNotSupportedException
/*      */   {
/*  950 */     PImage localPImage = (PImage)super.clone();
/*      */ 
/*  954 */     localPImage.pixels = new int[this.width * this.height];
/*  955 */     System.arraycopy(this.pixels, 0, localPImage.pixels, 0, this.pixels.length);
/*      */ 
/*  958 */     return localPImage;
/*      */   }
/*      */ 
/*      */   private final void blit_resize(PImage paramPImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfInt, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11)
/*      */   {
/*  975 */     if (paramInt1 < 0) paramInt1 = 0;
/*  976 */     if (paramInt2 < 0) paramInt2 = 0;
/*  977 */     if (paramInt3 >= paramPImage.width) paramInt3 = paramPImage.width - 1;
/*  978 */     if (paramInt4 >= paramPImage.width) paramInt4 = paramPImage.height - 1;
/*      */ 
/*  980 */     int i = paramInt3 - paramInt1;
/*  981 */     int j = paramInt4 - paramInt2;
/*  982 */     int k = paramInt9 - paramInt7;
/*  983 */     int l = paramInt10 - paramInt8;
/*      */ 
/*  985 */     if (!(this.smooth)) {
/*  986 */       ++i; ++j;
/*      */     }
/*      */ 
/*  989 */     if ((k <= 0) || (l <= 0) || (i <= 0) || (j <= 0) || (paramInt7 >= paramInt5) || (paramInt8 >= paramInt6) || (paramInt1 >= paramPImage.width) || (paramInt2 >= paramPImage.height))
/*      */     {
/*  993 */       return;
/*      */     }
/*      */ 
/*  996 */     int i1 = (int)(i / k * 32768.0F);
/*  997 */     int i2 = (int)(j / l * 32768.0F);
/*      */ 
/*  999 */     this.srcXOffset = ((paramInt7 < 0) ? -paramInt7 * i1 : paramInt1 * 32768);
/* 1000 */     this.srcYOffset = ((paramInt8 < 0) ? -paramInt8 * i2 : paramInt2 * 32768);
/*      */ 
/* 1002 */     if (paramInt7 < 0) {
/* 1003 */       k += paramInt7;
/* 1004 */       paramInt7 = 0;
/*      */     }
/* 1006 */     if (paramInt8 < 0) {
/* 1007 */       l += paramInt8;
/* 1008 */       paramInt8 = 0;
/*      */     }
/*      */ 
/* 1011 */     k = low(k, paramInt5 - paramInt7);
/* 1012 */     l = low(l, paramInt6 - paramInt8);
/*      */ 
/* 1014 */     int i3 = paramInt8 * paramInt5 + paramInt7;
/* 1015 */     this.srcBuffer = paramPImage.pixels;
/*      */ 
/* 1017 */     if (this.smooth)
/*      */     {
/* 1019 */       this.iw = paramPImage.width;
/* 1020 */       this.iw1 = (paramPImage.width - 1);
/* 1021 */       this.ih1 = (paramPImage.height - 1);
/*      */ 
/* 1023 */       switch (paramInt11)
/*      */       {
/*      */       case 1:
/* 1026 */         for (int i4 = 0; i4 < l; ++i4) {
/* 1027 */           filter_new_scanline();
/* 1028 */           for (int i16 = 0; i16 < k; ++i16) {
/* 1029 */             paramArrayOfInt[(i3 + i16)] = blend_multiply(paramArrayOfInt[(i3 + i16)], filter_bilinear());
/*      */ 
/* 1031 */             this.sX += i1;
/*      */           }
/* 1033 */           i3 += paramInt5;
/* 1034 */           this.srcYOffset += i2;
/*      */         }
/* 1036 */         break;
/*      */       case 2:
/* 1039 */         for (int i5 = 0; i5 < l; ++i5) {
/* 1040 */           filter_new_scanline();
/* 1041 */           for (int i17 = 0; i17 < k; ++i17) {
/* 1042 */             paramArrayOfInt[(i3 + i17)] = blend_add_pin(paramArrayOfInt[(i3 + i17)], filter_bilinear());
/*      */ 
/* 1044 */             this.sX += i1;
/*      */           }
/* 1046 */           i3 += paramInt5;
/* 1047 */           this.srcYOffset += i2;
/*      */         }
/* 1049 */         break;
/*      */       case 4:
/* 1052 */         for (int i6 = 0; i6 < l; ++i6) {
/* 1053 */           filter_new_scanline();
/* 1054 */           for (int i18 = 0; i18 < k; ++i18) {
/* 1055 */             paramArrayOfInt[(i3 + i18)] = blend_sub_pin(paramArrayOfInt[(i3 + i18)], filter_bilinear());
/*      */ 
/* 1057 */             this.sX += i1;
/*      */           }
/* 1059 */           i3 += paramInt5;
/* 1060 */           this.srcYOffset += i2;
/*      */         }
/* 1062 */         break;
/*      */       case 8:
/* 1065 */         for (int i7 = 0; i7 < l; ++i7) {
/* 1066 */           filter_new_scanline();
/* 1067 */           for (int i19 = 0; i19 < k; ++i19) {
/* 1068 */             paramArrayOfInt[(i3 + i19)] = blend_lightest(paramArrayOfInt[(i3 + i19)], filter_bilinear());
/*      */ 
/* 1070 */             this.sX += i1;
/*      */           }
/* 1072 */           i3 += paramInt5;
/* 1073 */           this.srcYOffset += i2;
/*      */         }
/* 1075 */         break;
/*      */       case 16:
/* 1078 */         for (int i8 = 0; i8 < l; ++i8) {
/* 1079 */           filter_new_scanline();
/* 1080 */           for (int i20 = 0; i20 < k; ++i20) {
/* 1081 */             paramArrayOfInt[(i3 + i20)] = blend_darkest(paramArrayOfInt[(i3 + i20)], filter_bilinear());
/*      */ 
/* 1083 */             this.sX += i1;
/*      */           }
/* 1085 */           i3 += paramInt5;
/* 1086 */           this.srcYOffset += i2;
/*      */         }
/* 1088 */         break;
/*      */       case 0:
/* 1091 */         for (int i9 = 0; i9 < l; ++i9) {
/* 1092 */           filter_new_scanline();
/* 1093 */           for (int i21 = 0; i21 < k; ++i21) {
/* 1094 */             paramArrayOfInt[(i3 + i21)] = filter_bilinear();
/* 1095 */             this.sX += i1;
/*      */           }
/* 1097 */           i3 += paramInt5;
/* 1098 */           this.srcYOffset += i2; } case 3:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 9:
/*      */       case 10:
/*      */       case 11:
/*      */       case 12:
/*      */       case 13:
/*      */       case 14:
/*      */       case 15: }  } else { switch (paramInt11)
/*      */       {
/*      */       case 1:
/* 1108 */         for (int i10 = 0; i10 < l; ++i10) {
/* 1109 */           this.sX = this.srcXOffset;
/* 1110 */           this.sY = ((this.srcYOffset >> 15) * paramPImage.width);
/* 1111 */           for (int i22 = 0; i22 < k; ++i22) {
/* 1112 */             paramArrayOfInt[(i3 + i22)] = blend_multiply(paramArrayOfInt[(i3 + i22)], this.srcBuffer[(this.sY + (this.sX >> 15))]);
/*      */ 
/* 1115 */             this.sX += i1;
/*      */           }
/* 1117 */           i3 += paramInt5;
/* 1118 */           this.srcYOffset += i2;
/*      */         }
/* 1120 */         break;
/*      */       case 2:
/* 1123 */         for (int i11 = 0; i11 < l; ++i11) {
/* 1124 */           this.sX = this.srcXOffset;
/* 1125 */           this.sY = ((this.srcYOffset >> 15) * paramPImage.width);
/* 1126 */           for (int i23 = 0; i23 < k; ++i23) {
/* 1127 */             paramArrayOfInt[(i3 + i23)] = blend_add_pin(paramArrayOfInt[(i3 + i23)], this.srcBuffer[(this.sY + (this.sX >> 15))]);
/*      */ 
/* 1130 */             this.sX += i1;
/*      */           }
/* 1132 */           i3 += paramInt5;
/* 1133 */           this.srcYOffset += i2;
/*      */         }
/* 1135 */         break;
/*      */       case 4:
/* 1138 */         for (int i12 = 0; i12 < l; ++i12) {
/* 1139 */           this.sX = this.srcXOffset;
/* 1140 */           this.sY = ((this.srcYOffset >> 15) * paramPImage.width);
/* 1141 */           for (int i24 = 0; i24 < k; ++i24) {
/* 1142 */             paramArrayOfInt[(i3 + i24)] = blend_sub_pin(paramArrayOfInt[(i3 + i24)], this.srcBuffer[(this.sY + (this.sX >> 15))]);
/*      */ 
/* 1145 */             this.sX += i1;
/*      */           }
/* 1147 */           i3 += paramInt5;
/* 1148 */           this.srcYOffset += i2;
/*      */         }
/* 1150 */         break;
/*      */       case 8:
/* 1153 */         for (int i13 = 0; i13 < l; ++i13) {
/* 1154 */           this.sX = this.srcXOffset;
/* 1155 */           this.sY = ((this.srcYOffset >> 15) * paramPImage.width);
/* 1156 */           for (int i25 = 0; i25 < k; ++i25) {
/* 1157 */             paramArrayOfInt[(i3 + i25)] = blend_lightest(paramArrayOfInt[(i3 + i25)], this.srcBuffer[(this.sY + (this.sX >> 15))]);
/*      */ 
/* 1160 */             this.sX += i1;
/*      */           }
/* 1162 */           i3 += paramInt5;
/* 1163 */           this.srcYOffset += i2;
/*      */         }
/* 1165 */         break;
/*      */       case 16:
/* 1168 */         for (int i14 = 0; i14 < l; ++i14) {
/* 1169 */           this.sX = this.srcXOffset;
/* 1170 */           this.sY = ((this.srcYOffset >> 15) * paramPImage.width);
/* 1171 */           for (int i26 = 0; i26 < k; ++i26) {
/* 1172 */             paramArrayOfInt[(i3 + i26)] = blend_darkest(paramArrayOfInt[(i3 + i26)], this.srcBuffer[(this.sY + (this.sX >> 15))]);
/*      */ 
/* 1175 */             this.sX += i1;
/*      */           }
/* 1177 */           i3 += paramInt5;
/* 1178 */           this.srcYOffset += i2;
/*      */         }
/* 1180 */         break;
/*      */       case 0:
/* 1183 */         for (int i15 = 0; i15 < l; ++i15) {
/* 1184 */           this.sX = this.srcXOffset;
/* 1185 */           this.sY = ((this.srcYOffset >> 15) * paramPImage.width);
/* 1186 */           for (int i27 = 0; i27 < k; ++i27) {
/* 1187 */             paramArrayOfInt[(i3 + i27)] = this.srcBuffer[(this.sY + (this.sX >> 15))];
/* 1188 */             this.sX += i1;
/*      */           }
/* 1190 */           i3 += paramInt5;
/* 1191 */           this.srcYOffset += i2; } case 3:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 9:
/*      */       case 10:
/*      */       case 11:
/*      */       case 12:
/*      */       case 13:
/*      */       case 14:
/*      */       case 15: }  }  } 
/*      */   private final void filter_new_scanline() { this.sX = this.srcXOffset;
/* 1201 */     this.fracV = (this.srcYOffset & 0x7FFF);
/* 1202 */     this.ifV = (32767 - this.fracV);
/* 1203 */     this.v1 = ((this.srcYOffset >> 15) * this.iw);
/* 1204 */     this.v2 = (low((this.srcYOffset >> 15) + 1, this.ih1) * this.iw);
/*      */   }
/*      */ 
/*      */   private final int filter_bilinear()
/*      */   {
/* 1209 */     this.fracU = (this.sX & 0x7FFF);
/* 1210 */     this.ifU = (32767 - this.fracU);
/* 1211 */     this.ul = (this.ifU * this.ifV >> 15);
/* 1212 */     this.ll = (this.ifU * this.fracV >> 15);
/* 1213 */     this.ur = (this.fracU * this.ifV >> 15);
/* 1214 */     this.lr = (this.fracU * this.fracV >> 15);
/* 1215 */     this.u1 = (this.sX >> 15);
/* 1216 */     this.u2 = low(this.u1 + 1, this.iw1);
/*      */ 
/* 1219 */     this.cUL = this.srcBuffer[(this.v1 + this.u1)];
/* 1220 */     this.cUR = this.srcBuffer[(this.v1 + this.u2)];
/* 1221 */     this.cLL = this.srcBuffer[(this.v2 + this.u1)];
/* 1222 */     this.cLR = this.srcBuffer[(this.v2 + this.u2)];
/*      */ 
/* 1224 */     this.r = (this.ul * ((this.cUL & 0xFF0000) >> 16) + this.ll * ((this.cLL & 0xFF0000) >> 16) + this.ur * ((this.cUR & 0xFF0000) >> 16) + this.lr * ((this.cLR & 0xFF0000) >> 16) << 1 & 0xFF0000);
/*      */ 
/* 1228 */     this.g = (this.ul * (this.cUL & 0xFF00) + this.ll * (this.cLL & 0xFF00) + this.ur * (this.cUR & 0xFF00) + this.lr * (this.cLR & 0xFF00) >>> 15 & 0xFF00);
/*      */ 
/* 1232 */     this.b = (this.ul * (this.cUL & 0xFF) + this.ll * (this.cLL & 0xFF) + this.ur * (this.cUR & 0xFF) + this.lr * (this.cLR & 0xFF) >>> 15);
/*      */ 
/* 1236 */     this.a = (this.ul * ((this.cUL & 0xFF000000) >>> 24) + this.ll * ((this.cLL & 0xFF000000) >>> 24) + this.ur * ((this.cUR & 0xFF000000) >>> 24) + this.lr * ((this.cLR & 0xFF000000) >>> 24) << 9 & 0xFF000000);
/*      */ 
/* 1240 */     return (this.a | this.r | this.g | this.b);
/*      */   }
/*      */ 
/*      */   private static final int low(int paramInt1, int paramInt2)
/*      */   {
/* 1251 */     return ((paramInt1 < paramInt2) ? paramInt1 : paramInt2);
/*      */   }
/*      */ 
/*      */   private static final int high(int paramInt1, int paramInt2)
/*      */   {
/* 1256 */     return ((paramInt1 > paramInt2) ? paramInt1 : paramInt2);
/*      */   }
/*      */ 
/*      */   private static final float frac(float paramFloat)
/*      */   {
/* 1261 */     return (paramFloat - (int)paramFloat);
/*      */   }
/*      */ 
/*      */   private static final int mix(int paramInt1, int paramInt2, int paramInt3)
/*      */   {
/* 1269 */     return (paramInt1 + ((paramInt2 - paramInt1) * paramInt3 >> 8));
/*      */   }
/*      */ 
/*      */   private static final int blend_multiply(int paramInt1, int paramInt2)
/*      */   {
/* 1279 */     int i = (paramInt2 & 0xFF000000) >>> 24;
/*      */ 
/* 1281 */     return (low(((paramInt1 & 0xFF000000) >>> 24) + i, 255) << 24 | mix(paramInt1 & 0xFF0000, paramInt2 & 0xFF0000, i) & 0xFF0000 | mix(paramInt1 & 0xFF00, paramInt2 & 0xFF00, i) & 0xFF00 | mix(paramInt1 & 0xFF, paramInt2 & 0xFF, i));
/*      */   }
/*      */ 
/*      */   private static final int blend_add_pin(int paramInt1, int paramInt2)
/*      */   {
/* 1292 */     int i = (paramInt2 & 0xFF000000) >>> 24;
/*      */ 
/* 1294 */     return (low(((paramInt1 & 0xFF000000) >>> 24) + i, 255) << 24 | low((paramInt1 & 0xFF0000) + ((paramInt2 & 0xFF0000) >> 8) * i, 16711680) & 0xFF0000 | low((paramInt1 & 0xFF00) + ((paramInt2 & 0xFF00) >> 8) * i, 65280) & 0xFF00 | low((paramInt1 & 0xFF) + ((paramInt2 & 0xFF) * i >> 8), 255));
/*      */   }
/*      */ 
/*      */   private static final int blend_sub_pin(int paramInt1, int paramInt2)
/*      */   {
/* 1308 */     int i = (paramInt2 & 0xFF000000) >>> 24;
/*      */ 
/* 1310 */     return (low(((paramInt1 & 0xFF000000) >>> 24) + i, 255) << 24 | high((paramInt1 & 0xFF0000) - (((paramInt2 & 0xFF0000) >> 8) * i), 65280) & 0xFF0000 | high((paramInt1 & 0xFF00) - (((paramInt2 & 0xFF00) >> 8) * i), 255) & 0xFF00 | high((paramInt1 & 0xFF) - ((paramInt2 & 0xFF) * i >> 8), 0));
/*      */   }
/*      */ 
/*      */   private static final int blend_lightest(int paramInt1, int paramInt2)
/*      */   {
/* 1323 */     int i = (paramInt2 & 0xFF000000) >>> 24;
/*      */ 
/* 1325 */     return (low(((paramInt1 & 0xFF000000) >>> 24) + i, 255) << 24 | high(paramInt1 & 0xFF0000, ((paramInt2 & 0xFF0000) >> 8) * i) & 0xFF0000 | high(paramInt1 & 0xFF00, ((paramInt2 & 0xFF00) >> 8) * i) & 0xFF00 | high(paramInt1 & 0xFF, (paramInt2 & 0xFF) * i >> 8));
/*      */   }
/*      */ 
/*      */   private static final int blend_darkest(int paramInt1, int paramInt2)
/*      */   {
/* 1336 */     int i = (paramInt2 & 0xFF000000) >>> 24;
/*      */ 
/* 1338 */     return (low(((paramInt1 & 0xFF000000) >>> 24) + i, 255) << 24 | mix(paramInt1 & 0xFF0000, low(paramInt1 & 0xFF0000, ((paramInt2 & 0xFF0000) >> 8) * i), i) & 0xFF0000 | mix(paramInt1 & 0xFF00, low(paramInt1 & 0xFF00, ((paramInt2 & 0xFF00) >> 8) * i), i) & 0xFF00 | mix(paramInt1 & 0xFF, low(paramInt1 & 0xFF, (paramInt2 & 0xFF) * i >> 8), i));
/*      */   }
/*      */ 
/*      */   public static boolean saveHeaderTIFF(OutputStream paramOutputStream, int paramInt1, int paramInt2)
/*      */   {
/*      */     try
/*      */     {
/* 1370 */       byte[] arrayOfByte = new byte[768];
/* 1371 */       System.arraycopy(tiff_header, 0, arrayOfByte, 0, tiff_header.length);
/*      */ 
/* 1373 */       arrayOfByte[30] = (byte)(paramInt1 >> 8 & 0xFF);
/* 1374 */       arrayOfByte[31] = (byte)(paramInt1 & 0xFF);
/* 1375 */       arrayOfByte[42] = (arrayOfByte[102] = (byte)(paramInt2 >> 8 & 0xFF));
/* 1376 */       arrayOfByte[43] = (arrayOfByte[103] = (byte)(paramInt2 & 0xFF));
/*      */ 
/* 1378 */       int i = paramInt1 * paramInt2 * 3;
/* 1379 */       arrayOfByte[114] = (byte)(i >> 24 & 0xFF);
/* 1380 */       arrayOfByte[115] = (byte)(i >> 16 & 0xFF);
/* 1381 */       arrayOfByte[116] = (byte)(i >> 8 & 0xFF);
/* 1382 */       arrayOfByte[117] = (byte)(i & 0xFF);
/*      */ 
/* 1384 */       paramOutputStream.write(arrayOfByte);
/* 1385 */       return true;
/*      */     }
/*      */     catch (IOException localIOException) {
/* 1388 */       localIOException.printStackTrace();
/*      */     }
/* 1390 */     return false;
/*      */   }
/*      */ 
/*      */   public static boolean saveTIFF(OutputStream paramOutputStream, int[] paramArrayOfInt, int paramInt1, int paramInt2)
/*      */   {
/*      */     try
/*      */     {
/* 1397 */       if (!(saveHeaderTIFF(paramOutputStream, paramInt1, paramInt2))) {
/* 1398 */         return false;
/*      */       }
/* 1400 */       for (int i = 0; i < paramArrayOfInt.length; ++i) {
/* 1401 */         paramOutputStream.write(paramArrayOfInt[i] >> 16 & 0xFF);
/* 1402 */         paramOutputStream.write(paramArrayOfInt[i] >> 8 & 0xFF);
/* 1403 */         paramOutputStream.write(paramArrayOfInt[i] & 0xFF);
/*      */       }
/* 1405 */       paramOutputStream.flush();
/* 1406 */       return true;
/*      */     }
/*      */     catch (IOException localIOException) {
/* 1409 */       localIOException.printStackTrace();
/*      */     }
/* 1411 */     return false;
/*      */   }
/*      */ 
/*      */   public static boolean saveHeaderTGA(OutputStream paramOutputStream, int paramInt1, int paramInt2)
/*      */   {
/*      */     try
/*      */     {
/* 1428 */       byte[] arrayOfByte = new byte[18];
/*      */ 
/* 1431 */       arrayOfByte[2] = 2;
/* 1432 */       arrayOfByte[12] = (byte)(paramInt1 & 0xFF);
/* 1433 */       arrayOfByte[13] = (byte)(paramInt1 >> 8);
/* 1434 */       arrayOfByte[14] = (byte)(paramInt2 & 0xFF);
/* 1435 */       arrayOfByte[15] = (byte)(paramInt2 >> 8);
/* 1436 */       arrayOfByte[16] = 32;
/* 1437 */       arrayOfByte[17] = 8;
/*      */ 
/* 1439 */       paramOutputStream.write(arrayOfByte);
/* 1440 */       return true;
/*      */     }
/*      */     catch (IOException localIOException) {
/* 1443 */       localIOException.printStackTrace();
/*      */     }
/* 1445 */     return false;
/*      */   }
/*      */ 
/*      */   public static boolean saveTGA(OutputStream paramOutputStream, int[] paramArrayOfInt, int paramInt1, int paramInt2)
/*      */   {
/*      */     try
/*      */     {
/* 1452 */       if (!(saveHeaderTGA(paramOutputStream, paramInt1, paramInt2))) {
/* 1453 */         return false;
/*      */       }
/*      */ 
/* 1456 */       int i = (paramInt2 - 1) * paramInt1;
/*      */ 
/* 1458 */       for (int j = paramInt2 - 1; j >= 0; --j) {
/* 1459 */         for (int k = 0; k < paramInt1; ++k) {
/* 1460 */           int l = paramArrayOfInt[(i + k)];
/* 1461 */           paramOutputStream.write(l & 0xFF);
/* 1462 */           paramOutputStream.write(l >> 8 & 0xFF);
/* 1463 */           paramOutputStream.write(l >> 16 & 0xFF);
/* 1464 */           paramOutputStream.write(l >>> 24 & 0xFF);
/*      */         }
/* 1466 */         i -= paramInt1;
/*      */       }
/* 1468 */       paramOutputStream.flush();
/* 1469 */       return true;
/*      */     }
/*      */     catch (IOException localIOException) {
/* 1472 */       localIOException.printStackTrace();
/*      */     }
/* 1474 */     return false;
/*      */   }
/*      */ 
/*      */   public void save(String paramString)
/*      */   {
/*      */     try {
/* 1480 */       BufferedOutputStream localBufferedOutputStream = null;
/*      */ 
/* 1482 */       if (paramString.toLowerCase().endsWith(".tga")) {
/* 1483 */         localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(paramString), 32768);
/* 1484 */         saveTGA(localBufferedOutputStream, this.pixels, this.width, this.height);
/*      */       }
/*      */       else {
/* 1487 */         if ((!(paramString.toLowerCase().endsWith(".tif"))) && (!(paramString.toLowerCase().endsWith(".tiff"))))
/*      */         {
/* 1490 */           paramString = paramString + ".tif";
/*      */         }
/* 1492 */         localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(paramString), 32768);
/* 1493 */         saveTIFF(localBufferedOutputStream, this.pixels, this.width, this.height);
/*      */       }
/* 1495 */       localBufferedOutputStream.flush();
/* 1496 */       localBufferedOutputStream.close();
/*      */     }
/*      */     catch (IOException localIOException) {
/* 1499 */       localIOException.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void jdMethod_this()
/*      */   {
/*   56 */     this.imageMode = 0;
/*   57 */     this.smooth = false;
/*      */   }
/*      */ 
/*      */   public PImage()
/*      */   {
/*   97 */     jdMethod_this();
/*   98 */     this.format = 1;
/*   99 */     this.cache = null;
/*      */   }
/*      */ 
/*      */   public PImage(int paramInt1, int paramInt2)
/*      */   {
/*  108 */     jdMethod_this();
/*  109 */     init(paramInt1, paramInt2, 1);
/*      */   }
/*      */ 
/*      */   public PImage(int[] paramArrayOfInt, int paramInt1, int paramInt2, int paramInt3)
/*      */   {
/*  122 */     jdMethod_this();
/*  123 */     this.pixels = paramArrayOfInt;
/*  124 */     this.width = paramInt1;
/*  125 */     this.height = paramInt2;
/*  126 */     this.format = paramInt3;
/*  127 */     this.cache = null;
/*      */   }
/*      */ 
/*      */   public PImage(Image paramImage)
/*      */   {
/*  150 */     jdMethod_this();
/*  151 */     this.width = paramImage.getWidth(null);
/*  152 */     this.height = paramImage.getHeight(null);
/*      */ 
/*  154 */     this.pixels = new int[this.width * this.height];
/*  155 */     PixelGrabber localPixelGrabber = new PixelGrabber(paramImage, 0, 0, this.width, this.height, this.pixels, 0, this.width);
/*      */     try
/*      */     {
/*  158 */       localPixelGrabber.grabPixels();
/*      */     } catch (InterruptedException localInterruptedException) {
/*      */     }
/*  161 */     this.format = 1;
/*  162 */     this.cache = null;
/*      */   }
/*      */ }

/* Location:           /Users/mfeyereisen/Desktop/Sources 2/common/
 * Qualified Name:     processing.core.PImage
 * JD-Core Version:    0.5.3
 */