/*      */ package processing.core;
/*      */ 
/*      */ import java.applet.Applet;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Container;
/*      */ import java.awt.Cursor;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.FileDialog;
/*      */ import java.awt.Font;
/*      */ import java.awt.Frame;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.GraphicsDevice;
/*      */ import java.awt.GraphicsEnvironment;
/*      */ import java.awt.Image;
/*      */ import java.awt.Insets;
/*      */ import java.awt.Label;
/*      */ import java.awt.MediaTracker;
/*      */ import java.awt.Point;
/*      */ import java.awt.SystemColor;
/*      */ import java.awt.Toolkit;
/*      */ import java.awt.Window;
/*      */ import java.awt.event.ComponentAdapter;
/*      */ import java.awt.event.ComponentEvent;
/*      */ import java.awt.event.FocusEvent;
/*      */ import java.awt.event.FocusListener;
/*      */ import java.awt.event.KeyEvent;
/*      */ import java.awt.event.KeyListener;
/*      */ import java.awt.event.MouseAdapter;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.awt.event.MouseListener;
/*      */ import java.awt.event.MouseMotionListener;
/*      */ import java.awt.event.WindowAdapter;
/*      */ import java.awt.event.WindowEvent;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.OutputStream;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.io.PrintStream;
/*      */ import java.io.PrintWriter;
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.text.NumberFormat;
/*      */ import java.util.Calendar;
/*      */ import java.util.Random;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.zip.GZIPInputStream;
/*      */ import java.util.zip.GZIPOutputStream;
/*      */ 
/*      */ public class PApplet extends Applet
/*      */   implements PConstants, Runnable, MouseListener, MouseMotionListener, KeyListener, FocusListener
/*      */ {
/*   49 */   public static final String javaVersionName = System.getProperty("java.version").substring(0, 3);
/*      */ 
/*   63 */   public static final float javaVersion = new Float(javaVersionName).floatValue();
/*      */   public static int platform;
/*   77 */   public static String platformName = System.getProperty("os.name");
/*      */   static final String NEW_RENDERER = "new renderer";
/*      */   static final boolean THREAD_DEBUG = 0;
/*      */   public static final int DEFAULT_WIDTH = 100;
/*      */   public static final int DEFAULT_HEIGHT = 100;
/*      */   public static final String LEECH_WAKEUP = "Error while running applet.";
/*      */   public static final String ARGS_EDITOR_LOCATION = "--editor-location";
/*      */   public static final String ARGS_EXTERNAL = "--external";
/*      */   public static final String ARGS_LOCATION = "--location";
/*      */   public static final String ARGS_DISPLAY = "--display";
/*      */   public static final String ARGS_PRESENT = "--present";
/*      */   public static final String ARGS_BGCOLOR = "--bgcolor";
/*      */   public static final String ARGS_PRESENT_STOP_COLOR = "--present-stop-color";
/*      */   public static final String ARGS_SKETCH_FOLDER = "--sketch-folder";
/*      */   public static final char EXTERNAL_STOP = 115;
/*      */   public static final String EXTERNAL_QUIT = "__QUIT__";
/*      */   public static final String EXTERNAL_MOVE = "__MOVE__";
/*      */   static final int PERLIN_YWRAPB = 4;
/*      */   static final int PERLIN_YWRAP = 16;
/*      */   static final int PERLIN_ZWRAPB = 8;
/*      */   static final int PERLIN_ZWRAP = 256;
/*      */   static final int PERLIN_SIZE = 4095;
/*      */   static final int BYTES = 1;
/*      */   static final int CHARS = 2;
/*      */   static final int INTS = 3;
/*      */   static final int FLOATS = 4;
/*      */   static final int STRINGS = 5;
/*      */   private static NumberFormat int_nf;
/*      */   private static int int_nf_digits;
/*      */   private static boolean int_nf_commas;
/*      */   private static NumberFormat float_nf;
/*      */   private static int float_nf_left;
/*      */   private static int float_nf_right;
/*      */   private static boolean float_nf_commas;
/*      */   public PGraphics g;
/*      */   protected Object glock;
/*      */   public Frame frame;
/*      */   public Dimension screen;
/*      */   public PGraphics recorder;
/*      */   public String[] args;
/*      */   public String folder;
/*      */   public int[] pixels;
/*      */   public int width;
/*      */   public int height;
/*      */   public int mouseX;
/*      */   public int mouseY;
/*      */   public int pmouseX;
/*      */   public int pmouseY;
/*      */   protected int dmouseX;
/*      */   protected int dmouseY;
/*      */   protected int emouseX;
/*      */   protected int emouseY;
/*      */   public boolean firstMouse;
/*      */   public int mouseButton;
/*      */   public boolean mousePressed;
/*      */   public MouseEvent mouseEvent;
/*      */   public char key;
/*      */   public int keyCode;
/*      */   public boolean keyPressed;
/*      */   public KeyEvent keyEvent;
/*      */   public boolean focused;
/*      */   public boolean online;
/*      */   long millisOffset;
/*      */   public float framerate;
/*      */   protected long framerateLastMillis;
/*      */   protected long framerateLastDelayTime;
/*      */   protected float framerateTarget;
/*      */   protected boolean looping;
/*      */   protected boolean redraw;
/*      */   public int frameCount;
/*      */   public boolean finished;
/*      */   Thread thread;
/*      */   public Exception exception;
/*      */   protected RegisteredMethods sizeMethods;
/*      */   protected RegisteredMethods preMethods;
/*      */   protected RegisteredMethods drawMethods;
/*      */   protected RegisteredMethods postMethods;
/*      */   protected RegisteredMethods mouseEventMethods;
/*      */   protected RegisteredMethods keyEventMethods;
/*      */   protected RegisteredMethods disposeMethods;
/*      */   public PrintStream leechErr;
/*      */   protected boolean listenersAdded;
/*      */   MouseEvent[] mouseEventQueue;
/*      */   int mouseEventCount;
/*      */   KeyEvent[] keyEventQueue;
/*      */   int keyEventCount;
/*      */   int cursor_type;
/*      */   boolean cursor_visible;
/*      */   PImage invisible_cursor;
/*      */   Random internalRandom;
/*      */   int perlin_octaves;
/*      */   float perlin_amp_falloff;
/*      */   int perlin_TWOPI;
/*      */   int perlin_PI;
/*      */   float[] perlin_cosTable;
/*      */   float[] perlin;
/*      */   Random perlinRandom;
/*      */   int sort_mode;
/*      */   byte[] sort_bytes;
/*      */   char[] sort_chars;
/*      */   int[] sort_ints;
/*      */   float[] sort_floats;
/*      */   String[] sort_strings;
/*      */   static Class class$java$awt$Component;
/*      */   static Class class$java$awt$event$MouseEvent;
/*      */   static Class class$java$awt$event$KeyEvent;
/*      */   static Class class$processing$core$PApplet;
/*      */   static Class class$java$lang$String;
/*      */   static Class class$java$awt$Image;
/*      */   static Class class$java$awt$Point;
/*      */   static Class class$java$awt$Toolkit;
/*      */   static Class class$java$awt$Font;
/*      */   static Class class$java$io$InputStream;
/*      */ 
/*      */   // ERROR //
/*      */   public void init()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 203	processing/core/PApplet:javaVersion	F
/*      */     //   3: ldc 204
/*      */     //   5: fcmpl
/*      */     //   6: iflt +53 -> 59
/*      */     //   9: getstatic 206	processing/core/PApplet:class$java$awt$Component	Ljava/lang/Class;
/*      */     //   12: dup
/*      */     //   13: ifnonnull +14 -> 27
/*      */     //   16: pop
/*      */     //   17: ldc 208
/*      */     //   19: iconst_0
/*      */     //   20: invokestatic 212	processing/core/PApplet:class	(Ljava/lang/String;Z)Ljava/lang/Class;
/*      */     //   23: dup
/*      */     //   24: putstatic 206	processing/core/PApplet:class$java$awt$Component	Ljava/lang/Class;
/*      */     //   27: ldc 214
/*      */     //   29: iconst_1
/*      */     //   30: anewarray 216	java/lang/Class
/*      */     //   33: dup
/*      */     //   34: iconst_0
/*      */     //   35: getstatic 221	java/lang/Boolean:TYPE	Ljava/lang/Class;
/*      */     //   38: aastore
/*      */     //   39: invokevirtual 225	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*      */     //   42: astore_1
/*      */     //   43: aload_1
/*      */     //   44: aload_0
/*      */     //   45: iconst_1
/*      */     //   46: anewarray 227	java/lang/Object
/*      */     //   49: dup
/*      */     //   50: iconst_0
/*      */     //   51: getstatic 231	java/lang/Boolean:FALSE	Ljava/lang/Boolean;
/*      */     //   54: aastore
/*      */     //   55: invokevirtual 237	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   58: pop
/*      */     //   59: goto +4 -> 63
/*      */     //   62: pop
/*      */     //   63: aload_0
/*      */     //   64: invokestatic 245	java/lang/System:currentTimeMillis	()J
/*      */     //   67: putfield 247	processing/core/PApplet:millisOffset	J
/*      */     //   70: aload_0
/*      */     //   71: iconst_0
/*      */     //   72: putfield 249	processing/core/PApplet:finished	Z
/*      */     //   75: aload_0
/*      */     //   76: iconst_1
/*      */     //   77: putfield 251	processing/core/PApplet:looping	Z
/*      */     //   80: aload_0
/*      */     //   81: iconst_1
/*      */     //   82: putfield 253	processing/core/PApplet:redraw	Z
/*      */     //   85: aload_0
/*      */     //   86: iconst_1
/*      */     //   87: putfield 255	processing/core/PApplet:firstMouse	Z
/*      */     //   90: aload_0
/*      */     //   91: new 257	processing/core/PApplet$RegisteredMethods
/*      */     //   94: dup
/*      */     //   95: aload_0
/*      */     //   96: invokespecial 263	processing/core/PApplet$RegisteredMethods:<init>	(Lprocessing/core/PApplet;)V
/*      */     //   99: putfield 265	processing/core/PApplet:sizeMethods	Lprocessing/core/PApplet$RegisteredMethods;
/*      */     //   102: aload_0
/*      */     //   103: new 257	processing/core/PApplet$RegisteredMethods
/*      */     //   106: dup
/*      */     //   107: aload_0
/*      */     //   108: invokespecial 263	processing/core/PApplet$RegisteredMethods:<init>	(Lprocessing/core/PApplet;)V
/*      */     //   111: putfield 267	processing/core/PApplet:preMethods	Lprocessing/core/PApplet$RegisteredMethods;
/*      */     //   114: aload_0
/*      */     //   115: new 257	processing/core/PApplet$RegisteredMethods
/*      */     //   118: dup
/*      */     //   119: aload_0
/*      */     //   120: invokespecial 263	processing/core/PApplet$RegisteredMethods:<init>	(Lprocessing/core/PApplet;)V
/*      */     //   123: putfield 269	processing/core/PApplet:drawMethods	Lprocessing/core/PApplet$RegisteredMethods;
/*      */     //   126: aload_0
/*      */     //   127: new 257	processing/core/PApplet$RegisteredMethods
/*      */     //   130: dup
/*      */     //   131: aload_0
/*      */     //   132: invokespecial 263	processing/core/PApplet$RegisteredMethods:<init>	(Lprocessing/core/PApplet;)V
/*      */     //   135: putfield 271	processing/core/PApplet:postMethods	Lprocessing/core/PApplet$RegisteredMethods;
/*      */     //   138: aload_0
/*      */     //   139: new 257	processing/core/PApplet$RegisteredMethods
/*      */     //   142: dup
/*      */     //   143: aload_0
/*      */     //   144: invokespecial 263	processing/core/PApplet$RegisteredMethods:<init>	(Lprocessing/core/PApplet;)V
/*      */     //   147: putfield 273	processing/core/PApplet:mouseEventMethods	Lprocessing/core/PApplet$RegisteredMethods;
/*      */     //   150: aload_0
/*      */     //   151: new 257	processing/core/PApplet$RegisteredMethods
/*      */     //   154: dup
/*      */     //   155: aload_0
/*      */     //   156: invokespecial 263	processing/core/PApplet$RegisteredMethods:<init>	(Lprocessing/core/PApplet;)V
/*      */     //   159: putfield 275	processing/core/PApplet:keyEventMethods	Lprocessing/core/PApplet$RegisteredMethods;
/*      */     //   162: aload_0
/*      */     //   163: new 257	processing/core/PApplet$RegisteredMethods
/*      */     //   166: dup
/*      */     //   167: aload_0
/*      */     //   168: invokespecial 263	processing/core/PApplet$RegisteredMethods:<init>	(Lprocessing/core/PApplet;)V
/*      */     //   171: putfield 277	processing/core/PApplet:disposeMethods	Lprocessing/core/PApplet$RegisteredMethods;
/*      */     //   174: aload_0
/*      */     //   175: invokevirtual 281	processing/core/PApplet:getAppletContext	()Ljava/applet/AppletContext;
/*      */     //   178: pop
/*      */     //   179: aload_0
/*      */     //   180: iconst_1
/*      */     //   181: putfield 283	processing/core/PApplet:online	Z
/*      */     //   184: goto +9 -> 193
/*      */     //   187: astore_1
/*      */     //   188: aload_0
/*      */     //   189: iconst_0
/*      */     //   190: putfield 283	processing/core/PApplet:online	Z
/*      */     //   193: getstatic 203	processing/core/PApplet:javaVersion	F
/*      */     //   196: ldc_w 286
/*      */     //   199: fcmpg
/*      */     //   200: ifge +16 -> 216
/*      */     //   203: aload_0
/*      */     //   204: new 288	processing/core/PApplet$1
/*      */     //   207: dup
/*      */     //   208: aload_0
/*      */     //   209: invokespecial 289	processing/core/PApplet$1:<init>	(Lprocessing/core/PApplet;)V
/*      */     //   212: invokevirtual 293	processing/core/PApplet:addMouseListener	(Ljava/awt/event/MouseListener;)V
/*      */     //   215: return
/*      */     //   216: aload_0
/*      */     //   217: bipush 100
/*      */     //   219: bipush 100
/*      */     //   221: invokevirtual 297	processing/core/PApplet:size	(II)V
/*      */     //   224: aload_0
/*      */     //   225: iconst_0
/*      */     //   226: putfield 299	processing/core/PApplet:width	I
/*      */     //   229: aload_0
/*      */     //   230: iconst_0
/*      */     //   231: putfield 301	processing/core/PApplet:height	I
/*      */     //   234: aload_0
/*      */     //   235: invokevirtual 304	processing/core/PApplet:start	()V
/*      */     //   238: return
/*      */     //
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   0	59	62	java/lang/Exception
/*      */     //   174	184	187	java/lang/NullPointerException
/*      */   }
/*      */ 
/*      */   public void start()
/*      */   {
/*  455 */     if (javaVersion < 1.3F) return;
/*      */ 
/*  457 */     if (this.thread != null) return;
/*  458 */     this.thread = new Thread(this);
/*  459 */     this.thread.start();
/*      */   }
/*      */ 
/*      */   public void stop()
/*      */   {
/*  471 */     if (this.thread == null) return;
/*  472 */     this.thread = null;
/*      */ 
/*  474 */     this.disposeMethods.handle();
/*      */   }
/*      */ 
/*      */   public void destroy()
/*      */   {
/*  489 */     stop();
/*      */   }
/*      */ 
/*      */   public Dimension getPreferredSize()
/*      */   {
/*  494 */     return new Dimension(this.width, this.height);
/*      */   }
/*      */ 
/*      */   public void registerSize(Object paramObject)
/*      */   {
/*  544 */     Class[] arrayOfClass = { Integer.TYPE, Integer.TYPE };
/*  545 */     registerWithArgs(this.preMethods, "size", paramObject, arrayOfClass);
/*      */   }
/*      */ 
/*      */   public void registerPre(Object paramObject) {
/*  549 */     registerNoArgs(this.preMethods, "pre", paramObject);
/*      */   }
/*      */ 
/*      */   public void registerDraw(Object paramObject) {
/*  553 */     registerNoArgs(this.drawMethods, "draw", paramObject);
/*      */   }
/*      */ 
/*      */   public void registerPost(Object paramObject) {
/*  557 */     registerNoArgs(this.postMethods, "post", paramObject);
/*      */   }
/*      */ 
/*      */   public void registerMouseEvent(Object paramObject)
/*      */   {
/*      */     Class tmp9_6 = class$java$awt$event$MouseEvent; if (tmp9_6 == null) tmp9_6; 0[tmp9_6] = (PApplet.class$java$awt$event$MouseEvent = jdMethod_class("[Ljava.awt.event.MouseEvent;", false)); Class[] arrayOfClass = new Class[1];
/*  562 */     registerWithArgs(this.mouseEventMethods, "mouseEvent", paramObject, arrayOfClass);
/*      */   }
/*      */ 
/*      */   public void registerKeyEvent(Object paramObject)
/*      */   {
/*      */     Class tmp9_6 = class$java$awt$event$KeyEvent; if (tmp9_6 == null) tmp9_6; 0[tmp9_6] = (PApplet.class$java$awt$event$KeyEvent = jdMethod_class("[Ljava.awt.event.KeyEvent;", false)); Class[] arrayOfClass = new Class[1];
/*  568 */     registerWithArgs(this.keyEventMethods, "keyEvent", paramObject, arrayOfClass);
/*      */   }
/*      */ 
/*      */   public void registerDispose(Object paramObject) {
/*  572 */     registerNoArgs(this.disposeMethods, "dispose", paramObject);
/*      */   }
/*      */ 
/*      */   protected void registerNoArgs(RegisteredMethods paramRegisteredMethods, String paramString, Object paramObject)
/*      */   {
/*  578 */     Class localClass = paramObject.getClass();
/*      */     try {
/*  580 */       Method localMethod = localClass.getMethod(paramString, new Class[0]);
/*  581 */       paramRegisteredMethods.add(paramObject, localMethod);
/*      */     }
/*      */     catch (Exception localException) {
/*  584 */       die("Could not register " + paramString + " + () for " + paramObject, localException);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void registerWithArgs(RegisteredMethods paramRegisteredMethods, String paramString, Object paramObject, Class[] paramArrayOfClass)
/*      */   {
/*  591 */     Class localClass = paramObject.getClass();
/*      */     try {
/*  593 */       Method localMethod = localClass.getMethod(paramString, paramArrayOfClass);
/*  594 */       paramRegisteredMethods.add(paramObject, localMethod);
/*      */     }
/*      */     catch (Exception localException) {
/*  597 */       die("Could not register " + paramString + " + () for " + paramObject, localException);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setup()
/*      */   {
/*      */   }
/*      */ 
/*      */   public void draw()
/*      */   {
/*  612 */     this.finished = true;
/*      */   }
/*      */ 
/*      */   public synchronized void redraw()
/*      */   {
/*  617 */     if (!(this.looping)) {
/*  618 */       this.redraw = true;
/*  619 */       if (this.thread == null) {
/*      */         return;
/*      */       }
/*      */ 
/*  623 */       this.thread.interrupt();
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void loop()
/*      */   {
/*  634 */     if (!(this.looping)) {
/*  635 */       this.looping = true;
/*  636 */       if (this.thread == null) {
/*      */         return;
/*      */       }
/*      */ 
/*  640 */       this.thread.interrupt();
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void noLoop()
/*      */   {
/*  651 */     if (this.looping) {
/*  652 */       this.looping = false;
/*      */ 
/*  655 */       this.framerateLastDelayTime = 0L;
/*  656 */       this.framerateLastMillis = 0L;
/*      */ 
/*  658 */       if (this.thread == null)
/*      */         return;
/*  660 */       this.thread.interrupt();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void size(int paramInt1, int paramInt2)
/*      */   {
/*  689 */     if (this.g != null)
/*      */     {
/*  691 */       size(paramInt1, paramInt2, this.g.getClass().getName());
/*      */     }
/*      */     else {
/*  694 */       if (javaVersion < 1.3F) return;
/*      */       try {
/*  696 */         Class localClass = Class.forName("processing.core.PGraphics2");
/*  697 */         size(paramInt1, paramInt2, "processing.core.PGraphics2");
/*  698 */         return;
/*      */       }
/*      */       catch (ClassNotFoundException localClassNotFoundException) {
/*  701 */         size(paramInt1, paramInt2, "processing.core.PGraphics"); }  }  } 
/*      */   // ERROR //
/*      */   public void size(int paramInt1, int paramInt2, String paramString) { // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 407	processing/core/PApplet:g	Lprocessing/core/PGraphics;
/*      */     //   4: ifnonnull +7 -> 11
/*      */     //   7: aconst_null
/*      */     //   8: goto +13 -> 21
/*      */     //   11: aload_0
/*      */     //   12: getfield 407	processing/core/PApplet:g	Lprocessing/core/PGraphics;
/*      */     //   15: invokevirtual 367	java/lang/Object:getClass	()Ljava/lang/Class;
/*      */     //   18: invokevirtual 410	java/lang/Class:getName	()Ljava/lang/String;
/*      */     //   21: astore 4
/*      */     //   23: aload 4
/*      */     //   25: ifnull +63 -> 88
/*      */     //   28: aload 4
/*      */     //   30: aload_3
/*      */     //   31: invokevirtual 429	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   34: ifeq +36 -> 70
/*      */     //   37: iload_1
/*      */     //   38: aload_0
/*      */     //   39: getfield 407	processing/core/PApplet:g	Lprocessing/core/PGraphics;
/*      */     //   42: getfield 432	processing/core/PGraphics:width	I
/*      */     //   45: if_icmpne +22 -> 67
/*      */     //   48: iload_2
/*      */     //   49: aload_0
/*      */     //   50: getfield 407	processing/core/PApplet:g	Lprocessing/core/PGraphics;
/*      */     //   53: getfield 433	processing/core/PGraphics:height	I
/*      */     //   56: if_icmpne +11 -> 67
/*      */     //   59: aload_0
/*      */     //   60: getfield 407	processing/core/PApplet:g	Lprocessing/core/PGraphics;
/*      */     //   63: invokevirtual 436	processing/core/PGraphics:defaults	()V
/*      */     //   66: return
/*      */     //   67: goto +21 -> 88
/*      */     //   70: aload_0
/*      */     //   71: getfield 438	processing/core/PApplet:frameCount	I
/*      */     //   74: ifle +14 -> 88
/*      */     //   77: new 440	java/lang/RuntimeException
/*      */     //   80: dup
/*      */     //   81: ldc_w 442
/*      */     //   84: invokespecial 443	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
/*      */     //   87: athrow
/*      */     //   88: ldc_w 445
/*      */     //   91: astore 5
/*      */     //   93: aload_3
/*      */     //   94: invokestatic 419	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   97: astore 6
/*      */     //   99: iconst_3
/*      */     //   100: anewarray 216	java/lang/Class
/*      */     //   103: dup
/*      */     //   104: iconst_0
/*      */     //   105: getstatic 330	java/lang/Integer:TYPE	Ljava/lang/Class;
/*      */     //   108: aastore
/*      */     //   109: dup
/*      */     //   110: iconst_1
/*      */     //   111: getstatic 330	java/lang/Integer:TYPE	Ljava/lang/Class;
/*      */     //   114: aastore
/*      */     //   115: dup
/*      */     //   116: iconst_2
/*      */     //   117: getstatic 447	processing/core/PApplet:class$processing$core$PApplet	Ljava/lang/Class;
/*      */     //   120: dup
/*      */     //   121: ifnonnull +15 -> 136
/*      */     //   124: pop
/*      */     //   125: ldc_w 449
/*      */     //   128: iconst_0
/*      */     //   129: invokestatic 212	processing/core/PApplet:class	(Ljava/lang/String;Z)Ljava/lang/Class;
/*      */     //   132: dup
/*      */     //   133: putstatic 447	processing/core/PApplet:class$processing$core$PApplet	Ljava/lang/Class;
/*      */     //   136: aastore
/*      */     //   137: astore 7
/*      */     //   139: aload 6
/*      */     //   141: aload 7
/*      */     //   143: invokevirtual 453	java/lang/Class:getConstructor	([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
/*      */     //   146: astore 8
/*      */     //   148: iconst_3
/*      */     //   149: anewarray 227	java/lang/Object
/*      */     //   152: dup
/*      */     //   153: iconst_0
/*      */     //   154: new 329	java/lang/Integer
/*      */     //   157: dup
/*      */     //   158: iload_1
/*      */     //   159: invokespecial 456	java/lang/Integer:<init>	(I)V
/*      */     //   162: aastore
/*      */     //   163: dup
/*      */     //   164: iconst_1
/*      */     //   165: new 329	java/lang/Integer
/*      */     //   168: dup
/*      */     //   169: iload_2
/*      */     //   170: invokespecial 456	java/lang/Integer:<init>	(I)V
/*      */     //   173: aastore
/*      */     //   174: dup
/*      */     //   175: iconst_2
/*      */     //   176: aload_0
/*      */     //   177: aastore
/*      */     //   178: astore 9
/*      */     //   180: aload_0
/*      */     //   181: aload 8
/*      */     //   183: aload 9
/*      */     //   185: invokevirtual 462	java/lang/reflect/Constructor:newInstance	([Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   188: checkcast 431	processing/core/PGraphics
/*      */     //   191: putfield 407	processing/core/PApplet:g	Lprocessing/core/PGraphics;
/*      */     //   194: aload_0
/*      */     //   195: iload_1
/*      */     //   196: putfield 299	processing/core/PApplet:width	I
/*      */     //   199: aload_0
/*      */     //   200: iload_2
/*      */     //   201: putfield 301	processing/core/PApplet:height	I
/*      */     //   204: aload_0
/*      */     //   205: aload_0
/*      */     //   206: getfield 299	processing/core/PApplet:width	I
/*      */     //   209: aload_0
/*      */     //   210: getfield 301	processing/core/PApplet:height	I
/*      */     //   213: invokevirtual 465	processing/core/PApplet:setSize	(II)V
/*      */     //   216: goto +127 -> 343
/*      */     //   219: astore 6
/*      */     //   221: aload 6
/*      */     //   223: invokevirtual 471	java/lang/reflect/InvocationTargetException:getTargetException	()Ljava/lang/Throwable;
/*      */     //   226: invokevirtual 476	java/lang/Throwable:getMessage	()Ljava/lang/String;
/*      */     //   229: astore 7
/*      */     //   231: aload 7
/*      */     //   233: ifnull +25 -> 258
/*      */     //   236: aload 7
/*      */     //   238: ldc_w 478
/*      */     //   241: invokevirtual 482	java/lang/String:indexOf	(Ljava/lang/String;)I
/*      */     //   244: iconst_m1
/*      */     //   245: if_icmpeq +13 -> 258
/*      */     //   248: new 440	java/lang/RuntimeException
/*      */     //   251: dup
/*      */     //   252: aload 5
/*      */     //   254: invokespecial 443	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
/*      */     //   257: athrow
/*      */     //   258: aload 6
/*      */     //   260: invokevirtual 471	java/lang/reflect/InvocationTargetException:getTargetException	()Ljava/lang/Throwable;
/*      */     //   263: invokevirtual 485	java/lang/Throwable:printStackTrace	()V
/*      */     //   266: goto +77 -> 343
/*      */     //   269: astore 6
/*      */     //   271: aload 6
/*      */     //   273: invokevirtual 486	java/lang/ClassNotFoundException:getMessage	()Ljava/lang/String;
/*      */     //   276: ldc_w 488
/*      */     //   279: invokevirtual 482	java/lang/String:indexOf	(Ljava/lang/String;)I
/*      */     //   282: iconst_m1
/*      */     //   283: if_icmpeq +13 -> 296
/*      */     //   286: new 440	java/lang/RuntimeException
/*      */     //   289: dup
/*      */     //   290: aload 5
/*      */     //   292: invokespecial 443	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
/*      */     //   295: athrow
/*      */     //   296: new 440	java/lang/RuntimeException
/*      */     //   299: dup
/*      */     //   300: new 373	java/lang/StringBuffer
/*      */     //   303: dup
/*      */     //   304: ldc_w 490
/*      */     //   307: invokespecial 378	java/lang/StringBuffer:<init>	(Ljava/lang/String;)V
/*      */     //   310: aload_3
/*      */     //   311: invokevirtual 382	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   314: ldc_w 492
/*      */     //   317: invokevirtual 382	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   320: invokevirtual 391	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*      */     //   323: invokespecial 443	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
/*      */     //   326: athrow
/*      */     //   327: astore 6
/*      */     //   329: aload 6
/*      */     //   331: invokevirtual 493	java/lang/Exception:printStackTrace	()V
/*      */     //   334: aload_0
/*      */     //   335: ldc_w 495
/*      */     //   338: aload 6
/*      */     //   340: invokevirtual 395	processing/core/PApplet:die	(Ljava/lang/String;Ljava/lang/Exception;)V
/*      */     //   343: aload 4
/*      */     //   345: ifnull +22 -> 367
/*      */     //   348: aload 4
/*      */     //   350: aload_3
/*      */     //   351: invokevirtual 429	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   354: ifne +13 -> 367
/*      */     //   357: new 440	java/lang/RuntimeException
/*      */     //   360: dup
/*      */     //   361: ldc 26
/*      */     //   363: invokespecial 443	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
/*      */     //   366: athrow
/*      */     //   367: aload_0
/*      */     //   368: getfield 407	processing/core/PApplet:g	Lprocessing/core/PGraphics;
/*      */     //   371: invokevirtual 436	processing/core/PGraphics:defaults	()V
/*      */     //   374: iconst_2
/*      */     //   375: anewarray 227	java/lang/Object
/*      */     //   378: dup
/*      */     //   379: iconst_0
/*      */     //   380: new 329	java/lang/Integer
/*      */     //   383: dup
/*      */     //   384: aload_0
/*      */     //   385: getfield 299	processing/core/PApplet:width	I
/*      */     //   388: invokespecial 456	java/lang/Integer:<init>	(I)V
/*      */     //   391: aastore
/*      */     //   392: dup
/*      */     //   393: iconst_1
/*      */     //   394: new 329	java/lang/Integer
/*      */     //   397: dup
/*      */     //   398: aload_0
/*      */     //   399: getfield 301	processing/core/PApplet:height	I
/*      */     //   402: invokespecial 456	java/lang/Integer:<init>	(I)V
/*      */     //   405: aastore
/*      */     //   406: astore 6
/*      */     //   408: aload_0
/*      */     //   409: getfield 265	processing/core/PApplet:sizeMethods	Lprocessing/core/PApplet$RegisteredMethods;
/*      */     //   412: aload 6
/*      */     //   414: invokevirtual 498	processing/core/PApplet$RegisteredMethods:handle	([Ljava/lang/Object;)V
/*      */     //   417: return
/*      */     //
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   93	216	219	java/lang/reflect/InvocationTargetException
/*      */     //   93	216	269	java/lang/ClassNotFoundException
/*      */     //   93	216	327	java/lang/Exception } 
/*      */   public void update(Graphics paramGraphics) { paint(paramGraphics);
/*      */   }
/*      */ 
/*      */   public synchronized void paint(Graphics paramGraphics)
/*      */   {
/*  861 */     if (javaVersion < 1.3F) {
/*  862 */       paramGraphics.setColor(new Color(64, 64, 64));
/*  863 */       Dimension localDimension = getSize();
/*  864 */       paramGraphics.fillRect(0, 0, localDimension.width, localDimension.height);
/*  865 */       paramGraphics.setColor(Color.white);
/*  866 */       paramGraphics.setFont(new Font("Dialog", 0, 9));
/*  867 */       paramGraphics.drawString("You need to install", 3, 15);
/*  868 */       paramGraphics.drawString("Java 1.3 or later", 3, 28);
/*  869 */       paramGraphics.drawString("to view this content.", 3, 41);
/*  870 */       paramGraphics.drawString("Click here to visit", 3, 59);
/*  871 */       paramGraphics.drawString("java.com and install.", 3, 72);
/*  872 */       return;
/*      */     }
/*      */ 
/*  882 */     if (this.frameCount == 0)
/*      */     {
/*  892 */       return;
/*      */     }
/*      */ 
/*  919 */     if ((this.g != null) && (this.g.image != null))
/*  920 */       paramGraphics.drawImage(this.g.image, 0, 0, null);
/*      */   }
/*      */ 
/*      */   public void run()
/*      */   {
/*      */     try
/*      */     {
/*  945 */       break label45:
/*      */       do
/*      */       {
/*  951 */         this.g.requestDisplay(this);
/*      */         try
/*      */         {
/*  975 */           int i = (this.looping) ? 1 : 10000;
/*      */ 
/*  978 */           if (this.frameCount == 1) i = 1;
/*  979 */           Thread.sleep(i);
/*      */         }
/*      */         catch (InterruptedException localInterruptedException)
/*      */         {
/*      */         }
/*  945 */         label45: if (Thread.currentThread() != this.thread) break;  }
/*  945 */       while (!(this.finished));
/*      */     }
/*      */     catch (Exception localException2)
/*      */     {
/*  996 */       this.finished = true;
/*      */       Exception localException2;
/*  997 */       if (localException1 instanceof InvocationTargetException)
/*      */       {
/*  999 */         localException2 = (Exception)((InvocationTargetException)localException1).getTargetException();
/*      */       }
/* 1001 */       this.exception = localException2;
/*      */ 
/* 1004 */       if (this.leechErr != null)
/*      */       {
/* 1007 */         this.leechErr.println("Error while running applet.");
/* 1008 */         localException2.printStackTrace(this.leechErr);
/*      */       }
/*      */       else {
/* 1011 */         System.err.println("Error while running applet.");
/* 1012 */         localException2.printStackTrace();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1018 */     stop();
/*      */   }
/*      */ 
/*      */   public synchronized void display()
/*      */   {
/* 1025 */     if ((!(this.looping)) && (!(this.redraw)))
/*      */     {
/*      */       return;
/*      */     }
/*      */ 
/* 1041 */     this.g.beginFrame();
/*      */ 
/* 1045 */     if (this.frameCount == 0)
/*      */     {
/*      */       try
/*      */       {
/* 1050 */         setup();
/*      */       }
/*      */       catch (RuntimeException localRuntimeException)
/*      */       {
/* 1060 */         String str = localRuntimeException.getMessage();
/* 1061 */         if ((str != null) && (localRuntimeException.getMessage().indexOf("new renderer") != -1))
/*      */         {
/* 1064 */           return;
/*      */         }
/*      */ 
/* 1070 */         throw localRuntimeException;
/*      */       }
/*      */ 
/* 1078 */       this.width = this.g.width;
/* 1079 */       this.height = this.g.height;
/*      */     }
/*      */     else
/*      */     {
/* 1083 */       if (this.framerateLastMillis != 0L) {
/* 1084 */         float f = (float)(System.currentTimeMillis() - this.framerateLastMillis);
/*      */ 
/* 1086 */         if (f != 0.0F) {
/* 1087 */           this.framerate = (this.framerate * 0.9F + 1.0F / f / 1000.0F * 0.1F);
/*      */         }
/*      */       }
/*      */ 
/* 1091 */       this.framerateLastMillis = System.currentTimeMillis();
/*      */ 
/* 1093 */       if (this.framerateTarget != 0.0F)
/*      */       {
/* 1095 */         if (this.framerateLastDelayTime == 0L) {
/* 1096 */           this.framerateLastDelayTime = System.currentTimeMillis();
/*      */         }
/*      */         else {
/* 1099 */           long l = this.framerateLastDelayTime + ()(1000.0F / this.framerateTarget);
/*      */ 
/* 1101 */           int i = (int)(l - System.currentTimeMillis());
/*      */ 
/* 1103 */           this.framerateLastDelayTime = l;
/* 1104 */           delay(i);
/*      */         }
/*      */       }
/*      */ 
/* 1108 */       this.preMethods.handle();
/*      */ 
/* 1110 */       this.pmouseX = this.dmouseX;
/* 1111 */       this.pmouseY = this.dmouseY;
/*      */ 
/* 1116 */       draw();
/*      */ 
/* 1130 */       this.dmouseX = this.mouseX;
/* 1131 */       this.dmouseY = this.mouseY;
/*      */ 
/* 1137 */       dequeueMouseEvents();
/*      */ 
/* 1139 */       dequeueKeyEvents();
/*      */ 
/* 1143 */       this.drawMethods.handle();
/*      */ 
/* 1148 */       this.redraw = false;
/*      */     }
/*      */ 
/* 1152 */     this.g.endFrame();
/* 1153 */     if (this.recorder != null) {
/* 1154 */       this.recorder.endFrame();
/* 1155 */       this.recorder = null;
/*      */     }
/*      */ 
/* 1164 */     this.frameCount += 1;
/*      */ 
/* 1167 */     repaint();
/*      */ 
/* 1170 */     getToolkit().sync();
/*      */ 
/* 1178 */     this.postMethods.handle();
/*      */   }
/*      */ 
/*      */   public void addListeners()
/*      */   {
/* 1193 */     if (!(this.listenersAdded)) {
/* 1194 */       addMouseListener(this);
/* 1195 */       addMouseMotionListener(this);
/* 1196 */       addKeyListener(this);
/* 1197 */       addFocusListener(this);
/* 1198 */       this.listenersAdded = true;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void enqueueMouseEvent(MouseEvent paramMouseEvent)
/*      */   {
/* 1210 */     synchronized (this.mouseEventQueue) {
/* 1211 */       if (this.mouseEventCount == this.mouseEventQueue.length) {
/* 1212 */         MouseEvent[] arrayOfMouseEvent = new MouseEvent[this.mouseEventCount << 1];
/* 1213 */         System.arraycopy(this.mouseEventQueue, 0, arrayOfMouseEvent, 0, this.mouseEventCount);
/* 1214 */         this.mouseEventQueue = arrayOfMouseEvent;
/*      */       }
/* 1216 */       this.mouseEventQueue[(this.mouseEventCount++)] = paramMouseEvent;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void dequeueMouseEvents() {
/* 1221 */     synchronized (this.mouseEventQueue) {
/* 1222 */       for (int i = 0; i < this.mouseEventCount; ++i) {
/* 1223 */         this.mouseEvent = this.mouseEventQueue[i];
/* 1224 */         handleMouseEvent(this.mouseEvent);
/*      */       }
/* 1226 */       this.mouseEventCount = 0;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void handleMouseEvent(MouseEvent paramMouseEvent)
/*      */   {
/* 1239 */     this.pmouseX = this.emouseX;
/* 1240 */     this.pmouseY = this.emouseY;
/*      */ 
/* 1242 */     this.mouseX = paramMouseEvent.getX();
/* 1243 */     this.mouseY = paramMouseEvent.getY();
/* 1244 */     this.mouseEvent = paramMouseEvent;
/*      */ 
/* 1246 */     int i = paramMouseEvent.getModifiers();
/* 1247 */     if ((i & 0x10) != 0)
/* 1248 */       this.mouseButton = 37;
/* 1249 */     else if ((i & 0x8) != 0)
/* 1250 */       this.mouseButton = 3;
/* 1251 */     else if ((i & 0x4) != 0) {
/* 1252 */       this.mouseButton = 39;
/*      */     }
/*      */ 
/* 1255 */     if ((((platform == 3) || (platform == 2))) && 
/* 1256 */       (this.mouseEvent.isPopupTrigger())) {
/* 1257 */       this.mouseButton = 39;
/*      */     }
/*      */ 
/* 1261 */     this.mouseEventMethods.handle(new Object[] { paramMouseEvent });
/*      */ 
/* 1272 */     if (this.firstMouse) {
/* 1273 */       this.pmouseX = this.mouseX;
/* 1274 */       this.pmouseY = this.mouseY;
/* 1275 */       this.dmouseX = this.mouseX;
/* 1276 */       this.dmouseY = this.mouseY;
/* 1277 */       this.firstMouse = false;
/*      */     }
/*      */ 
/* 1280 */     switch (paramMouseEvent.getID()) {
/*      */     case 501:
/* 1282 */       this.mousePressed = true;
/* 1283 */       mousePressed();
/* 1284 */       break;
/*      */     case 502:
/* 1286 */       this.mousePressed = false;
/* 1287 */       mouseReleased();
/* 1288 */       break;
/*      */     case 500:
/* 1290 */       mouseClicked();
/* 1291 */       break;
/*      */     case 506:
/* 1293 */       mouseDragged();
/* 1294 */       break;
/*      */     case 503:
/* 1296 */       mouseMoved();
/*      */     case 504:
/*      */     case 505: }
/* 1299 */     this.emouseX = this.mouseX;
/* 1300 */     this.emouseY = this.mouseY;
/*      */   }
/*      */ 
/*      */   protected void checkMouseEvent(MouseEvent paramMouseEvent)
/*      */   {
/* 1310 */     if (this.looping)
/* 1311 */       enqueueMouseEvent(paramMouseEvent);
/*      */     else
/* 1313 */       handleMouseEvent(paramMouseEvent);
/*      */   }
/*      */ 
/*      */   public void mousePressed(MouseEvent paramMouseEvent)
/*      */   {
/* 1324 */     checkMouseEvent(paramMouseEvent);
/*      */   }
/*      */ 
/*      */   public void mouseReleased(MouseEvent paramMouseEvent) {
/* 1328 */     checkMouseEvent(paramMouseEvent);
/*      */   }
/*      */ 
/*      */   public void mouseClicked(MouseEvent paramMouseEvent) {
/* 1332 */     checkMouseEvent(paramMouseEvent);
/*      */   }
/*      */ 
/*      */   public void mouseEntered(MouseEvent paramMouseEvent) {
/* 1336 */     checkMouseEvent(paramMouseEvent);
/*      */   }
/*      */ 
/*      */   public void mouseExited(MouseEvent paramMouseEvent) {
/* 1340 */     checkMouseEvent(paramMouseEvent);
/*      */   }
/*      */ 
/*      */   public void mouseDragged(MouseEvent paramMouseEvent) {
/* 1344 */     checkMouseEvent(paramMouseEvent);
/*      */   }
/*      */ 
/*      */   public void mouseMoved(MouseEvent paramMouseEvent) {
/* 1348 */     checkMouseEvent(paramMouseEvent);
/*      */   }
/*      */ 
/*      */   public void mousePressed()
/*      */   {
/*      */   }
/*      */ 
/*      */   public void mouseReleased()
/*      */   {
/*      */   }
/*      */ 
/*      */   public void mouseClicked()
/*      */   {
/*      */   }
/*      */ 
/*      */   public void mouseDragged()
/*      */   {
/*      */   }
/*      */ 
/*      */   public void mouseMoved()
/*      */   {
/*      */   }
/*      */ 
/*      */   protected void enqueueKeyEvent(KeyEvent paramKeyEvent)
/*      */   {
/* 1393 */     synchronized (this.keyEventQueue) {
/* 1394 */       if (this.keyEventCount == this.keyEventQueue.length) {
/* 1395 */         KeyEvent[] arrayOfKeyEvent = new KeyEvent[this.keyEventCount << 1];
/* 1396 */         System.arraycopy(this.keyEventQueue, 0, arrayOfKeyEvent, 0, this.keyEventCount);
/* 1397 */         this.keyEventQueue = arrayOfKeyEvent;
/*      */       }
/* 1399 */       this.keyEventQueue[(this.keyEventCount++)] = paramKeyEvent;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void dequeueKeyEvents() {
/* 1404 */     synchronized (this.keyEventQueue) {
/* 1405 */       for (int i = 0; i < this.keyEventCount; ++i) {
/* 1406 */         this.keyEvent = this.keyEventQueue[i];
/* 1407 */         handleKeyEvent(this.keyEvent);
/*      */       }
/* 1409 */       this.keyEventCount = 0;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void handleKeyEvent(KeyEvent paramKeyEvent)
/*      */   {
/* 1415 */     this.keyEvent = paramKeyEvent;
/* 1416 */     this.key = paramKeyEvent.getKeyChar();
/* 1417 */     this.keyCode = paramKeyEvent.getKeyCode();
/*      */ 
/* 1419 */     this.keyEventMethods.handle(new Object[] { paramKeyEvent });
/*      */ 
/* 1428 */     switch (paramKeyEvent.getID())
/*      */     {
/*      */     case 401:
/* 1430 */       this.keyPressed = true;
/* 1431 */       keyPressed();
/* 1432 */       break;
/*      */     case 402:
/* 1434 */       this.keyPressed = false;
/* 1435 */       keyReleased();
/* 1436 */       break;
/*      */     case 400:
/* 1438 */       keyTyped();
/*      */     }
/*      */ 
/* 1444 */     if (this.key == '\27')
/* 1445 */       exit();
/*      */   }
/*      */ 
/*      */   protected void checkKeyEvent(KeyEvent paramKeyEvent)
/*      */   {
/* 1451 */     if (this.looping)
/* 1452 */       enqueueKeyEvent(paramKeyEvent);
/*      */     else
/* 1454 */       handleKeyEvent(paramKeyEvent);
/*      */   }
/*      */ 
/*      */   public void keyPressed(KeyEvent paramKeyEvent)
/*      */   {
/* 1466 */     checkKeyEvent(paramKeyEvent); } 
/*      */   public void keyReleased(KeyEvent paramKeyEvent) { checkKeyEvent(paramKeyEvent); } 
/*      */   public void keyTyped(KeyEvent paramKeyEvent) { checkKeyEvent(paramKeyEvent);
/*      */   }
/*      */ 
/*      */   public void keyPressed()
/*      */   {
/*      */   }
/*      */ 
/*      */   public void keyReleased()
/*      */   {
/*      */   }
/*      */ 
/*      */   public void keyTyped()
/*      */   {
/*      */   }
/*      */ 
/*      */   public void focusGained()
/*      */   {
/*      */   }
/*      */ 
/*      */   public void focusGained(FocusEvent paramFocusEvent)
/*      */   {
/* 1541 */     this.focused = true;
/* 1542 */     focusGained();
/*      */   }
/*      */ 
/*      */   public void focusLost() {
/*      */   }
/*      */ 
/*      */   public void focusLost(FocusEvent paramFocusEvent) {
/* 1549 */     this.focused = false;
/* 1550 */     focusLost();
/*      */   }
/*      */ 
/*      */   public int millis()
/*      */   {
/* 1566 */     return (int)(System.currentTimeMillis() - this.millisOffset);
/*      */   }
/*      */ 
/*      */   public static int second()
/*      */   {
/* 1571 */     return Calendar.getInstance().get(13);
/*      */   }
/*      */ 
/*      */   public static int minute()
/*      */   {
/* 1576 */     return Calendar.getInstance().get(12);
/*      */   }
/*      */ 
/*      */   public static int hour()
/*      */   {
/* 1587 */     return Calendar.getInstance().get(11);
/*      */   }
/*      */ 
/*      */   public static int day()
/*      */   {
/* 1597 */     return Calendar.getInstance().get(5);
/*      */   }
/*      */ 
/*      */   public static int month()
/*      */   {
/* 1605 */     return (Calendar.getInstance().get(2) + 1);
/*      */   }
/*      */ 
/*      */   public static int year()
/*      */   {
/* 1612 */     return Calendar.getInstance().get(1);
/*      */   }
/*      */ 
/*      */   public void delay(int paramInt)
/*      */   {
/* 1625 */     if (this.frameCount == 0) return;
/* 1626 */     if (paramInt <= 0) return;
/*      */     try {
/* 1628 */       Thread.sleep(paramInt);
/*      */     }
/*      */     catch (InterruptedException localInterruptedException)
/*      */     {
/*      */     }
/*      */   }
/*      */ 
/*      */   public void framerate(float paramFloat)
/*      */   {
/* 1639 */     this.framerateTarget = paramFloat;
/*      */   }
/*      */ 
/*      */   public String param(String paramString)
/*      */   {
/* 1651 */     if (this.online) {
/* 1652 */       return getParameter(paramString);
/*      */     }
/*      */ 
/* 1655 */     System.err.println("param() only works inside a web browser");
/*      */ 
/* 1657 */     return null;
/*      */   }
/*      */ 
/*      */   public void status(String paramString)
/*      */   {
/* 1667 */     if (this.online) {
/* 1668 */       showStatus(paramString);
/*      */     }
/*      */     else
/* 1671 */       System.out.println(paramString);
/*      */   }
/*      */ 
/*      */   public void link(String paramString)
/*      */   {
/* 1677 */     link(paramString, null); } 
/*      */   // ERROR //
/*      */   public void link(String paramString1, String paramString2) { // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 283	processing/core/PApplet:online	Z
/*      */     //   4: ifeq +81 -> 85
/*      */     //   7: aload_2
/*      */     //   8: ifnonnull +23 -> 31
/*      */     //   11: aload_0
/*      */     //   12: invokevirtual 281	processing/core/PApplet:getAppletContext	()Ljava/applet/AppletContext;
/*      */     //   15: new 812	java/net/URL
/*      */     //   18: dup
/*      */     //   19: aload_1
/*      */     //   20: invokespecial 813	java/net/URL:<init>	(Ljava/lang/String;)V
/*      */     //   23: invokeinterface 819 2 0
/*      */     //   28: goto +21 -> 49
/*      */     //   31: aload_0
/*      */     //   32: invokevirtual 281	processing/core/PApplet:getAppletContext	()Ljava/applet/AppletContext;
/*      */     //   35: new 812	java/net/URL
/*      */     //   38: dup
/*      */     //   39: aload_1
/*      */     //   40: invokespecial 813	java/net/URL:<init>	(Ljava/lang/String;)V
/*      */     //   43: aload_2
/*      */     //   44: invokeinterface 822 3 0
/*      */     //   49: goto +33 -> 82
/*      */     //   52: astore_3
/*      */     //   53: aload_3
/*      */     //   54: invokevirtual 493	java/lang/Exception:printStackTrace	()V
/*      */     //   57: new 440	java/lang/RuntimeException
/*      */     //   60: dup
/*      */     //   61: new 373	java/lang/StringBuffer
/*      */     //   64: dup
/*      */     //   65: ldc_w 824
/*      */     //   68: invokespecial 378	java/lang/StringBuffer:<init>	(Ljava/lang/String;)V
/*      */     //   71: aload_1
/*      */     //   72: invokevirtual 382	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   75: invokevirtual 391	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*      */     //   78: invokespecial 443	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
/*      */     //   81: athrow
/*      */     //   82: goto +163 -> 245
/*      */     //   85: getstatic 692	processing/core/PApplet:platform	I
/*      */     //   88: iconst_1
/*      */     //   89: if_icmpne +30 -> 119
/*      */     //   92: invokestatic 830	java/lang/Runtime:getRuntime	()Ljava/lang/Runtime;
/*      */     //   95: new 373	java/lang/StringBuffer
/*      */     //   98: dup
/*      */     //   99: ldc_w 832
/*      */     //   102: invokespecial 378	java/lang/StringBuffer:<init>	(Ljava/lang/String;)V
/*      */     //   105: aload_1
/*      */     //   106: invokevirtual 382	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   109: invokevirtual 391	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*      */     //   112: invokevirtual 836	java/lang/Runtime:exec	(Ljava/lang/String;)Ljava/lang/Process;
/*      */     //   115: pop
/*      */     //   116: goto +96 -> 212
/*      */     //   119: getstatic 692	processing/core/PApplet:platform	I
/*      */     //   122: iconst_3
/*      */     //   123: if_icmpeq +10 -> 133
/*      */     //   126: getstatic 692	processing/core/PApplet:platform	I
/*      */     //   129: iconst_2
/*      */     //   130: if_icmpne +71 -> 201
/*      */     //   133: ldc_w 838
/*      */     //   136: invokestatic 419	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
/*      */     //   139: astore_3
/*      */     //   140: aload_3
/*      */     //   141: ldc_w 840
/*      */     //   144: iconst_1
/*      */     //   145: anewarray 216	java/lang/Class
/*      */     //   148: dup
/*      */     //   149: iconst_0
/*      */     //   150: getstatic 842	processing/core/PApplet:class$java$lang$String	Ljava/lang/Class;
/*      */     //   153: dup
/*      */     //   154: ifnonnull +15 -> 169
/*      */     //   157: pop
/*      */     //   158: ldc_w 844
/*      */     //   161: iconst_0
/*      */     //   162: invokestatic 212	processing/core/PApplet:class	(Ljava/lang/String;Z)Ljava/lang/Class;
/*      */     //   165: dup
/*      */     //   166: putstatic 842	processing/core/PApplet:class$java$lang$String	Ljava/lang/Class;
/*      */     //   169: aastore
/*      */     //   170: invokevirtual 225	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*      */     //   173: astore 4
/*      */     //   175: aload 4
/*      */     //   177: aconst_null
/*      */     //   178: iconst_1
/*      */     //   179: anewarray 227	java/lang/Object
/*      */     //   182: dup
/*      */     //   183: iconst_0
/*      */     //   184: aload_1
/*      */     //   185: aastore
/*      */     //   186: invokevirtual 237	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   189: pop
/*      */     //   190: goto +8 -> 198
/*      */     //   193: astore_3
/*      */     //   194: aload_3
/*      */     //   195: invokevirtual 493	java/lang/Exception:printStackTrace	()V
/*      */     //   198: goto +14 -> 212
/*      */     //   201: new 440	java/lang/RuntimeException
/*      */     //   204: dup
/*      */     //   205: ldc_w 846
/*      */     //   208: invokespecial 443	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
/*      */     //   211: athrow
/*      */     //   212: goto +33 -> 245
/*      */     //   215: astore_3
/*      */     //   216: aload_3
/*      */     //   217: invokevirtual 849	java/io/IOException:printStackTrace	()V
/*      */     //   220: new 440	java/lang/RuntimeException
/*      */     //   223: dup
/*      */     //   224: new 373	java/lang/StringBuffer
/*      */     //   227: dup
/*      */     //   228: ldc_w 824
/*      */     //   231: invokespecial 378	java/lang/StringBuffer:<init>	(Ljava/lang/String;)V
/*      */     //   234: aload_1
/*      */     //   235: invokevirtual 382	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   238: invokevirtual 391	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*      */     //   241: invokespecial 443	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
/*      */     //   244: athrow
/*      */     //   245: return
/*      */     //
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	49	52	java/lang/Exception
/*      */     //   133	190	193	java/lang/Exception
/*      */     //   85	212	215	java/io/IOException } 
/*      */   public void open(String paramString) { if (platform == 1)
/*      */     {
/*      */       try
/*      */       {
/* 1752 */         Runtime.getRuntime().exec("cmd /c \"" + paramString + '"');
/*      */       } catch (IOException localIOException) {
/* 1754 */         localIOException.printStackTrace();
/* 1755 */         throw new RuntimeException("Could not open " + paramString);
/*      */       }
/*      */     }
/* 1758 */     else if ((platform == 3) || (platform == 2))
/*      */     {
/* 1760 */       String str = "file://" + paramString;
/*      */ 
/* 1766 */       if (str.indexOf(32) != -1) {
/* 1767 */         StringBuffer localStringBuffer = new StringBuffer();
/* 1768 */         char[] arrayOfChar = str.toCharArray();
/* 1769 */         for (int i = 0; i < arrayOfChar.length; ++i) {
/* 1770 */           if (arrayOfChar[i] == ' ')
/* 1771 */             localStringBuffer.append("%20");
/*      */           else {
/* 1773 */             localStringBuffer.append(arrayOfChar[i]);
/*      */           }
/*      */         }
/* 1776 */         str = localStringBuffer.toString();
/*      */       }
/* 1778 */       link(str);
/*      */     }
/*      */     else {
/* 1781 */       open(new String[] { paramString });
/*      */     }
/*      */   }
/*      */ 
/*      */   public Process open(String[] paramArrayOfString)
/*      */   {
/*      */     try
/*      */     {
/* 1792 */       return Runtime.getRuntime().exec(paramArrayOfString);
/*      */     } catch (Exception localException) {
/* 1794 */       localException.printStackTrace();
/* 1795 */       throw new RuntimeException("Could not open " + join(paramArrayOfString, ' '));
/*      */     }
/*      */   }
/*      */ 
/*      */   public void die(String paramString)
/*      */   {
/* 1810 */     stop();
/* 1811 */     throw new RuntimeException(paramString);
/*      */   }
/*      */ 
/*      */   public void die(String paramString, Exception paramException)
/*      */   {
/* 1828 */     if (paramException != null) paramException.printStackTrace();
/* 1829 */     die(paramString);
/*      */   }
/*      */ 
/*      */   public void exit()
/*      */   {
/* 1839 */     stop();
/* 1840 */     this.finished = true;
/*      */ 
/* 1842 */     if ((this.leechErr == null) && (!(this.online)))
/* 1843 */       System.exit(0);
/*      */   }
/*      */ 
/*      */   public void save(String paramString)
/*      */   {
/* 1860 */     this.g.save(savePath(paramString));
/*      */   }
/*      */ 
/*      */   public void saveFrame()
/*      */   {
/* 1873 */     if (this.online) {
/* 1874 */       System.err.println("Can't use saveFrame() when running in a browser.");
/* 1875 */       return;
/*      */     }
/*      */ 
/* 1881 */     save("screen-" + nf(this.frameCount, 4) + ".tif");
/*      */   }
/*      */ 
/*      */   public void saveFrame(String paramString)
/*      */   {
/* 1896 */     if (this.online) {
/* 1897 */       System.err.println("Can't use saveFrame() when running in a browser.");
/* 1898 */       return;
/*      */     }
/*      */ 
/* 1901 */     int i = paramString.indexOf(35);
/* 1902 */     int j = paramString.lastIndexOf(35);
/*      */ 
/* 1904 */     if (i == -1) {
/* 1905 */       save(paramString);
/*      */     }
/*      */     else {
/* 1908 */       String str1 = paramString.substring(0, i);
/* 1909 */       int k = j - i + 1;
/* 1910 */       String str2 = paramString.substring(j + 1);
/* 1911 */       save(str1 + nf(this.frameCount, k) + str2);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void cursor(int paramInt)
/*      */   {
/* 1933 */     setCursor(Cursor.getPredefinedCursor(paramInt));
/* 1934 */     this.cursor_visible = true;
/* 1935 */     this.cursor_type = paramInt; } 
/*      */   // ERROR //
/*      */   public void cursor(PImage paramPImage, int paramInt1, int paramInt2) { // Byte code:
/*      */     //   0: getstatic 203	processing/core/PApplet:javaVersion	F
/*      */     //   3: ldc_w 926
/*      */     //   6: fcmpg
/*      */     //   7: ifge +43 -> 50
/*      */     //   10: getstatic 588	java/lang/System:err	Ljava/io/PrintStream;
/*      */     //   13: ldc_w 928
/*      */     //   16: invokevirtual 582	java/io/PrintStream:println	(Ljava/lang/String;)V
/*      */     //   19: getstatic 588	java/lang/System:err	Ljava/io/PrintStream;
/*      */     //   22: new 373	java/lang/StringBuffer
/*      */     //   25: dup
/*      */     //   26: ldc_w 930
/*      */     //   29: invokespecial 378	java/lang/StringBuffer:<init>	(Ljava/lang/String;)V
/*      */     //   32: getstatic 932	processing/core/PApplet:javaVersionName	Ljava/lang/String;
/*      */     //   35: invokevirtual 382	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   38: bipush 41
/*      */     //   40: invokevirtual 855	java/lang/StringBuffer:append	(C)Ljava/lang/StringBuffer;
/*      */     //   43: invokevirtual 391	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*      */     //   46: invokevirtual 582	java/io/PrintStream:println	(Ljava/lang/String;)V
/*      */     //   49: return
/*      */     //   50: aload_0
/*      */     //   51: new 934	java/awt/image/MemoryImageSource
/*      */     //   54: dup
/*      */     //   55: aload_1
/*      */     //   56: getfield 937	processing/core/PImage:width	I
/*      */     //   59: aload_1
/*      */     //   60: getfield 938	processing/core/PImage:height	I
/*      */     //   63: aload_1
/*      */     //   64: getfield 940	processing/core/PImage:pixels	[I
/*      */     //   67: iconst_0
/*      */     //   68: aload_1
/*      */     //   69: getfield 937	processing/core/PImage:width	I
/*      */     //   72: invokespecial 943	java/awt/image/MemoryImageSource:<init>	(II[III)V
/*      */     //   75: invokevirtual 947	processing/core/PApplet:createImage	(Ljava/awt/image/ImageProducer;)Ljava/awt/Image;
/*      */     //   78: astore 4
/*      */     //   80: new 949	java/awt/Point
/*      */     //   83: dup
/*      */     //   84: iload_2
/*      */     //   85: iload_3
/*      */     //   86: invokespecial 950	java/awt/Point:<init>	(II)V
/*      */     //   89: astore 5
/*      */     //   91: getstatic 952	processing/core/PApplet:class$java$awt$Toolkit	Ljava/lang/Class;
/*      */     //   94: dup
/*      */     //   95: ifnonnull +15 -> 110
/*      */     //   98: pop
/*      */     //   99: ldc_w 954
/*      */     //   102: iconst_0
/*      */     //   103: invokestatic 212	processing/core/PApplet:class	(Ljava/lang/String;Z)Ljava/lang/Class;
/*      */     //   106: dup
/*      */     //   107: putstatic 952	processing/core/PApplet:class$java$awt$Toolkit	Ljava/lang/Class;
/*      */     //   110: ldc_w 956
/*      */     //   113: iconst_3
/*      */     //   114: anewarray 216	java/lang/Class
/*      */     //   117: dup
/*      */     //   118: iconst_0
/*      */     //   119: getstatic 958	processing/core/PApplet:class$java$awt$Image	Ljava/lang/Class;
/*      */     //   122: dup
/*      */     //   123: ifnonnull +15 -> 138
/*      */     //   126: pop
/*      */     //   127: ldc_w 960
/*      */     //   130: iconst_0
/*      */     //   131: invokestatic 212	processing/core/PApplet:class	(Ljava/lang/String;Z)Ljava/lang/Class;
/*      */     //   134: dup
/*      */     //   135: putstatic 958	processing/core/PApplet:class$java$awt$Image	Ljava/lang/Class;
/*      */     //   138: aastore
/*      */     //   139: dup
/*      */     //   140: iconst_1
/*      */     //   141: getstatic 962	processing/core/PApplet:class$java$awt$Point	Ljava/lang/Class;
/*      */     //   144: dup
/*      */     //   145: ifnonnull +15 -> 160
/*      */     //   148: pop
/*      */     //   149: ldc_w 964
/*      */     //   152: iconst_0
/*      */     //   153: invokestatic 212	processing/core/PApplet:class	(Ljava/lang/String;Z)Ljava/lang/Class;
/*      */     //   156: dup
/*      */     //   157: putstatic 962	processing/core/PApplet:class$java$awt$Point	Ljava/lang/Class;
/*      */     //   160: aastore
/*      */     //   161: dup
/*      */     //   162: iconst_2
/*      */     //   163: getstatic 842	processing/core/PApplet:class$java$lang$String	Ljava/lang/Class;
/*      */     //   166: dup
/*      */     //   167: ifnonnull +15 -> 182
/*      */     //   170: pop
/*      */     //   171: ldc_w 844
/*      */     //   174: iconst_0
/*      */     //   175: invokestatic 212	processing/core/PApplet:class	(Ljava/lang/String;Z)Ljava/lang/Class;
/*      */     //   178: dup
/*      */     //   179: putstatic 842	processing/core/PApplet:class$java$lang$String	Ljava/lang/Class;
/*      */     //   182: aastore
/*      */     //   183: invokevirtual 225	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*      */     //   186: astore 6
/*      */     //   188: aload 6
/*      */     //   190: invokestatic 967	java/awt/Toolkit:getDefaultToolkit	()Ljava/awt/Toolkit;
/*      */     //   193: iconst_3
/*      */     //   194: anewarray 227	java/lang/Object
/*      */     //   197: dup
/*      */     //   198: iconst_0
/*      */     //   199: aload 4
/*      */     //   201: aastore
/*      */     //   202: dup
/*      */     //   203: iconst_1
/*      */     //   204: aload 5
/*      */     //   206: aastore
/*      */     //   207: dup
/*      */     //   208: iconst_2
/*      */     //   209: ldc_w 969
/*      */     //   212: aastore
/*      */     //   213: invokevirtual 237	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   216: checkcast 915	java/awt/Cursor
/*      */     //   219: astore 7
/*      */     //   221: aload_0
/*      */     //   222: aload 7
/*      */     //   224: invokevirtual 920	processing/core/PApplet:setCursor	(Ljava/awt/Cursor;)V
/*      */     //   227: aload_0
/*      */     //   228: iconst_1
/*      */     //   229: putfield 922	processing/core/PApplet:cursor_visible	Z
/*      */     //   232: goto +78 -> 310
/*      */     //   235: astore 6
/*      */     //   237: getstatic 588	java/lang/System:err	Ljava/io/PrintStream;
/*      */     //   240: new 373	java/lang/StringBuffer
/*      */     //   243: dup
/*      */     //   244: ldc_w 973
/*      */     //   247: invokespecial 378	java/lang/StringBuffer:<init>	(Ljava/lang/String;)V
/*      */     //   250: getstatic 932	processing/core/PApplet:javaVersionName	Ljava/lang/String;
/*      */     //   253: invokevirtual 382	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   256: invokevirtual 391	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*      */     //   259: invokevirtual 582	java/io/PrintStream:println	(Ljava/lang/String;)V
/*      */     //   262: goto +48 -> 310
/*      */     //   265: astore 6
/*      */     //   267: getstatic 588	java/lang/System:err	Ljava/io/PrintStream;
/*      */     //   270: new 373	java/lang/StringBuffer
/*      */     //   273: dup
/*      */     //   274: ldc_w 977
/*      */     //   277: invokespecial 378	java/lang/StringBuffer:<init>	(Ljava/lang/String;)V
/*      */     //   280: aload 5
/*      */     //   282: invokevirtual 387	java/lang/StringBuffer:append	(Ljava/lang/Object;)Ljava/lang/StringBuffer;
/*      */     //   285: ldc_w 979
/*      */     //   288: invokevirtual 382	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   291: invokevirtual 391	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*      */     //   294: invokevirtual 582	java/io/PrintStream:println	(Ljava/lang/String;)V
/*      */     //   297: goto +13 -> 310
/*      */     //   300: astore 6
/*      */     //   302: getstatic 588	java/lang/System:err	Ljava/io/PrintStream;
/*      */     //   305: aload 6
/*      */     //   307: invokevirtual 981	java/io/PrintStream:println	(Ljava/lang/Object;)V
/*      */     //   310: return
/*      */     //
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   91	232	235	java/lang/NoSuchMethodError
/*      */     //   91	232	265	java/lang/IndexOutOfBoundsException
/*      */     //   91	232	300	java/lang/Exception } 
/*      */   public void cursor() { if (!(this.cursor_visible)) {
/* 1998 */       this.cursor_visible = true;
/* 1999 */       setCursor(Cursor.getPredefinedCursor(this.cursor_type));
/*      */     }
/*      */   }
/*      */ 
/*      */   public void noCursor()
/*      */   {
/* 2009 */     if (!(this.cursor_visible)) return;
/*      */ 
/* 2011 */     if (this.invisible_cursor == null) {
/* 2012 */       this.invisible_cursor = new PImage(new int[256], 16, 16, 2);
/*      */     }
/*      */ 
/* 2016 */     cursor(this.invisible_cursor, 0, 0);
/* 2017 */     this.cursor_visible = false;
/*      */   }
/*      */ 
/*      */   public static void print(byte paramByte)
/*      */   {
/* 2025 */     System.out.print(paramByte);
/* 2026 */     System.out.flush();
/*      */   }
/*      */ 
/*      */   public static void print(boolean paramBoolean) {
/* 2030 */     System.out.print(paramBoolean);
/* 2031 */     System.out.flush();
/*      */   }
/*      */ 
/*      */   public static void print(char paramChar) {
/* 2035 */     System.out.print(paramChar);
/* 2036 */     System.out.flush();
/*      */   }
/*      */ 
/*      */   public static void print(int paramInt) {
/* 2040 */     System.out.print(paramInt);
/* 2041 */     System.out.flush();
/*      */   }
/*      */ 
/*      */   public static void print(float paramFloat) {
/* 2045 */     System.out.print(paramFloat);
/* 2046 */     System.out.flush();
/*      */   }
/*      */ 
/*      */   public static void print(double paramDouble) {
/* 2050 */     System.out.print(paramDouble);
/* 2051 */     System.out.flush();
/*      */   }
/*      */ 
/*      */   public static void print(String paramString) {
/* 2055 */     System.out.print(paramString);
/* 2056 */     System.out.flush();
/*      */   }
/*      */ 
/*      */   public static void print(Object paramObject) {
/* 2060 */     if (paramObject == null)
/*      */     {
/* 2062 */       System.out.print("null");
/*      */     }
/*      */     else {
/* 2065 */       String str = paramObject.getClass().getName();
/* 2066 */       if (str.charAt(0) == '[')
/* 2067 */         switch (str.charAt(1))
/*      */         {
/*      */         case '[':
/* 2071 */           System.out.print(paramObject);
/* 2072 */           System.out.print(' ');
/* 2073 */           break;
/*      */         case 'L':
/* 2077 */           Object[] arrayOfObject = (Object[])paramObject;
/* 2078 */           for (int i = 0; i < arrayOfObject.length; ++i) {
/* 2079 */             System.out.print(arrayOfObject[i]);
/* 2080 */             System.out.print(' ');
/*      */           }
/* 2082 */           break;
/*      */         case 'Z':
/* 2085 */           boolean[] arrayOfBoolean = (boolean[])paramObject;
/* 2086 */           for (int j = 0; j < arrayOfBoolean.length; ++j) {
/* 2087 */             System.out.print(arrayOfBoolean[j]);
/* 2088 */             System.out.print(' ');
/*      */           }
/* 2090 */           break;
/*      */         case 'B':
/* 2093 */           byte[] arrayOfByte = (byte[])paramObject;
/* 2094 */           for (int k = 0; k < arrayOfByte.length; ++k) {
/* 2095 */             System.out.print(arrayOfByte[k]);
/* 2096 */             System.out.print(' ');
/*      */           }
/* 2098 */           break;
/*      */         case 'C':
/* 2101 */           char[] arrayOfChar = (char[])paramObject;
/* 2102 */           for (int l = 0; l < arrayOfChar.length; ++l) {
/* 2103 */             System.out.print(arrayOfChar[l]);
/* 2104 */             System.out.print(' ');
/*      */           }
/* 2106 */           break;
/*      */         case 'I':
/* 2109 */           int[] arrayOfInt = (int[])paramObject;
/* 2110 */           for (int i1 = 0; i1 < arrayOfInt.length; ++i1) {
/* 2111 */             System.out.print(arrayOfInt[i1]);
/* 2112 */             System.out.print(' ');
/*      */           }
/* 2114 */           break;
/*      */         case 'F':
/* 2117 */           float[] arrayOfFloat = (float[])paramObject;
/* 2118 */           for (int i2 = 0; i2 < arrayOfFloat.length; ++i2) {
/* 2119 */             System.out.print(arrayOfFloat[i2]);
/* 2120 */             System.out.print(' ');
/*      */           }
/* 2122 */           break;
/*      */         case 'D':
/* 2125 */           double[] arrayOfDouble = (double[])paramObject;
/* 2126 */           for (int i3 = 0; i3 < arrayOfDouble.length; ++i3) {
/* 2127 */             System.out.print(arrayOfDouble[i3]);
/* 2128 */             System.out.print(' ');
/*      */           }
/* 2130 */           break;
/*      */         default:
/* 2133 */           System.out.print(paramObject);
/*      */         }
/*      */       else
/* 2136 */         System.out.print(paramObject);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void println()
/*      */   {
/* 2144 */     System.out.println();
/*      */   }
/*      */ 
/*      */   public static void println(byte paramByte)
/*      */   {
/* 2150 */     print(paramByte); System.out.println();
/*      */   }
/*      */ 
/*      */   public static void println(boolean paramBoolean) {
/* 2154 */     print(paramBoolean); System.out.println();
/*      */   }
/*      */ 
/*      */   public static void println(char paramChar) {
/* 2158 */     print(paramChar); System.out.println();
/*      */   }
/*      */ 
/*      */   public static void println(int paramInt) {
/* 2162 */     print(paramInt); System.out.println();
/*      */   }
/*      */ 
/*      */   public static void println(float paramFloat) {
/* 2166 */     print(paramFloat); System.out.println();
/*      */   }
/*      */ 
/*      */   public static void println(double paramDouble) {
/* 2170 */     print(paramDouble); System.out.println();
/*      */   }
/*      */ 
/*      */   public static void println(String paramString) {
/* 2174 */     print(paramString); System.out.println();
/*      */   }
/*      */ 
/*      */   public static void println(Object paramObject) {
/* 2178 */     if (paramObject == null)
/*      */     {
/* 2180 */       System.out.println("null");
/*      */     }
/*      */     else {
/* 2183 */       String str = paramObject.getClass().getName();
/* 2184 */       if (str.charAt(0) == '[')
/* 2185 */         switch (str.charAt(1))
/*      */         {
/*      */         case '[':
/* 2189 */           System.out.println(paramObject);
/* 2190 */           break;
/*      */         case 'L':
/* 2194 */           Object[] arrayOfObject = (Object[])paramObject;
/* 2195 */           for (int i = 0; i < arrayOfObject.length; ++i) {
/* 2196 */             System.out.println(arrayOfObject[i]);
/*      */           }
/* 2198 */           break;
/*      */         case 'Z':
/* 2201 */           boolean[] arrayOfBoolean = (boolean[])paramObject;
/* 2202 */           for (int j = 0; j < arrayOfBoolean.length; ++j) {
/* 2203 */             System.out.println(arrayOfBoolean[j]);
/*      */           }
/* 2205 */           break;
/*      */         case 'B':
/* 2208 */           byte[] arrayOfByte = (byte[])paramObject;
/* 2209 */           for (int k = 0; k < arrayOfByte.length; ++k) {
/* 2210 */             System.out.println(arrayOfByte[k]);
/*      */           }
/* 2212 */           break;
/*      */         case 'C':
/* 2215 */           char[] arrayOfChar = (char[])paramObject;
/* 2216 */           for (int l = 0; l < arrayOfChar.length; ++l) {
/* 2217 */             System.out.println(arrayOfChar[l]);
/*      */           }
/* 2219 */           break;
/*      */         case 'I':
/* 2222 */           int[] arrayOfInt = (int[])paramObject;
/* 2223 */           for (int i1 = 0; i1 < arrayOfInt.length; ++i1) {
/* 2224 */             System.out.println(arrayOfInt[i1]);
/*      */           }
/* 2226 */           break;
/*      */         case 'F':
/* 2229 */           float[] arrayOfFloat = (float[])paramObject;
/* 2230 */           for (int i2 = 0; i2 < arrayOfFloat.length; ++i2) {
/* 2231 */             System.out.println(arrayOfFloat[i2]);
/*      */           }
/* 2233 */           break;
/*      */         case 'D':
/* 2236 */           double[] arrayOfDouble = (double[])paramObject;
/* 2237 */           for (int i3 = 0; i3 < arrayOfDouble.length; ++i3) {
/* 2238 */             System.out.println(arrayOfDouble[i3]);
/*      */           }
/* 2240 */           break;
/*      */         default:
/* 2243 */           System.out.println(paramObject);
/*      */         }
/*      */       else
/* 2246 */         System.out.println(paramObject);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static final float abs(float paramFloat)
/*      */   {
/* 2319 */     return ((paramFloat < 0.0F) ? -paramFloat : paramFloat);
/*      */   }
/*      */ 
/*      */   public static final int abs(int paramInt) {
/* 2323 */     return ((paramInt < 0) ? -paramInt : paramInt);
/*      */   }
/*      */ 
/*      */   public static final float sq(float paramFloat) {
/* 2327 */     return (paramFloat * paramFloat);
/*      */   }
/*      */ 
/*      */   public static final float sqrt(float paramFloat) {
/* 2331 */     return (float)Math.sqrt(paramFloat);
/*      */   }
/*      */ 
/*      */   public static final float log(float paramFloat) {
/* 2335 */     return (float)Math.log(paramFloat);
/*      */   }
/*      */ 
/*      */   public static final float exp(float paramFloat) {
/* 2339 */     return (float)Math.exp(paramFloat);
/*      */   }
/*      */ 
/*      */   public static final float pow(float paramFloat1, float paramFloat2) {
/* 2343 */     return (float)Math.pow(paramFloat1, paramFloat2);
/*      */   }
/*      */ 
/*      */   public static final float max(float paramFloat1, float paramFloat2)
/*      */   {
/* 2348 */     return Math.max(paramFloat1, paramFloat2);
/*      */   }
/*      */ 
/*      */   public static final float max(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 2352 */     return Math.max(paramFloat1, Math.max(paramFloat2, paramFloat3));
/*      */   }
/*      */ 
/*      */   public static final float min(float paramFloat1, float paramFloat2) {
/* 2356 */     return Math.min(paramFloat1, paramFloat2);
/*      */   }
/*      */ 
/*      */   public static final float min(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 2360 */     return Math.min(paramFloat1, Math.min(paramFloat2, paramFloat3));
/*      */   }
/*      */ 
/*      */   public static final float lerp(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 2365 */     return (paramFloat1 + (paramFloat2 - paramFloat1) * paramFloat3);
/*      */   }
/*      */ 
/*      */   public static final float constrain(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 2369 */     return ((paramFloat1 > paramFloat3) ? paramFloat3 : (paramFloat1 < paramFloat2) ? paramFloat2 : paramFloat1);
/*      */   }
/*      */ 
/*      */   public static final int max(int paramInt1, int paramInt2)
/*      */   {
/* 2374 */     return ((paramInt1 > paramInt2) ? paramInt1 : paramInt2);
/*      */   }
/*      */ 
/*      */   public static final int max(int paramInt1, int paramInt2, int paramInt3) {
/* 2378 */     return ((paramInt2 > paramInt3) ? paramInt2 : (paramInt1 > paramInt2) ? (paramInt1 > paramInt3) ? paramInt1 : paramInt3 : paramInt3);
/*      */   }
/*      */ 
/*      */   public static final int min(int paramInt1, int paramInt2) {
/* 2382 */     return ((paramInt1 < paramInt2) ? paramInt1 : paramInt2);
/*      */   }
/*      */ 
/*      */   public static final int min(int paramInt1, int paramInt2, int paramInt3) {
/* 2386 */     return ((paramInt2 < paramInt3) ? paramInt2 : (paramInt1 < paramInt2) ? (paramInt1 < paramInt3) ? paramInt1 : paramInt3 : paramInt3);
/*      */   }
/*      */ 
/*      */   public static final int constrain(int paramInt1, int paramInt2, int paramInt3) {
/* 2390 */     return ((paramInt1 > paramInt3) ? paramInt3 : (paramInt1 < paramInt2) ? paramInt2 : paramInt1);
/*      */   }
/*      */ 
/*      */   public final float sin(float paramFloat)
/*      */   {
/* 2396 */     return (float)Math.sin(paramFloat);
/*      */   }
/*      */ 
/*      */   public final float cos(float paramFloat)
/*      */   {
/* 2401 */     return (float)Math.cos(paramFloat);
/*      */   }
/*      */ 
/*      */   public final float tan(float paramFloat)
/*      */   {
/* 2406 */     return (float)Math.tan(paramFloat);
/*      */   }
/*      */ 
/*      */   public final float asin(float paramFloat)
/*      */   {
/* 2413 */     return (float)Math.asin(paramFloat);
/*      */   }
/*      */ 
/*      */   public final float acos(float paramFloat)
/*      */   {
/* 2419 */     return (float)Math.acos(paramFloat);
/*      */   }
/*      */ 
/*      */   public final float atan(float paramFloat)
/*      */   {
/* 2425 */     return (float)Math.atan(paramFloat);
/*      */   }
/*      */ 
/*      */   public final float atan2(float paramFloat1, float paramFloat2)
/*      */   {
/* 2431 */     return (float)Math.atan2(paramFloat1, paramFloat2);
/*      */   }
/*      */ 
/*      */   public static final float degrees(float paramFloat)
/*      */   {
/* 2436 */     return (paramFloat * 57.295776F);
/*      */   }
/*      */ 
/*      */   public static final float radians(float paramFloat) {
/* 2440 */     return (paramFloat * 0.01745329F);
/*      */   }
/*      */ 
/*      */   public static final int ceil(float paramFloat)
/*      */   {
/* 2445 */     return (int)Math.ceil(paramFloat);
/*      */   }
/*      */ 
/*      */   public static final int floor(float paramFloat) {
/* 2449 */     return (int)Math.floor(paramFloat);
/*      */   }
/*      */ 
/*      */   public static final int round(float paramFloat) {
/* 2453 */     return Math.round(paramFloat);
/*      */   }
/*      */ 
/*      */   public static final float mag(float paramFloat1, float paramFloat2)
/*      */   {
/* 2458 */     return (float)Math.sqrt(paramFloat1 * paramFloat1 + paramFloat2 * paramFloat2);
/*      */   }
/*      */ 
/*      */   public static final float mag(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 2462 */     return (float)Math.sqrt(paramFloat1 * paramFloat1 + paramFloat2 * paramFloat2 + paramFloat3 * paramFloat3);
/*      */   }
/*      */ 
/*      */   public static final float dist(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 2467 */     return sqrt(sq(paramFloat3 - paramFloat1) + sq(paramFloat4 - paramFloat2));
/*      */   }
/*      */ 
/*      */   public static final float dist(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/* 2472 */     return sqrt(sq(paramFloat4 - paramFloat1) + sq(paramFloat5 - paramFloat2) + sq(paramFloat6 - paramFloat3));
/*      */   }
/*      */ 
/*      */   public final float random(float paramFloat)
/*      */   {
/* 2496 */     if (paramFloat == 0.0F) return 0.0F;
/*      */ 
/* 2499 */     if (this.internalRandom == null) this.internalRandom = new Random();
/*      */ 
/* 2501 */     float f = 0.0F;
/*      */     do
/*      */     {
/* 2504 */       f = this.internalRandom.nextFloat() * paramFloat; }
/* 2505 */     while (f == paramFloat);
/* 2506 */     return f;
/*      */   }
/*      */ 
/*      */   public final float random(float paramFloat1, float paramFloat2)
/*      */   {
/* 2521 */     if (paramFloat1 >= paramFloat2) return paramFloat1;
/* 2522 */     float f = paramFloat2 - paramFloat1;
/* 2523 */     return (random(f) + paramFloat1);
/*      */   }
/*      */ 
/*      */   public final void randomSeed(long paramLong)
/*      */   {
/* 2529 */     if (this.internalRandom == null) this.internalRandom = new Random();
/* 2530 */     this.internalRandom.setSeed(paramLong);
/*      */   }
/*      */ 
/*      */   public float noise(float paramFloat)
/*      */   {
/* 2573 */     return noise(paramFloat, 0.0F, 0.0F);
/*      */   }
/*      */ 
/*      */   public float noise(float paramFloat1, float paramFloat2)
/*      */   {
/* 2580 */     return noise(paramFloat1, paramFloat2, 0.0F);
/*      */   }
/*      */ 
/*      */   public float noise(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 2587 */     if (this.perlin == null) {
/* 2588 */       if (this.perlinRandom == null) {
/* 2589 */         this.perlinRandom = new Random();
/*      */       }
/* 2591 */       this.perlin = new float[4096];
/* 2592 */       for (i = 0; i < 4096; ++i) {
/* 2593 */         this.perlin[i] = this.perlinRandom.nextFloat();
/*      */       }
/*      */ 
/* 2598 */       this.perlin_cosTable = PGraphics.cosLUT;
/* 2599 */       this.perlin_TWOPI = (this.perlin_PI = 720);
/* 2600 */       this.perlin_PI >>= 1;
/*      */     }
/*      */ 
/* 2603 */     if (paramFloat1 < 0.0F) paramFloat1 = -paramFloat1;
/* 2604 */     if (paramFloat2 < 0.0F) paramFloat2 = -paramFloat2;
/* 2605 */     if (paramFloat3 < 0.0F) paramFloat3 = -paramFloat3;
/*      */ 
/* 2607 */     int i = (int)paramFloat1; int j = (int)paramFloat2; int k = (int)paramFloat3;
/* 2608 */     float f1 = paramFloat1 - i;
/* 2609 */     float f2 = paramFloat2 - j;
/* 2610 */     float f3 = paramFloat3 - k;
/*      */ 
/* 2613 */     float f6 = 0.0F;
/* 2614 */     float f7 = 0.5F;
/*      */ 
/* 2618 */     for (int l = 0; l < this.perlin_octaves; ++l) {
/* 2619 */       int i1 = i + (j << 4) + (k << 8);
/*      */ 
/* 2621 */       float f4 = noise_fsc(f1);
/* 2622 */       float f5 = noise_fsc(f2);
/*      */ 
/* 2624 */       float f8 = this.perlin[(i1 & 0xFFF)];
/* 2625 */       f8 += f4 * (this.perlin[(i1 + 1 & 0xFFF)] - f8);
/* 2626 */       float f9 = this.perlin[(i1 + 16 & 0xFFF)];
/* 2627 */       f9 += f4 * (this.perlin[(i1 + 16 + 1 & 0xFFF)] - f9);
/* 2628 */       f8 += f5 * (f9 - f8);
/*      */ 
/* 2630 */       i1 += 256;
/* 2631 */       f9 = this.perlin[(i1 & 0xFFF)];
/* 2632 */       f9 += f4 * (this.perlin[(i1 + 1 & 0xFFF)] - f9);
/* 2633 */       float f10 = this.perlin[(i1 + 16 & 0xFFF)];
/* 2634 */       f10 += f4 * (this.perlin[(i1 + 16 + 1 & 0xFFF)] - f10);
/* 2635 */       f9 += f5 * (f10 - f9);
/*      */ 
/* 2637 */       f8 += noise_fsc(f3) * (f9 - f8);
/*      */ 
/* 2639 */       f6 += f8 * f7;
/* 2640 */       f7 *= this.perlin_amp_falloff;
/* 2641 */       i <<= 1; f1 *= 2.0F;
/* 2642 */       j <<= 1; f2 *= 2.0F;
/* 2643 */       k <<= 1; f3 *= 2.0F;
/*      */ 
/* 2645 */       if (f1 >= 1.0F) { ++i; f1 -= 1.0F; }
/* 2646 */       if (f2 >= 1.0F) { ++j; f2 -= 1.0F; }
/* 2647 */       if (f3 < 1.0F) continue; ++k; f3 -= 1.0F;
/*      */     }
/* 2649 */     return f6;
/*      */   }
/*      */ 
/*      */   private final float noise_fsc(float paramFloat)
/*      */   {
/* 2657 */     return (0.5F * (1.0F - this.perlin_cosTable[((int)(paramFloat * this.perlin_PI) % this.perlin_TWOPI)]));
/*      */   }
/*      */ 
/*      */   public void noiseDetail(int paramInt)
/*      */   {
/* 2666 */     if (paramInt <= 0) return; this.perlin_octaves = paramInt;
/*      */   }
/*      */ 
/*      */   public void noiseDetail(int paramInt, float paramFloat) {
/* 2670 */     if (paramInt > 0) this.perlin_octaves = paramInt;
/* 2671 */     if (paramFloat <= 0.0F) return; this.perlin_amp_falloff = paramFloat;
/*      */   }
/*      */ 
/*      */   public void noiseSeed(long paramLong) {
/* 2675 */     if (this.perlinRandom == null) this.perlinRandom = new Random();
/* 2676 */     this.perlinRandom.setSeed(paramLong);
/*      */   }
/*      */ 
/*      */   public PSound loadSound(String paramString)
/*      */   {
/* 2687 */     if (javaVersion >= 1.3F) {
/* 2688 */       return new PSound2(this, openStream(paramString));
/*      */     }
/* 2690 */     return new PSound(this, openStream(paramString));
/*      */   }
/*      */ 
/*      */   public PImage loadImage(String paramString)
/*      */   {
/* 2701 */     if (paramString.toLowerCase().endsWith(".tga")) {
/* 2702 */       return loadImageTGA(paramString);
/*      */     }
/* 2704 */     return loadImage(paramString, true);
/*      */   }
/*      */ 
/*      */   public PImage loadImage(String paramString, boolean paramBoolean)
/*      */   {
/* 2710 */     Image localImage = Toolkit.getDefaultToolkit().createImage(loadBytes(paramString));
/*      */ 
/* 2713 */     MediaTracker localMediaTracker = new MediaTracker(this);
/* 2714 */     localMediaTracker.addImage(localImage, 0);
/*      */     try {
/* 2716 */       localMediaTracker.waitForAll();
/*      */     }
/*      */     catch (InterruptedException localInterruptedException)
/*      */     {
/*      */     }
/*      */ 
/* 2723 */     PImage localPImage = new PImage(localImage);
/*      */ 
/* 2726 */     if (paramString.toLowerCase().endsWith(".gif")) {
/* 2727 */       for (int i = 0; i < localPImage.pixels.length; ++i)
/*      */       {
/* 2730 */         if ((localPImage.pixels[i] & 0xFF000000) != -16777216) {
/* 2731 */           localPImage.format = 2;
/*      */         }
/*      */       }
/*      */     }
/* 2735 */     return localPImage;
/*      */   }
/*      */ 
/*      */   protected PImage loadImageTGA(String paramString)
/*      */   {
/* 2747 */     byte[] arrayOfByte = loadBytes(paramString);
/*      */ 
/* 2750 */     if ((arrayOfByte[2] == 2) && (arrayOfByte[17] == 8))
/*      */     {
/* 2753 */       int i = ((arrayOfByte[13] & 0xFF) << 8) + (arrayOfByte[12] & 0xFF);
/*      */ 
/* 2755 */       int j = ((arrayOfByte[15] & 0xFF) << 8) + (arrayOfByte[14] & 0xFF);
/*      */ 
/* 2757 */       if (arrayOfByte[16] == 32) 0; int k = 1;
/*      */ 
/* 2760 */       PImage localPImage = new PImage(i, j);
/* 2761 */       localPImage.format = (k + 1);
/*      */ 
/* 2764 */       int l = (j - 1) * i;
/*      */ 
/* 2766 */       int i1 = 18;
/*      */ 
/* 2769 */       int i2 = j - 1; break label223:
/*      */       while (true) { for (int i3 = 0; i3 < i; ++i3) {
/* 2771 */           localPImage.pixels[(l + i3)] = (arrayOfByte[(i1++)] & 0xFF | (arrayOfByte[(i1++)] & 0xFF) << 8 | (arrayOfByte[(i1++)] & 0xFF) << 16 | ((k != 0) ? (arrayOfByte[(i1++)] & 0xFF) << 24 : -16777216));
/*      */         }
/*      */ 
/* 2777 */         l -= i;
/*      */ 
/* 2769 */         --i2; if (i2 < 0)
/*      */         {
/* 2779 */           label223: return localPImage; } }
/*      */     }
/* 2781 */     die("loadImage(): bad targa image format");
/* 2782 */     return null;
/*      */   }
/*      */ 
/*      */   public PFont loadFont(String paramString)
/*      */   {
/*      */     try
/*      */     {
/* 2798 */       String str = paramString.toLowerCase();
/* 2799 */       Object localObject = openStream(paramString);
/*      */ 
/* 2801 */       if (str.endsWith(".vlw.gz")) {
/* 2802 */         localObject = new GZIPInputStream((InputStream)localObject);
/*      */       }
/* 2804 */       else if (!(str.endsWith(".vlw")))
/*      */       {
/* 2806 */         throw new IOException("I don't know how to load a font named " + paramString);
/*      */       }
/*      */ 
/* 2809 */       return new PFont((InputStream)localObject);
/*      */     }
/*      */     catch (Exception localException) {
/* 2812 */       die("Could not load font " + paramString + "\nMake sure that the font has been copied\nto the data folder of your sketch.", localException);
/*      */     }
/*      */ 
/* 2816 */     return ((PFont)null);
/*      */   }
/*      */ 
/*      */   public PFont createFont(String paramString, float paramFloat)
/*      */   {
/* 2821 */     return createFont(paramString, paramFloat, true, PFont.DEFAULT_CHARSET);
/*      */   }
/*      */ 
/*      */   public PFont createFont(String paramString, float paramFloat, boolean paramBoolean)
/*      */   {
/* 2826 */     return createFont(paramString, paramFloat, paramBoolean, PFont.DEFAULT_CHARSET); } 
/*      */   // ERROR //
/*      */   public PFont createFont(String paramString, float paramFloat, boolean paramBoolean, char[] paramArrayOfChar) { // Byte code:
/*      */     //   0: getstatic 203	processing/core/PApplet:javaVersion	F
/*      */     //   3: ldc_w 286
/*      */     //   6: fcmpg
/*      */     //   7: ifge +14 -> 21
/*      */     //   10: new 440	java/lang/RuntimeException
/*      */     //   13: dup
/*      */     //   14: ldc_w 1258
/*      */     //   17: invokespecial 443	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
/*      */     //   20: athrow
/*      */     //   21: aload_1
/*      */     //   22: invokevirtual 1183	java/lang/String:toLowerCase	()Ljava/lang/String;
/*      */     //   25: astore 5
/*      */     //   27: aconst_null
/*      */     //   28: astore 6
/*      */     //   30: getstatic 1260	processing/core/PApplet:class$java$awt$Font	Ljava/lang/Class;
/*      */     //   33: dup
/*      */     //   34: ifnonnull +15 -> 49
/*      */     //   37: pop
/*      */     //   38: ldc_w 1262
/*      */     //   41: iconst_0
/*      */     //   42: invokestatic 212	processing/core/PApplet:class	(Ljava/lang/String;Z)Ljava/lang/Class;
/*      */     //   45: dup
/*      */     //   46: putstatic 1260	processing/core/PApplet:class$java$awt$Font	Ljava/lang/Class;
/*      */     //   49: ldc_w 1264
/*      */     //   52: iconst_1
/*      */     //   53: anewarray 216	java/lang/Class
/*      */     //   56: dup
/*      */     //   57: iconst_0
/*      */     //   58: getstatic 1267	java/lang/Float:TYPE	Ljava/lang/Class;
/*      */     //   61: aastore
/*      */     //   62: invokevirtual 225	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*      */     //   65: astore 7
/*      */     //   67: new 1266	java/lang/Float
/*      */     //   70: dup
/*      */     //   71: fload_2
/*      */     //   72: invokespecial 1269	java/lang/Float:<init>	(F)V
/*      */     //   75: astore 8
/*      */     //   77: aload 5
/*      */     //   79: ldc_w 1271
/*      */     //   82: invokevirtual 1189	java/lang/String:endsWith	(Ljava/lang/String;)Z
/*      */     //   85: ifne +14 -> 99
/*      */     //   88: aload 5
/*      */     //   90: ldc_w 1273
/*      */     //   93: invokevirtual 1189	java/lang/String:endsWith	(Ljava/lang/String;)Z
/*      */     //   96: ifeq +157 -> 253
/*      */     //   99: getstatic 1260	processing/core/PApplet:class$java$awt$Font	Ljava/lang/Class;
/*      */     //   102: dup
/*      */     //   103: ifnonnull +15 -> 118
/*      */     //   106: pop
/*      */     //   107: ldc_w 1262
/*      */     //   110: iconst_0
/*      */     //   111: invokestatic 212	processing/core/PApplet:class	(Ljava/lang/String;Z)Ljava/lang/Class;
/*      */     //   114: dup
/*      */     //   115: putstatic 1260	processing/core/PApplet:class$java$awt$Font	Ljava/lang/Class;
/*      */     //   118: ldc_w 1274
/*      */     //   121: iconst_2
/*      */     //   122: anewarray 216	java/lang/Class
/*      */     //   125: dup
/*      */     //   126: iconst_0
/*      */     //   127: getstatic 330	java/lang/Integer:TYPE	Ljava/lang/Class;
/*      */     //   130: aastore
/*      */     //   131: dup
/*      */     //   132: iconst_1
/*      */     //   133: getstatic 1276	processing/core/PApplet:class$java$io$InputStream	Ljava/lang/Class;
/*      */     //   136: dup
/*      */     //   137: ifnonnull +15 -> 152
/*      */     //   140: pop
/*      */     //   141: ldc_w 1278
/*      */     //   144: iconst_0
/*      */     //   145: invokestatic 212	processing/core/PApplet:class	(Ljava/lang/String;Z)Ljava/lang/Class;
/*      */     //   148: dup
/*      */     //   149: putstatic 1276	processing/core/PApplet:class$java$io$InputStream	Ljava/lang/Class;
/*      */     //   152: aastore
/*      */     //   153: invokevirtual 225	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*      */     //   156: astore 9
/*      */     //   158: getstatic 1260	processing/core/PApplet:class$java$awt$Font	Ljava/lang/Class;
/*      */     //   161: dup
/*      */     //   162: ifnonnull +15 -> 177
/*      */     //   165: pop
/*      */     //   166: ldc_w 1262
/*      */     //   169: iconst_0
/*      */     //   170: invokestatic 212	processing/core/PApplet:class	(Ljava/lang/String;Z)Ljava/lang/Class;
/*      */     //   173: dup
/*      */     //   174: putstatic 1260	processing/core/PApplet:class$java$awt$Font	Ljava/lang/Class;
/*      */     //   177: ldc_w 1280
/*      */     //   180: invokevirtual 1284	java/lang/Class:getField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
/*      */     //   183: astore 10
/*      */     //   185: new 329	java/lang/Integer
/*      */     //   188: dup
/*      */     //   189: aload 10
/*      */     //   191: aload 10
/*      */     //   193: invokevirtual 1290	java/lang/reflect/Field:getInt	(Ljava/lang/Object;)I
/*      */     //   196: invokespecial 456	java/lang/Integer:<init>	(I)V
/*      */     //   199: astore 11
/*      */     //   201: aload 9
/*      */     //   203: aload_1
/*      */     //   204: iconst_2
/*      */     //   205: anewarray 227	java/lang/Object
/*      */     //   208: dup
/*      */     //   209: iconst_0
/*      */     //   210: aload 11
/*      */     //   212: aastore
/*      */     //   213: dup
/*      */     //   214: iconst_1
/*      */     //   215: aload_0
/*      */     //   216: aload_1
/*      */     //   217: invokevirtual 1172	processing/core/PApplet:openStream	(Ljava/lang/String;)Ljava/io/InputStream;
/*      */     //   220: aastore
/*      */     //   221: invokevirtual 237	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   224: checkcast 529	java/awt/Font
/*      */     //   227: astore 12
/*      */     //   229: aload 7
/*      */     //   231: aload 12
/*      */     //   233: iconst_1
/*      */     //   234: anewarray 227	java/lang/Object
/*      */     //   237: dup
/*      */     //   238: iconst_0
/*      */     //   239: aload 8
/*      */     //   241: aastore
/*      */     //   242: invokevirtual 237	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   245: checkcast 529	java/awt/Font
/*      */     //   248: astore 6
/*      */     //   250: goto +36 -> 286
/*      */     //   253: new 529	java/awt/Font
/*      */     //   256: dup
/*      */     //   257: aload_1
/*      */     //   258: iconst_0
/*      */     //   259: iconst_1
/*      */     //   260: invokespecial 534	java/awt/Font:<init>	(Ljava/lang/String;II)V
/*      */     //   263: astore 9
/*      */     //   265: aload 7
/*      */     //   267: aload 9
/*      */     //   269: iconst_1
/*      */     //   270: anewarray 227	java/lang/Object
/*      */     //   273: dup
/*      */     //   274: iconst_0
/*      */     //   275: aload 8
/*      */     //   277: aastore
/*      */     //   278: invokevirtual 237	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   281: checkcast 529	java/awt/Font
/*      */     //   284: astore 6
/*      */     //   286: goto +35 -> 321
/*      */     //   289: astore 7
/*      */     //   291: aload 7
/*      */     //   293: invokevirtual 493	java/lang/Exception:printStackTrace	()V
/*      */     //   296: new 440	java/lang/RuntimeException
/*      */     //   299: dup
/*      */     //   300: new 373	java/lang/StringBuffer
/*      */     //   303: dup
/*      */     //   304: ldc_w 1292
/*      */     //   307: invokespecial 378	java/lang/StringBuffer:<init>	(Ljava/lang/String;)V
/*      */     //   310: aload_1
/*      */     //   311: invokevirtual 382	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   314: invokevirtual 391	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*      */     //   317: invokespecial 443	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
/*      */     //   320: athrow
/*      */     //   321: new 1242	processing/core/PFont
/*      */     //   324: dup
/*      */     //   325: aload 6
/*      */     //   327: iload_3
/*      */     //   328: aload 4
/*      */     //   330: invokespecial 1295	processing/core/PFont:<init>	(Ljava/awt/Font;Z[C)V
/*      */     //   333: areturn
/*      */     //
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   30	286	289	java/lang/Exception } 
/*      */   public File inputFile() { return inputFile("Select a file...");
/*      */   }
/*      */ 
/*      */   public File inputFile(String paramString)
/*      */   {
/* 2898 */     Frame localFrame = null;
/* 2899 */     Container localContainer = getParent();
/* 2900 */     while (localContainer != null) {
/* 2901 */       if (localContainer instanceof Frame) {
/* 2902 */         localFrame = (Frame)localContainer;
/* 2903 */         break;
/*      */       }
/* 2905 */       localContainer = localContainer.getParent();
/*      */     }
/* 2907 */     return inputFile(paramString, localFrame);
/*      */   }
/*      */ 
/*      */   public static File inputFile(Frame paramFrame)
/*      */   {
/* 2912 */     return inputFile("Select a file...", paramFrame);
/*      */   }
/*      */ 
/*      */   public static File inputFile(String paramString, Frame paramFrame)
/*      */   {
/* 2924 */     if (paramFrame == null) paramFrame = new Frame();
/* 2925 */     FileDialog localFileDialog = new FileDialog(paramFrame, paramString, 0);
/* 2926 */     localFileDialog.show();
/*      */ 
/* 2928 */     String str1 = localFileDialog.getDirectory();
/* 2929 */     String str2 = localFileDialog.getFile();
/* 2930 */     if (str2 == null) return null;
/* 2931 */     return new File(str1, str2);
/*      */   }
/*      */ 
/*      */   public File outputFile()
/*      */   {
/* 2936 */     return outputFile("Save as...");
/*      */   }
/*      */ 
/*      */   public File outputFile(String paramString)
/*      */   {
/* 2941 */     Frame localFrame = null;
/* 2942 */     Container localContainer = getParent();
/* 2943 */     while (localContainer != null)
/*      */     {
/* 2945 */       if (localContainer instanceof Frame) {
/* 2946 */         localFrame = (Frame)localContainer;
/* 2947 */         break;
/*      */       }
/* 2949 */       localContainer = localContainer.getParent();
/*      */     }
/* 2951 */     return outputFile(paramString, this.frame);
/*      */   }
/*      */ 
/*      */   public static File outputFile(Frame paramFrame)
/*      */   {
/* 2957 */     return outputFile("Save as...", paramFrame);
/*      */   }
/*      */ 
/*      */   public static File outputFile(String paramString, Frame paramFrame)
/*      */   {
/* 2968 */     if (paramFrame == null) paramFrame = new Frame();
/* 2969 */     FileDialog localFileDialog = new FileDialog(paramFrame, paramString, 1);
/* 2970 */     localFileDialog.show();
/*      */ 
/* 2972 */     String str1 = localFileDialog.getDirectory();
/* 2973 */     String str2 = localFileDialog.getFile();
/* 2974 */     if (str2 == null) return null;
/* 2975 */     return new File(str1, str2);
/*      */   }
/*      */ 
/*      */   public BufferedReader reader(String paramString)
/*      */   {
/*      */     try
/*      */     {
/* 2985 */       return reader(openStream(paramString));
/*      */     }
/*      */     catch (Exception localException) {
/* 2988 */       if (paramString == null)
/* 2989 */         die("Filename passed to reader() was null", localException);
/*      */       else {
/* 2991 */         die("Couldn't create a reader for " + paramString, localException);
/*      */       }
/*      */     }
/* 2994 */     return null;
/*      */   }
/*      */ 
/*      */   public static BufferedReader reader(File paramFile)
/*      */   {
/*      */     try
/*      */     {
/* 3003 */       return reader(new FileInputStream(paramFile));
/*      */     }
/*      */     catch (Exception localException) {
/* 3006 */       if (paramFile == null) {
/* 3007 */         throw new RuntimeException("File passed to reader() was null");
/*      */       }
/* 3009 */       localException.printStackTrace();
/* 3010 */       throw new RuntimeException("Couldn't create a reader for " + paramFile.getAbsolutePath());
/*      */     }
/*      */   }
/*      */ 
/*      */   public static BufferedReader reader(InputStream paramInputStream)
/*      */   {
/* 3023 */     InputStreamReader localInputStreamReader = new InputStreamReader(paramInputStream);
/* 3024 */     return new BufferedReader(localInputStreamReader);
/*      */   }
/*      */ 
/*      */   public static InputStream gzipInput(InputStream paramInputStream)
/*      */   {
/*      */     try
/*      */     {
/* 3033 */       return new GZIPInputStream(paramInputStream);
/*      */     } catch (IOException localIOException) {
/* 3035 */       localIOException.printStackTrace();
/* 3036 */       throw new RuntimeException("Problem with gzip input");
/*      */     }
/*      */   }
/*      */ 
/*      */   public static OutputStream gzipOutput(OutputStream paramOutputStream)
/*      */   {
/*      */     try
/*      */     {
/* 3047 */       return new GZIPOutputStream(paramOutputStream);
/*      */     } catch (IOException localIOException) {
/* 3049 */       localIOException.printStackTrace();
/* 3050 */       throw new RuntimeException("Problem with gzip output");
/*      */     }
/*      */   }
/*      */ 
/*      */   public PrintWriter writer(String paramString)
/*      */   {
/*      */     try
/*      */     {
/* 3061 */       return writer(new FileOutputStream(savePath(paramString)));
/*      */     }
/*      */     catch (Exception localException) {
/* 3064 */       if (paramString == null)
/* 3065 */         die("Filename passed to writer() was null", localException);
/*      */       else {
/* 3067 */         die("Couldn't create a writer for " + paramString, localException);
/*      */       }
/*      */     }
/* 3070 */     return null;
/*      */   }
/*      */ 
/*      */   public static PrintWriter writer(File paramFile)
/*      */   {
/*      */     try
/*      */     {
/* 3080 */       return writer(new FileOutputStream(paramFile));
/*      */     }
/*      */     catch (Exception localException) {
/* 3083 */       if (paramFile == null) {
/* 3084 */         throw new RuntimeException("File passed to writer() was null");
/*      */       }
/* 3086 */       localException.printStackTrace();
/* 3087 */       throw new RuntimeException("Couldn't create a writer for " + paramFile.getAbsolutePath());
/*      */     }
/*      */   }
/*      */ 
/*      */   public static PrintWriter writer(OutputStream paramOutputStream)
/*      */   {
/* 3100 */     OutputStreamWriter localOutputStreamWriter = new OutputStreamWriter(paramOutputStream);
/* 3101 */     return new PrintWriter(localOutputStreamWriter);
/*      */   }
/*      */ 
/*      */   public static InputStream openStream(File paramFile)
/*      */   {
/*      */     try {
/* 3107 */       return new FileInputStream(paramFile);
/*      */     }
/*      */     catch (IOException localIOException) {
/* 3110 */       if (paramFile == null) {
/* 3111 */         throw new RuntimeException("File passed to openStream() was null");
/*      */       }
/*      */ 
/* 3114 */       localIOException.printStackTrace();
/* 3115 */       throw new RuntimeException("Couldn't openStream() for " + paramFile.getAbsolutePath());
/*      */     }
/*      */   }
/*      */ 
/*      */   public InputStream openStream(String paramString)
/*      */   {
/* 3138 */     Object localObject1 = null;
/*      */     try
/*      */     {
/* 3141 */       URL localURL = new URL(paramString);
/* 3142 */       localObject1 = localURL.openStream();
/* 3143 */       return localObject1;
/*      */     }
/*      */     catch (MalformedURLException localMalformedURLException)
/*      */     {
/*      */     }
/*      */     catch (IOException localIOException1) {
/* 3149 */       throw new RuntimeException("Error downloading from URL " + paramString);
/*      */     }
/*      */     Object localObject2;
/* 3152 */     if (!(this.online))
/*      */       try {
/* 3154 */         localObject2 = this.folder + File.separator + "data";
/* 3155 */         File localFile = new File((String)localObject2, paramString);
/*      */         try
/*      */         {
/* 3158 */           String str1 = localFile.getCanonicalPath();
/* 3159 */           String str2 = new File(str1).getName();
/*      */ 
/* 3161 */           if (!(str2.equals(paramString))) {
/* 3162 */             throw new RuntimeException("This file is named " + str2 + " not " + paramString + '.');
/*      */           }
/*      */ 
/*      */         }
/*      */         catch (Exception localException2)
/*      */         {
/*      */         }
/*      */ 
/* 3175 */         localObject1 = new FileInputStream(localFile);
/* 3176 */         if (localObject1 != null) return localObject1;
/*      */       }
/*      */       catch (Exception localException3)
/*      */       {
/*      */       }
/*      */     try {
/* 3182 */       localObject1 = super.getClass().getResourceAsStream(paramString);
/* 3183 */       if (localObject1 != null) return localObject1;
/*      */ 
/* 3185 */       localObject1 = super.getClass().getResourceAsStream("data/" + paramString);
/* 3186 */       if (localObject1 != null) return localObject1;
/*      */ 
/*      */       try
/*      */       {
/* 3190 */         localObject2 = new File(this.folder, paramString);
/* 3191 */         localObject1 = new FileInputStream((File)localObject2);
/* 3192 */         if (localObject1 != null) return localObject1;
/*      */       }
/*      */       catch (Exception localException4)
/*      */       {
/*      */         try {
/* 3197 */           localObject1 = new FileInputStream(new File("data", paramString));
/* 3198 */           if (localObject1 != null) return localObject1;
/*      */         } catch (IOException localIOException2) {
/*      */         }
/*      */         try {
/* 3202 */           localObject1 = new FileInputStream(paramString);
/* 3203 */           if (localObject1 != null) return localObject1;  } catch (IOException localIOException3) {
/*      */         }
/* 3204 */         break label321:
/*      */       }
/*      */       catch (SecurityException localSecurityException) {
/*      */       }
/* 3208 */       if (localObject1 == null)
/* 3209 */         label321: throw new IOException("openStream() could not open " + paramString);
/*      */     }
/*      */     catch (Exception localException1) {
/* 3212 */       die(localException1.getMessage(), localException1);
/*      */     }
/* 3214 */     return ((InputStream)(InputStream)null);
/*      */   }
/*      */ 
/*      */   public byte[] loadBytes(String paramString)
/*      */   {
/* 3219 */     return loadBytes(openStream(paramString));
/*      */   }
/*      */ 
/*      */   public static byte[] loadBytes(InputStream paramInputStream)
/*      */   {
/*      */     try {
/* 3225 */       BufferedInputStream localBufferedInputStream = new BufferedInputStream(paramInputStream);
/* 3226 */       ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
/*      */ 
/* 3228 */       int i = localBufferedInputStream.read();
/* 3229 */       while (i != -1) {
/* 3230 */         localByteArrayOutputStream.write(i);
/* 3231 */         i = localBufferedInputStream.read();
/*      */       }
/* 3233 */       return localByteArrayOutputStream.toByteArray();
/*      */     }
/*      */     catch (IOException localIOException) {
/* 3236 */       localIOException.printStackTrace();
/* 3237 */       throw new RuntimeException("Couldn't load bytes from stream");
/*      */     }
/*      */   }
/*      */ 
/*      */   public static String[] loadStrings(File paramFile)
/*      */   {
/* 3244 */     InputStream localInputStream = openStream(paramFile);
/* 3245 */     if (localInputStream != null) return loadStrings(localInputStream);
/* 3246 */     return null;
/*      */   }
/*      */ 
/*      */   public String[] loadStrings(String paramString)
/*      */   {
/* 3251 */     InputStream localInputStream = openStream(paramString);
/* 3252 */     if (localInputStream != null) return loadStrings(localInputStream);
/*      */ 
/* 3254 */     die("Couldn't open " + paramString);
/* 3255 */     return null;
/*      */   }
/*      */ 
/*      */   public static String[] loadStrings(InputStream paramInputStream)
/*      */   {
/*      */     try {
/* 3261 */       BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(paramInputStream));
/*      */ 
/* 3264 */       Object localObject = new String[100];
/* 3265 */       int i = 0;
/* 3266 */       String str = null;
/* 3267 */       while ((str = localBufferedReader.readLine()) != null) {
/* 3268 */         if (i == localObject.length) {
/* 3269 */           arrayOfString = new String[i << 1];
/* 3270 */           System.arraycopy(localObject, 0, arrayOfString, 0, i);
/* 3271 */           localObject = arrayOfString;
/*      */         }
/* 3273 */         localObject[(i++)] = str;
/*      */       }
/* 3275 */       localBufferedReader.close();
/*      */ 
/* 3277 */       if (i == localObject.length) {
/* 3278 */         return localObject;
/*      */       }
/*      */ 
/* 3282 */       String[] arrayOfString = new String[i];
/* 3283 */       System.arraycopy(localObject, 0, arrayOfString, 0, i);
/* 3284 */       return arrayOfString;
/*      */     }
/*      */     catch (IOException localIOException) {
/* 3287 */       localIOException.printStackTrace();
/* 3288 */       throw new RuntimeException("Error inside loadStrings()");
/*      */     }
/*      */   }
/*      */ 
/*      */   public void saveBytes(String paramString, byte[] paramArrayOfByte)
/*      */   {
/*      */     try
/*      */     {
/* 3309 */       String str = savePath(paramString);
/* 3310 */       FileOutputStream localFileOutputStream = new FileOutputStream(str);
/* 3311 */       saveBytes(localFileOutputStream, paramArrayOfByte);
/* 3312 */       localFileOutputStream.close();
/*      */     }
/*      */     catch (IOException localIOException) {
/* 3315 */       System.err.println("error saving bytes to " + paramString);
/* 3316 */       localIOException.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void saveBytes(File paramFile, byte[] paramArrayOfByte)
/*      */   {
/*      */     try
/*      */     {
/* 3325 */       String str = paramFile.getAbsolutePath();
/* 3326 */       createPath(str);
/* 3327 */       FileOutputStream localFileOutputStream = new FileOutputStream(paramFile);
/* 3328 */       saveBytes(localFileOutputStream, paramArrayOfByte);
/* 3329 */       localFileOutputStream.close();
/*      */     }
/*      */     catch (IOException localIOException) {
/* 3332 */       System.err.println("error saving bytes to " + paramFile);
/* 3333 */       localIOException.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void saveBytes(OutputStream paramOutputStream, byte[] paramArrayOfByte)
/*      */   {
/*      */     try
/*      */     {
/* 3344 */       paramOutputStream.write(paramArrayOfByte);
/* 3345 */       paramOutputStream.flush();
/*      */     }
/*      */     catch (IOException localIOException) {
/* 3348 */       localIOException.printStackTrace();
/* 3349 */       throw new RuntimeException("Couldn't save bytes");
/*      */     }
/*      */   }
/*      */ 
/*      */   public void saveStrings(String paramString, String[] paramArrayOfString)
/*      */   {
/*      */     try
/*      */     {
/* 3357 */       String str = savePath(paramString);
/* 3358 */       FileOutputStream localFileOutputStream = new FileOutputStream(str);
/* 3359 */       saveStrings(localFileOutputStream, paramArrayOfString);
/* 3360 */       localFileOutputStream.close();
/*      */     }
/*      */     catch (IOException localIOException) {
/* 3363 */       localIOException.printStackTrace();
/* 3364 */       throw new RuntimeException("saveStrings() failed: " + localIOException.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void saveStrings(File paramFile, String[] paramArrayOfString)
/*      */   {
/*      */     try {
/* 3371 */       String str = paramFile.getAbsolutePath();
/* 3372 */       createPath(str);
/* 3373 */       FileOutputStream localFileOutputStream = new FileOutputStream(str);
/* 3374 */       saveStrings(localFileOutputStream, paramArrayOfString);
/* 3375 */       localFileOutputStream.close();
/*      */     }
/*      */     catch (IOException localIOException) {
/* 3378 */       System.err.println("error while saving strings");
/* 3379 */       localIOException.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void saveStrings(OutputStream paramOutputStream, String[] paramArrayOfString)
/*      */   {
/* 3385 */     PrintWriter localPrintWriter = new PrintWriter(new OutputStreamWriter(paramOutputStream));
/*      */ 
/* 3387 */     for (int i = 0; i < paramArrayOfString.length; ++i) {
/* 3388 */       localPrintWriter.println(paramArrayOfString[i]);
/*      */     }
/* 3390 */     localPrintWriter.flush();
/*      */   }
/*      */ 
/*      */   public String savePath(String paramString)
/*      */   {
/* 3404 */     String str = this.folder + File.separator + paramString;
/* 3405 */     createPath(str);
/* 3406 */     return str;
/*      */   }
/*      */ 
/*      */   public static void createPath(String paramString)
/*      */   {
/* 3414 */     File localFile1 = new File(paramString);
/* 3415 */     String str = localFile1.getParent();
/* 3416 */     if (str != null) {
/* 3417 */       File localFile2 = new File(str);
/* 3418 */       if (localFile2.exists()) return; localFile2.mkdirs();
/*      */     }
/*      */   }
/*      */ 
/*      */   public byte[] sort(byte[] paramArrayOfByte)
/*      */   {
/* 3443 */     return sort(paramArrayOfByte, paramArrayOfByte.length);
/*      */   }
/*      */ 
/*      */   public char[] sort(char[] paramArrayOfChar) {
/* 3447 */     return sort(paramArrayOfChar, paramArrayOfChar.length);
/*      */   }
/*      */ 
/*      */   public int[] sort(int[] paramArrayOfInt) {
/* 3451 */     return sort(paramArrayOfInt, paramArrayOfInt.length);
/*      */   }
/*      */ 
/*      */   public float[] sort(float[] paramArrayOfFloat) {
/* 3455 */     return sort(paramArrayOfFloat, paramArrayOfFloat.length);
/*      */   }
/*      */ 
/*      */   public String[] sort(String[] paramArrayOfString) {
/* 3459 */     return sort(paramArrayOfString, paramArrayOfString.length);
/*      */   }
/*      */ 
/*      */   public byte[] sort(byte[] paramArrayOfByte, int paramInt)
/*      */   {
/* 3465 */     if (paramInt == 0) return null;
/* 3466 */     this.sort_mode = 1;
/* 3467 */     this.sort_bytes = new byte[paramInt];
/* 3468 */     System.arraycopy(paramArrayOfByte, 0, this.sort_bytes, 0, paramInt);
/* 3469 */     sort_internal(0, paramInt - 1);
/* 3470 */     return this.sort_bytes;
/*      */   }
/*      */ 
/*      */   public char[] sort(char[] paramArrayOfChar, int paramInt) {
/* 3474 */     if (paramInt == 0) return null;
/* 3475 */     this.sort_mode = 2;
/* 3476 */     this.sort_chars = new char[paramInt];
/* 3477 */     System.arraycopy(paramArrayOfChar, 0, this.sort_chars, 0, paramInt);
/* 3478 */     sort_internal(0, paramInt - 1);
/* 3479 */     return this.sort_chars;
/*      */   }
/*      */ 
/*      */   public int[] sort(int[] paramArrayOfInt, int paramInt) {
/* 3483 */     if (paramInt == 0) return null;
/* 3484 */     this.sort_mode = 3;
/* 3485 */     this.sort_ints = new int[paramInt];
/* 3486 */     System.arraycopy(paramArrayOfInt, 0, this.sort_ints, 0, paramInt);
/* 3487 */     sort_internal(0, paramInt - 1);
/* 3488 */     return this.sort_ints;
/*      */   }
/*      */ 
/*      */   public float[] sort(float[] paramArrayOfFloat, int paramInt) {
/* 3492 */     if (paramInt == 0) return null;
/* 3493 */     this.sort_mode = 4;
/* 3494 */     this.sort_floats = new float[paramInt];
/* 3495 */     System.arraycopy(paramArrayOfFloat, 0, this.sort_floats, 0, paramInt);
/* 3496 */     sort_internal(0, paramInt - 1);
/* 3497 */     return this.sort_floats;
/*      */   }
/*      */ 
/*      */   public String[] sort(String[] paramArrayOfString, int paramInt) {
/* 3501 */     if (paramInt == 0) return null;
/* 3502 */     this.sort_mode = 5;
/* 3503 */     this.sort_strings = new String[paramInt];
/* 3504 */     System.arraycopy(paramArrayOfString, 0, this.sort_strings, 0, paramInt);
/* 3505 */     sort_internal(0, paramInt - 1);
/* 3506 */     return this.sort_strings;
/*      */   }
/*      */ 
/*      */   protected void sort_internal(int paramInt1, int paramInt2)
/*      */   {
/* 3512 */     int i = (paramInt1 + paramInt2) / 2;
/* 3513 */     sort_swap(i, paramInt2);
/* 3514 */     int j = sort_partition(paramInt1 - 1, paramInt2);
/* 3515 */     sort_swap(j, paramInt2);
/* 3516 */     if (j - paramInt1 > 1) sort_internal(paramInt1, j - 1);
/* 3517 */     if (paramInt2 - j <= 1) return; sort_internal(j + 1, paramInt2);
/*      */   }
/*      */ 
/*      */   protected int sort_partition(int paramInt1, int paramInt2)
/*      */   {
/* 3522 */     int i = paramInt2;
/*      */     do {
/* 3524 */       if (sort_compare(++paramInt1, i) >= 0);
/* 3525 */       while ((paramInt2 != 0) && (sort_compare(--paramInt2, i) > 0));
/* 3526 */       sort_swap(paramInt1, paramInt2); }
/* 3527 */     while (paramInt1 < paramInt2);
/* 3528 */     sort_swap(paramInt1, paramInt2);
/* 3529 */     return paramInt1;
/*      */   }
/*      */ 
/*      */   protected void sort_swap(int paramInt1, int paramInt2)
/*      */   {
/* 3534 */     switch (this.sort_mode)
/*      */     {
/*      */     case 1:
/* 3536 */       int i = this.sort_bytes[paramInt1];
/* 3537 */       this.sort_bytes[paramInt1] = this.sort_bytes[paramInt2];
/* 3538 */       this.sort_bytes[paramInt2] = i;
/* 3539 */       break;
/*      */     case 2:
/* 3541 */       int j = this.sort_chars[paramInt1];
/* 3542 */       this.sort_chars[paramInt1] = this.sort_chars[paramInt2];
/* 3543 */       this.sort_chars[paramInt2] = j;
/* 3544 */       break;
/*      */     case 3:
/* 3546 */       int k = this.sort_ints[paramInt1];
/* 3547 */       this.sort_ints[paramInt1] = this.sort_ints[paramInt2];
/* 3548 */       this.sort_ints[paramInt2] = k;
/* 3549 */       break;
/*      */     case 4:
/* 3551 */       float f = this.sort_floats[paramInt1];
/* 3552 */       this.sort_floats[paramInt1] = this.sort_floats[paramInt2];
/* 3553 */       this.sort_floats[paramInt2] = f;
/* 3554 */       break;
/*      */     case 5:
/* 3556 */       String str = this.sort_strings[paramInt1];
/* 3557 */       this.sort_strings[paramInt1] = this.sort_strings[paramInt2];
/* 3558 */       this.sort_strings[paramInt2] = str;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected int sort_compare(int paramInt1, int paramInt2)
/*      */   {
/* 3564 */     switch (this.sort_mode)
/*      */     {
/*      */     case 1:
/* 3566 */       return (this.sort_bytes[paramInt1] - this.sort_bytes[paramInt2]);
/*      */     case 2:
/* 3568 */       return (this.sort_chars[paramInt1] - this.sort_chars[paramInt2]);
/*      */     case 3:
/* 3570 */       return (this.sort_ints[paramInt1] - this.sort_ints[paramInt2]);
/*      */     case 4:
/* 3574 */       if (this.sort_floats[paramInt1] < this.sort_floats[paramInt2]) return -1;
/* 3575 */       if (this.sort_floats[paramInt1] == this.sort_floats[paramInt2]) 0; return (1 - 1);
/*      */     case 5:
/* 3577 */       return this.sort_strings[paramInt1].compareTo(this.sort_strings[paramInt2]);
/*      */     }
/* 3579 */     return 0;
/*      */   }
/*      */ 
/*      */   public static void arraycopy(Object paramObject1, int paramInt1, Object paramObject2, int paramInt2, int paramInt3)
/*      */   {
/* 3597 */     System.arraycopy(paramObject1, paramInt1, paramObject2, paramInt2, paramInt3);
/*      */   }
/*      */ 
/*      */   public static void arraycopy(Object paramObject1, Object paramObject2)
/*      */   {
/* 3607 */     System.arraycopy(paramObject1, 0, paramObject2, 0, Array.getLength(paramObject1));
/*      */   }
/*      */ 
/*      */   public static boolean[] expand(boolean[] paramArrayOfBoolean)
/*      */   {
/* 3612 */     return expand(paramArrayOfBoolean, paramArrayOfBoolean.length << 1);
/*      */   }
/*      */ 
/*      */   public static boolean[] expand(boolean[] paramArrayOfBoolean, int paramInt) {
/* 3616 */     boolean[] arrayOfBoolean = new boolean[paramInt];
/* 3617 */     System.arraycopy(paramArrayOfBoolean, 0, arrayOfBoolean, 0, Math.min(paramInt, paramArrayOfBoolean.length));
/* 3618 */     return arrayOfBoolean;
/*      */   }
/*      */ 
/*      */   public static byte[] expand(byte[] paramArrayOfByte)
/*      */   {
/* 3623 */     return expand(paramArrayOfByte, paramArrayOfByte.length << 1);
/*      */   }
/*      */ 
/*      */   public static byte[] expand(byte[] paramArrayOfByte, int paramInt) {
/* 3627 */     byte[] arrayOfByte = new byte[paramInt];
/* 3628 */     System.arraycopy(paramArrayOfByte, 0, arrayOfByte, 0, Math.min(paramInt, paramArrayOfByte.length));
/* 3629 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */   public static char[] expand(char[] paramArrayOfChar)
/*      */   {
/* 3634 */     return expand(paramArrayOfChar, paramArrayOfChar.length << 1);
/*      */   }
/*      */ 
/*      */   public static char[] expand(char[] paramArrayOfChar, int paramInt) {
/* 3638 */     char[] arrayOfChar = new char[paramInt];
/* 3639 */     System.arraycopy(paramArrayOfChar, 0, arrayOfChar, 0, Math.min(paramInt, paramArrayOfChar.length));
/* 3640 */     return arrayOfChar;
/*      */   }
/*      */ 
/*      */   public static int[] expand(int[] paramArrayOfInt)
/*      */   {
/* 3645 */     return expand(paramArrayOfInt, paramArrayOfInt.length << 1);
/*      */   }
/*      */ 
/*      */   public static int[] expand(int[] paramArrayOfInt, int paramInt) {
/* 3649 */     int[] arrayOfInt = new int[paramInt];
/* 3650 */     System.arraycopy(paramArrayOfInt, 0, arrayOfInt, 0, Math.min(paramInt, paramArrayOfInt.length));
/* 3651 */     return arrayOfInt;
/*      */   }
/*      */ 
/*      */   public static float[] expand(float[] paramArrayOfFloat)
/*      */   {
/* 3656 */     return expand(paramArrayOfFloat, paramArrayOfFloat.length << 1);
/*      */   }
/*      */ 
/*      */   public static float[] expand(float[] paramArrayOfFloat, int paramInt) {
/* 3660 */     float[] arrayOfFloat = new float[paramInt];
/* 3661 */     System.arraycopy(paramArrayOfFloat, 0, arrayOfFloat, 0, Math.min(paramInt, paramArrayOfFloat.length));
/* 3662 */     return arrayOfFloat;
/*      */   }
/*      */ 
/*      */   public static String[] expand(String[] paramArrayOfString)
/*      */   {
/* 3667 */     return expand(paramArrayOfString, paramArrayOfString.length << 1);
/*      */   }
/*      */ 
/*      */   public static String[] expand(String[] paramArrayOfString, int paramInt) {
/* 3671 */     String[] arrayOfString = new String[paramInt];
/*      */ 
/* 3673 */     System.arraycopy(paramArrayOfString, 0, arrayOfString, 0, Math.min(paramInt, paramArrayOfString.length));
/* 3674 */     return arrayOfString;
/*      */   }
/*      */ 
/*      */   public static Object expand(Object paramObject)
/*      */   {
/* 3679 */     return expand(paramObject, Array.getLength(paramObject) << 1);
/*      */   }
/*      */ 
/*      */   public static Object expand(Object paramObject, int paramInt) {
/* 3683 */     Class localClass = paramObject.getClass().getComponentType();
/* 3684 */     Object localObject = Array.newInstance(localClass, paramInt);
/* 3685 */     System.arraycopy(paramObject, 0, localObject, 0, Math.min(Array.getLength(paramObject), paramInt));
/*      */ 
/* 3687 */     return localObject;
/*      */   }
/*      */ 
/*      */   public static boolean[] contract(boolean[] paramArrayOfBoolean, int paramInt)
/*      */   {
/* 3693 */     return expand(paramArrayOfBoolean, paramInt);
/*      */   }
/*      */ 
/*      */   public static byte[] contract(byte[] paramArrayOfByte, int paramInt) {
/* 3697 */     return expand(paramArrayOfByte, paramInt);
/*      */   }
/*      */ 
/*      */   public static char[] contract(char[] paramArrayOfChar, int paramInt) {
/* 3701 */     return expand(paramArrayOfChar, paramInt);
/*      */   }
/*      */ 
/*      */   public static int[] contract(int[] paramArrayOfInt, int paramInt) {
/* 3705 */     return expand(paramArrayOfInt, paramInt);
/*      */   }
/*      */ 
/*      */   public static float[] contract(float[] paramArrayOfFloat, int paramInt) {
/* 3709 */     return expand(paramArrayOfFloat, paramInt);
/*      */   }
/*      */ 
/*      */   public static String[] contract(String[] paramArrayOfString, int paramInt) {
/* 3713 */     return expand(paramArrayOfString, paramInt);
/*      */   }
/*      */ 
/*      */   public static Object contract(Object paramObject, int paramInt) {
/* 3717 */     return expand(paramObject, paramInt);
/*      */   }
/*      */ 
/*      */   public static byte[] append(byte[] paramArrayOfByte, byte paramByte)
/*      */   {
/* 3723 */     paramArrayOfByte = expand(paramArrayOfByte, paramArrayOfByte.length + 1);
/* 3724 */     paramArrayOfByte[(paramArrayOfByte.length - 1)] = paramByte;
/* 3725 */     return paramArrayOfByte;
/*      */   }
/*      */ 
/*      */   public static char[] append(char[] paramArrayOfChar, char paramChar) {
/* 3729 */     paramArrayOfChar = expand(paramArrayOfChar, paramArrayOfChar.length + 1);
/* 3730 */     paramArrayOfChar[(paramArrayOfChar.length - 1)] = paramChar;
/* 3731 */     return paramArrayOfChar;
/*      */   }
/*      */ 
/*      */   public static int[] append(int[] paramArrayOfInt, int paramInt) {
/* 3735 */     paramArrayOfInt = expand(paramArrayOfInt, paramArrayOfInt.length + 1);
/* 3736 */     paramArrayOfInt[(paramArrayOfInt.length - 1)] = paramInt;
/* 3737 */     return paramArrayOfInt;
/*      */   }
/*      */ 
/*      */   public static float[] append(float[] paramArrayOfFloat, float paramFloat) {
/* 3741 */     paramArrayOfFloat = expand(paramArrayOfFloat, paramArrayOfFloat.length + 1);
/* 3742 */     paramArrayOfFloat[(paramArrayOfFloat.length - 1)] = paramFloat;
/* 3743 */     return paramArrayOfFloat;
/*      */   }
/*      */ 
/*      */   public static String[] append(String[] paramArrayOfString, String paramString) {
/* 3747 */     paramArrayOfString = expand(paramArrayOfString, paramArrayOfString.length + 1);
/* 3748 */     paramArrayOfString[(paramArrayOfString.length - 1)] = paramString;
/* 3749 */     return paramArrayOfString;
/*      */   }
/*      */ 
/*      */   public static boolean[] shorten(boolean[] paramArrayOfBoolean)
/*      */   {
/* 3763 */     return contract(paramArrayOfBoolean, paramArrayOfBoolean.length - 1);
/*      */   }
/*      */ 
/*      */   public static byte[] shorten(byte[] paramArrayOfByte) {
/* 3767 */     return contract(paramArrayOfByte, paramArrayOfByte.length - 1);
/*      */   }
/*      */ 
/*      */   public static char[] shorten(char[] paramArrayOfChar) {
/* 3771 */     return contract(paramArrayOfChar, paramArrayOfChar.length - 1);
/*      */   }
/*      */ 
/*      */   public static int[] shorten(int[] paramArrayOfInt) {
/* 3775 */     return contract(paramArrayOfInt, paramArrayOfInt.length - 1);
/*      */   }
/*      */ 
/*      */   public static float[] shorten(float[] paramArrayOfFloat) {
/* 3779 */     return contract(paramArrayOfFloat, paramArrayOfFloat.length - 1);
/*      */   }
/*      */ 
/*      */   public static String[] shorten(String[] paramArrayOfString) {
/* 3783 */     return contract(paramArrayOfString, paramArrayOfString.length - 1);
/*      */   }
/*      */ 
/*      */   public static final boolean[] splice(boolean[] paramArrayOfBoolean, boolean paramBoolean, int paramInt)
/*      */   {
/* 3796 */     boolean[] arrayOfBoolean = new boolean[paramArrayOfBoolean.length + 1];
/* 3797 */     System.arraycopy(paramArrayOfBoolean, 0, arrayOfBoolean, 0, paramInt);
/* 3798 */     arrayOfBoolean[paramInt] = paramBoolean;
/* 3799 */     System.arraycopy(paramArrayOfBoolean, paramInt, arrayOfBoolean, paramInt + 1, paramArrayOfBoolean.length - paramInt);
/*      */ 
/* 3801 */     return arrayOfBoolean;
/*      */   }
/*      */ 
/*      */   public static final boolean[] splice(boolean[] paramArrayOfBoolean1, boolean[] paramArrayOfBoolean2, int paramInt)
/*      */   {
/* 3806 */     boolean[] arrayOfBoolean = new boolean[paramArrayOfBoolean1.length + paramArrayOfBoolean2.length];
/* 3807 */     System.arraycopy(paramArrayOfBoolean1, 0, arrayOfBoolean, 0, paramInt);
/* 3808 */     System.arraycopy(paramArrayOfBoolean2, 0, arrayOfBoolean, paramInt, paramArrayOfBoolean2.length);
/* 3809 */     System.arraycopy(paramArrayOfBoolean1, paramInt, arrayOfBoolean, paramInt + paramArrayOfBoolean2.length, paramArrayOfBoolean1.length - paramInt);
/*      */ 
/* 3811 */     return arrayOfBoolean;
/*      */   }
/*      */ 
/*      */   public static final byte[] splice(byte[] paramArrayOfByte, byte paramByte, int paramInt)
/*      */   {
/* 3817 */     byte[] arrayOfByte = new byte[paramArrayOfByte.length + 1];
/* 3818 */     System.arraycopy(paramArrayOfByte, 0, arrayOfByte, 0, paramInt);
/* 3819 */     arrayOfByte[paramInt] = paramByte;
/* 3820 */     System.arraycopy(paramArrayOfByte, paramInt, arrayOfByte, paramInt + 1, paramArrayOfByte.length - paramInt);
/*      */ 
/* 3822 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */   public static final byte[] splice(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt)
/*      */   {
/* 3827 */     byte[] arrayOfByte = new byte[paramArrayOfByte1.length + paramArrayOfByte2.length];
/* 3828 */     System.arraycopy(paramArrayOfByte1, 0, arrayOfByte, 0, paramInt);
/* 3829 */     System.arraycopy(paramArrayOfByte2, 0, arrayOfByte, paramInt, paramArrayOfByte2.length);
/* 3830 */     System.arraycopy(paramArrayOfByte1, paramInt, arrayOfByte, paramInt + paramArrayOfByte2.length, paramArrayOfByte1.length - paramInt);
/*      */ 
/* 3832 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */   public static final char[] splice(char[] paramArrayOfChar, char paramChar, int paramInt)
/*      */   {
/* 3838 */     char[] arrayOfChar = new char[paramArrayOfChar.length + 1];
/* 3839 */     System.arraycopy(paramArrayOfChar, 0, arrayOfChar, 0, paramInt);
/* 3840 */     arrayOfChar[paramInt] = paramChar;
/* 3841 */     System.arraycopy(paramArrayOfChar, paramInt, arrayOfChar, paramInt + 1, paramArrayOfChar.length - paramInt);
/*      */ 
/* 3843 */     return arrayOfChar;
/*      */   }
/*      */ 
/*      */   public static final char[] splice(char[] paramArrayOfChar1, char[] paramArrayOfChar2, int paramInt)
/*      */   {
/* 3848 */     char[] arrayOfChar = new char[paramArrayOfChar1.length + paramArrayOfChar2.length];
/* 3849 */     System.arraycopy(paramArrayOfChar1, 0, arrayOfChar, 0, paramInt);
/* 3850 */     System.arraycopy(paramArrayOfChar2, 0, arrayOfChar, paramInt, paramArrayOfChar2.length);
/* 3851 */     System.arraycopy(paramArrayOfChar1, paramInt, arrayOfChar, paramInt + paramArrayOfChar2.length, paramArrayOfChar1.length - paramInt);
/*      */ 
/* 3853 */     return arrayOfChar;
/*      */   }
/*      */ 
/*      */   public static final int[] splice(int[] paramArrayOfInt, int paramInt1, int paramInt2)
/*      */   {
/* 3859 */     int[] arrayOfInt = new int[paramArrayOfInt.length + 1];
/* 3860 */     System.arraycopy(paramArrayOfInt, 0, arrayOfInt, 0, paramInt2);
/* 3861 */     arrayOfInt[paramInt2] = paramInt1;
/* 3862 */     System.arraycopy(paramArrayOfInt, paramInt2, arrayOfInt, paramInt2 + 1, paramArrayOfInt.length - paramInt2);
/*      */ 
/* 3864 */     return arrayOfInt;
/*      */   }
/*      */ 
/*      */   public static final int[] splice(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt)
/*      */   {
/* 3869 */     int[] arrayOfInt = new int[paramArrayOfInt1.length + paramArrayOfInt2.length];
/* 3870 */     System.arraycopy(paramArrayOfInt1, 0, arrayOfInt, 0, paramInt);
/* 3871 */     System.arraycopy(paramArrayOfInt2, 0, arrayOfInt, paramInt, paramArrayOfInt2.length);
/* 3872 */     System.arraycopy(paramArrayOfInt1, paramInt, arrayOfInt, paramInt + paramArrayOfInt2.length, paramArrayOfInt1.length - paramInt);
/*      */ 
/* 3874 */     return arrayOfInt;
/*      */   }
/*      */ 
/*      */   public static final float[] splice(float[] paramArrayOfFloat, float paramFloat, int paramInt)
/*      */   {
/* 3880 */     float[] arrayOfFloat = new float[paramArrayOfFloat.length + 1];
/* 3881 */     System.arraycopy(paramArrayOfFloat, 0, arrayOfFloat, 0, paramInt);
/* 3882 */     arrayOfFloat[paramInt] = paramFloat;
/* 3883 */     System.arraycopy(paramArrayOfFloat, paramInt, arrayOfFloat, paramInt + 1, paramArrayOfFloat.length - paramInt);
/*      */ 
/* 3885 */     return arrayOfFloat;
/*      */   }
/*      */ 
/*      */   public static final float[] splice(float[] paramArrayOfFloat1, float[] paramArrayOfFloat2, int paramInt)
/*      */   {
/* 3890 */     float[] arrayOfFloat = new float[paramArrayOfFloat1.length + paramArrayOfFloat2.length];
/* 3891 */     System.arraycopy(paramArrayOfFloat1, 0, arrayOfFloat, 0, paramInt);
/* 3892 */     System.arraycopy(paramArrayOfFloat2, 0, arrayOfFloat, paramInt, paramArrayOfFloat2.length);
/* 3893 */     System.arraycopy(paramArrayOfFloat1, paramInt, arrayOfFloat, paramInt + paramArrayOfFloat2.length, paramArrayOfFloat1.length - paramInt);
/*      */ 
/* 3895 */     return arrayOfFloat;
/*      */   }
/*      */ 
/*      */   public static final String[] splice(String[] paramArrayOfString, String paramString, int paramInt)
/*      */   {
/* 3901 */     String[] arrayOfString = new String[paramArrayOfString.length + 1];
/* 3902 */     System.arraycopy(paramArrayOfString, 0, arrayOfString, 0, paramInt);
/* 3903 */     arrayOfString[paramInt] = paramString;
/* 3904 */     System.arraycopy(paramArrayOfString, paramInt, arrayOfString, paramInt + 1, paramArrayOfString.length - paramInt);
/*      */ 
/* 3906 */     return arrayOfString;
/*      */   }
/*      */ 
/*      */   public static final String[] splice(String[] paramArrayOfString1, String[] paramArrayOfString2, int paramInt)
/*      */   {
/* 3911 */     String[] arrayOfString = new String[paramArrayOfString1.length + paramArrayOfString2.length];
/* 3912 */     System.arraycopy(paramArrayOfString1, 0, arrayOfString, 0, paramInt);
/* 3913 */     System.arraycopy(paramArrayOfString2, 0, arrayOfString, paramInt, paramArrayOfString2.length);
/* 3914 */     System.arraycopy(paramArrayOfString1, paramInt, arrayOfString, paramInt + paramArrayOfString2.length, paramArrayOfString1.length - paramInt);
/*      */ 
/* 3916 */     return arrayOfString;
/*      */   }
/*      */ 
/*      */   public static int[] subset(int[] paramArrayOfInt, int paramInt)
/*      */   {
/* 3922 */     return subset(paramArrayOfInt, paramInt, paramArrayOfInt.length - paramInt);
/*      */   }
/*      */ 
/*      */   public static int[] subset(int[] paramArrayOfInt, int paramInt1, int paramInt2) {
/* 3926 */     int[] arrayOfInt = new int[paramInt2];
/* 3927 */     System.arraycopy(paramArrayOfInt, paramInt1, arrayOfInt, 0, paramInt2);
/* 3928 */     return arrayOfInt;
/*      */   }
/*      */ 
/*      */   public static float[] subset(float[] paramArrayOfFloat, int paramInt)
/*      */   {
/* 3933 */     return subset(paramArrayOfFloat, paramInt, paramArrayOfFloat.length - paramInt);
/*      */   }
/*      */ 
/*      */   public static float[] subset(float[] paramArrayOfFloat, int paramInt1, int paramInt2) {
/* 3937 */     float[] arrayOfFloat = new float[paramInt2];
/* 3938 */     System.arraycopy(paramArrayOfFloat, paramInt1, arrayOfFloat, 0, paramInt2);
/* 3939 */     return arrayOfFloat;
/*      */   }
/*      */ 
/*      */   public static String[] subset(String[] paramArrayOfString, int paramInt)
/*      */   {
/* 3944 */     return subset(paramArrayOfString, paramInt, paramArrayOfString.length - paramInt);
/*      */   }
/*      */ 
/*      */   public static String[] subset(String[] paramArrayOfString, int paramInt1, int paramInt2) {
/* 3948 */     String[] arrayOfString = new String[paramInt2];
/* 3949 */     System.arraycopy(paramArrayOfString, paramInt1, arrayOfString, 0, paramInt2);
/* 3950 */     return arrayOfString;
/*      */   }
/*      */ 
/*      */   public static boolean[] concat(boolean[] paramArrayOfBoolean1, boolean[] paramArrayOfBoolean2)
/*      */   {
/* 3956 */     boolean[] arrayOfBoolean = new boolean[paramArrayOfBoolean1.length + paramArrayOfBoolean2.length];
/* 3957 */     System.arraycopy(paramArrayOfBoolean1, 0, arrayOfBoolean, 0, paramArrayOfBoolean1.length);
/* 3958 */     System.arraycopy(paramArrayOfBoolean2, 0, arrayOfBoolean, paramArrayOfBoolean1.length, paramArrayOfBoolean2.length);
/* 3959 */     return arrayOfBoolean;
/*      */   }
/*      */ 
/*      */   public static byte[] concat(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2) {
/* 3963 */     byte[] arrayOfByte = new byte[paramArrayOfByte1.length + paramArrayOfByte2.length];
/* 3964 */     System.arraycopy(paramArrayOfByte1, 0, arrayOfByte, 0, paramArrayOfByte1.length);
/* 3965 */     System.arraycopy(paramArrayOfByte2, 0, arrayOfByte, paramArrayOfByte1.length, paramArrayOfByte2.length);
/* 3966 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */   public static char[] concat(char[] paramArrayOfChar1, char[] paramArrayOfChar2) {
/* 3970 */     char[] arrayOfChar = new char[paramArrayOfChar1.length + paramArrayOfChar2.length];
/* 3971 */     System.arraycopy(paramArrayOfChar1, 0, arrayOfChar, 0, paramArrayOfChar1.length);
/* 3972 */     System.arraycopy(paramArrayOfChar2, 0, arrayOfChar, paramArrayOfChar1.length, paramArrayOfChar2.length);
/* 3973 */     return arrayOfChar;
/*      */   }
/*      */ 
/*      */   public static int[] concat(int[] paramArrayOfInt1, int[] paramArrayOfInt2) {
/* 3977 */     int[] arrayOfInt = new int[paramArrayOfInt1.length + paramArrayOfInt2.length];
/* 3978 */     System.arraycopy(paramArrayOfInt1, 0, arrayOfInt, 0, paramArrayOfInt1.length);
/* 3979 */     System.arraycopy(paramArrayOfInt2, 0, arrayOfInt, paramArrayOfInt1.length, paramArrayOfInt2.length);
/* 3980 */     return arrayOfInt;
/*      */   }
/*      */ 
/*      */   public static float[] concat(float[] paramArrayOfFloat1, float[] paramArrayOfFloat2) {
/* 3984 */     float[] arrayOfFloat = new float[paramArrayOfFloat1.length + paramArrayOfFloat2.length];
/* 3985 */     System.arraycopy(paramArrayOfFloat1, 0, arrayOfFloat, 0, paramArrayOfFloat1.length);
/* 3986 */     System.arraycopy(paramArrayOfFloat2, 0, arrayOfFloat, paramArrayOfFloat1.length, paramArrayOfFloat2.length);
/* 3987 */     return arrayOfFloat;
/*      */   }
/*      */ 
/*      */   public static String[] concat(String[] paramArrayOfString1, String[] paramArrayOfString2) {
/* 3991 */     String[] arrayOfString = new String[paramArrayOfString1.length + paramArrayOfString2.length];
/* 3992 */     System.arraycopy(paramArrayOfString1, 0, arrayOfString, 0, paramArrayOfString1.length);
/* 3993 */     System.arraycopy(paramArrayOfString2, 0, arrayOfString, paramArrayOfString1.length, paramArrayOfString2.length);
/* 3994 */     return arrayOfString;
/*      */   }
/*      */ 
/*      */   public static boolean[] reverse(boolean[] paramArrayOfBoolean)
/*      */   {
/* 4000 */     boolean[] arrayOfBoolean = new boolean[paramArrayOfBoolean.length];
/* 4001 */     int i = paramArrayOfBoolean.length - 1;
/* 4002 */     for (int j = 0; j < paramArrayOfBoolean.length; ++j) {
/* 4003 */       arrayOfBoolean[j] = paramArrayOfBoolean[(i - j)];
/*      */     }
/* 4005 */     return arrayOfBoolean;
/*      */   }
/*      */ 
/*      */   public static byte[] reverse(byte[] paramArrayOfByte) {
/* 4009 */     byte[] arrayOfByte = new byte[paramArrayOfByte.length];
/* 4010 */     int i = paramArrayOfByte.length - 1;
/* 4011 */     for (int j = 0; j < paramArrayOfByte.length; ++j) {
/* 4012 */       arrayOfByte[j] = paramArrayOfByte[(i - j)];
/*      */     }
/* 4014 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */   public static char[] reverse(char[] paramArrayOfChar) {
/* 4018 */     char[] arrayOfChar = new char[paramArrayOfChar.length];
/* 4019 */     int i = paramArrayOfChar.length - 1;
/* 4020 */     for (int j = 0; j < paramArrayOfChar.length; ++j) {
/* 4021 */       arrayOfChar[j] = paramArrayOfChar[(i - j)];
/*      */     }
/* 4023 */     return arrayOfChar;
/*      */   }
/*      */ 
/*      */   public static int[] reverse(int[] paramArrayOfInt) {
/* 4027 */     int[] arrayOfInt = new int[paramArrayOfInt.length];
/* 4028 */     int i = paramArrayOfInt.length - 1;
/* 4029 */     for (int j = 0; j < paramArrayOfInt.length; ++j) {
/* 4030 */       arrayOfInt[j] = paramArrayOfInt[(i - j)];
/*      */     }
/* 4032 */     return arrayOfInt;
/*      */   }
/*      */ 
/*      */   public static float[] reverse(float[] paramArrayOfFloat) {
/* 4036 */     float[] arrayOfFloat = new float[paramArrayOfFloat.length];
/* 4037 */     int i = paramArrayOfFloat.length - 1;
/* 4038 */     for (int j = 0; j < paramArrayOfFloat.length; ++j) {
/* 4039 */       arrayOfFloat[j] = paramArrayOfFloat[(i - j)];
/*      */     }
/* 4041 */     return arrayOfFloat;
/*      */   }
/*      */ 
/*      */   public static String[] reverse(String[] paramArrayOfString) {
/* 4045 */     String[] arrayOfString = new String[paramArrayOfString.length];
/* 4046 */     int i = paramArrayOfString.length - 1;
/* 4047 */     for (int j = 0; j < paramArrayOfString.length; ++j) {
/* 4048 */       arrayOfString[j] = paramArrayOfString[(i - j)];
/*      */     }
/* 4050 */     return arrayOfString;
/*      */   }
/*      */ 
/*      */   public static String trim(String paramString)
/*      */   {
/* 4066 */     return paramString.replace(160, ' ').trim();
/*      */   }
/*      */ 
/*      */   public static String join(String[] paramArrayOfString, char paramChar)
/*      */   {
/* 4087 */     return join(paramArrayOfString, String.valueOf(paramChar));
/*      */   }
/*      */ 
/*      */   public static String join(String[] paramArrayOfString, String paramString)
/*      */   {
/* 4103 */     StringBuffer localStringBuffer = new StringBuffer();
/* 4104 */     for (int i = 0; i < paramArrayOfString.length; ++i) {
/* 4105 */       if (i != 0) localStringBuffer.append(paramString);
/* 4106 */       localStringBuffer.append(paramArrayOfString[i]);
/*      */     }
/* 4108 */     return localStringBuffer.toString();
/*      */   }
/*      */ 
/*      */   public static String[] split(String paramString)
/*      */   {
/* 4128 */     return split(paramString, " \t\n\r\f ");
/*      */   }
/*      */ 
/*      */   public static String[] split(String paramString1, String paramString2)
/*      */   {
/* 4147 */     StringTokenizer localStringTokenizer = new StringTokenizer(paramString1, paramString2);
/* 4148 */     String[] arrayOfString = new String[localStringTokenizer.countTokens()];
/*      */ 
/* 4150 */     int i = 0;
/* 4151 */     while (localStringTokenizer.hasMoreTokens()) {
/* 4152 */       arrayOfString[(i++)] = localStringTokenizer.nextToken();
/*      */     }
/* 4154 */     return arrayOfString;
/*      */   }
/*      */ 
/*      */   public static String[] split(String paramString, char paramChar)
/*      */   {
/* 4171 */     if (paramString == null) return null;
/*      */ 
/* 4174 */     char[] arrayOfChar = paramString.toCharArray();
/* 4175 */     int i = 0;
/* 4176 */     for (int j = 0; j < arrayOfChar.length; ++j) {
/* 4177 */       if (arrayOfChar[j] != paramChar) continue; ++i;
/*      */     }
/*      */ 
/* 4185 */     if (i == 0) {
/* 4186 */       arrayOfString = new String[1];
/* 4187 */       arrayOfString[0] = new String(paramString);
/* 4188 */       return arrayOfString;
/*      */     }
/*      */ 
/* 4191 */     String[] arrayOfString = new String[i + 1];
/* 4192 */     int k = 0;
/* 4193 */     int l = 0;
/* 4194 */     for (int i1 = 0; i1 < arrayOfChar.length; ++i1) {
/* 4195 */       if (arrayOfChar[i1] == paramChar) {
/* 4196 */         arrayOfString[(k++)] = new String(arrayOfChar, l, i1 - l);
/*      */ 
/* 4198 */         l = i1 + 1;
/*      */       }
/*      */     }
/*      */ 
/* 4202 */     arrayOfString[k] = new String(arrayOfChar, l, arrayOfChar.length - l);
/*      */ 
/* 4205 */     return arrayOfString;
/*      */   }
/*      */ 
/*      */   public static final boolean toBoolean(char paramChar)
/*      */   {
/* 4216 */     if ((paramChar == 't') || (paramChar == 'T') || (paramChar == '1')) 0; return true;
/*      */   }
/*      */ 
/*      */   public static final boolean toBoolean(int paramInt) {
/* 4220 */     if (paramInt != 0) 0; return true;
/*      */   }
/*      */ 
/*      */   public static final boolean toBoolean(float paramFloat) {
/* 4224 */     if (paramFloat != 0.0F) 0; return true;
/*      */   }
/*      */ 
/*      */   public static final boolean toBoolean(String paramString) {
/* 4228 */     return new Boolean(paramString).booleanValue();
/*      */   }
/*      */ 
/*      */   public static final boolean[] toBoolean(char[] paramArrayOfChar)
/*      */   {
/* 4234 */     boolean[] arrayOfBoolean = new boolean[paramArrayOfChar.length];
/* 4235 */     for (int i = 0; i < paramArrayOfChar.length; ++i) {
/* 4236 */       if ((paramArrayOfChar[i] == 't') || (paramArrayOfChar[i] == 'T') || (paramArrayOfChar[i] == '1')) 0; arrayOfBoolean[i] = true;
/*      */     }
/*      */ 
/* 4239 */     return arrayOfBoolean;
/*      */   }
/*      */ 
/*      */   public static final boolean[] toBoolean(byte[] paramArrayOfByte) {
/* 4243 */     boolean[] arrayOfBoolean = new boolean[paramArrayOfByte.length];
/* 4244 */     for (int i = 0; i < paramArrayOfByte.length; ++i) {
/* 4245 */       if (paramArrayOfByte[i] != 0) 0; arrayOfBoolean[i] = true;
/*      */     }
/* 4247 */     return arrayOfBoolean;
/*      */   }
/*      */ 
/*      */   public static final boolean[] toBoolean(float[] paramArrayOfFloat) {
/* 4251 */     boolean[] arrayOfBoolean = new boolean[paramArrayOfFloat.length];
/* 4252 */     for (int i = 0; i < paramArrayOfFloat.length; ++i) {
/* 4253 */       if (paramArrayOfFloat[i] != 0.0F) 0; arrayOfBoolean[i] = true;
/*      */     }
/* 4255 */     return arrayOfBoolean;
/*      */   }
/*      */ 
/*      */   public static final boolean[] toBoolean(String[] paramArrayOfString) {
/* 4259 */     boolean[] arrayOfBoolean = new boolean[paramArrayOfString.length];
/* 4260 */     for (int i = 0; i < paramArrayOfString.length; ++i) {
/* 4261 */       arrayOfBoolean[i] = new Boolean(paramArrayOfString[i]).booleanValue();
/*      */     }
/* 4263 */     return arrayOfBoolean;
/*      */   }
/*      */ 
/*      */   public static final byte toByte(boolean paramBoolean)
/*      */   {
/* 4269 */     return paramBoolean;
/*      */   }
/*      */ 
/*      */   public static final byte toByte(char paramChar) {
/* 4273 */     return (byte)paramChar;
/*      */   }
/*      */ 
/*      */   public static final byte toByte(int paramInt) {
/* 4277 */     return (byte)paramInt;
/*      */   }
/*      */ 
/*      */   public static final byte toByte(float paramFloat) {
/* 4281 */     return (byte)(int)paramFloat;
/*      */   }
/*      */ 
/*      */   public static final byte[] toByte(String paramString) {
/* 4285 */     return paramString.getBytes();
/*      */   }
/*      */ 
/*      */   public static final byte[] toByte(boolean[] paramArrayOfBoolean)
/*      */   {
/* 4291 */     byte[] arrayOfByte = new byte[paramArrayOfBoolean.length];
/* 4292 */     for (int i = 0; i < paramArrayOfBoolean.length; ++i) {
/* 4293 */       arrayOfByte[i] = paramArrayOfBoolean[i];
/*      */     }
/* 4295 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */   public static final byte[] toByte(char[] paramArrayOfChar) {
/* 4299 */     byte[] arrayOfByte = new byte[paramArrayOfChar.length];
/* 4300 */     for (int i = 0; i < paramArrayOfChar.length; ++i) {
/* 4301 */       arrayOfByte[i] = (byte)paramArrayOfChar[i];
/*      */     }
/* 4303 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */   public static final byte[] toByte(int[] paramArrayOfInt) {
/* 4307 */     byte[] arrayOfByte = new byte[paramArrayOfInt.length];
/* 4308 */     for (int i = 0; i < paramArrayOfInt.length; ++i) {
/* 4309 */       arrayOfByte[i] = (byte)paramArrayOfInt[i];
/*      */     }
/* 4311 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */   public static final byte[] toByte(float[] paramArrayOfFloat) {
/* 4315 */     byte[] arrayOfByte = new byte[paramArrayOfFloat.length];
/* 4316 */     for (int i = 0; i < paramArrayOfFloat.length; ++i) {
/* 4317 */       arrayOfByte[i] = (byte)(int)paramArrayOfFloat[i];
/*      */     }
/* 4319 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */   public static final byte[][] toByte(String[] paramArrayOfString) {
/* 4323 */     byte[][] arrayOfByte = new byte[paramArrayOfString.length][];
/* 4324 */     for (int i = 0; i < paramArrayOfString.length; ++i) {
/* 4325 */       arrayOfByte[i] = paramArrayOfString[i].getBytes();
/*      */     }
/* 4327 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */   public static final char toChar(boolean paramBoolean)
/*      */   {
/* 4333 */     return ((paramBoolean) ? 't' : 'f');
/*      */   }
/*      */ 
/*      */   public static final char toChar(byte paramByte) {
/* 4337 */     return (char)(paramByte & 0xFF);
/*      */   }
/*      */ 
/*      */   public static final char toChar(int paramInt) {
/* 4341 */     return (char)paramInt;
/*      */   }
/*      */ 
/*      */   public static final char toChar(float paramFloat) {
/* 4345 */     return (char)(int)paramFloat;
/*      */   }
/*      */ 
/*      */   public static final char[] toChar(String paramString) {
/* 4349 */     return paramString.toCharArray();
/*      */   }
/*      */ 
/*      */   public static final char[] toChar(boolean[] paramArrayOfBoolean)
/*      */   {
/* 4355 */     char[] arrayOfChar = new char[paramArrayOfBoolean.length];
/* 4356 */     for (int i = 0; i < paramArrayOfBoolean.length; ++i) {
/* 4357 */       arrayOfChar[i] = ((paramArrayOfBoolean[i] != 0) ? 116 : 'f');
/*      */     }
/* 4359 */     return arrayOfChar;
/*      */   }
/*      */ 
/*      */   public static final char[] toChar(int[] paramArrayOfInt) {
/* 4363 */     char[] arrayOfChar = new char[paramArrayOfInt.length];
/* 4364 */     for (int i = 0; i < paramArrayOfInt.length; ++i) {
/* 4365 */       arrayOfChar[i] = (char)paramArrayOfInt[i];
/*      */     }
/* 4367 */     return arrayOfChar;
/*      */   }
/*      */ 
/*      */   public static final char[] toChar(byte[] paramArrayOfByte) {
/* 4371 */     char[] arrayOfChar = new char[paramArrayOfByte.length];
/* 4372 */     for (int i = 0; i < paramArrayOfByte.length; ++i) {
/* 4373 */       arrayOfChar[i] = (char)(paramArrayOfByte[i] & 0xFF);
/*      */     }
/* 4375 */     return arrayOfChar;
/*      */   }
/*      */ 
/*      */   public static final char[] toChar(float[] paramArrayOfFloat) {
/* 4379 */     char[] arrayOfChar = new char[paramArrayOfFloat.length];
/* 4380 */     for (int i = 0; i < paramArrayOfFloat.length; ++i) {
/* 4381 */       arrayOfChar[i] = (char)(int)paramArrayOfFloat[i];
/*      */     }
/* 4383 */     return arrayOfChar;
/*      */   }
/*      */ 
/*      */   public static final char[][] toChar(String[] paramArrayOfString) {
/* 4387 */     char[][] arrayOfChar = new char[paramArrayOfString.length][];
/* 4388 */     for (int i = 0; i < paramArrayOfString.length; ++i) {
/* 4389 */       arrayOfChar[i] = paramArrayOfString[i].toCharArray();
/*      */     }
/* 4391 */     return arrayOfChar;
/*      */   }
/*      */ 
/*      */   public static final int toInt(boolean paramBoolean)
/*      */   {
/* 4397 */     return paramBoolean;
/*      */   }
/*      */ 
/*      */   public static final int toInt(byte paramByte) {
/* 4401 */     return (paramByte & 0xFF);
/*      */   }
/*      */ 
/*      */   public static final int toInt(char paramChar)
/*      */   {
/* 4410 */     return paramChar;
/*      */   }
/*      */ 
/*      */   public static final int toInt(float paramFloat) {
/* 4414 */     return (int)paramFloat;
/*      */   }
/*      */ 
/*      */   public static final int toInt(String paramString) {
/*      */     try {
/* 4419 */       return Integer.parseInt(paramString); } catch (NumberFormatException localNumberFormatException) {
/*      */     }
/* 4421 */     return 0;
/*      */   }
/*      */ 
/*      */   public static final int toInt(String paramString, int paramInt) {
/*      */     try {
/* 4426 */       return Integer.parseInt(paramString);
/*      */     } catch (NumberFormatException localNumberFormatException) {
/*      */     }
/* 4429 */     return paramInt;
/*      */   }
/*      */ 
/*      */   public static final int[] toInt(boolean[] paramArrayOfBoolean)
/*      */   {
/* 4435 */     int[] arrayOfInt = new int[paramArrayOfBoolean.length];
/* 4436 */     for (int i = 0; i < paramArrayOfBoolean.length; ++i) {
/* 4437 */       arrayOfInt[i] = paramArrayOfBoolean[i];
/*      */     }
/* 4439 */     return arrayOfInt;
/*      */   }
/*      */ 
/*      */   public static final int[] toInt(byte[] paramArrayOfByte) {
/* 4443 */     int[] arrayOfInt = new int[paramArrayOfByte.length];
/* 4444 */     for (int i = 0; i < paramArrayOfByte.length; ++i) {
/* 4445 */       arrayOfInt[i] = (paramArrayOfByte[i] & 0xFF);
/*      */     }
/* 4447 */     return arrayOfInt;
/*      */   }
/*      */ 
/*      */   public static final int[] toInt(char[] paramArrayOfChar) {
/* 4451 */     int[] arrayOfInt = new int[paramArrayOfChar.length];
/* 4452 */     for (int i = 0; i < paramArrayOfChar.length; ++i) {
/* 4453 */       arrayOfInt[i] = paramArrayOfChar[i];
/*      */     }
/* 4455 */     return arrayOfInt;
/*      */   }
/*      */ 
/*      */   public static int[] toInt(float[] paramArrayOfFloat) {
/* 4459 */     int[] arrayOfInt = new int[paramArrayOfFloat.length];
/* 4460 */     for (int i = 0; i < paramArrayOfFloat.length; ++i) {
/* 4461 */       arrayOfInt[i] = (int)paramArrayOfFloat[i];
/*      */     }
/* 4463 */     return arrayOfInt;
/*      */   }
/*      */ 
/*      */   public static int[] toInt(String[] paramArrayOfString)
/*      */   {
/* 4476 */     return toInt(paramArrayOfString, 0);
/*      */   }
/*      */ 
/*      */   public static int[] toInt(String[] paramArrayOfString, int paramInt)
/*      */   {
/* 4490 */     int[] arrayOfInt = new int[paramArrayOfString.length];
/* 4491 */     for (int i = 0; i < paramArrayOfString.length; ++i) {
/*      */       try {
/* 4493 */         arrayOfInt[i] = Integer.parseInt(paramArrayOfString[i]);
/*      */       } catch (NumberFormatException localNumberFormatException) {
/* 4495 */         arrayOfInt[i] = paramInt;
/*      */       }
/*      */     }
/* 4498 */     return arrayOfInt;
/*      */   }
/*      */ 
/*      */   public static final float toFloat(boolean paramBoolean)
/*      */   {
/* 4504 */     return paramBoolean;
/*      */   }
/*      */ 
/*      */   public static final float toFloat(int paramInt) {
/* 4508 */     return paramInt;
/*      */   }
/*      */ 
/*      */   public static final float toFloat(String paramString)
/*      */   {
/* 4513 */     return toFloat(paramString, (0.0F / 0.0F));
/*      */   }
/*      */ 
/*      */   public static final float toFloat(String paramString, float paramFloat) {
/*      */     try {
/* 4518 */       return new Float(paramString).floatValue();
/*      */     } catch (NumberFormatException localNumberFormatException) {
/*      */     }
/* 4521 */     return paramFloat;
/*      */   }
/*      */ 
/*      */   public static final float[] toFloat(boolean[] paramArrayOfBoolean)
/*      */   {
/* 4527 */     float[] arrayOfFloat = new float[paramArrayOfBoolean.length];
/* 4528 */     for (int i = 0; i < paramArrayOfBoolean.length; ++i) {
/* 4529 */       arrayOfFloat[i] = paramArrayOfBoolean[i];
/*      */     }
/* 4531 */     return arrayOfFloat;
/*      */   }
/*      */ 
/*      */   public static final float[] toFloat(char[] paramArrayOfChar) {
/* 4535 */     float[] arrayOfFloat = new float[paramArrayOfChar.length];
/* 4536 */     for (int i = 0; i < paramArrayOfChar.length; ++i) {
/* 4537 */       arrayOfFloat[i] = paramArrayOfChar[i];
/*      */     }
/* 4539 */     return arrayOfFloat;
/*      */   }
/*      */ 
/*      */   public static final float[] toFloat(int[] paramArrayOfInt) {
/* 4543 */     float[] arrayOfFloat = new float[paramArrayOfInt.length];
/* 4544 */     for (int i = 0; i < paramArrayOfInt.length; ++i) {
/* 4545 */       arrayOfFloat[i] = paramArrayOfInt[i];
/*      */     }
/* 4547 */     return arrayOfFloat;
/*      */   }
/*      */ 
/*      */   public static final float[] toFloat(String[] paramArrayOfString) {
/* 4551 */     return toFloat(paramArrayOfString, 0.0F);
/*      */   }
/*      */ 
/*      */   public static final float[] toFloat(String[] paramArrayOfString, float paramFloat) {
/* 4555 */     float[] arrayOfFloat = new float[paramArrayOfString.length];
/* 4556 */     for (int i = 0; i < paramArrayOfString.length; ++i) {
/*      */       try {
/* 4558 */         arrayOfFloat[i] = new Float(paramArrayOfString[i]).floatValue();
/*      */       } catch (NumberFormatException localNumberFormatException) {
/* 4560 */         arrayOfFloat[i] = paramFloat;
/*      */       }
/*      */     }
/* 4563 */     return arrayOfFloat;
/*      */   }
/*      */ 
/*      */   public static final String str(boolean paramBoolean)
/*      */   {
/* 4568 */     return String.valueOf(paramBoolean); } 
/*      */   public static final String str(byte paramByte) { return String.valueOf(paramByte); } 
/*      */   public static final String str(char paramChar) { return String.valueOf(paramChar); } 
/*      */   public static final String str(short paramShort) { return String.valueOf(paramShort); } 
/*      */   public static final String str(int paramInt) { return String.valueOf(paramInt); } 
/*      */   public static final String str(float paramFloat) { return String.valueOf(paramFloat); } 
/*      */   public static final String str(long paramLong) { return String.valueOf(paramLong); } 
/*      */   public static final String str(double paramDouble) { return String.valueOf(paramDouble);
/*      */   }
/*      */ 
/*      */   public static final String[] str(boolean[] paramArrayOfBoolean)
/*      */   {
/* 4580 */     String[] arrayOfString = new String[paramArrayOfBoolean.length];
/* 4581 */     for (int i = 0; i < paramArrayOfBoolean.length; ++i) arrayOfString[i] = String.valueOf(paramArrayOfBoolean);
/* 4582 */     return arrayOfString;
/*      */   }
/*      */ 
/*      */   public static final String[] str(byte[] paramArrayOfByte) {
/* 4586 */     String[] arrayOfString = new String[paramArrayOfByte.length];
/* 4587 */     for (int i = 0; i < paramArrayOfByte.length; ++i) arrayOfString[i] = String.valueOf(paramArrayOfByte);
/* 4588 */     return arrayOfString;
/*      */   }
/*      */ 
/*      */   public static final String[] str(char[] paramArrayOfChar) {
/* 4592 */     String[] arrayOfString = new String[paramArrayOfChar.length];
/* 4593 */     for (int i = 0; i < paramArrayOfChar.length; ++i) arrayOfString[i] = String.valueOf(paramArrayOfChar);
/* 4594 */     return arrayOfString;
/*      */   }
/*      */ 
/*      */   public static final String[] str(short[] paramArrayOfShort) {
/* 4598 */     String[] arrayOfString = new String[paramArrayOfShort.length];
/* 4599 */     for (int i = 0; i < paramArrayOfShort.length; ++i) arrayOfString[i] = String.valueOf(paramArrayOfShort);
/* 4600 */     return arrayOfString;
/*      */   }
/*      */ 
/*      */   public static final String[] str(int[] paramArrayOfInt) {
/* 4604 */     String[] arrayOfString = new String[paramArrayOfInt.length];
/* 4605 */     for (int i = 0; i < paramArrayOfInt.length; ++i) arrayOfString[i] = String.valueOf(paramArrayOfInt);
/* 4606 */     return arrayOfString;
/*      */   }
/*      */ 
/*      */   public static final String[] str(float[] paramArrayOfFloat) {
/* 4610 */     String[] arrayOfString = new String[paramArrayOfFloat.length];
/* 4611 */     for (int i = 0; i < paramArrayOfFloat.length; ++i) arrayOfString[i] = String.valueOf(paramArrayOfFloat);
/* 4612 */     return arrayOfString;
/*      */   }
/*      */ 
/*      */   public static final String[] str(long[] paramArrayOfLong) {
/* 4616 */     String[] arrayOfString = new String[paramArrayOfLong.length];
/* 4617 */     for (int i = 0; i < paramArrayOfLong.length; ++i) arrayOfString[i] = String.valueOf(paramArrayOfLong);
/* 4618 */     return arrayOfString;
/*      */   }
/*      */ 
/*      */   public static final String[] str(double[] paramArrayOfDouble) {
/* 4622 */     String[] arrayOfString = new String[paramArrayOfDouble.length];
/* 4623 */     for (int i = 0; i < paramArrayOfDouble.length; ++i) arrayOfString[i] = String.valueOf(paramArrayOfDouble);
/* 4624 */     return arrayOfString;
/*      */   }
/*      */ 
/*      */   public static String[] nf(int[] paramArrayOfInt, int paramInt)
/*      */   {
/* 4643 */     String[] arrayOfString = new String[paramArrayOfInt.length];
/* 4644 */     for (int i = 0; i < arrayOfString.length; ++i) {
/* 4645 */       arrayOfString[i] = nf(paramArrayOfInt[i], paramInt);
/*      */     }
/* 4647 */     return arrayOfString;
/*      */   }
/*      */ 
/*      */   public static String nf(int paramInt1, int paramInt2)
/*      */   {
/* 4652 */     if ((int_nf != null) && (int_nf_digits == paramInt2) && (!(int_nf_commas)))
/*      */     {
/* 4655 */       return int_nf.format(paramInt1);
/*      */     }
/*      */ 
/* 4658 */     int_nf = NumberFormat.getInstance();
/* 4659 */     int_nf.setGroupingUsed(false);
/* 4660 */     int_nf_commas = false;
/* 4661 */     int_nf.setMinimumIntegerDigits(paramInt2);
/* 4662 */     int_nf_digits = paramInt2;
/* 4663 */     return int_nf.format(paramInt1);
/*      */   }
/*      */ 
/*      */   public static String[] nfc(int[] paramArrayOfInt)
/*      */   {
/* 4668 */     String[] arrayOfString = new String[paramArrayOfInt.length];
/* 4669 */     for (int i = 0; i < arrayOfString.length; ++i) {
/* 4670 */       arrayOfString[i] = nfc(paramArrayOfInt[i]);
/*      */     }
/* 4672 */     return arrayOfString;
/*      */   }
/*      */ 
/*      */   public static String nfc(int paramInt)
/*      */   {
/* 4677 */     if ((int_nf != null) && (int_nf_digits == 0) && (int_nf_commas))
/*      */     {
/* 4680 */       return int_nf.format(paramInt);
/*      */     }
/*      */ 
/* 4683 */     int_nf = NumberFormat.getInstance();
/* 4684 */     int_nf.setGroupingUsed(true);
/* 4685 */     int_nf_commas = true;
/* 4686 */     int_nf.setMinimumIntegerDigits(0);
/* 4687 */     int_nf_digits = 0;
/* 4688 */     return int_nf.format(paramInt);
/*      */   }
/*      */ 
/*      */   public static String nfs(int paramInt1, int paramInt2)
/*      */   {
/* 4699 */     return " " + nf(paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */   public static String[] nfs(int[] paramArrayOfInt, int paramInt) {
/* 4703 */     String[] arrayOfString = new String[paramArrayOfInt.length];
/* 4704 */     for (int i = 0; i < arrayOfString.length; ++i) {
/* 4705 */       arrayOfString[i] = nfs(paramArrayOfInt[i], paramInt);
/*      */     }
/* 4707 */     return arrayOfString;
/*      */   }
/*      */ 
/*      */   public static String nfp(int paramInt1, int paramInt2)
/*      */   {
/* 4718 */     return "+" + nf(paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */   public static String[] nfp(int[] paramArrayOfInt, int paramInt) {
/* 4722 */     String[] arrayOfString = new String[paramArrayOfInt.length];
/* 4723 */     for (int i = 0; i < arrayOfString.length; ++i) {
/* 4724 */       arrayOfString[i] = nfp(paramArrayOfInt[i], paramInt);
/*      */     }
/* 4726 */     return arrayOfString;
/*      */   }
/*      */ 
/*      */   public static String[] nf(float[] paramArrayOfFloat, int paramInt1, int paramInt2)
/*      */   {
/* 4742 */     String[] arrayOfString = new String[paramArrayOfFloat.length];
/* 4743 */     for (int i = 0; i < arrayOfString.length; ++i) {
/* 4744 */       arrayOfString[i] = nf(paramArrayOfFloat[i], paramInt1, paramInt2);
/*      */     }
/* 4746 */     return arrayOfString;
/*      */   }
/*      */ 
/*      */   public static String nf(float paramFloat, int paramInt1, int paramInt2)
/*      */   {
/* 4751 */     if ((float_nf != null) && (float_nf_left == paramInt1) && (float_nf_right == paramInt2) && (!(float_nf_commas)))
/*      */     {
/* 4755 */       return float_nf.format(paramFloat);
/*      */     }
/*      */ 
/* 4758 */     float_nf = NumberFormat.getInstance();
/* 4759 */     float_nf.setGroupingUsed(false);
/* 4760 */     float_nf_commas = false;
/*      */ 
/* 4762 */     if (paramInt1 != 0) float_nf.setMinimumIntegerDigits(paramInt1);
/* 4763 */     if (paramInt2 != 0) {
/* 4764 */       float_nf.setMinimumFractionDigits(paramInt2);
/* 4765 */       float_nf.setMaximumFractionDigits(paramInt2);
/*      */     }
/* 4767 */     float_nf_left = paramInt1;
/* 4768 */     float_nf_right = paramInt2;
/* 4769 */     return float_nf.format(paramFloat);
/*      */   }
/*      */ 
/*      */   public static String[] nfc(float[] paramArrayOfFloat, int paramInt)
/*      */   {
/* 4774 */     String[] arrayOfString = new String[paramArrayOfFloat.length];
/* 4775 */     for (int i = 0; i < arrayOfString.length; ++i) {
/* 4776 */       arrayOfString[i] = nfc(paramArrayOfFloat[i], paramInt);
/*      */     }
/* 4778 */     return arrayOfString;
/*      */   }
/*      */ 
/*      */   public static String nfc(float paramFloat, int paramInt)
/*      */   {
/* 4783 */     if ((float_nf != null) && (float_nf_left == 0) && (float_nf_right == paramInt) && (float_nf_commas))
/*      */     {
/* 4787 */       return float_nf.format(paramFloat);
/*      */     }
/*      */ 
/* 4790 */     float_nf = NumberFormat.getInstance();
/* 4791 */     float_nf.setGroupingUsed(true);
/* 4792 */     float_nf_commas = true;
/*      */ 
/* 4794 */     if (paramInt != 0) {
/* 4795 */       float_nf.setMinimumFractionDigits(paramInt);
/* 4796 */       float_nf.setMaximumFractionDigits(paramInt);
/*      */     }
/* 4798 */     float_nf_left = 0;
/* 4799 */     float_nf_right = paramInt;
/* 4800 */     return float_nf.format(paramFloat);
/*      */   }
/*      */ 
/*      */   public static String[] nfs(float[] paramArrayOfFloat, int paramInt1, int paramInt2)
/*      */   {
/* 4809 */     String[] arrayOfString = new String[paramArrayOfFloat.length];
/* 4810 */     for (int i = 0; i < arrayOfString.length; ++i) {
/* 4811 */       arrayOfString[i] = nfs(paramArrayOfFloat[i], paramInt1, paramInt2);
/*      */     }
/* 4813 */     return arrayOfString;
/*      */   }
/*      */ 
/*      */   public static String nfs(float paramFloat, int paramInt1, int paramInt2) {
/* 4817 */     return " " + nf(paramFloat, paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */   public static String[] nfp(float[] paramArrayOfFloat, int paramInt1, int paramInt2)
/*      */   {
/* 4822 */     String[] arrayOfString = new String[paramArrayOfFloat.length];
/* 4823 */     for (int i = 0; i < arrayOfString.length; ++i) {
/* 4824 */       arrayOfString[i] = nfp(paramArrayOfFloat[i], paramInt1, paramInt2);
/*      */     }
/* 4826 */     return arrayOfString;
/*      */   }
/*      */ 
/*      */   public static String nfp(float paramFloat, int paramInt1, int paramInt2) {
/* 4830 */     return "+" + nf(paramFloat, paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */   public static final String hex(byte paramByte)
/*      */   {
/* 4841 */     return hex(paramByte, 2);
/*      */   }
/*      */ 
/*      */   public static final String hex(char paramChar) {
/* 4845 */     return hex(paramChar, 4);
/*      */   }
/*      */ 
/*      */   public static final String hex(int paramInt) {
/* 4849 */     return hex(paramInt, 8);
/*      */   }
/*      */ 
/*      */   public static final String hex(int paramInt1, int paramInt2) {
/* 4853 */     String str = Integer.toHexString(paramInt1).toUpperCase();
/*      */ 
/* 4855 */     int i = str.length();
/* 4856 */     if (i > paramInt2) {
/* 4857 */       return str.substring(i - paramInt2);
/*      */     }
/* 4859 */     if (i < paramInt2) {
/* 4860 */       return "00000000".substring(8 - (paramInt2 - i)) + str;
/*      */     }
/* 4862 */     return str;
/*      */   }
/*      */ 
/*      */   public static final int unhex(String paramString)
/*      */   {
/* 4867 */     return (int)Long.parseLong(paramString, 16);
/*      */   }
/*      */ 
/*      */   public static final String binary(byte paramByte)
/*      */   {
/* 4877 */     return binary(paramByte, 8);
/*      */   }
/*      */ 
/*      */   public static final String binary(char paramChar)
/*      */   {
/* 4886 */     return binary(paramChar, 16);
/*      */   }
/*      */ 
/*      */   public static final String binary(int paramInt)
/*      */   {
/* 4898 */     return Integer.toBinaryString(paramInt);
/*      */   }
/*      */ 
/*      */   public static final String binary(int paramInt1, int paramInt2)
/*      */   {
/* 4907 */     String str = Integer.toBinaryString(paramInt1);
/*      */ 
/* 4909 */     int i = str.length();
/* 4910 */     if (i > paramInt2) {
/* 4911 */       return str.substring(i - paramInt2);
/*      */     }
/* 4913 */     if (i < paramInt2) {
/* 4914 */       int j = 32 - (paramInt2 - i);
/* 4915 */       return "00000000000000000000000000000000".substring(j) + str;
/*      */     }
/* 4917 */     return str;
/*      */   }
/*      */ 
/*      */   public static final int unbinary(String paramString)
/*      */   {
/* 4926 */     return Integer.parseInt(paramString, 2);
/*      */   }
/*      */ 
/*      */   public final int color(int paramInt)
/*      */   {
/* 4940 */     if (this.g == null) {
/* 4941 */       if (paramInt > 255) paramInt = 255; else if (paramInt < 0) paramInt = 0;
/* 4942 */       return (0xFF000000 | paramInt << 16 | paramInt << 8 | paramInt);
/*      */     }
/* 4944 */     return this.g.color(paramInt);
/*      */   }
/*      */ 
/*      */   public final int color(float paramFloat)
/*      */   {
/* 4949 */     if (this.g == null) {
/* 4950 */       int i = (int)paramFloat;
/* 4951 */       if (i > 255) i = 255; else if (i < 0) i = 0;
/* 4952 */       return (0xFF000000 | i << 16 | i << 8 | i);
/*      */     }
/* 4954 */     return this.g.color(paramFloat);
/*      */   }
/*      */ 
/*      */   public final int color(int paramInt1, int paramInt2)
/*      */   {
/* 4959 */     if (this.g == null) {
/* 4960 */       if (paramInt1 > 255) paramInt1 = 255; else if (paramInt1 < 0) paramInt1 = 0;
/* 4961 */       if (paramInt2 > 255) paramInt2 = 255; else if (paramInt2 < 0) paramInt2 = 0;
/* 4962 */       return (paramInt2 << 24 | paramInt1 << 16 | paramInt1 << 8 | paramInt1);
/*      */     }
/* 4964 */     return this.g.color(paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */   public final int color(float paramFloat1, float paramFloat2)
/*      */   {
/* 4969 */     if (this.g == null) {
/* 4970 */       int i = (int)paramFloat1;
/* 4971 */       int j = (int)paramFloat2;
/* 4972 */       if (i > 255) i = 255; else if (i < 0) i = 0;
/* 4973 */       if (j > 255) j = 255; else if (j < 0) j = 0;
/* 4974 */       return (0xFF000000 | i << 16 | i << 8 | i);
/*      */     }
/* 4976 */     return this.g.color(paramFloat1, paramFloat2);
/*      */   }
/*      */ 
/*      */   public final int color(int paramInt1, int paramInt2, int paramInt3)
/*      */   {
/* 4981 */     if (this.g == null) {
/* 4982 */       if (paramInt1 > 255) paramInt1 = 255; else if (paramInt1 < 0) paramInt1 = 0;
/* 4983 */       if (paramInt2 > 255) paramInt2 = 255; else if (paramInt2 < 0) paramInt2 = 0;
/* 4984 */       if (paramInt3 > 255) paramInt3 = 255; else if (paramInt3 < 0) paramInt3 = 0;
/*      */ 
/* 4986 */       return (0xFF000000 | paramInt1 << 16 | paramInt2 << 8 | paramInt3);
/*      */     }
/* 4988 */     return this.g.color(paramInt1, paramInt2, paramInt3);
/*      */   }
/*      */ 
/*      */   public final int color(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 4993 */     if (this.g == null) {
/* 4994 */       if (paramFloat1 > 255.0F) paramFloat1 = 255.0F; else if (paramFloat1 < 0.0F) paramFloat1 = 0.0F;
/* 4995 */       if (paramFloat2 > 255.0F) paramFloat2 = 255.0F; else if (paramFloat2 < 0.0F) paramFloat2 = 0.0F;
/* 4996 */       if (paramFloat3 > 255.0F) paramFloat3 = 255.0F; else if (paramFloat3 < 0.0F) paramFloat3 = 0.0F;
/*      */ 
/* 4998 */       return (0xFF000000 | (int)paramFloat1 << 16 | (int)paramFloat2 << 8 | (int)paramFloat3);
/*      */     }
/* 5000 */     return this.g.color(paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public final int color(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*      */   {
/* 5005 */     if (this.g == null) {
/* 5006 */       if (paramInt4 > 255) paramInt4 = 255; else if (paramInt4 < 0) paramInt4 = 0;
/* 5007 */       if (paramInt1 > 255) paramInt1 = 255; else if (paramInt1 < 0) paramInt1 = 0;
/* 5008 */       if (paramInt2 > 255) paramInt2 = 255; else if (paramInt2 < 0) paramInt2 = 0;
/* 5009 */       if (paramInt3 > 255) paramInt3 = 255; else if (paramInt3 < 0) paramInt3 = 0;
/*      */ 
/* 5011 */       return (paramInt4 << 24 | paramInt1 << 16 | paramInt2 << 8 | paramInt3);
/*      */     }
/* 5013 */     return this.g.color(paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */ 
/*      */   public final int color(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 5018 */     if (this.g == null) {
/* 5019 */       if (paramFloat4 > 255.0F) paramFloat4 = 255.0F; else if (paramFloat4 < 0.0F) paramFloat4 = 0.0F;
/* 5020 */       if (paramFloat1 > 255.0F) paramFloat1 = 255.0F; else if (paramFloat1 < 0.0F) paramFloat1 = 0.0F;
/* 5021 */       if (paramFloat2 > 255.0F) paramFloat2 = 255.0F; else if (paramFloat2 < 0.0F) paramFloat2 = 0.0F;
/* 5022 */       if (paramFloat3 > 255.0F) paramFloat3 = 255.0F; else if (paramFloat3 < 0.0F) paramFloat3 = 0.0F;
/*      */ 
/* 5024 */       return ((int)paramFloat4 << 24 | (int)paramFloat1 << 16 | (int)paramFloat2 << 8 | (int)paramFloat3);
/*      */     }
/* 5026 */     return this.g.color(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*      */   }
/*      */ 
/*      */   public void setupExternal(Frame paramFrame)
/*      */   {
/* 5175 */     Worker localWorker = new Worker();
/*      */ 
/* 5211 */     paramFrame.addComponentListener(new ComponentAdapter() {
/*      */       public final void componentMoved(ComponentEvent paramComponentEvent) {
/* 5213 */         Point localPoint = ((Frame)paramComponentEvent.getSource()).getLocation();
/* 5214 */         System.err.println("__MOVE__ " + localPoint.x + ' ' + localPoint.y);
/*      */ 
/* 5216 */         System.err.flush();
/*      */       }
/*      */     });
/* 5220 */     paramFrame.addWindowListener(new WindowAdapter() {
/*      */       public final void windowClosing(WindowEvent paramWindowEvent) {
/* 5222 */         System.err.println("__QUIT__");
/* 5223 */         System.err.flush();
/* 5224 */         System.exit(0);
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public static void main(String[] paramArrayOfString)
/*      */   {
/* 5278 */     if (paramArrayOfString.length < 1) {
/* 5279 */       System.err.println("Usage: PApplet <appletname>");
/* 5280 */       System.err.println("For additional options, see the javadoc for PApplet");
/*      */ 
/* 5282 */       System.exit(1);
/*      */     }
/*      */     try
/*      */     {
/* 5286 */       int i = 0;
/* 5287 */       int[] arrayOfInt1 = null;
/* 5288 */       int[] arrayOfInt2 = null;
/* 5289 */       Object localObject1 = System.getProperty("user.dir");
/* 5290 */       String str1 = null;
/* 5291 */       int j = 0;
/* 5292 */       Object localObject2 = Color.BLACK;
/* 5293 */       Color localColor = Color.GRAY;
/* 5294 */       GraphicsDevice localGraphicsDevice = null;
/*      */ 
/* 5296 */       String str2 = null; String str3 = null;
/*      */ 
/* 5298 */       int k = 0;
/* 5299 */       while (k < paramArrayOfString.length) {
/* 5300 */         int l = paramArrayOfString[k].indexOf(61);
/* 5301 */         if (l != -1) {
/* 5302 */           str2 = paramArrayOfString[k].substring(0, l);
/* 5303 */           str3 = paramArrayOfString[k].substring(l + 1);
/*      */ 
/* 5305 */           if (str2.equals("--editor-location")) {
/* 5306 */             i = 1;
/* 5307 */             arrayOfInt2 = toInt(split(str3, ','));
/*      */           }
/* 5309 */           else if (str2.equals("--display")) {
/* 5310 */             int i1 = Integer.parseInt(str3) - 1;
/*      */ 
/* 5315 */             localObject4 = GraphicsEnvironment.getLocalGraphicsEnvironment();
/*      */ 
/* 5317 */             localObject5 = ((GraphicsEnvironment)localObject4).getScreenDevices();
/* 5318 */             if ((i1 >= 0) && (i1 < localObject5.length))
/* 5319 */               localGraphicsDevice = localObject5[i1];
/*      */             else {
/* 5321 */               System.err.println("Display " + str3 + " does not exist, using the default display instead.");
/*      */             }
/*      */ 
/*      */           }
/* 5325 */           else if (str2.equals("--bgcolor")) {
/* 5326 */             if (str3.charAt(0) == '#') str3 = str3.substring(1);
/* 5327 */             localObject2 = new Color(Integer.parseInt(str3, 16));
/*      */           }
/* 5329 */           else if (str2.equals("--present-stop-color")) {
/* 5330 */             if (str3.charAt(0) == '#') str3 = str3.substring(1);
/* 5331 */             localColor = new Color(Integer.parseInt(str3, 16));
/*      */           }
/* 5333 */           else if (str2.equals("--sketch-folder")) {
/* 5334 */             localObject1 = str3;
/*      */           }
/* 5336 */           else if (str2.equals("--location")) {
/* 5337 */             arrayOfInt1 = toInt(split(str3, ','));
/*      */           }
/*      */ 
/*      */         }
/* 5341 */         else if (paramArrayOfString[k].equals("--present")) {
/* 5342 */           j = 1;
/*      */         }
/* 5344 */         else if (paramArrayOfString[k].equals("--external")) {
/* 5345 */           i = 1;
/*      */         }
/*      */         else {
/* 5348 */           str1 = paramArrayOfString[k];
/* 5349 */           break;
/*      */         }
/*      */ 
/* 5352 */         ++k;
/*      */       }
/*      */ 
/* 5355 */       if (localGraphicsDevice == null) {
/* 5356 */         localObject3 = GraphicsEnvironment.getLocalGraphicsEnvironment();
/*      */ 
/* 5358 */         localGraphicsDevice = ((GraphicsEnvironment)localObject3).getDefaultScreenDevice();
/*      */       }
/*      */ 
/* 5361 */       Object localObject3 = new Frame(localGraphicsDevice.getDefaultConfiguration());
/*      */ 
/* 5371 */       Dimension localDimension1 = Toolkit.getDefaultToolkit().getScreenSize();
/*      */ 
/* 5373 */       ((Frame)localObject3).setResizable(false);
/*      */ 
/* 5375 */       Object localObject4 = Class.forName(str1);
/* 5376 */       Object localObject5 = (PApplet)((Class)localObject4).newInstance();
/*      */ 
/* 5379 */       ((PApplet)localObject5).frame = ((Frame)localObject3);
/* 5380 */       ((PApplet)localObject5).folder = ((String)localObject1);
/* 5381 */       ((PApplet)localObject5).args = subset(paramArrayOfString, 1);
/*      */ 
/* 5383 */       ((PApplet)localObject5).init();
/*      */ 
/* 5387 */       while ((((PApplet)localObject5).width == 0) && (!(((PApplet)localObject5).finished)))
/*      */         try {
/* 5389 */           Thread.sleep(5);
/*      */         }
/*      */         catch (InterruptedException localInterruptedException)
/*      */         {
/*      */         }
/*      */       Object localObject6;
/* 5394 */       if (j != 0) {
/* 5395 */         ((Frame)localObject3).setUndecorated(true);
/* 5396 */         ((Frame)localObject3).setBackground((Color)localObject2);
/* 5397 */         localGraphicsDevice.setFullScreenWindow((Window)localObject3);
/*      */ 
/* 5399 */         ((Frame)localObject3).add((Component)localObject5);
/* 5400 */         localObject6 = ((Frame)localObject3).getSize();
/* 5401 */         ((PApplet)localObject5).setBounds((((Dimension)localObject6).width - ((PApplet)localObject5).width) / 2, (((Dimension)localObject6).height - ((PApplet)localObject5).height) / 2, ((PApplet)localObject5).width, ((PApplet)localObject5).height);
/*      */ 
/* 5418 */         Label localLabel = new Label("stop");
/* 5419 */         localLabel.setForeground(localColor);
/* 5420 */         localLabel.addMouseListener(new MouseAdapter() {
/*      */           public final void mousePressed(MouseEvent paramMouseEvent) {
/* 5422 */             System.exit(0);
/*      */           }
/*      */         });
/* 5425 */         ((Frame)localObject3).add(localLabel);
/*      */ 
/* 5427 */         Dimension localDimension2 = localLabel.getPreferredSize();
/*      */ 
/* 5430 */         localDimension2 = new Dimension(100, localDimension2.height);
/* 5431 */         localLabel.setSize(localDimension2);
/* 5432 */         localLabel.setLocation(20, ((Dimension)localObject6).height - localDimension2.height - 20);
/*      */ 
/* 5435 */         if (i != 0) {
/* 5436 */           ((PApplet)localObject5).setupExternal((Frame)localObject3);
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 5441 */         ((Frame)localObject3).pack();
/* 5442 */         localObject6 = ((Frame)localObject3).getInsets();
/*      */ 
/* 5444 */         int i2 = Math.max(((PApplet)localObject5).width, 120) + ((Insets)localObject6).left + ((Insets)localObject6).right;
/*      */ 
/* 5446 */         int i3 = Math.max(((PApplet)localObject5).height, 120) + ((Insets)localObject6).top + ((Insets)localObject6).bottom;
/*      */ 
/* 5449 */         ((Frame)localObject3).setSize(i2, i3);
/*      */ 
/* 5451 */         if (arrayOfInt1 != null)
/*      */         {
/* 5454 */           ((Frame)localObject3).setLocation(arrayOfInt1[0], arrayOfInt1[1]);
/*      */         }
/* 5456 */         else if (i != 0) {
/* 5457 */           i4 = arrayOfInt2[0] - 20;
/* 5458 */           int i5 = arrayOfInt2[1];
/*      */ 
/* 5460 */           if (i4 - i2 > 10)
/*      */           {
/* 5462 */             ((Frame)localObject3).setLocation(i4 - i2, i5);
/*      */           }
/*      */           else
/*      */           {
/* 5468 */             i4 = arrayOfInt2[0] + 66;
/* 5469 */             i5 = arrayOfInt2[1] + 66;
/*      */ 
/* 5471 */             if ((i4 + i2 > localDimension1.width - 33) || (i5 + i3 > localDimension1.height - 33))
/*      */             {
/* 5474 */               i4 = (localDimension1.width - i2) / 2;
/* 5475 */               i5 = (localDimension1.height - i3) / 2;
/*      */             }
/* 5477 */             ((Frame)localObject3).setLocation(i4, i5);
/*      */           }
/*      */         } else {
/* 5480 */           ((Frame)localObject3).setLocation((localDimension1.width - ((PApplet)localObject5).width) / 2, (localDimension1.height - ((PApplet)localObject5).height) / 2);
/*      */         }
/*      */ 
/* 5484 */         ((Frame)localObject3).setLayout(null);
/* 5485 */         ((Frame)localObject3).add((Component)localObject5);
/*      */ 
/* 5487 */         if (localObject2 == Color.BLACK)
/*      */         {
/* 5489 */           localObject2 = SystemColor.control;
/*      */         }
/* 5491 */         ((Frame)localObject3).setBackground((Color)localObject2);
/*      */ 
/* 5493 */         int i4 = i3 - ((Insets)localObject6).top - ((Insets)localObject6).bottom;
/* 5494 */         ((PApplet)localObject5).setBounds((i2 - ((PApplet)localObject5).width) / 2, ((Insets)localObject6).top + (i4 - ((PApplet)localObject5).height) / 2, i2, i3);
/*      */ 
/* 5498 */         if (i != 0) {
/* 5499 */           ((PApplet)localObject5).setupExternal((Frame)localObject3);
/*      */         }
/*      */         else {
/* 5502 */           ((Frame)localObject3).addWindowListener(new WindowAdapter() {
/*      */             public final void windowClosing(WindowEvent paramWindowEvent) {
/* 5504 */               System.exit(0);
/*      */             }
/*      */ 
/*      */           });
/*      */         }
/*      */ 
/* 5510 */         ((Frame)localObject3).show();
/*      */       }
/*      */ 
/* 5515 */       ((PApplet)localObject5).requestFocus();
/*      */     }
/*      */     catch (Exception localException)
/*      */     {
/* 5519 */       localException.printStackTrace();
/* 5520 */       System.exit(1);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void recordFrame(PGraphics paramPGraphics)
/*      */   {
/* 5529 */     this.recorder = paramPGraphics;
/* 5530 */     paramPGraphics.beginFrame();
/*      */   }
/*      */ 
/*      */   public void loadPixels()
/*      */   {
/* 5538 */     this.g.loadPixels();
/* 5539 */     this.pixels = this.g.pixels;
/*      */   }
/*      */ 
/*      */   public void imageMode(int paramInt)
/*      */   {
/* 5561 */     if (this.recorder != null) this.recorder.imageMode(paramInt);
/* 5562 */     this.g.imageMode(paramInt);
/*      */   }
/*      */ 
/*      */   public void smooth()
/*      */   {
/* 5567 */     if (this.recorder != null) this.recorder.smooth();
/* 5568 */     this.g.smooth();
/*      */   }
/*      */ 
/*      */   public void noSmooth()
/*      */   {
/* 5573 */     if (this.recorder != null) this.recorder.noSmooth();
/* 5574 */     this.g.noSmooth();
/*      */   }
/*      */ 
/*      */   public void updatePixels()
/*      */   {
/* 5579 */     if (this.recorder != null) this.recorder.updatePixels();
/* 5580 */     this.g.updatePixels();
/*      */   }
/*      */ 
/*      */   public void updatePixels(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*      */   {
/* 5585 */     if (this.recorder != null) this.recorder.updatePixels(paramInt1, paramInt2, paramInt3, paramInt4);
/* 5586 */     this.g.updatePixels(paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */ 
/*      */   public int get(int paramInt1, int paramInt2)
/*      */   {
/* 5591 */     return this.g.get(paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */   public PImage get(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*      */   {
/* 5596 */     return this.g.get(paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */ 
/*      */   public PImage get()
/*      */   {
/* 5601 */     return this.g.get();
/*      */   }
/*      */ 
/*      */   public void set(int paramInt1, int paramInt2, int paramInt3)
/*      */   {
/* 5606 */     if (this.recorder != null) this.recorder.set(paramInt1, paramInt2, paramInt3);
/* 5607 */     this.g.set(paramInt1, paramInt2, paramInt3);
/*      */   }
/*      */ 
/*      */   public void set(int paramInt1, int paramInt2, PImage paramPImage)
/*      */   {
/* 5612 */     if (this.recorder != null) this.recorder.set(paramInt1, paramInt2, paramPImage);
/* 5613 */     this.g.set(paramInt1, paramInt2, paramPImage);
/*      */   }
/*      */ 
/*      */   public void mask(int[] paramArrayOfInt)
/*      */   {
/* 5618 */     if (this.recorder != null) this.recorder.mask(paramArrayOfInt);
/* 5619 */     this.g.mask(paramArrayOfInt);
/*      */   }
/*      */ 
/*      */   public void mask(PImage paramPImage)
/*      */   {
/* 5624 */     if (this.recorder != null) this.recorder.mask(paramPImage);
/* 5625 */     this.g.mask(paramPImage);
/*      */   }
/*      */ 
/*      */   public void filter(int paramInt)
/*      */   {
/* 5630 */     if (this.recorder != null) this.recorder.filter(paramInt);
/* 5631 */     this.g.filter(paramInt);
/*      */   }
/*      */ 
/*      */   public void filter(int paramInt, float paramFloat)
/*      */   {
/* 5636 */     if (this.recorder != null) this.recorder.filter(paramInt, paramFloat);
/* 5637 */     this.g.filter(paramInt, paramFloat);
/*      */   }
/*      */ 
/*      */   public void copy(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8)
/*      */   {
/* 5643 */     if (this.recorder != null) this.recorder.copy(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8);
/* 5644 */     this.g.copy(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8);
/*      */   }
/*      */ 
/*      */   public void copy(PImage paramPImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8)
/*      */   {
/* 5651 */     if (this.recorder != null) this.recorder.copy(paramPImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8);
/* 5652 */     this.g.copy(paramPImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8);
/*      */   }
/*      */ 
/*      */   public static int blend(int paramInt1, int paramInt2, int paramInt3)
/*      */   {
/* 5657 */     return PGraphics.blend(paramInt1, paramInt2, paramInt3);
/*      */   }
/*      */ 
/*      */   public void blend(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
/*      */   {
/* 5662 */     if (this.recorder != null) this.recorder.blend(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/* 5663 */     this.g.blend(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*      */   }
/*      */ 
/*      */   public void blend(PImage paramPImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
/*      */   {
/* 5669 */     if (this.recorder != null) this.recorder.blend(paramPImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/* 5670 */     this.g.blend(paramPImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*      */   }
/*      */ 
/*      */   public void blend(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9)
/*      */   {
/* 5676 */     if (this.recorder != null) this.recorder.blend(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9);
/* 5677 */     this.g.blend(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9);
/*      */   }
/*      */ 
/*      */   public void blend(PImage paramPImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9)
/*      */   {
/* 5684 */     if (this.recorder != null) this.recorder.blend(paramPImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9);
/* 5685 */     this.g.blend(paramPImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9);
/*      */   }
/*      */ 
/*      */   public static boolean saveHeaderTIFF(OutputStream paramOutputStream, int paramInt1, int paramInt2)
/*      */   {
/* 5691 */     return PGraphics.saveHeaderTIFF(paramOutputStream, paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */   public static boolean saveTIFF(OutputStream paramOutputStream, int[] paramArrayOfInt, int paramInt1, int paramInt2)
/*      */   {
/* 5697 */     return PGraphics.saveTIFF(paramOutputStream, paramArrayOfInt, paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */   public static boolean saveHeaderTGA(OutputStream paramOutputStream, int paramInt1, int paramInt2)
/*      */   {
/* 5703 */     return PGraphics.saveHeaderTGA(paramOutputStream, paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */   public static boolean saveTGA(OutputStream paramOutputStream, int[] paramArrayOfInt, int paramInt1, int paramInt2)
/*      */   {
/* 5709 */     return PGraphics.saveTGA(paramOutputStream, paramArrayOfInt, paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */   public void hint(int paramInt)
/*      */   {
/* 5714 */     if (this.recorder != null) this.recorder.hint(paramInt);
/* 5715 */     this.g.hint(paramInt);
/*      */   }
/*      */ 
/*      */   public void unhint(int paramInt)
/*      */   {
/* 5720 */     if (this.recorder != null) this.recorder.unhint(paramInt);
/* 5721 */     this.g.unhint(paramInt);
/*      */   }
/*      */ 
/*      */   public void beginShape()
/*      */   {
/* 5726 */     if (this.recorder != null) this.recorder.beginShape();
/* 5727 */     this.g.beginShape();
/*      */   }
/*      */ 
/*      */   public void beginShape(int paramInt)
/*      */   {
/* 5732 */     if (this.recorder != null) this.recorder.beginShape(paramInt);
/* 5733 */     this.g.beginShape(paramInt);
/*      */   }
/*      */ 
/*      */   public void normal(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 5738 */     if (this.recorder != null) this.recorder.normal(paramFloat1, paramFloat2, paramFloat3);
/* 5739 */     this.g.normal(paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public void textureMode(int paramInt)
/*      */   {
/* 5744 */     if (this.recorder != null) this.recorder.textureMode(paramInt);
/* 5745 */     this.g.textureMode(paramInt);
/*      */   }
/*      */ 
/*      */   public void texture(PImage paramPImage)
/*      */   {
/* 5750 */     if (this.recorder != null) this.recorder.texture(paramPImage);
/* 5751 */     this.g.texture(paramPImage);
/*      */   }
/*      */ 
/*      */   public void vertex(float paramFloat1, float paramFloat2)
/*      */   {
/* 5756 */     if (this.recorder != null) this.recorder.vertex(paramFloat1, paramFloat2);
/* 5757 */     this.g.vertex(paramFloat1, paramFloat2);
/*      */   }
/*      */ 
/*      */   public void vertex(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 5762 */     if (this.recorder != null) this.recorder.vertex(paramFloat1, paramFloat2, paramFloat3);
/* 5763 */     this.g.vertex(paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public void vertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 5768 */     if (this.recorder != null) this.recorder.vertex(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/* 5769 */     this.g.vertex(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*      */   }
/*      */ 
/*      */   public void vertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5)
/*      */   {
/* 5774 */     if (this.recorder != null) this.recorder.vertex(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5);
/* 5775 */     this.g.vertex(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5);
/*      */   }
/*      */ 
/*      */   public void bezierVertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/* 5782 */     if (this.recorder != null) this.recorder.bezierVertex(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/* 5783 */     this.g.bezierVertex(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/*      */   }
/*      */ 
/*      */   public void bezierVertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9)
/*      */   {
/* 5790 */     if (this.recorder != null) this.recorder.bezierVertex(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9);
/* 5791 */     this.g.bezierVertex(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9);
/*      */   }
/*      */ 
/*      */   public void curveVertex(float paramFloat1, float paramFloat2)
/*      */   {
/* 5796 */     if (this.recorder != null) this.recorder.curveVertex(paramFloat1, paramFloat2);
/* 5797 */     this.g.curveVertex(paramFloat1, paramFloat2);
/*      */   }
/*      */ 
/*      */   public void curveVertex(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 5802 */     if (this.recorder != null) this.recorder.curveVertex(paramFloat1, paramFloat2, paramFloat3);
/* 5803 */     this.g.curveVertex(paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public void endShape()
/*      */   {
/* 5808 */     if (this.recorder != null) this.recorder.endShape();
/* 5809 */     this.g.endShape();
/*      */   }
/*      */ 
/*      */   public void point(float paramFloat1, float paramFloat2)
/*      */   {
/* 5814 */     if (this.recorder != null) this.recorder.point(paramFloat1, paramFloat2);
/* 5815 */     this.g.point(paramFloat1, paramFloat2);
/*      */   }
/*      */ 
/*      */   public void point(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 5820 */     if (this.recorder != null) this.recorder.point(paramFloat1, paramFloat2, paramFloat3);
/* 5821 */     this.g.point(paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public void line(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 5826 */     if (this.recorder != null) this.recorder.line(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/* 5827 */     this.g.line(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*      */   }
/*      */ 
/*      */   public void line(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/* 5833 */     if (this.recorder != null) this.recorder.line(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/* 5834 */     this.g.line(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/*      */   }
/*      */ 
/*      */   public void triangle(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/* 5840 */     if (this.recorder != null) this.recorder.triangle(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/* 5841 */     this.g.triangle(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/*      */   }
/*      */ 
/*      */   public void quad(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8)
/*      */   {
/* 5847 */     if (this.recorder != null) this.recorder.quad(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8);
/* 5848 */     this.g.quad(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8);
/*      */   }
/*      */ 
/*      */   public void rectMode(int paramInt)
/*      */   {
/* 5853 */     if (this.recorder != null) this.recorder.rectMode(paramInt);
/* 5854 */     this.g.rectMode(paramInt);
/*      */   }
/*      */ 
/*      */   public void rect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 5859 */     if (this.recorder != null) this.recorder.rect(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/* 5860 */     this.g.rect(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*      */   }
/*      */ 
/*      */   public void ellipseMode(int paramInt)
/*      */   {
/* 5865 */     if (this.recorder != null) this.recorder.ellipseMode(paramInt);
/* 5866 */     this.g.ellipseMode(paramInt);
/*      */   }
/*      */ 
/*      */   public void ellipse(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 5871 */     if (this.recorder != null) this.recorder.ellipse(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/* 5872 */     this.g.ellipse(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*      */   }
/*      */ 
/*      */   public void arc(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/* 5878 */     if (this.recorder != null) this.recorder.arc(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/* 5879 */     this.g.arc(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/*      */   }
/*      */ 
/*      */   public void box(float paramFloat)
/*      */   {
/* 5884 */     if (this.recorder != null) this.recorder.box(paramFloat);
/* 5885 */     this.g.box(paramFloat);
/*      */   }
/*      */ 
/*      */   public void box(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 5890 */     if (this.recorder != null) this.recorder.box(paramFloat1, paramFloat2, paramFloat3);
/* 5891 */     this.g.box(paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public void sphereDetail(int paramInt)
/*      */   {
/* 5896 */     if (this.recorder != null) this.recorder.sphereDetail(paramInt);
/* 5897 */     this.g.sphereDetail(paramInt);
/*      */   }
/*      */ 
/*      */   public void sphere(float paramFloat)
/*      */   {
/* 5902 */     if (this.recorder != null) this.recorder.sphere(paramFloat);
/* 5903 */     this.g.sphere(paramFloat);
/*      */   }
/*      */ 
/*      */   public float bezierPoint(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5)
/*      */   {
/* 5908 */     return this.g.bezierPoint(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5);
/*      */   }
/*      */ 
/*      */   public float bezierTangent(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5)
/*      */   {
/* 5913 */     return this.g.bezierTangent(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5);
/*      */   }
/*      */ 
/*      */   public void bezier(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8)
/*      */   {
/* 5921 */     if (this.recorder != null) this.recorder.bezier(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8);
/* 5922 */     this.g.bezier(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8);
/*      */   }
/*      */ 
/*      */   public void bezier(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12)
/*      */   {
/* 5930 */     if (this.recorder != null) this.recorder.bezier(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramFloat11, paramFloat12);
/* 5931 */     this.g.bezier(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramFloat11, paramFloat12);
/*      */   }
/*      */ 
/*      */   public void bezierDetail(int paramInt)
/*      */   {
/* 5936 */     if (this.recorder != null) this.recorder.bezierDetail(paramInt);
/* 5937 */     this.g.bezierDetail(paramInt);
/*      */   }
/*      */ 
/*      */   public void curveDetail(int paramInt)
/*      */   {
/* 5942 */     if (this.recorder != null) this.recorder.curveDetail(paramInt);
/* 5943 */     this.g.curveDetail(paramInt);
/*      */   }
/*      */ 
/*      */   public void curveTightness(float paramFloat)
/*      */   {
/* 5948 */     if (this.recorder != null) this.recorder.curveTightness(paramFloat);
/* 5949 */     this.g.curveTightness(paramFloat);
/*      */   }
/*      */ 
/*      */   public float curvePoint(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5)
/*      */   {
/* 5954 */     return this.g.curvePoint(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5);
/*      */   }
/*      */ 
/*      */   public float curveTangent(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5)
/*      */   {
/* 5960 */     return this.g.curveTangent(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5);
/*      */   }
/*      */ 
/*      */   public void curve(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8)
/*      */   {
/* 5968 */     if (this.recorder != null) this.recorder.curve(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8);
/* 5969 */     this.g.curve(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8);
/*      */   }
/*      */ 
/*      */   public void curve(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12)
/*      */   {
/* 5977 */     if (this.recorder != null) this.recorder.curve(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramFloat11, paramFloat12);
/* 5978 */     this.g.curve(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramFloat11, paramFloat12);
/*      */   }
/*      */ 
/*      */   public void image(PImage paramPImage, float paramFloat1, float paramFloat2)
/*      */   {
/* 5983 */     if (this.recorder != null) this.recorder.image(paramPImage, paramFloat1, paramFloat2);
/* 5984 */     this.g.image(paramPImage, paramFloat1, paramFloat2);
/*      */   }
/*      */ 
/*      */   public void image(PImage paramPImage, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 5990 */     if (this.recorder != null) this.recorder.image(paramPImage, paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/* 5991 */     this.g.image(paramPImage, paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*      */   }
/*      */ 
/*      */   public void image(PImage paramPImage, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*      */   {
/* 5998 */     if (this.recorder != null) this.recorder.image(paramPImage, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramInt1, paramInt2, paramInt3, paramInt4);
/* 5999 */     this.g.image(paramPImage, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */ 
/*      */   public void textFont(PFont paramPFont, float paramFloat)
/*      */   {
/* 6004 */     if (this.recorder != null) this.recorder.textFont(paramPFont, paramFloat);
/* 6005 */     this.g.textFont(paramPFont, paramFloat);
/*      */   }
/*      */ 
/*      */   public void textFont(PFont paramPFont)
/*      */   {
/* 6010 */     if (this.recorder != null) this.recorder.textFont(paramPFont);
/* 6011 */     this.g.textFont(paramPFont);
/*      */   }
/*      */ 
/*      */   public void textSize(float paramFloat)
/*      */   {
/* 6016 */     if (this.recorder != null) this.recorder.textSize(paramFloat);
/* 6017 */     this.g.textSize(paramFloat);
/*      */   }
/*      */ 
/*      */   public void textLeading(float paramFloat)
/*      */   {
/* 6022 */     if (this.recorder != null) this.recorder.textLeading(paramFloat);
/* 6023 */     this.g.textLeading(paramFloat);
/*      */   }
/*      */ 
/*      */   public void textAlign(int paramInt)
/*      */   {
/* 6028 */     if (this.recorder != null) this.recorder.textAlign(paramInt);
/* 6029 */     this.g.textAlign(paramInt);
/*      */   }
/*      */ 
/*      */   public void textMode(int paramInt)
/*      */   {
/* 6034 */     if (this.recorder != null) this.recorder.textMode(paramInt);
/* 6035 */     this.g.textMode(paramInt);
/*      */   }
/*      */ 
/*      */   public float textAscent()
/*      */   {
/* 6040 */     return this.g.textAscent();
/*      */   }
/*      */ 
/*      */   public float textDescent()
/*      */   {
/* 6045 */     return this.g.textDescent();
/*      */   }
/*      */ 
/*      */   public float textWidth(char paramChar)
/*      */   {
/* 6050 */     return this.g.textWidth(paramChar);
/*      */   }
/*      */ 
/*      */   public float textWidth(String paramString)
/*      */   {
/* 6055 */     return this.g.textWidth(paramString);
/*      */   }
/*      */ 
/*      */   public void text(char paramChar, float paramFloat1, float paramFloat2)
/*      */   {
/* 6060 */     if (this.recorder != null) this.recorder.text(paramChar, paramFloat1, paramFloat2);
/* 6061 */     this.g.text(paramChar, paramFloat1, paramFloat2);
/*      */   }
/*      */ 
/*      */   public void text(char paramChar, float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 6066 */     if (this.recorder != null) this.recorder.text(paramChar, paramFloat1, paramFloat2, paramFloat3);
/* 6067 */     this.g.text(paramChar, paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public void text(String paramString, float paramFloat1, float paramFloat2)
/*      */   {
/* 6072 */     if (this.recorder != null) this.recorder.text(paramString, paramFloat1, paramFloat2);
/* 6073 */     this.g.text(paramString, paramFloat1, paramFloat2);
/*      */   }
/*      */ 
/*      */   public void text(String paramString, float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 6078 */     if (this.recorder != null) this.recorder.text(paramString, paramFloat1, paramFloat2, paramFloat3);
/* 6079 */     this.g.text(paramString, paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public void text(String paramString, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 6084 */     if (this.recorder != null) this.recorder.text(paramString, paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/* 6085 */     this.g.text(paramString, paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*      */   }
/*      */ 
/*      */   public void text(String paramString, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5)
/*      */   {
/* 6090 */     if (this.recorder != null) this.recorder.text(paramString, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5);
/* 6091 */     this.g.text(paramString, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5);
/*      */   }
/*      */ 
/*      */   public void text(int paramInt, float paramFloat1, float paramFloat2)
/*      */   {
/* 6096 */     if (this.recorder != null) this.recorder.text(paramInt, paramFloat1, paramFloat2);
/* 6097 */     this.g.text(paramInt, paramFloat1, paramFloat2);
/*      */   }
/*      */ 
/*      */   public void text(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 6102 */     if (this.recorder != null) this.recorder.text(paramInt, paramFloat1, paramFloat2, paramFloat3);
/* 6103 */     this.g.text(paramInt, paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public void text(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 6108 */     if (this.recorder != null) this.recorder.text(paramFloat1, paramFloat2, paramFloat3);
/* 6109 */     this.g.text(paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public void text(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 6114 */     if (this.recorder != null) this.recorder.text(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/* 6115 */     this.g.text(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*      */   }
/*      */ 
/*      */   public void translate(float paramFloat1, float paramFloat2)
/*      */   {
/* 6120 */     if (this.recorder != null) this.recorder.translate(paramFloat1, paramFloat2);
/* 6121 */     this.g.translate(paramFloat1, paramFloat2);
/*      */   }
/*      */ 
/*      */   public void translate(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 6126 */     if (this.recorder != null) this.recorder.translate(paramFloat1, paramFloat2, paramFloat3);
/* 6127 */     this.g.translate(paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public void rotate(float paramFloat)
/*      */   {
/* 6132 */     if (this.recorder != null) this.recorder.rotate(paramFloat);
/* 6133 */     this.g.rotate(paramFloat);
/*      */   }
/*      */ 
/*      */   public void rotateX(float paramFloat)
/*      */   {
/* 6138 */     if (this.recorder != null) this.recorder.rotateX(paramFloat);
/* 6139 */     this.g.rotateX(paramFloat);
/*      */   }
/*      */ 
/*      */   public void rotateY(float paramFloat)
/*      */   {
/* 6144 */     if (this.recorder != null) this.recorder.rotateY(paramFloat);
/* 6145 */     this.g.rotateY(paramFloat);
/*      */   }
/*      */ 
/*      */   public void rotateZ(float paramFloat)
/*      */   {
/* 6150 */     if (this.recorder != null) this.recorder.rotateZ(paramFloat);
/* 6151 */     this.g.rotateZ(paramFloat);
/*      */   }
/*      */ 
/*      */   public void rotate(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 6156 */     if (this.recorder != null) this.recorder.rotate(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/* 6157 */     this.g.rotate(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*      */   }
/*      */ 
/*      */   public void scale(float paramFloat)
/*      */   {
/* 6162 */     if (this.recorder != null) this.recorder.scale(paramFloat);
/* 6163 */     this.g.scale(paramFloat);
/*      */   }
/*      */ 
/*      */   public void scale(float paramFloat1, float paramFloat2)
/*      */   {
/* 6168 */     if (this.recorder != null) this.recorder.scale(paramFloat1, paramFloat2);
/* 6169 */     this.g.scale(paramFloat1, paramFloat2);
/*      */   }
/*      */ 
/*      */   public void scale(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 6174 */     if (this.recorder != null) this.recorder.scale(paramFloat1, paramFloat2, paramFloat3);
/* 6175 */     this.g.scale(paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public void pushMatrix()
/*      */   {
/* 6180 */     if (this.recorder != null) this.recorder.pushMatrix();
/* 6181 */     this.g.pushMatrix();
/*      */   }
/*      */ 
/*      */   public void popMatrix()
/*      */   {
/* 6186 */     if (this.recorder != null) this.recorder.popMatrix();
/* 6187 */     this.g.popMatrix();
/*      */   }
/*      */ 
/*      */   public void resetMatrix()
/*      */   {
/* 6192 */     if (this.recorder != null) this.recorder.resetMatrix();
/* 6193 */     this.g.resetMatrix();
/*      */   }
/*      */ 
/*      */   public void applyMatrix(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/* 6199 */     if (this.recorder != null) this.recorder.applyMatrix(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/* 6200 */     this.g.applyMatrix(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/*      */   }
/*      */ 
/*      */   public void applyMatrix(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12, float paramFloat13, float paramFloat14, float paramFloat15, float paramFloat16)
/*      */   {
/* 6208 */     if (this.recorder != null) this.recorder.applyMatrix(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramFloat11, paramFloat12, paramFloat13, paramFloat14, paramFloat15, paramFloat16);
/* 6209 */     this.g.applyMatrix(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramFloat11, paramFloat12, paramFloat13, paramFloat14, paramFloat15, paramFloat16);
/*      */   }
/*      */ 
/*      */   public void printMatrix()
/*      */   {
/* 6214 */     if (this.recorder != null) this.recorder.printMatrix();
/* 6215 */     this.g.printMatrix();
/*      */   }
/*      */ 
/*      */   public void cameraMode(int paramInt)
/*      */   {
/* 6220 */     if (this.recorder != null) this.recorder.cameraMode(paramInt);
/* 6221 */     this.g.cameraMode(paramInt);
/*      */   }
/*      */ 
/*      */   public void beginCamera()
/*      */   {
/* 6226 */     if (this.recorder != null) this.recorder.beginCamera();
/* 6227 */     this.g.beginCamera();
/*      */   }
/*      */ 
/*      */   public void endCamera()
/*      */   {
/* 6232 */     if (this.recorder != null) this.recorder.endCamera();
/* 6233 */     this.g.endCamera();
/*      */   }
/*      */ 
/*      */   public void camera()
/*      */   {
/* 6238 */     if (this.recorder != null) this.recorder.camera();
/* 6239 */     this.g.camera();
/*      */   }
/*      */ 
/*      */   public void camera(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9)
/*      */   {
/* 6246 */     if (this.recorder != null) this.recorder.camera(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9);
/* 6247 */     this.g.camera(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9);
/*      */   }
/*      */ 
/*      */   public void ortho()
/*      */   {
/* 6252 */     if (this.recorder != null) this.recorder.ortho();
/* 6253 */     this.g.ortho();
/*      */   }
/*      */ 
/*      */   public void ortho(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/* 6260 */     if (this.recorder != null) this.recorder.ortho(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/* 6261 */     this.g.ortho(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/*      */   }
/*      */ 
/*      */   public void perspective()
/*      */   {
/* 6266 */     if (this.recorder != null) this.recorder.perspective();
/* 6267 */     this.g.perspective();
/*      */   }
/*      */ 
/*      */   public void perspective(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 6272 */     if (this.recorder != null) this.recorder.perspective(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/* 6273 */     this.g.perspective(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*      */   }
/*      */ 
/*      */   public void frustum(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/* 6279 */     if (this.recorder != null) this.recorder.frustum(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/* 6280 */     this.g.frustum(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/*      */   }
/*      */ 
/*      */   public void printCamera()
/*      */   {
/* 6285 */     if (this.recorder != null) this.recorder.printCamera();
/* 6286 */     this.g.printCamera();
/*      */   }
/*      */ 
/*      */   public void printProjection()
/*      */   {
/* 6291 */     if (this.recorder != null) this.recorder.printProjection();
/* 6292 */     this.g.printProjection();
/*      */   }
/*      */ 
/*      */   public float screenX(float paramFloat1, float paramFloat2)
/*      */   {
/* 6297 */     return this.g.screenX(paramFloat1, paramFloat2);
/*      */   }
/*      */ 
/*      */   public float screenY(float paramFloat1, float paramFloat2)
/*      */   {
/* 6302 */     return this.g.screenY(paramFloat1, paramFloat2);
/*      */   }
/*      */ 
/*      */   public float screenX(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 6307 */     return this.g.screenX(paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public float screenY(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 6312 */     return this.g.screenY(paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public float screenZ(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 6317 */     return this.g.screenZ(paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public float modelX(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 6322 */     return this.g.modelX(paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public float modelY(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 6327 */     return this.g.modelY(paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public float modelZ(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 6332 */     return this.g.modelZ(paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public void colorMode(int paramInt)
/*      */   {
/* 6337 */     if (this.recorder != null) this.recorder.colorMode(paramInt);
/* 6338 */     this.g.colorMode(paramInt);
/*      */   }
/*      */ 
/*      */   public void colorMode(int paramInt, float paramFloat)
/*      */   {
/* 6343 */     if (this.recorder != null) this.recorder.colorMode(paramInt, paramFloat);
/* 6344 */     this.g.colorMode(paramInt, paramFloat);
/*      */   }
/*      */ 
/*      */   public void colorMode(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 6350 */     if (this.recorder != null) this.recorder.colorMode(paramInt, paramFloat1, paramFloat2, paramFloat3);
/* 6351 */     this.g.colorMode(paramInt, paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public void colorMode(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 6357 */     if (this.recorder != null) this.recorder.colorMode(paramInt, paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/* 6358 */     this.g.colorMode(paramInt, paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*      */   }
/*      */ 
/*      */   public void noTint()
/*      */   {
/* 6363 */     if (this.recorder != null) this.recorder.noTint();
/* 6364 */     this.g.noTint();
/*      */   }
/*      */ 
/*      */   public void tint(int paramInt)
/*      */   {
/* 6369 */     if (this.recorder != null) this.recorder.tint(paramInt);
/* 6370 */     this.g.tint(paramInt);
/*      */   }
/*      */ 
/*      */   public void tint(float paramFloat)
/*      */   {
/* 6375 */     if (this.recorder != null) this.recorder.tint(paramFloat);
/* 6376 */     this.g.tint(paramFloat);
/*      */   }
/*      */ 
/*      */   public void tint(float paramFloat1, float paramFloat2)
/*      */   {
/* 6381 */     if (this.recorder != null) this.recorder.tint(paramFloat1, paramFloat2);
/* 6382 */     this.g.tint(paramFloat1, paramFloat2);
/*      */   }
/*      */ 
/*      */   public void tint(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 6387 */     if (this.recorder != null) this.recorder.tint(paramFloat1, paramFloat2, paramFloat3);
/* 6388 */     this.g.tint(paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public void tint(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 6393 */     if (this.recorder != null) this.recorder.tint(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/* 6394 */     this.g.tint(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*      */   }
/*      */ 
/*      */   public void noFill()
/*      */   {
/* 6399 */     if (this.recorder != null) this.recorder.noFill();
/* 6400 */     this.g.noFill();
/*      */   }
/*      */ 
/*      */   public void fill(int paramInt)
/*      */   {
/* 6405 */     if (this.recorder != null) this.recorder.fill(paramInt);
/* 6406 */     this.g.fill(paramInt);
/*      */   }
/*      */ 
/*      */   public void fill(float paramFloat)
/*      */   {
/* 6411 */     if (this.recorder != null) this.recorder.fill(paramFloat);
/* 6412 */     this.g.fill(paramFloat);
/*      */   }
/*      */ 
/*      */   public void fill(float paramFloat1, float paramFloat2)
/*      */   {
/* 6417 */     if (this.recorder != null) this.recorder.fill(paramFloat1, paramFloat2);
/* 6418 */     this.g.fill(paramFloat1, paramFloat2);
/*      */   }
/*      */ 
/*      */   public void fill(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 6423 */     if (this.recorder != null) this.recorder.fill(paramFloat1, paramFloat2, paramFloat3);
/* 6424 */     this.g.fill(paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public void fill(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 6429 */     if (this.recorder != null) this.recorder.fill(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/* 6430 */     this.g.fill(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*      */   }
/*      */ 
/*      */   public void ambient(int paramInt)
/*      */   {
/* 6435 */     if (this.recorder != null) this.recorder.ambient(paramInt);
/* 6436 */     this.g.ambient(paramInt);
/*      */   }
/*      */ 
/*      */   public void ambient(float paramFloat)
/*      */   {
/* 6441 */     if (this.recorder != null) this.recorder.ambient(paramFloat);
/* 6442 */     this.g.ambient(paramFloat);
/*      */   }
/*      */ 
/*      */   public void ambient(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 6447 */     if (this.recorder != null) this.recorder.ambient(paramFloat1, paramFloat2, paramFloat3);
/* 6448 */     this.g.ambient(paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public void specular(int paramInt)
/*      */   {
/* 6453 */     if (this.recorder != null) this.recorder.specular(paramInt);
/* 6454 */     this.g.specular(paramInt);
/*      */   }
/*      */ 
/*      */   public void specular(float paramFloat)
/*      */   {
/* 6459 */     if (this.recorder != null) this.recorder.specular(paramFloat);
/* 6460 */     this.g.specular(paramFloat);
/*      */   }
/*      */ 
/*      */   public void specular(float paramFloat1, float paramFloat2)
/*      */   {
/* 6465 */     if (this.recorder != null) this.recorder.specular(paramFloat1, paramFloat2);
/* 6466 */     this.g.specular(paramFloat1, paramFloat2);
/*      */   }
/*      */ 
/*      */   public void specular(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 6471 */     if (this.recorder != null) this.recorder.specular(paramFloat1, paramFloat2, paramFloat3);
/* 6472 */     this.g.specular(paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public void specular(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 6477 */     if (this.recorder != null) this.recorder.specular(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/* 6478 */     this.g.specular(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*      */   }
/*      */ 
/*      */   public void shininess(float paramFloat)
/*      */   {
/* 6483 */     if (this.recorder != null) this.recorder.shininess(paramFloat);
/* 6484 */     this.g.shininess(paramFloat);
/*      */   }
/*      */ 
/*      */   public void emissive(int paramInt)
/*      */   {
/* 6489 */     if (this.recorder != null) this.recorder.emissive(paramInt);
/* 6490 */     this.g.emissive(paramInt);
/*      */   }
/*      */ 
/*      */   public void emissive(float paramFloat)
/*      */   {
/* 6495 */     if (this.recorder != null) this.recorder.emissive(paramFloat);
/* 6496 */     this.g.emissive(paramFloat);
/*      */   }
/*      */ 
/*      */   public void emissive(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 6501 */     if (this.recorder != null) this.recorder.emissive(paramFloat1, paramFloat2, paramFloat3);
/* 6502 */     this.g.emissive(paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public void lights()
/*      */   {
/* 6507 */     if (this.recorder != null) this.recorder.lights();
/* 6508 */     this.g.lights();
/*      */   }
/*      */ 
/*      */   public void ambientLight(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 6513 */     if (this.recorder != null) this.recorder.ambientLight(paramFloat1, paramFloat2, paramFloat3);
/* 6514 */     this.g.ambientLight(paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public void ambientLight(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/* 6519 */     if (this.recorder != null) this.recorder.ambientLight(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/* 6520 */     this.g.ambientLight(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/*      */   }
/*      */ 
/*      */   public void directionalLight(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/* 6526 */     if (this.recorder != null) this.recorder.directionalLight(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/* 6527 */     this.g.directionalLight(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/*      */   }
/*      */ 
/*      */   public void pointLight(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/* 6533 */     if (this.recorder != null) this.recorder.pointLight(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/* 6534 */     this.g.pointLight(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/*      */   }
/*      */ 
/*      */   public void spotLight(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11)
/*      */   {
/* 6542 */     if (this.recorder != null) this.recorder.spotLight(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramFloat11);
/* 6543 */     this.g.spotLight(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramFloat11);
/*      */   }
/*      */ 
/*      */   public void lightFalloff(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 6548 */     if (this.recorder != null) this.recorder.lightFalloff(paramFloat1, paramFloat2, paramFloat3);
/* 6549 */     this.g.lightFalloff(paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public void lightSpecular(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 6554 */     if (this.recorder != null) this.recorder.lightSpecular(paramFloat1, paramFloat2, paramFloat3);
/* 6555 */     this.g.lightSpecular(paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public void strokeWeight(float paramFloat)
/*      */   {
/* 6560 */     if (this.recorder != null) this.recorder.strokeWeight(paramFloat);
/* 6561 */     this.g.strokeWeight(paramFloat);
/*      */   }
/*      */ 
/*      */   public void strokeJoin(int paramInt)
/*      */   {
/* 6566 */     if (this.recorder != null) this.recorder.strokeJoin(paramInt);
/* 6567 */     this.g.strokeJoin(paramInt);
/*      */   }
/*      */ 
/*      */   public void strokeCap(int paramInt)
/*      */   {
/* 6572 */     if (this.recorder != null) this.recorder.strokeCap(paramInt);
/* 6573 */     this.g.strokeCap(paramInt);
/*      */   }
/*      */ 
/*      */   public void noStroke()
/*      */   {
/* 6578 */     if (this.recorder != null) this.recorder.noStroke();
/* 6579 */     this.g.noStroke();
/*      */   }
/*      */ 
/*      */   public void stroke(int paramInt)
/*      */   {
/* 6584 */     if (this.recorder != null) this.recorder.stroke(paramInt);
/* 6585 */     this.g.stroke(paramInt);
/*      */   }
/*      */ 
/*      */   public void stroke(float paramFloat)
/*      */   {
/* 6590 */     if (this.recorder != null) this.recorder.stroke(paramFloat);
/* 6591 */     this.g.stroke(paramFloat);
/*      */   }
/*      */ 
/*      */   public void stroke(float paramFloat1, float paramFloat2)
/*      */   {
/* 6596 */     if (this.recorder != null) this.recorder.stroke(paramFloat1, paramFloat2);
/* 6597 */     this.g.stroke(paramFloat1, paramFloat2);
/*      */   }
/*      */ 
/*      */   public void stroke(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 6602 */     if (this.recorder != null) this.recorder.stroke(paramFloat1, paramFloat2, paramFloat3);
/* 6603 */     this.g.stroke(paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public void stroke(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 6608 */     if (this.recorder != null) this.recorder.stroke(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/* 6609 */     this.g.stroke(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*      */   }
/*      */ 
/*      */   public void background(int paramInt)
/*      */   {
/* 6614 */     if (this.recorder != null) this.recorder.background(paramInt);
/* 6615 */     this.g.background(paramInt);
/*      */   }
/*      */ 
/*      */   public void background(float paramFloat)
/*      */   {
/* 6620 */     if (this.recorder != null) this.recorder.background(paramFloat);
/* 6621 */     this.g.background(paramFloat);
/*      */   }
/*      */ 
/*      */   public void background(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 6626 */     if (this.recorder != null) this.recorder.background(paramFloat1, paramFloat2, paramFloat3);
/* 6627 */     this.g.background(paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public void background(PImage paramPImage)
/*      */   {
/* 6632 */     if (this.recorder != null) this.recorder.background(paramPImage);
/* 6633 */     this.g.background(paramPImage);
/*      */   }
/*      */ 
/*      */   public final float alpha(int paramInt)
/*      */   {
/* 6638 */     return this.g.alpha(paramInt);
/*      */   }
/*      */ 
/*      */   public final float red(int paramInt)
/*      */   {
/* 6643 */     return this.g.red(paramInt);
/*      */   }
/*      */ 
/*      */   public final float green(int paramInt)
/*      */   {
/* 6648 */     return this.g.green(paramInt);
/*      */   }
/*      */ 
/*      */   public final float blue(int paramInt)
/*      */   {
/* 6653 */     return this.g.blue(paramInt);
/*      */   }
/*      */ 
/*      */   public final float hue(int paramInt)
/*      */   {
/* 6658 */     return this.g.hue(paramInt);
/*      */   }
/*      */ 
/*      */   public final float saturation(int paramInt)
/*      */   {
/* 6663 */     return this.g.saturation(paramInt);
/*      */   }
/*      */ 
/*      */   public final float brightness(int paramInt)
/*      */   {
/* 6668 */     return this.g.brightness(paramInt);
/*      */   }
/*      */ 
/*      */   static Class jdMethod_class(String paramString, boolean paramBoolean)
/*      */   {
/*      */     try
/*      */     {
/*      */       if (!(paramBoolean));
/*      */       return Class.forName(paramString).getComponentType();
/*      */     }
/*      */     catch (ClassNotFoundException localClassNotFoundException)
/*      */     {
/*      */       throw new NoClassDefFoundError(localClassNotFoundException.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void jdMethod_this()
/*      */   {
/*  112 */     this.glock = new Object();
/*      */ 
/*  140 */     this.screen = Toolkit.getDefaultToolkit().getScreenSize();
/*      */ 
/*  256 */     this.focused = false;
/*      */ 
/*  264 */     this.online = false;
/*      */ 
/*  282 */     this.framerate = 10.0F;
/*  283 */     this.framerateLastMillis = 0L;
/*      */ 
/*  286 */     this.framerateLastDelayTime = 0L;
/*  287 */     this.framerateTarget = 0.0F;
/*      */ 
/* 1206 */     this.mouseEventQueue = new MouseEvent[10];
/*      */ 
/* 1389 */     this.keyEventQueue = new KeyEvent[10];
/*      */ 
/* 1924 */     this.cursor_type = 0;
/* 1925 */     this.cursor_visible = true;
/*      */ 
/* 2556 */     this.perlin_octaves = 4;
/* 2557 */     this.perlin_amp_falloff = 0.5F;
/*      */   }
/*      */ 
/*      */   public PApplet()
/*      */   {
/*   42 */     jdMethod_this();
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*   84 */     if (platformName.toLowerCase().indexOf("mac") != -1)
/*      */     {
/*   88 */       if (System.getProperty("mrj.version") != null) {
/*   89 */         platform = platformName.equals("Mac OS X") + true;
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*   94 */       String str = System.getProperty("os.name");
/*      */ 
/*   96 */       if (str.indexOf("Windows") != -1) {
/*   97 */         platform = 1;
/*      */       }
/*   99 */       else if (str.equals("Linux")) {
/*  100 */         platform = 4;
/*      */       }
/*      */       else
/*  103 */         platform = 0;
/*      */     }
/*      */   }
/*      */ 
/*      */   public class RegisteredMethods
/*      */   {
/*      */     int count;
/*      */     Object[] objects;
/*      */     Method[] methods;
/*      */ 
/*      */     public void handle()
/*      */     {
/*  509 */       handle(new Object[0]);
/*      */     }
/*      */ 
/*      */     public void handle(Object[] paramArrayOfObject) {
/*  513 */       for (int i = 0; i < this.count; ++i)
/*      */         try
/*      */         {
/*  516 */           this.methods[i].invoke(this.objects[i], paramArrayOfObject);
/*      */         } catch (Exception localException) {
/*  518 */           localException.printStackTrace();
/*      */         }
/*      */     }
/*      */ 
/*      */     public void add(Object paramObject, Method paramMethod)
/*      */     {
/*  524 */       if (this.objects == null) {
/*  525 */         this.objects = new Object[5];
/*  526 */         this.methods = new Method[5];
/*      */       }
/*  528 */       if (this.count == this.objects.length) {
/*  529 */         Object[] arrayOfObject = new Object[this.count << 1];
/*  530 */         System.arraycopy(this.objects, 0, arrayOfObject, 0, this.count);
/*  531 */         this.objects = arrayOfObject;
/*  532 */         Method[] arrayOfMethod = new Method[this.count << 1];
/*  533 */         System.arraycopy(this.methods, 0, arrayOfMethod, 0, this.count);
/*  534 */         this.methods = arrayOfMethod;
/*      */       }
/*  536 */       this.objects[this.count] = paramObject;
/*  537 */       this.methods[this.count] = paramMethod;
/*  538 */       this.count += 1;
/*      */     }
/*      */   }
/*      */ 
/*      */   class Worker
/*      */   {
/*      */     private Object value;
/*      */     private PApplet.WorkerVar workerVar;
/*      */ 
/*      */     protected synchronized Object getValue()
/*      */     {
/* 5048 */       return this.value;
/*      */     }
/*      */ 
/*      */     private final synchronized void setValue(Object paramObject) {
/* 5052 */       this.value = paramObject;
/*      */     }
/*      */ 
/*      */     public Object construct() {
/*      */       try {
/* 5057 */         int i = System.in.read();
/* 5058 */         if (i == 115)
/*      */         {
/* 5064 */           PApplet.this.stop();
/* 5065 */           PApplet.this.finished = true;
/*      */         }
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/* 5070 */         PApplet.this.finished = true;
/*      */       }
/*      */       try {
/* 5073 */         Thread.sleep(250L);
/*      */       } catch (InterruptedException localInterruptedException) {
/*      */       }
/* 5076 */       return null;
/*      */     }
/*      */ 
/*      */     public void interrupt()
/*      */     {
/* 5083 */       Thread localThread = this.workerVar.get();
/* 5084 */       if (localThread != null) {
/* 5085 */         localThread.interrupt();
/*      */       }
/* 5087 */       this.workerVar.clear();
/*      */     }
/*      */ 
/*      */     public Object get() {
/*      */       while (true) {
/* 5092 */         Thread localThread = this.workerVar.get();
/* 5093 */         if (localThread == null)
/* 5094 */           return getValue();
/*      */         try
/*      */         {
/* 5097 */           localThread.join();
/*      */         } catch (InterruptedException localInterruptedException) {
/* 5099 */           Thread.currentThread().interrupt();
/* 5100 */           return null;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     public void start()
/*      */     {
/* 5129 */       Thread localThread = this.workerVar.get();
/* 5130 */       if (localThread == null) return; localThread.start();
/*      */     }
/*      */ 
/*      */     public Worker()
/*      */     {
/* 5111 */       1 local1 = new Runnable() {
/*      */         public final void run() {
/*      */           try {
/* 5114 */             PApplet.Worker.this.setValue(PApplet.Worker.this.construct());
/*      */           }
/*      */           finally {
/* 5117 */             PApplet.Worker.this.workerVar.clear();
/*      */           }
/*      */         }
/*      */       };
/* 5124 */       Thread localThread = new Thread(local1);
/* 5125 */       this.workerVar = new PApplet.WorkerVar(localThread);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class WorkerVar
/*      */   {
/*      */     private Thread thread;
/*      */ 
/*      */     synchronized Thread get()
/*      */     {
/* 5039 */       return this.thread; } 
/*      */     synchronized void clear() { this.thread = null;
/*      */     }
/*      */ 
/*      */     WorkerVar(Thread paramThread)
/*      */     {
/* 5038 */       this.thread = paramThread;
/*      */     }
/*      */   }
/*      */ }

/* Location:           /Users/mfeyereisen/Desktop/Sources 2/common/
 * Qualified Name:     processing.core.PApplet
 * JD-Core Version:    0.5.3
 */