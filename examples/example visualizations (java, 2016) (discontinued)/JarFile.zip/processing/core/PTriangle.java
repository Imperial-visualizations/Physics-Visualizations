/*      */ package processing.core;
/*      */ 
/*      */ public class PTriangle
/*      */   implements PConstants
/*      */ {
/*      */   static final int R_GOURAUD = 1;
/*      */   static final int R_TEXTURE8 = 2;
/*      */   static final int R_TEXTURE24 = 4;
/*      */   static final int R_TEXTURE32 = 8;
/*      */   static final int R_ALPHA = 16;
/*      */   private int[] m_pixels;
/*      */   private int[] m_texture;
/*      */   private int[] m_stencil;
/*      */   private float[] m_zbuffer;
/*      */   private int SCREEN_WIDTH;
/*      */   private int SCREEN_HEIGHT;
/*      */   private int SCREEN_WIDTH1;
/*      */   private int SCREEN_HEIGHT1;
/*      */   private int TEX_WIDTH;
/*      */   private int TEX_HEIGHT;
/*      */   private float F_TEX_WIDTH;
/*      */   private float F_TEX_HEIGHT;
/*      */   public boolean INTERPOLATE_UV;
/*      */   public boolean INTERPOLATE_RGB;
/*      */   public boolean INTERPOLATE_ALPHA;
/*      */   private float[] x_array;
/*      */   private float[] y_array;
/*      */   private float[] z_array;
/*      */   private float[] u_array;
/*      */   private float[] v_array;
/*      */   private float[] r_array;
/*      */   private float[] g_array;
/*      */   private float[] b_array;
/*      */   private float[] a_array;
/*      */   private int o0;
/*      */   private int o1;
/*      */   private int o2;
/*      */   private float r0;
/*      */   private float r1;
/*      */   private float r2;
/*      */   private float g0;
/*      */   private float g1;
/*      */   private float g2;
/*      */   private float b0;
/*      */   private float b1;
/*      */   private float b2;
/*      */   private float a0;
/*      */   private float a1;
/*      */   private float a2;
/*      */   private float u0;
/*      */   private float u1;
/*      */   private float u2;
/*      */   private float v0;
/*      */   private float v1;
/*      */   private float v2;
/*      */   private float dx0;
/*      */   private float dx1;
/*      */   private float dx2;
/*      */   private float dy0;
/*      */   private float dy1;
/*      */   private float dy2;
/*      */   private float dz0;
/*      */   private float dz1;
/*      */   private float dz2;
/*      */   private float du0;
/*      */   private float du1;
/*      */   private float du2;
/*      */   private float dv0;
/*      */   private float dv1;
/*      */   private float dv2;
/*      */   private float dr0;
/*      */   private float dr1;
/*      */   private float dr2;
/*      */   private float dg0;
/*      */   private float dg1;
/*      */   private float dg2;
/*      */   private float db0;
/*      */   private float db1;
/*      */   private float db2;
/*      */   private float da0;
/*      */   private float da1;
/*      */   private float da2;
/*      */   private float uleft;
/*      */   private float vleft;
/*      */   private float uleftadd;
/*      */   private float vleftadd;
/*      */   private float xleft;
/*      */   private float xrght;
/*      */   private float xadd1;
/*      */   private float xadd2;
/*      */   private float zleft;
/*      */   private float zleftadd;
/*      */   private float rleft;
/*      */   private float gleft;
/*      */   private float bleft;
/*      */   private float aleft;
/*      */   private float rleftadd;
/*      */   private float gleftadd;
/*      */   private float bleftadd;
/*      */   private float aleftadd;
/*      */   private float dta;
/*      */   private float dta2;
/*      */   private float temp;
/*      */   private float width;
/*      */   private int iuadd;
/*      */   private int ivadd;
/*      */   private int iradd;
/*      */   private int igadd;
/*      */   private int ibadd;
/*      */   private int iaadd;
/*      */   private float izadd;
/*      */   private int m_fill;
/*      */   public int m_drawFlags;
/*      */   private int m_index;
/*      */   private PGraphics3 parent;
/*      */   private boolean m_culling;
/*      */   private boolean m_singleRight;
/*      */   private boolean m_bilinear;
/*      */ 
/*      */   public void reset()
/*      */   {
/*  224 */     this.SCREEN_WIDTH = this.parent.width;
/*  225 */     this.SCREEN_HEIGHT = this.parent.height;
/*  226 */     this.SCREEN_WIDTH1 = (this.SCREEN_WIDTH - 1);
/*  227 */     this.SCREEN_HEIGHT1 = (this.SCREEN_HEIGHT - 1);
/*      */ 
/*  229 */     this.m_pixels = this.parent.pixels;
/*  230 */     this.m_stencil = this.parent.stencil;
/*  231 */     this.m_zbuffer = this.parent.zbuffer;
/*      */ 
/*  235 */     this.INTERPOLATE_UV = false;
/*  236 */     this.INTERPOLATE_RGB = false;
/*  237 */     this.INTERPOLATE_ALPHA = false;
/*      */ 
/*  239 */     this.m_texture = null;
/*  240 */     this.m_drawFlags = 0;
/*      */   }
/*      */ 
/*      */   public void setCulling(boolean paramBoolean)
/*      */   {
/*  247 */     this.m_culling = paramBoolean;
/*      */   }
/*      */ 
/*      */   public void setVertices(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9)
/*      */   {
/*  257 */     this.x_array[0] = paramFloat1;
/*  258 */     this.x_array[1] = paramFloat4;
/*  259 */     this.x_array[2] = paramFloat7;
/*      */ 
/*  261 */     this.y_array[0] = paramFloat2;
/*  262 */     this.y_array[1] = paramFloat5;
/*  263 */     this.y_array[2] = paramFloat8;
/*      */ 
/*  265 */     this.z_array[0] = paramFloat3;
/*  266 */     this.z_array[1] = paramFloat6;
/*  267 */     this.z_array[2] = paramFloat9;
/*      */   }
/*      */ 
/*      */   public void setUV(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/*  277 */     this.u_array[0] = ((paramFloat1 * this.F_TEX_WIDTH + 0.5F) * 65536.0F);
/*  278 */     this.u_array[1] = ((paramFloat3 * this.F_TEX_WIDTH + 0.5F) * 65536.0F);
/*  279 */     this.u_array[2] = ((paramFloat5 * this.F_TEX_WIDTH + 0.5F) * 65536.0F);
/*  280 */     this.v_array[0] = ((paramFloat2 * this.F_TEX_HEIGHT + 0.5F) * 65536.0F);
/*  281 */     this.v_array[1] = ((paramFloat4 * this.F_TEX_HEIGHT + 0.5F) * 65536.0F);
/*  282 */     this.v_array[2] = ((paramFloat6 * this.F_TEX_HEIGHT + 0.5F) * 65536.0F);
/*      */   }
/*      */ 
/*      */   public void setIntensities(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12)
/*      */   {
/*  292 */     if ((paramFloat4 != 1.0F) || (paramFloat8 != 1.0F) || (paramFloat12 != 1.0F)) {
/*  293 */       this.INTERPOLATE_ALPHA = true;
/*  294 */       this.a_array[0] = ((paramFloat4 * 253.0F + 1.0F) * 65536.0F);
/*  295 */       this.a_array[1] = ((paramFloat8 * 253.0F + 1.0F) * 65536.0F);
/*  296 */       this.a_array[2] = ((paramFloat12 * 253.0F + 1.0F) * 65536.0F);
/*  297 */       this.m_drawFlags |= 16;
/*      */     } else {
/*  299 */       this.INTERPOLATE_ALPHA = false;
/*  300 */       this.m_drawFlags &= -17;
/*      */     }
/*      */ 
/*  304 */     if ((paramFloat1 != paramFloat5) || (paramFloat5 != paramFloat9)) {
/*  305 */       this.INTERPOLATE_RGB = true;
/*  306 */       this.m_drawFlags |= 1;
/*  307 */     } else if ((paramFloat2 != paramFloat6) || (paramFloat6 != paramFloat10)) {
/*  308 */       this.INTERPOLATE_RGB = true;
/*  309 */       this.m_drawFlags |= 1;
/*  310 */     } else if ((paramFloat3 != paramFloat7) || (paramFloat7 != paramFloat11)) {
/*  311 */       this.INTERPOLATE_RGB = true;
/*  312 */       this.m_drawFlags |= 1;
/*      */     }
/*      */     else {
/*  315 */       this.m_drawFlags &= -2;
/*      */     }
/*      */ 
/*  320 */     this.r_array[0] = ((paramFloat1 * 253.0F + 1.0F) * 65536.0F);
/*  321 */     this.r_array[1] = ((paramFloat5 * 253.0F + 1.0F) * 65536.0F);
/*  322 */     this.r_array[2] = ((paramFloat9 * 253.0F + 1.0F) * 65536.0F);
/*      */ 
/*  324 */     this.g_array[0] = ((paramFloat2 * 253.0F + 1.0F) * 65536.0F);
/*  325 */     this.g_array[1] = ((paramFloat6 * 253.0F + 1.0F) * 65536.0F);
/*  326 */     this.g_array[2] = ((paramFloat10 * 253.0F + 1.0F) * 65536.0F);
/*      */ 
/*  328 */     this.b_array[0] = ((paramFloat3 * 253.0F + 1.0F) * 65536.0F);
/*  329 */     this.b_array[1] = ((paramFloat7 * 253.0F + 1.0F) * 65536.0F);
/*  330 */     this.b_array[2] = ((paramFloat11 * 253.0F + 1.0F) * 65536.0F);
/*      */ 
/*  333 */     this.m_fill = ((int)(255.0F * paramFloat1) << 16 | (int)(255.0F * paramFloat2) << 8 | (int)(255.0F * paramFloat3));
/*      */   }
/*      */ 
/*      */   public void setTexture(PImage paramPImage)
/*      */   {
/*  342 */     this.m_texture = paramPImage.pixels;
/*  343 */     this.TEX_WIDTH = paramPImage.width;
/*  344 */     this.TEX_HEIGHT = paramPImage.height;
/*  345 */     this.F_TEX_WIDTH = (this.TEX_WIDTH - 1);
/*  346 */     this.F_TEX_HEIGHT = (this.TEX_HEIGHT - 1);
/*  347 */     this.INTERPOLATE_UV = true;
/*      */ 
/*  349 */     if (paramPImage.format == 2)
/*  350 */       this.m_drawFlags |= 8;
/*  351 */     else if (paramPImage.format == 1)
/*  352 */       this.m_drawFlags |= 4;
/*  353 */     else if (paramPImage.format == 4) {
/*  354 */       this.m_drawFlags |= 2;
/*      */     }
/*      */ 
/*  358 */     if (this.parent.smooth)
/*  359 */       this.m_bilinear = true;
/*      */     else
/*  361 */       this.m_bilinear = false;
/*      */   }
/*      */ 
/*      */   public void setUV(float[] paramArrayOfFloat1, float[] paramArrayOfFloat2)
/*      */   {
/*  369 */     if (this.m_bilinear)
/*      */     {
/*  371 */       this.u_array[0] = (paramArrayOfFloat1[0] * this.F_TEX_WIDTH * 65500.0F);
/*  372 */       this.u_array[1] = (paramArrayOfFloat1[1] * this.F_TEX_WIDTH * 65500.0F);
/*  373 */       this.u_array[2] = (paramArrayOfFloat1[2] * this.F_TEX_WIDTH * 65500.0F);
/*  374 */       this.v_array[0] = (paramArrayOfFloat2[0] * this.F_TEX_HEIGHT * 65500.0F);
/*  375 */       this.v_array[1] = (paramArrayOfFloat2[1] * this.F_TEX_HEIGHT * 65500.0F);
/*  376 */       this.v_array[2] = (paramArrayOfFloat2[2] * this.F_TEX_HEIGHT * 65500.0F);
/*      */     }
/*      */     else {
/*  379 */       this.u_array[0] = (paramArrayOfFloat1[0] * this.TEX_WIDTH * 65500.0F);
/*  380 */       this.u_array[1] = (paramArrayOfFloat1[1] * this.TEX_WIDTH * 65500.0F);
/*  381 */       this.u_array[2] = (paramArrayOfFloat1[2] * this.TEX_WIDTH * 65500.0F);
/*  382 */       this.v_array[0] = (paramArrayOfFloat2[0] * this.TEX_HEIGHT * 65500.0F);
/*  383 */       this.v_array[1] = (paramArrayOfFloat2[1] * this.TEX_HEIGHT * 65500.0F);
/*  384 */       this.v_array[2] = (paramArrayOfFloat2[2] * this.TEX_HEIGHT * 65500.0F);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setIndex(int paramInt) {
/*  389 */     this.m_index = paramInt;
/*      */   }
/*      */ 
/*      */   public void render()
/*      */   {
/*  401 */     draw();
/*      */   }
/*      */ 
/*      */   private final void draw()
/*      */   {
/*  425 */     float f7 = this.y_array[0];
/*  426 */     float f8 = this.y_array[1];
/*  427 */     float f9 = this.y_array[2];
/*      */     float f1;
/*  430 */     if (this.m_culling) {
/*  431 */       f1 = this.x_array[0];
/*  432 */       if ((this.x_array[2] - f1) * (f8 - f7) < (this.x_array[1] - f1) * (f9 - f7)) {
/*  433 */         return;
/*      */       }
/*      */     }
/*      */ 
/*  437 */     if (f7 < f8) {
/*  438 */       if (f9 < f8) {
/*  439 */         if (f9 < f7)
/*      */         {
/*  441 */           this.o0 = 2;
/*  442 */           this.o1 = 0;
/*  443 */           this.o2 = 1;
/*      */         }
/*      */         else
/*      */         {
/*  447 */           this.o0 = 0;
/*  448 */           this.o1 = 2;
/*  449 */           this.o2 = 1;
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  454 */         this.o0 = 0;
/*  455 */         this.o1 = 1;
/*  456 */         this.o2 = 2;
/*      */       }
/*      */     }
/*  459 */     else if (f9 > f8) {
/*  460 */       if (f9 < f7)
/*      */       {
/*  462 */         this.o0 = 1;
/*  463 */         this.o1 = 2;
/*  464 */         this.o2 = 0;
/*      */       }
/*      */       else
/*      */       {
/*  468 */         this.o0 = 1;
/*  469 */         this.o1 = 0;
/*  470 */         this.o2 = 2;
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  475 */       this.o0 = 2;
/*  476 */       this.o1 = 1;
/*  477 */       this.o2 = 0;
/*      */     }
/*      */ 
/*  487 */     f7 = this.y_array[this.o0];
/*  488 */     int i = (int)(f7 + 0.5F);
/*  489 */     if (i > this.SCREEN_HEIGHT)
/*  490 */       return;
/*  491 */     if (i < 0) {
/*  492 */       i = 0;
/*      */     }
/*      */ 
/*  495 */     f9 = this.y_array[this.o2];
/*  496 */     int j = (int)(f9 + 0.5F);
/*  497 */     if (j < 0)
/*  498 */       return;
/*  499 */     if (j > this.SCREEN_HEIGHT) {
/*  500 */       j = this.SCREEN_HEIGHT;
/*      */     }
/*      */ 
/*  504 */     if (j > i) {
/*  505 */       f1 = this.x_array[this.o0];
/*  506 */       float f2 = this.x_array[this.o1];
/*  507 */       float f3 = this.x_array[this.o2];
/*      */ 
/*  510 */       f8 = this.y_array[this.o1];
/*  511 */       int k = (int)(f8 + 0.5F);
/*  512 */       if (k < 0)
/*  513 */         k = 0;
/*  514 */       if (k > this.SCREEN_HEIGHT) {
/*  515 */         k = this.SCREEN_HEIGHT;
/*      */       }
/*      */ 
/*  518 */       this.dx2 = (f3 - f1);
/*  519 */       this.dy0 = (f8 - f7);
/*  520 */       this.dy2 = (f9 - f7);
/*  521 */       this.xadd2 = (this.dx2 / this.dy2);
/*  522 */       this.temp = (this.dy0 / this.dy2);
/*  523 */       this.width = (this.temp * this.dx2 + f1 - f2);
/*      */ 
/*  526 */       if (this.INTERPOLATE_ALPHA) {
/*  527 */         this.a0 = this.a_array[this.o0];
/*  528 */         this.a1 = this.a_array[this.o1];
/*  529 */         this.a2 = this.a_array[this.o2];
/*  530 */         this.da0 = (this.a1 - this.a0);
/*  531 */         this.da2 = (this.a2 - this.a0);
/*  532 */         this.iaadd = (int)((this.temp * this.da2 - this.da0) / this.width);
/*      */       }
/*      */ 
/*  536 */       if (this.INTERPOLATE_RGB) {
/*  537 */         this.r0 = this.r_array[this.o0];
/*  538 */         this.r1 = this.r_array[this.o1];
/*  539 */         this.r2 = this.r_array[this.o2];
/*      */ 
/*  541 */         this.g0 = this.g_array[this.o0];
/*  542 */         this.g1 = this.g_array[this.o1];
/*  543 */         this.g2 = this.g_array[this.o2];
/*      */ 
/*  545 */         this.b0 = this.b_array[this.o0];
/*  546 */         this.b1 = this.b_array[this.o1];
/*  547 */         this.b2 = this.b_array[this.o2];
/*      */ 
/*  549 */         this.dr0 = (this.r1 - this.r0);
/*  550 */         this.dg0 = (this.g1 - this.g0);
/*  551 */         this.db0 = (this.b1 - this.b0);
/*      */ 
/*  553 */         this.dr2 = (this.r2 - this.r0);
/*  554 */         this.dg2 = (this.g2 - this.g0);
/*  555 */         this.db2 = (this.b2 - this.b0);
/*      */ 
/*  557 */         this.iradd = (int)((this.temp * this.dr2 - this.dr0) / this.width);
/*  558 */         this.igadd = (int)((this.temp * this.dg2 - this.dg0) / this.width);
/*  559 */         this.ibadd = (int)((this.temp * this.db2 - this.db0) / this.width);
/*      */       }
/*      */ 
/*  563 */       if (this.INTERPOLATE_UV) {
/*  564 */         this.u0 = this.u_array[this.o0];
/*  565 */         this.u1 = this.u_array[this.o1];
/*  566 */         this.u2 = this.u_array[this.o2];
/*  567 */         this.v0 = this.v_array[this.o0];
/*  568 */         this.v1 = this.v_array[this.o1];
/*  569 */         this.v2 = this.v_array[this.o2];
/*  570 */         this.du0 = (this.u1 - this.u0);
/*  571 */         this.dv0 = (this.v1 - this.v0);
/*  572 */         this.du2 = (this.u2 - this.u0);
/*  573 */         this.dv2 = (this.v2 - this.v0);
/*  574 */         this.iuadd = (int)((this.temp * this.du2 - this.du0) / this.width);
/*  575 */         this.ivadd = (int)((this.temp * this.dv2 - this.dv0) / this.width);
/*      */       }
/*      */ 
/*  578 */       float f4 = this.z_array[this.o0];
/*  579 */       float f5 = this.z_array[this.o1];
/*  580 */       float f6 = this.z_array[this.o2];
/*  581 */       this.dz0 = (f5 - f4);
/*  582 */       this.dz2 = (f6 - f4);
/*  583 */       this.izadd = ((this.temp * this.dz2 - this.dz0) / this.width);
/*      */ 
/*  586 */       if (k > i) {
/*  587 */         this.dta = (i + 0.5F - f7);
/*  588 */         this.xadd1 = ((f2 - f1) / this.dy0);
/*      */ 
/*  591 */         if (this.xadd2 > this.xadd1) {
/*  592 */           this.xleft = (f1 + this.dta * this.xadd1);
/*  593 */           this.xrght = (f1 + this.dta * this.xadd2);
/*  594 */           this.zleftadd = (this.dz0 / this.dy0);
/*  595 */           this.zleft = (this.dta * this.zleftadd + f4);
/*      */ 
/*  598 */           if (this.INTERPOLATE_UV) {
/*  599 */             this.uleftadd = (this.du0 / this.dy0);
/*  600 */             this.vleftadd = (this.dv0 / this.dy0);
/*  601 */             this.uleft = (this.dta * this.uleftadd + this.u0);
/*  602 */             this.vleft = (this.dta * this.vleftadd + this.v0);
/*      */           }
/*      */ 
/*  606 */           if (this.INTERPOLATE_RGB) {
/*  607 */             this.rleftadd = (this.dr0 / this.dy0);
/*  608 */             this.gleftadd = (this.dg0 / this.dy0);
/*  609 */             this.bleftadd = (this.db0 / this.dy0);
/*  610 */             this.rleft = (this.dta * this.rleftadd + this.r0);
/*  611 */             this.gleft = (this.dta * this.gleftadd + this.g0);
/*  612 */             this.bleft = (this.dta * this.bleftadd + this.b0);
/*      */           }
/*      */ 
/*  616 */           if (this.INTERPOLATE_ALPHA) {
/*  617 */             this.aleftadd = (this.da0 / this.dy0);
/*  618 */             this.aleft = (this.dta * this.aleftadd + this.a0);
/*      */ 
/*  620 */             if (this.m_drawFlags == 16)
/*  621 */               drawsegment_plain_alpha(this.xadd1, this.xadd2, i, k);
/*  622 */             else if (this.m_drawFlags == 17)
/*  623 */               drawsegment_gouraud_alpha(this.xadd1, this.xadd2, i, k);
/*  624 */             else if (this.m_drawFlags == 18)
/*  625 */               drawsegment_texture8_alpha(this.xadd1, this.xadd2, i, k);
/*  626 */             else if (this.m_drawFlags == 20)
/*  627 */               drawsegment_texture24_alpha(this.xadd1, this.xadd2, i, k);
/*  628 */             else if (this.m_drawFlags == 24)
/*  629 */               drawsegment_texture32_alpha(this.xadd1, this.xadd2, i, k);
/*  630 */             else if (this.m_drawFlags == 19)
/*  631 */               drawsegment_gouraud_texture8_alpha(this.xadd1, this.xadd2, i, k);
/*  632 */             else if (this.m_drawFlags == 21)
/*  633 */               drawsegment_gouraud_texture24_alpha(this.xadd1, this.xadd2, i, k);
/*  634 */             else if (this.m_drawFlags == 25) {
/*  635 */               drawsegment_gouraud_texture32_alpha(this.xadd1, this.xadd2, i, k);
/*      */             }
/*      */           }
/*  638 */           else if (this.m_drawFlags == 0) {
/*  639 */             drawsegment_plain(this.xadd1, this.xadd2, i, k);
/*  640 */           } else if (this.m_drawFlags == 1) {
/*  641 */             drawsegment_gouraud(this.xadd1, this.xadd2, i, k);
/*  642 */           } else if (this.m_drawFlags == 2) {
/*  643 */             drawsegment_texture8(this.xadd1, this.xadd2, i, k);
/*  644 */           } else if (this.m_drawFlags == 4) {
/*  645 */             drawsegment_texture24(this.xadd1, this.xadd2, i, k);
/*  646 */           } else if (this.m_drawFlags == 8) {
/*  647 */             drawsegment_texture32(this.xadd1, this.xadd2, i, k);
/*  648 */           } else if (this.m_drawFlags == 3) {
/*  649 */             drawsegment_gouraud_texture8(this.xadd1, this.xadd2, i, k);
/*  650 */           } else if (this.m_drawFlags == 5) {
/*  651 */             drawsegment_gouraud_texture24(this.xadd1, this.xadd2, i, k);
/*  652 */           } else if (this.m_drawFlags == 9) {
/*  653 */             drawsegment_gouraud_texture32(this.xadd1, this.xadd2, i, k);
/*      */           }
/*      */ 
/*  656 */           this.m_singleRight = true;
/*      */         } else {
/*  658 */           this.xleft = (f1 + this.dta * this.xadd2);
/*  659 */           this.xrght = (f1 + this.dta * this.xadd1);
/*  660 */           this.zleftadd = (this.dz2 / this.dy2);
/*  661 */           this.zleft = (this.dta * this.zleftadd + f4);
/*      */ 
/*  663 */           if (this.INTERPOLATE_UV) {
/*  664 */             this.uleftadd = (this.du2 / this.dy2);
/*  665 */             this.vleftadd = (this.dv2 / this.dy2);
/*  666 */             this.uleft = (this.dta * this.uleftadd + this.u0);
/*  667 */             this.vleft = (this.dta * this.vleftadd + this.v0);
/*      */           }
/*      */ 
/*  671 */           if (this.INTERPOLATE_RGB) {
/*  672 */             this.rleftadd = (this.dr2 / this.dy2);
/*  673 */             this.gleftadd = (this.dg2 / this.dy2);
/*  674 */             this.bleftadd = (this.db2 / this.dy2);
/*  675 */             this.rleft = (this.dta * this.rleftadd + this.r0);
/*  676 */             this.gleft = (this.dta * this.gleftadd + this.g0);
/*  677 */             this.bleft = (this.dta * this.bleftadd + this.b0);
/*      */           }
/*      */ 
/*  681 */           if (this.INTERPOLATE_ALPHA) {
/*  682 */             this.aleftadd = (this.da2 / this.dy2);
/*  683 */             this.aleft = (this.dta * this.aleftadd + this.a0);
/*      */ 
/*  685 */             if (this.m_drawFlags == 16)
/*  686 */               drawsegment_plain_alpha(this.xadd2, this.xadd1, i, k);
/*  687 */             else if (this.m_drawFlags == 17)
/*  688 */               drawsegment_gouraud_alpha(this.xadd2, this.xadd1, i, k);
/*  689 */             else if (this.m_drawFlags == 18)
/*  690 */               drawsegment_texture8_alpha(this.xadd2, this.xadd1, i, k);
/*  691 */             else if (this.m_drawFlags == 20)
/*  692 */               drawsegment_texture24_alpha(this.xadd2, this.xadd1, i, k);
/*  693 */             else if (this.m_drawFlags == 24)
/*  694 */               drawsegment_texture32_alpha(this.xadd2, this.xadd1, i, k);
/*  695 */             else if (this.m_drawFlags == 19)
/*  696 */               drawsegment_gouraud_texture8_alpha(this.xadd2, this.xadd1, i, k);
/*  697 */             else if (this.m_drawFlags == 21)
/*  698 */               drawsegment_gouraud_texture24_alpha(this.xadd2, this.xadd1, i, k);
/*  699 */             else if (this.m_drawFlags == 25) {
/*  700 */               drawsegment_gouraud_texture32_alpha(this.xadd2, this.xadd1, i, k);
/*      */             }
/*      */           }
/*  703 */           else if (this.m_drawFlags == 0) {
/*  704 */             drawsegment_plain(this.xadd2, this.xadd1, i, k);
/*  705 */           } else if (this.m_drawFlags == 1) {
/*  706 */             drawsegment_gouraud(this.xadd2, this.xadd1, i, k);
/*  707 */           } else if (this.m_drawFlags == 2) {
/*  708 */             drawsegment_texture8(this.xadd2, this.xadd1, i, k);
/*  709 */           } else if (this.m_drawFlags == 4) {
/*  710 */             drawsegment_texture24(this.xadd2, this.xadd1, i, k);
/*  711 */           } else if (this.m_drawFlags == 8) {
/*  712 */             drawsegment_texture32(this.xadd2, this.xadd1, i, k);
/*  713 */           } else if (this.m_drawFlags == 3) {
/*  714 */             drawsegment_gouraud_texture8(this.xadd2, this.xadd1, i, k);
/*  715 */           } else if (this.m_drawFlags == 5) {
/*  716 */             drawsegment_gouraud_texture24(this.xadd2, this.xadd1, i, k);
/*  717 */           } else if (this.m_drawFlags == 9) {
/*  718 */             drawsegment_gouraud_texture32(this.xadd2, this.xadd1, i, k);
/*      */           }
/*      */ 
/*  721 */           this.m_singleRight = false;
/*      */         }
/*      */ 
/*  725 */         if (j == k) {
/*  726 */           return;
/*      */         }
/*      */ 
/*  729 */         this.dy1 = (f9 - f8);
/*  730 */         this.xadd1 = ((f3 - f2) / this.dy1);
/*      */       }
/*      */       else {
/*  733 */         this.dy1 = (f9 - f8);
/*  734 */         this.xadd1 = ((f3 - f2) / this.dy1);
/*      */ 
/*  737 */         if (this.xadd2 < this.xadd1) {
/*  738 */           this.xrght = ((k + 0.5F - f7) * this.xadd2 + f1);
/*  739 */           this.m_singleRight = true;
/*      */         } else {
/*  741 */           this.dta = (k + 0.5F - f7);
/*  742 */           this.xleft = (this.dta * this.xadd2 + f1);
/*  743 */           this.zleftadd = (this.dz2 / this.dy2);
/*  744 */           this.zleft = (this.dta * this.zleftadd + f4);
/*      */ 
/*  746 */           if (this.INTERPOLATE_UV) {
/*  747 */             this.uleftadd = (this.du2 / this.dy2);
/*  748 */             this.vleftadd = (this.dv2 / this.dy2);
/*  749 */             this.uleft = (this.dta * this.uleftadd + this.u0);
/*  750 */             this.vleft = (this.dta * this.vleftadd + this.v0);
/*      */           }
/*      */ 
/*  753 */           if (this.INTERPOLATE_RGB) {
/*  754 */             this.rleftadd = (this.dr2 / this.dy2);
/*  755 */             this.gleftadd = (this.dg2 / this.dy2);
/*  756 */             this.bleftadd = (this.db2 / this.dy2);
/*  757 */             this.rleft = (this.dta * this.rleftadd + this.r0);
/*  758 */             this.gleft = (this.dta * this.gleftadd + this.g0);
/*  759 */             this.bleft = (this.dta * this.bleftadd + this.b0);
/*      */           }
/*      */ 
/*  763 */           if (this.INTERPOLATE_ALPHA) {
/*  764 */             this.aleftadd = (this.da2 / this.dy2);
/*  765 */             this.aleft = (this.dta * this.aleftadd + this.a0);
/*      */           }
/*  767 */           this.m_singleRight = false;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  772 */       if (this.m_singleRight) {
/*  773 */         this.dta = (k + 0.5F - f8);
/*  774 */         this.xleft = (this.dta * this.xadd1 + f2);
/*  775 */         this.zleftadd = ((f6 - f5) / this.dy1);
/*  776 */         this.zleft = (this.dta * this.zleftadd + f5);
/*      */ 
/*  778 */         if (this.INTERPOLATE_UV) {
/*  779 */           this.uleftadd = ((this.u2 - this.u1) / this.dy1);
/*  780 */           this.vleftadd = ((this.v2 - this.v1) / this.dy1);
/*  781 */           this.uleft = (this.dta * this.uleftadd + this.u1);
/*  782 */           this.vleft = (this.dta * this.vleftadd + this.v1);
/*      */         }
/*      */ 
/*  785 */         if (this.INTERPOLATE_RGB) {
/*  786 */           this.rleftadd = ((this.r2 - this.r1) / this.dy1);
/*  787 */           this.gleftadd = ((this.g2 - this.g1) / this.dy1);
/*  788 */           this.bleftadd = ((this.b2 - this.b1) / this.dy1);
/*  789 */           this.rleft = (this.dta * this.rleftadd + this.r1);
/*  790 */           this.gleft = (this.dta * this.gleftadd + this.g1);
/*  791 */           this.bleft = (this.dta * this.bleftadd + this.b1);
/*      */         }
/*      */ 
/*  794 */         if (this.INTERPOLATE_ALPHA) {
/*  795 */           this.aleftadd = ((this.a2 - this.a1) / this.dy1);
/*  796 */           this.aleft = (this.dta * this.aleftadd + this.a1);
/*      */ 
/*  798 */           if (this.m_drawFlags == 16)
/*  799 */             drawsegment_plain_alpha(this.xadd1, this.xadd2, k, j);
/*  800 */           else if (this.m_drawFlags == 17)
/*  801 */             drawsegment_gouraud_alpha(this.xadd1, this.xadd2, k, j);
/*  802 */           else if (this.m_drawFlags == 18)
/*  803 */             drawsegment_texture8_alpha(this.xadd1, this.xadd2, k, j);
/*  804 */           else if (this.m_drawFlags == 20)
/*  805 */             drawsegment_texture24_alpha(this.xadd1, this.xadd2, k, j);
/*  806 */           else if (this.m_drawFlags == 24)
/*  807 */             drawsegment_texture32_alpha(this.xadd1, this.xadd2, k, j);
/*  808 */           else if (this.m_drawFlags == 19)
/*  809 */             drawsegment_gouraud_texture8_alpha(this.xadd1, this.xadd2, k, j);
/*  810 */           else if (this.m_drawFlags == 21)
/*  811 */             drawsegment_gouraud_texture24_alpha(this.xadd1, this.xadd2, k, j);
/*  812 */           else if (this.m_drawFlags == 25) {
/*  813 */             drawsegment_gouraud_texture32_alpha(this.xadd1, this.xadd2, k, j);
/*      */           }
/*      */         }
/*  816 */         else if (this.m_drawFlags == 0) {
/*  817 */           drawsegment_plain(this.xadd1, this.xadd2, k, j);
/*  818 */         } else if (this.m_drawFlags == 1) {
/*  819 */           drawsegment_gouraud(this.xadd1, this.xadd2, k, j);
/*  820 */         } else if (this.m_drawFlags == 2) {
/*  821 */           drawsegment_texture8(this.xadd1, this.xadd2, k, j);
/*  822 */         } else if (this.m_drawFlags == 4) {
/*  823 */           drawsegment_texture24(this.xadd1, this.xadd2, k, j);
/*  824 */         } else if (this.m_drawFlags == 8) {
/*  825 */           drawsegment_texture32(this.xadd1, this.xadd2, k, j);
/*  826 */         } else if (this.m_drawFlags == 3) {
/*  827 */           drawsegment_gouraud_texture8(this.xadd1, this.xadd2, k, j);
/*  828 */         } else if (this.m_drawFlags == 5) {
/*  829 */           drawsegment_gouraud_texture24(this.xadd1, this.xadd2, k, j);
/*  830 */         } else if (this.m_drawFlags == 9) {
/*  831 */           drawsegment_gouraud_texture32(this.xadd1, this.xadd2, k, j);
/*      */         }
/*      */       }
/*      */       else {
/*  835 */         this.xrght = ((k + 0.5F - f8) * this.xadd1 + f2);
/*      */ 
/*  837 */         if (this.INTERPOLATE_ALPHA) {
/*  838 */           if (this.m_drawFlags == 16)
/*  839 */             drawsegment_plain_alpha(this.xadd2, this.xadd1, k, j);
/*  840 */           else if (this.m_drawFlags == 17)
/*  841 */             drawsegment_gouraud_alpha(this.xadd2, this.xadd1, k, j);
/*  842 */           else if (this.m_drawFlags == 18)
/*  843 */             drawsegment_texture8_alpha(this.xadd2, this.xadd1, k, j);
/*  844 */           else if (this.m_drawFlags == 20)
/*  845 */             drawsegment_texture24_alpha(this.xadd2, this.xadd1, k, j);
/*  846 */           else if (this.m_drawFlags == 24)
/*  847 */             drawsegment_texture32_alpha(this.xadd2, this.xadd1, k, j);
/*  848 */           else if (this.m_drawFlags == 19)
/*  849 */             drawsegment_gouraud_texture8_alpha(this.xadd2, this.xadd1, k, j);
/*  850 */           else if (this.m_drawFlags == 21)
/*  851 */             drawsegment_gouraud_texture24_alpha(this.xadd2, this.xadd1, k, j);
/*  852 */           else if (this.m_drawFlags == 25) {
/*  853 */             drawsegment_gouraud_texture32_alpha(this.xadd2, this.xadd1, k, j);
/*      */           }
/*      */         }
/*  856 */         else if (this.m_drawFlags == 0)
/*  857 */           drawsegment_plain(this.xadd2, this.xadd1, k, j);
/*  858 */         else if (this.m_drawFlags == 1)
/*  859 */           drawsegment_gouraud(this.xadd2, this.xadd1, k, j);
/*  860 */         else if (this.m_drawFlags == 2)
/*  861 */           drawsegment_texture8(this.xadd2, this.xadd1, k, j);
/*  862 */         else if (this.m_drawFlags == 4)
/*  863 */           drawsegment_texture24(this.xadd2, this.xadd1, k, j);
/*  864 */         else if (this.m_drawFlags == 8)
/*  865 */           drawsegment_texture32(this.xadd2, this.xadd1, k, j);
/*  866 */         else if (this.m_drawFlags == 3)
/*  867 */           drawsegment_gouraud_texture8(this.xadd2, this.xadd1, k, j);
/*  868 */         else if (this.m_drawFlags == 5)
/*  869 */           drawsegment_gouraud_texture24(this.xadd2, this.xadd1, k, j);
/*  870 */         else if (this.m_drawFlags == 9)
/*  871 */           drawsegment_gouraud_texture32(this.xadd2, this.xadd1, k, j);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void drawsegment_plain(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2)
/*      */   {
/*  890 */     paramInt1 *= this.SCREEN_WIDTH;
/*  891 */     paramInt2 *= this.SCREEN_WIDTH;
/*  892 */     int i = this.m_fill;
/*  893 */     int j = this.m_index;
/*      */ 
/*  895 */     while (paramInt1 < paramInt2) {
/*  896 */       int k = (int)(this.xleft + 0.5F);
/*  897 */       if (k < 0) {
/*  898 */         k = 0;
/*      */       }
/*  900 */       int l = (int)(this.xrght + 0.5F);
/*  901 */       if (l > this.SCREEN_WIDTH) {
/*  902 */         l = this.SCREEN_WIDTH;
/*      */       }
/*  904 */       float f1 = k + 0.5F - this.xleft;
/*  905 */       float f2 = this.izadd * f1 + this.zleft;
/*  906 */       k += paramInt1;
/*  907 */       l += paramInt1;
/*      */ 
/*  909 */       for (; k < l; ++k) {
/*  910 */         if (f2 <= this.m_zbuffer[k]) {
/*  911 */           this.m_zbuffer[k] = f2;
/*  912 */           this.m_pixels[k] = i;
/*  913 */           this.m_stencil[k] = j;
/*      */         }
/*  915 */         f2 += this.izadd;
/*      */       }
/*      */ 
/*  918 */       paramInt1 += this.SCREEN_WIDTH;
/*  919 */       this.xleft += paramFloat1;
/*  920 */       this.xrght += paramFloat2;
/*  921 */       this.zleft += this.zleftadd;
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void drawsegment_plain_alpha(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2)
/*      */   {
/*  935 */     paramInt1 *= this.SCREEN_WIDTH;
/*  936 */     paramInt2 *= this.SCREEN_WIDTH;
/*      */ 
/*  938 */     int i = this.m_fill & 0xFF0000;
/*  939 */     int j = this.m_fill & 0xFF00;
/*  940 */     int k = this.m_fill & 0xFF;
/*      */ 
/*  942 */     int l = this.m_index;
/*  943 */     float f1 = this.iaadd;
/*      */ 
/*  945 */     while (paramInt1 < paramInt2) {
/*  946 */       int i1 = (int)(this.xleft + 0.5F);
/*  947 */       if (i1 < 0) {
/*  948 */         i1 = 0;
/*      */       }
/*  950 */       int i2 = (int)(this.xrght + 0.5F);
/*  951 */       if (i2 > this.SCREEN_WIDTH) {
/*  952 */         i2 = this.SCREEN_WIDTH;
/*      */       }
/*  954 */       float f2 = i1 + 0.5F - this.xleft;
/*  955 */       float f3 = this.izadd * f2 + this.zleft;
/*  956 */       int i3 = (int)(f1 * f2 + this.aleft);
/*  957 */       i1 += paramInt1;
/*  958 */       i2 += paramInt1;
/*      */ 
/*  960 */       for (; i1 < i2; ++i1) {
/*  961 */         if (f3 <= this.m_zbuffer[i1])
/*      */         {
/*  964 */           int i4 = i3 >> 16;
/*  965 */           int i5 = this.m_pixels[i1];
/*  966 */           int i6 = i5 & 0xFF00;
/*  967 */           int i7 = i5 & 0xFF;
/*  968 */           i5 &= 16711680;
/*      */ 
/*  970 */           i5 += ((i - i5) * i4 >> 8);
/*  971 */           i6 += ((j - i6) * i4 >> 8);
/*  972 */           i7 += ((k - i7) * i4 >> 8);
/*  973 */           this.m_pixels[i1] = (i5 & 0xFF0000 | i6 & 0xFF00 | i7 & 0xFF);
/*      */ 
/*  975 */           this.m_stencil[i1] = l;
/*      */         }
/*  977 */         f3 += this.izadd;
/*  978 */         i3 += this.iaadd;
/*      */       }
/*  980 */       paramInt1 += this.SCREEN_WIDTH;
/*  981 */       this.xleft += paramFloat1;
/*  982 */       this.xrght += paramFloat2;
/*  983 */       this.zleft += this.zleftadd;
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void drawsegment_gouraud(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2)
/*      */   {
/*  998 */     float f1 = this.iradd;
/*  999 */     float f2 = this.igadd;
/* 1000 */     float f3 = this.ibadd;
/*      */ 
/* 1002 */     paramInt1 *= this.SCREEN_WIDTH;
/* 1003 */     paramInt2 *= this.SCREEN_WIDTH;
/* 1004 */     int i = this.m_index;
/*      */ 
/* 1006 */     while (paramInt1 < paramInt2) {
/* 1007 */       int j = (int)(this.xleft + 0.5F);
/* 1008 */       if (j < 0) {
/* 1009 */         j = 0;
/*      */       }
/* 1011 */       int k = (int)(this.xrght + 0.5F);
/* 1012 */       if (k > this.SCREEN_WIDTH) {
/* 1013 */         k = this.SCREEN_WIDTH;
/*      */       }
/* 1015 */       float f4 = j + 0.5F - this.xleft;
/* 1016 */       int l = (int)(f1 * f4 + this.rleft);
/* 1017 */       int i1 = (int)(f2 * f4 + this.gleft);
/* 1018 */       int i2 = (int)(f3 * f4 + this.bleft);
/* 1019 */       float f5 = this.izadd * f4 + this.zleft;
/*      */ 
/* 1021 */       j += paramInt1;
/* 1022 */       k += paramInt1;
/*      */ 
/* 1024 */       for (; j < k; ++j) {
/* 1025 */         if (f5 <= this.m_zbuffer[j]) {
/* 1026 */           this.m_zbuffer[j] = f5;
/* 1027 */           this.m_pixels[j] = (l & 0xFF0000 | i1 >> 8 & 0xFF00 | i2 >> 16);
/* 1028 */           this.m_stencil[j] = i;
/*      */         }
/*      */ 
/* 1032 */         l += this.iradd;
/* 1033 */         i1 += this.igadd;
/* 1034 */         i2 += this.ibadd;
/* 1035 */         f5 += this.izadd;
/*      */       }
/*      */ 
/* 1038 */       paramInt1 += this.SCREEN_WIDTH;
/* 1039 */       this.xleft += paramFloat1;
/* 1040 */       this.xrght += paramFloat2;
/* 1041 */       this.rleft += this.rleftadd;
/* 1042 */       this.gleft += this.gleftadd;
/* 1043 */       this.bleft += this.bleftadd;
/* 1044 */       this.zleft += this.zleftadd;
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void drawsegment_gouraud_alpha(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2)
/*      */   {
/* 1059 */     paramInt1 *= this.SCREEN_WIDTH;
/* 1060 */     paramInt2 *= this.SCREEN_WIDTH;
/* 1061 */     int i = this.m_index;
/*      */ 
/* 1063 */     float f1 = this.iradd;
/* 1064 */     float f2 = this.igadd;
/* 1065 */     float f3 = this.ibadd;
/* 1066 */     float f4 = this.iaadd;
/*      */ 
/* 1068 */     while (paramInt1 < paramInt2) {
/* 1069 */       int j = (int)(this.xleft + 0.5F);
/* 1070 */       if (j < 0)
/* 1071 */         j = 0;
/* 1072 */       int k = (int)(this.xrght + 0.5F);
/* 1073 */       if (k > this.SCREEN_WIDTH)
/* 1074 */         k = this.SCREEN_WIDTH;
/* 1075 */       float f5 = j + 0.5F - this.xleft;
/*      */ 
/* 1077 */       int l = (int)(f1 * f5 + this.rleft);
/* 1078 */       int i1 = (int)(f2 * f5 + this.gleft);
/* 1079 */       int i2 = (int)(f3 * f5 + this.bleft);
/* 1080 */       int i3 = (int)(f4 * f5 + this.aleft);
/* 1081 */       float f6 = this.izadd * f5 + this.zleft;
/*      */ 
/* 1083 */       j += paramInt1;
/* 1084 */       k += paramInt1;
/*      */ 
/* 1086 */       for (; j < k; ++j) {
/* 1087 */         if (f6 <= this.m_zbuffer[j])
/*      */         {
/* 1091 */           int i4 = l & 0xFF0000;
/* 1092 */           int i5 = i1 >> 8 & 0xFF00;
/* 1093 */           int i6 = i2 >> 16;
/*      */ 
/* 1096 */           int i7 = this.m_pixels[j];
/* 1097 */           int i8 = i7 & 0xFF0000;
/* 1098 */           int i9 = i7 & 0xFF00;
/* 1099 */           i7 &= 255;
/*      */ 
/* 1102 */           int i10 = i3 >> 16;
/*      */ 
/* 1105 */           this.m_pixels[j] = (i8 + ((i4 - i8) * i10 >> 8) & 0xFF0000 | i9 + ((i5 - i9) * i10 >> 8) & 0xFF00 | i7 + ((i6 - i7) * i10 >> 8) & 0xFF);
/* 1106 */           this.m_stencil[j] = i;
/*      */         }
/*      */ 
/* 1110 */         l += this.iradd;
/* 1111 */         i1 += this.igadd;
/* 1112 */         i2 += this.ibadd;
/* 1113 */         i3 += this.iaadd;
/* 1114 */         f6 += this.izadd;
/*      */       }
/*      */ 
/* 1117 */       paramInt1 += this.SCREEN_WIDTH;
/* 1118 */       this.xleft += paramFloat1;
/* 1119 */       this.xrght += paramFloat2;
/* 1120 */       this.rleft += this.rleftadd;
/* 1121 */       this.gleft += this.gleftadd;
/* 1122 */       this.bleft += this.bleftadd;
/* 1123 */       this.aleft += this.aleftadd;
/* 1124 */       this.zleft += this.zleftadd;
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void drawsegment_texture8(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2)
/*      */   {
/* 1139 */     paramInt1 *= this.SCREEN_WIDTH;
/* 1140 */     paramInt2 *= this.SCREEN_WIDTH;
/* 1141 */     int i = this.m_index;
/*      */ 
/* 1143 */     float f1 = this.iuadd;
/* 1144 */     float f2 = this.ivadd;
/*      */ 
/* 1146 */     int j = this.m_fill & 0xFF0000;
/* 1147 */     int k = this.m_fill & 0xFF00;
/* 1148 */     int l = this.m_fill & 0xFF;
/*      */ 
/* 1150 */     while (paramInt1 < paramInt2) {
/* 1151 */       int i1 = (int)(this.xleft + 0.5F);
/* 1152 */       if (i1 < 0) {
/* 1153 */         i1 = 0;
/*      */       }
/* 1155 */       int i2 = (int)(this.xrght + 0.5F);
/* 1156 */       if (i2 > this.SCREEN_WIDTH) {
/* 1157 */         i2 = this.SCREEN_WIDTH;
/*      */       }
/* 1159 */       float f3 = i1 + 0.5F - this.xleft;
/* 1160 */       int i3 = (int)(f1 * f3 + this.uleft);
/* 1161 */       int i4 = (int)(f2 * f3 + this.vleft);
/* 1162 */       float f4 = this.izadd * f3 + this.zleft;
/*      */ 
/* 1164 */       i1 += paramInt1;
/* 1165 */       i2 += paramInt1;
/*      */ 
/* 1167 */       for (; i1 < i2; ++i1)
/*      */       {
/*      */         try
/*      */         {
/* 1171 */           if (f4 <= this.m_zbuffer[i1])
/*      */           {
/*      */             int i5;
/* 1175 */             if (this.m_bilinear) {
/* 1176 */               i6 = (i4 >> 16) * this.TEX_WIDTH + (i3 >> 16);
/* 1177 */               i7 = i3 & (char)-1;
/* 1178 */               i5 = this.m_texture[i6] & 0xFF;
/* 1179 */               i8 = this.m_texture[(i6 + 1)] & 0xFF;
/* 1180 */               i6 += this.TEX_WIDTH;
/* 1181 */               int i9 = this.m_texture[i6] & 0xFF;
/* 1182 */               int i10 = this.m_texture[(i6 + 1)] & 0xFF;
/* 1183 */               i5 += ((i8 - i5) * i7 >> 16);
/* 1184 */               i9 += ((i10 - i9) * i7 >> 16);
/* 1185 */               i5 += ((i9 - i5) * (i4 & (char)-1) >> 16);
/*      */             } else {
/* 1187 */               i5 = this.m_texture[((i4 >> 16) * this.TEX_WIDTH + (i3 >> 16))] & 0xFF;
/*      */             }
/*      */ 
/* 1190 */             int i6 = this.m_pixels[i1];
/* 1191 */             int i7 = i6 & 0xFF00;
/* 1192 */             int i8 = i6 & 0xFF;
/* 1193 */             i6 &= 16711680;
/* 1194 */             this.m_pixels[i1] = (i6 + ((j - i6) * i5 >> 8) & 0xFF0000 | i7 + ((k - i7) * i5 >> 8) & 0xFF00 | i8 + ((l - i8) * i5 >> 8) & 0xFF);
/* 1195 */             this.m_stencil[i1] = i;
/*      */           }
/*      */         }
/*      */         catch (Exception localException) {
/*      */         }
/* 1200 */         i3 += this.iuadd;
/* 1201 */         i4 += this.ivadd;
/* 1202 */         f4 += this.izadd;
/*      */       }
/*      */ 
/* 1205 */       paramInt1 += this.SCREEN_WIDTH;
/*      */ 
/* 1207 */       this.xleft += paramFloat1;
/* 1208 */       this.xrght += paramFloat2;
/* 1209 */       this.uleft += this.uleftadd;
/* 1210 */       this.vleft += this.vleftadd;
/* 1211 */       this.zleft += this.zleftadd;
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void drawsegment_texture8_alpha(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2)
/*      */   {
/* 1226 */     paramInt1 *= this.SCREEN_WIDTH;
/* 1227 */     paramInt2 *= this.SCREEN_WIDTH;
/* 1228 */     int i = this.m_index;
/*      */ 
/* 1230 */     float f1 = this.iuadd;
/* 1231 */     float f2 = this.ivadd;
/* 1232 */     float f3 = this.iaadd;
/*      */ 
/* 1234 */     int j = this.m_fill & 0xFF0000;
/* 1235 */     int k = this.m_fill & 0xFF00;
/* 1236 */     int l = this.m_fill & 0xFF;
/*      */ 
/* 1238 */     while (paramInt1 < paramInt2) {
/* 1239 */       int i1 = (int)(this.xleft + 0.5F);
/* 1240 */       if (i1 < 0) {
/* 1241 */         i1 = 0;
/*      */       }
/* 1243 */       int i2 = (int)(this.xrght + 0.5F);
/* 1244 */       if (i2 > this.SCREEN_WIDTH) {
/* 1245 */         i2 = this.SCREEN_WIDTH;
/*      */       }
/* 1247 */       float f4 = i1 + 0.5F - this.xleft;
/* 1248 */       int i3 = (int)(f1 * f4 + this.uleft);
/* 1249 */       int i4 = (int)(f2 * f4 + this.vleft);
/* 1250 */       int i5 = (int)(f3 * f4 + this.aleft);
/* 1251 */       float f5 = this.izadd * f4 + this.zleft;
/*      */ 
/* 1253 */       i1 += paramInt1;
/* 1254 */       i2 += paramInt1;
/*      */ 
/* 1256 */       for (; i1 < i2; ++i1)
/*      */       {
/*      */         try
/*      */         {
/* 1260 */           if (f5 <= this.m_zbuffer[i1])
/*      */           {
/* 1264 */             if (this.m_bilinear) {
/* 1265 */               i7 = (i4 >> 16) * this.TEX_WIDTH + (i3 >> 16);
/* 1266 */               i8 = i3 & (char)-1;
/* 1267 */               i6 = this.m_texture[i7] & 0xFF;
/* 1268 */               i9 = this.m_texture[(i7 + 1)] & 0xFF;
/* 1269 */               i7 += this.TEX_WIDTH;
/* 1270 */               int i10 = this.m_texture[i7] & 0xFF;
/* 1271 */               int i11 = this.m_texture[(i7 + 1)] & 0xFF;
/* 1272 */               i6 += ((i9 - i6) * i8 >> 16);
/* 1273 */               i10 += ((i11 - i10) * i8 >> 16);
/* 1274 */               i6 += ((i10 - i6) * (i4 & (char)-1) >> 16);
/*      */             } else {
/* 1276 */               i6 = this.m_texture[((i4 >> 16) * this.TEX_WIDTH + (i3 >> 16))] & 0xFF;
/*      */             }
/* 1278 */             int i6 = i6 * (i5 >> 16) >> 8;
/*      */ 
/* 1280 */             int i7 = this.m_pixels[i1];
/* 1281 */             int i8 = i7 & 0xFF00;
/* 1282 */             int i9 = i7 & 0xFF;
/* 1283 */             i7 &= 16711680;
/* 1284 */             this.m_pixels[i1] = (i7 + ((j - i7) * i6 >> 8) & 0xFF0000 | i8 + ((k - i8) * i6 >> 8) & 0xFF00 | i9 + ((l - i9) * i6 >> 8) & 0xFF);
/* 1285 */             this.m_stencil[i1] = i;
/*      */           }
/*      */         }
/*      */         catch (Exception localException) {
/*      */         }
/* 1290 */         i3 += this.iuadd;
/* 1291 */         i4 += this.ivadd;
/* 1292 */         f5 += this.izadd;
/* 1293 */         i5 += this.iaadd;
/*      */       }
/*      */ 
/* 1296 */       paramInt1 += this.SCREEN_WIDTH;
/* 1297 */       this.xleft += paramFloat1;
/* 1298 */       this.xrght += paramFloat2;
/* 1299 */       this.uleft += this.uleftadd;
/* 1300 */       this.vleft += this.vleftadd;
/* 1301 */       this.zleft += this.zleftadd;
/* 1302 */       this.aleft += this.aleftadd;
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void drawsegment_texture24(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2)
/*      */   {
/* 1317 */     paramInt1 *= this.SCREEN_WIDTH;
/* 1318 */     paramInt2 *= this.SCREEN_WIDTH;
/* 1319 */     int i = this.m_index;
/*      */ 
/* 1321 */     float f1 = this.iuadd;
/* 1322 */     float f2 = this.ivadd;
/*      */ 
/* 1324 */     while (paramInt1 < paramInt2) {
/* 1325 */       int j = (int)(this.xleft + 0.5F);
/* 1326 */       if (j < 0) {
/* 1327 */         j = 0;
/*      */       }
/* 1329 */       int k = (int)(this.xrght + 0.5F);
/* 1330 */       if (k > this.SCREEN_WIDTH) {
/* 1331 */         k = this.SCREEN_WIDTH;
/*      */       }
/* 1333 */       float f3 = j + 0.5F - this.xleft;
/* 1334 */       int l = (int)(f1 * f3 + this.uleft);
/* 1335 */       int i1 = (int)(f2 * f3 + this.vleft);
/* 1336 */       float f4 = this.izadd * f3 + this.zleft;
/*      */ 
/* 1338 */       j += paramInt1;
/* 1339 */       k += paramInt1;
/*      */ 
/* 1341 */       for (; j < k; ++j)
/*      */       {
/*      */         try
/*      */         {
/* 1345 */           if (f4 <= this.m_zbuffer[j]) {
/* 1346 */             this.m_zbuffer[j] = f4;
/* 1347 */             if (this.m_bilinear) {
/* 1348 */               int i2 = (i1 >> 16) * this.TEX_WIDTH + (l >> 16);
/* 1349 */               int i3 = (l & (char)-1) >> 9;
/* 1350 */               int i4 = (i1 & (char)-1) >> 9;
/*      */ 
/* 1353 */               int i5 = this.m_texture[i2];
/* 1354 */               int i6 = this.m_texture[(i2 + 1)];
/* 1355 */               i2 += this.TEX_WIDTH;
/* 1356 */               int i7 = this.m_texture[i2];
/* 1357 */               int i8 = this.m_texture[(i2 + 1)];
/*      */ 
/* 1360 */               int i9 = i5 & 0xFF0000;
/* 1361 */               int i10 = i7 & 0xFF0000;
/* 1362 */               int i11 = i9 + (((i6 & 0xFF0000) - i9) * i3 >> 7);
/* 1363 */               int i12 = i10 + (((i8 & 0xFF0000) - i10) * i3 >> 7);
/* 1364 */               int i13 = i11 + ((i12 - i11) * i4 >> 7);
/*      */ 
/* 1367 */               i9 = i5 & 0xFF00;
/* 1368 */               i10 = i7 & 0xFF00;
/* 1369 */               i11 = i9 + (((i6 & 0xFF00) - i9) * i3 >> 7);
/* 1370 */               i12 = i10 + (((i8 & 0xFF00) - i10) * i3 >> 7);
/* 1371 */               int i14 = i11 + ((i12 - i11) * i4 >> 7);
/*      */ 
/* 1374 */               i9 = i5 & 0xFF;
/* 1375 */               i10 = i7 & 0xFF;
/* 1376 */               i11 = i9 + (((i6 & 0xFF) - i9) * i3 >> 7);
/* 1377 */               i12 = i10 + (((i8 & 0xFF) - i10) * i3 >> 7);
/* 1378 */               int i15 = i11 + ((i12 - i11) * i4 >> 7);
/*      */ 
/* 1381 */               this.m_pixels[j] = (i13 & 0xFF0000 | i14 & 0xFF00 | i15 & 0xFF);
/*      */             } else {
/* 1383 */               this.m_pixels[j] = this.m_texture[((i1 >> 16) * this.TEX_WIDTH + (l >> 16))];
/*      */             }
/* 1385 */             this.m_stencil[j] = i;
/*      */           }
/*      */         }
/*      */         catch (Exception localException)
/*      */         {
/*      */         }
/* 1391 */         l += this.iuadd;
/* 1392 */         i1 += this.ivadd;
/* 1393 */         f4 += this.izadd;
/*      */       }
/*      */ 
/* 1396 */       paramInt1 += this.SCREEN_WIDTH;
/* 1397 */       this.xleft += paramFloat1;
/* 1398 */       this.xrght += paramFloat2;
/* 1399 */       this.uleft += this.uleftadd;
/* 1400 */       this.vleft += this.vleftadd;
/* 1401 */       this.zleft += this.zleftadd;
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void drawsegment_texture24_alpha(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2)
/*      */   {
/* 1415 */     paramInt1 *= this.SCREEN_WIDTH;
/* 1416 */     paramInt2 *= this.SCREEN_WIDTH;
/* 1417 */     int i = this.m_index;
/*      */ 
/* 1419 */     float f1 = this.iuadd;
/* 1420 */     float f2 = this.ivadd;
/* 1421 */     float f3 = this.iaadd;
/*      */ 
/* 1423 */     while (paramInt1 < paramInt2) {
/* 1424 */       int j = (int)(this.xleft + 0.5F);
/* 1425 */       if (j < 0) {
/* 1426 */         j = 0;
/*      */       }
/* 1428 */       int k = (int)(this.xrght + 0.5F);
/* 1429 */       if (k > this.SCREEN_WIDTH) {
/* 1430 */         k = this.SCREEN_WIDTH;
/*      */       }
/* 1432 */       float f4 = j + 0.5F - this.xleft;
/* 1433 */       int l = (int)(f1 * f4 + this.uleft);
/* 1434 */       int i1 = (int)(f2 * f4 + this.vleft);
/* 1435 */       int i2 = (int)(f3 * f4 + this.aleft);
/* 1436 */       float f5 = this.izadd * f4 + this.zleft;
/*      */ 
/* 1438 */       j += paramInt1;
/* 1439 */       k += paramInt1;
/*      */ 
/* 1441 */       for (; j < k; ++j)
/*      */       {
/*      */         try
/*      */         {
/* 1445 */           if (f5 <= this.m_zbuffer[j])
/*      */           {
/* 1449 */             int i3 = i2 >> 16;
/*      */             int i4;
/*      */             int i5;
/*      */             int i6;
/*      */             int i7;
/*      */             int i8;
/*      */             int i9;
/* 1451 */             if (this.m_bilinear) {
/* 1452 */               i4 = (i1 >> 16) * this.TEX_WIDTH + (l >> 16);
/* 1453 */               i5 = (l & (char)-1) >> 9;
/* 1454 */               i6 = (i1 & (char)-1) >> 9;
/*      */ 
/* 1457 */               i7 = this.m_texture[i4];
/* 1458 */               i8 = this.m_texture[(i4 + 1)];
/* 1459 */               i4 += this.TEX_WIDTH;
/* 1460 */               i9 = this.m_texture[i4];
/* 1461 */               int i10 = this.m_texture[(i4 + 1)];
/*      */ 
/* 1464 */               int i11 = i7 & 0xFF0000;
/* 1465 */               int i12 = i9 & 0xFF0000;
/* 1466 */               int i13 = i11 + (((i8 & 0xFF0000) - i11) * i5 >> 7);
/* 1467 */               int i14 = i12 + (((i10 & 0xFF0000) - i12) * i5 >> 7);
/* 1468 */               int i15 = i13 + ((i14 - i13) * i6 >> 7);
/*      */ 
/* 1471 */               i11 = i7 & 0xFF00;
/* 1472 */               i12 = i9 & 0xFF00;
/* 1473 */               i13 = i11 + (((i8 & 0xFF00) - i11) * i5 >> 7);
/* 1474 */               i14 = i12 + (((i10 & 0xFF00) - i12) * i5 >> 7);
/* 1475 */               int i16 = i13 + ((i14 - i13) * i6 >> 7);
/*      */ 
/* 1478 */               i11 = i7 & 0xFF;
/* 1479 */               i12 = i9 & 0xFF;
/* 1480 */               i13 = i11 + (((i8 & 0xFF) - i11) * i5 >> 7);
/* 1481 */               i14 = i12 + (((i10 & 0xFF) - i12) * i5 >> 7);
/* 1482 */               int i17 = i13 + ((i14 - i13) * i6 >> 7);
/*      */ 
/* 1485 */               int i18 = this.m_pixels[j];
/* 1486 */               int i19 = i18 & 0xFF0000;
/* 1487 */               int i20 = i18 & 0xFF00;
/* 1488 */               i18 &= 255;
/* 1489 */               this.m_pixels[j] = (i19 + ((i15 - i19) * i3 >> 8) & 0xFF0000 | i20 + ((i16 - i20) * i3 >> 8) & 0xFF00 | i18 + ((i17 - i18) * i3 >> 8) & 0xFF);
/*      */             } else {
/* 1491 */               i4 = this.m_texture[((i1 >> 16) * this.TEX_WIDTH + (l >> 16))];
/* 1492 */               i5 = i4 & 0xFF00;
/* 1493 */               i6 = i4 & 0xFF;
/* 1494 */               i4 &= 16711680;
/*      */ 
/* 1497 */               i7 = this.m_pixels[j];
/* 1498 */               i8 = i7 & 0xFF0000;
/* 1499 */               i9 = i7 & 0xFF00;
/* 1500 */               i7 &= 255;
/* 1501 */               this.m_pixels[j] = (i8 + ((i4 - i8) * i3 >> 8) & 0xFF0000 | i9 + ((i5 - i9) * i3 >> 8) & 0xFF00 | i7 + ((i6 - i7) * i3 >> 8) & 0xFF);
/*      */             }
/* 1503 */             this.m_stencil[j] = i;
/*      */           }
/*      */         }
/*      */         catch (Exception localException) {
/*      */         }
/* 1508 */         l += this.iuadd;
/* 1509 */         i1 += this.ivadd;
/* 1510 */         i2 += this.iaadd;
/* 1511 */         f5 += this.izadd;
/*      */       }
/*      */ 
/* 1514 */       paramInt1 += this.SCREEN_WIDTH;
/*      */ 
/* 1516 */       this.xleft += paramFloat1;
/* 1517 */       this.xrght += paramFloat2;
/* 1518 */       this.uleft += this.uleftadd;
/* 1519 */       this.vleft += this.vleftadd;
/* 1520 */       this.zleft += this.zleftadd;
/* 1521 */       this.aleft += this.aleftadd;
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void drawsegment_texture32(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2)
/*      */   {
/* 1535 */     paramInt1 *= this.SCREEN_WIDTH;
/* 1536 */     paramInt2 *= this.SCREEN_WIDTH;
/* 1537 */     int i = this.m_index;
/*      */ 
/* 1539 */     float f1 = this.iuadd;
/* 1540 */     float f2 = this.ivadd;
/*      */ 
/* 1542 */     while (paramInt1 < paramInt2) {
/* 1543 */       int j = (int)(this.xleft + 0.5F);
/* 1544 */       if (j < 0) {
/* 1545 */         j = 0;
/*      */       }
/* 1547 */       int k = (int)(this.xrght + 0.5F);
/* 1548 */       if (k > this.SCREEN_WIDTH) {
/* 1549 */         k = this.SCREEN_WIDTH;
/*      */       }
/* 1551 */       float f3 = j + 0.5F - this.xleft;
/* 1552 */       int l = (int)(f1 * f3 + this.uleft);
/* 1553 */       int i1 = (int)(f2 * f3 + this.vleft);
/* 1554 */       float f4 = this.izadd * f3 + this.zleft;
/*      */ 
/* 1556 */       j += paramInt1;
/* 1557 */       k += paramInt1;
/*      */ 
/* 1559 */       for (; j < k; ++j)
/*      */       {
/*      */         try
/*      */         {
/* 1563 */           if (f4 <= this.m_zbuffer[j])
/*      */           {
/*      */             int i2;
/*      */             int i3;
/*      */             int i4;
/*      */             int i5;
/*      */             int i6;
/*      */             int i7;
/*      */             int i8;
/* 1566 */             if (this.m_bilinear) {
/* 1567 */               i2 = (i1 >> 16) * this.TEX_WIDTH + (l >> 16);
/* 1568 */               i3 = (l & (char)-1) >> 9;
/* 1569 */               i4 = (i1 & (char)-1) >> 9;
/*      */ 
/* 1572 */               i5 = this.m_texture[i2];
/* 1573 */               i6 = this.m_texture[(i2 + 1)];
/* 1574 */               i2 += this.TEX_WIDTH;
/* 1575 */               i7 = this.m_texture[i2];
/* 1576 */               i8 = this.m_texture[(i2 + 1)];
/*      */ 
/* 1579 */               int i9 = i5 & 0xFF0000;
/* 1580 */               int i10 = i7 & 0xFF0000;
/* 1581 */               int i11 = i9 + (((i6 & 0xFF0000) - i9) * i3 >> 7);
/* 1582 */               int i12 = i10 + (((i8 & 0xFF0000) - i10) * i3 >> 7);
/* 1583 */               int i13 = i11 + ((i12 - i11) * i4 >> 7);
/*      */ 
/* 1586 */               i9 = i5 & 0xFF00;
/* 1587 */               i10 = i7 & 0xFF00;
/* 1588 */               i11 = i9 + (((i6 & 0xFF00) - i9) * i3 >> 7);
/* 1589 */               i12 = i10 + (((i8 & 0xFF00) - i10) * i3 >> 7);
/* 1590 */               int i14 = i11 + ((i12 - i11) * i4 >> 7);
/*      */ 
/* 1593 */               i9 = i5 & 0xFF;
/* 1594 */               i10 = i7 & 0xFF;
/* 1595 */               i11 = i9 + (((i6 & 0xFF) - i9) * i3 >> 7);
/* 1596 */               i12 = i10 + (((i8 & 0xFF) - i10) * i3 >> 7);
/* 1597 */               int i15 = i11 + ((i12 - i11) * i4 >> 7);
/*      */ 
/* 1600 */               i5 >>>= 24;
/* 1601 */               i7 >>>= 24;
/* 1602 */               i11 = i5 + (((i6 >>> 24) - i5) * i3 >> 7);
/* 1603 */               i12 = i7 + (((i8 >>> 24) - i7) * i3 >> 7);
/* 1604 */               int i16 = i11 + ((i12 - i11) * i4 >> 7);
/*      */ 
/* 1607 */               int i17 = this.m_pixels[j];
/* 1608 */               int i18 = i17 & 0xFF0000;
/* 1609 */               int i19 = i17 & 0xFF00;
/* 1610 */               i17 &= 255;
/* 1611 */               this.m_pixels[j] = (i18 + ((i13 - i18) * i16 >> 8) & 0xFF0000 | i19 + ((i14 - i19) * i16 >> 8) & 0xFF00 | i17 + ((i15 - i17) * i16 >> 8) & 0xFF);
/*      */             } else {
/* 1613 */               i2 = this.m_texture[((i1 >> 16) * this.TEX_WIDTH + (l >> 16))];
/* 1614 */               i3 = i2 >>> 24;
/* 1615 */               i4 = i2 & 0xFF00;
/* 1616 */               i5 = i2 & 0xFF;
/* 1617 */               i2 &= 16711680;
/*      */ 
/* 1620 */               i6 = this.m_pixels[j];
/* 1621 */               i7 = i6 & 0xFF0000;
/* 1622 */               i8 = i6 & 0xFF00;
/* 1623 */               i6 &= 255;
/* 1624 */               this.m_pixels[j] = (i7 + ((i2 - i7) * i3 >> 8) & 0xFF0000 | i8 + ((i4 - i8) * i3 >> 8) & 0xFF00 | i6 + ((i5 - i6) * i3 >> 8) & 0xFF);
/*      */             }
/* 1626 */             this.m_stencil[j] = i;
/*      */           }
/*      */         }
/*      */         catch (Exception localException) {
/*      */         }
/* 1631 */         l += this.iuadd;
/* 1632 */         i1 += this.ivadd;
/* 1633 */         f4 += this.izadd;
/*      */       }
/*      */ 
/* 1636 */       paramInt1 += this.SCREEN_WIDTH;
/*      */ 
/* 1638 */       this.xleft += paramFloat1;
/* 1639 */       this.xrght += paramFloat2;
/* 1640 */       this.uleft += this.uleftadd;
/* 1641 */       this.vleft += this.vleftadd;
/* 1642 */       this.zleft += this.zleftadd;
/* 1643 */       this.aleft += this.aleftadd;
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void drawsegment_texture32_alpha(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2)
/*      */   {
/* 1660 */     paramInt1 *= this.SCREEN_WIDTH;
/* 1661 */     paramInt2 *= this.SCREEN_WIDTH;
/* 1662 */     int i = this.m_index;
/*      */ 
/* 1664 */     float f1 = this.iuadd;
/* 1665 */     float f2 = this.ivadd;
/* 1666 */     float f3 = this.iaadd;
/*      */ 
/* 1668 */     while (paramInt1 < paramInt2) {
/* 1669 */       int j = (int)(this.xleft + 0.5F);
/* 1670 */       if (j < 0) {
/* 1671 */         j = 0;
/*      */       }
/* 1673 */       int k = (int)(this.xrght + 0.5F);
/* 1674 */       if (k > this.SCREEN_WIDTH) {
/* 1675 */         k = this.SCREEN_WIDTH;
/*      */       }
/* 1677 */       float f4 = j + 0.5F - this.xleft;
/* 1678 */       int l = (int)(f1 * f4 + this.uleft);
/* 1679 */       int i1 = (int)(f2 * f4 + this.vleft);
/* 1680 */       int i2 = (int)(f3 * f4 + this.aleft);
/* 1681 */       float f5 = this.izadd * f4 + this.zleft;
/*      */ 
/* 1683 */       j += paramInt1;
/* 1684 */       k += paramInt1;
/*      */ 
/* 1686 */       for (; j < k; ++j)
/*      */       {
/*      */         try
/*      */         {
/* 1690 */           if (f5 <= this.m_zbuffer[j])
/*      */           {
/* 1694 */             int i3 = i2 >> 16;
/*      */             int i4;
/*      */             int i5;
/*      */             int i6;
/*      */             int i7;
/*      */             int i8;
/*      */             int i9;
/* 1696 */             if (this.m_bilinear) {
/* 1697 */               i4 = (i1 >> 16) * this.TEX_WIDTH + (l >> 16);
/* 1698 */               i5 = (l & (char)-1) >> 9;
/* 1699 */               i6 = (i1 & (char)-1) >> 9;
/*      */ 
/* 1702 */               i7 = this.m_texture[i4];
/* 1703 */               i8 = this.m_texture[(i4 + 1)];
/* 1704 */               i4 += this.TEX_WIDTH;
/* 1705 */               i9 = this.m_texture[i4];
/* 1706 */               int i10 = this.m_texture[(i4 + 1)];
/*      */ 
/* 1709 */               int i11 = i7 & 0xFF0000;
/* 1710 */               int i12 = i9 & 0xFF0000;
/* 1711 */               int i13 = i11 + (((i8 & 0xFF0000) - i11) * i5 >> 7);
/* 1712 */               int i14 = i12 + (((i10 & 0xFF0000) - i12) * i5 >> 7);
/* 1713 */               int i15 = i13 + ((i14 - i13) * i6 >> 7);
/*      */ 
/* 1716 */               i11 = i7 & 0xFF00;
/* 1717 */               i12 = i9 & 0xFF00;
/* 1718 */               i13 = i11 + (((i8 & 0xFF00) - i11) * i5 >> 7);
/* 1719 */               i14 = i12 + (((i10 & 0xFF00) - i12) * i5 >> 7);
/* 1720 */               int i16 = i13 + ((i14 - i13) * i6 >> 7);
/*      */ 
/* 1723 */               i11 = i7 & 0xFF;
/* 1724 */               i12 = i9 & 0xFF;
/* 1725 */               i13 = i11 + (((i8 & 0xFF) - i11) * i5 >> 7);
/* 1726 */               i14 = i12 + (((i10 & 0xFF) - i12) * i5 >> 7);
/* 1727 */               int i17 = i13 + ((i14 - i13) * i6 >> 7);
/*      */ 
/* 1730 */               i7 >>>= 24;
/* 1731 */               i9 >>>= 24;
/* 1732 */               i13 = i7 + (((i8 >>> 24) - i7) * i5 >> 7);
/* 1733 */               i14 = i9 + (((i10 >>> 24) - i9) * i5 >> 7);
/* 1734 */               i3 = i3 * (i13 + ((i14 - i13) * i6 >> 7)) >> 8;
/*      */ 
/* 1737 */               int i18 = this.m_pixels[j];
/* 1738 */               int i19 = i18 & 0xFF0000;
/* 1739 */               int i20 = i18 & 0xFF00;
/* 1740 */               i18 &= 255;
/* 1741 */               this.m_pixels[j] = (i19 + ((i15 - i19) * i3 >> 8) & 0xFF0000 | i20 + ((i16 - i20) * i3 >> 8) & 0xFF00 | i18 + ((i17 - i18) * i3 >> 8) & 0xFF);
/*      */             } else {
/* 1743 */               i4 = this.m_texture[((i1 >> 16) * this.TEX_WIDTH + (l >> 16))];
/* 1744 */               i3 = i3 * (i4 >>> 24) >> 8;
/* 1745 */               i5 = i4 & 0xFF00;
/* 1746 */               i6 = i4 & 0xFF;
/* 1747 */               i4 &= 16711680;
/*      */ 
/* 1750 */               i7 = this.m_pixels[j];
/* 1751 */               i8 = i7 & 0xFF0000;
/* 1752 */               i9 = i7 & 0xFF00;
/* 1753 */               i7 &= 255;
/* 1754 */               this.m_pixels[j] = (i8 + ((i4 - i8) * i3 >> 8) & 0xFF0000 | i9 + ((i5 - i9) * i3 >> 8) & 0xFF00 | i7 + ((i6 - i7) * i3 >> 8) & 0xFF);
/*      */             }
/* 1756 */             this.m_stencil[j] = i;
/*      */           }
/*      */         }
/*      */         catch (Exception localException) {
/*      */         }
/* 1761 */         l += this.iuadd;
/* 1762 */         i1 += this.ivadd;
/* 1763 */         i2 += this.iaadd;
/* 1764 */         f5 += this.izadd;
/*      */       }
/*      */ 
/* 1767 */       paramInt1 += this.SCREEN_WIDTH;
/*      */ 
/* 1769 */       this.xleft += paramFloat1;
/* 1770 */       this.xrght += paramFloat2;
/* 1771 */       this.uleft += this.uleftadd;
/* 1772 */       this.vleft += this.vleftadd;
/* 1773 */       this.zleft += this.zleftadd;
/* 1774 */       this.aleft += this.aleftadd;
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void drawsegment_gouraud_texture8(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2)
/*      */   {
/* 1791 */     paramInt1 *= this.SCREEN_WIDTH;
/* 1792 */     paramInt2 *= this.SCREEN_WIDTH;
/* 1793 */     int i = this.m_index;
/*      */ 
/* 1795 */     float f1 = this.iuadd;
/* 1796 */     float f2 = this.ivadd;
/* 1797 */     float f3 = this.iradd;
/* 1798 */     float f4 = this.igadd;
/* 1799 */     float f5 = this.ibadd;
/*      */ 
/* 1801 */     while (paramInt1 < paramInt2) {
/* 1802 */       int j = (int)(this.xleft + 0.5F);
/* 1803 */       if (j < 0)
/* 1804 */         j = 0;
/* 1805 */       int k = (int)(this.xrght + 0.5F);
/* 1806 */       if (k > this.SCREEN_WIDTH)
/* 1807 */         k = this.SCREEN_WIDTH;
/* 1808 */       float f6 = j + 0.5F - this.xleft;
/*      */ 
/* 1810 */       int l = (int)(f1 * f6 + this.uleft);
/* 1811 */       int i1 = (int)(f2 * f6 + this.vleft);
/* 1812 */       int i2 = (int)(f3 * f6 + this.rleft);
/* 1813 */       int i3 = (int)(f4 * f6 + this.gleft);
/* 1814 */       int i4 = (int)(f5 * f6 + this.bleft);
/* 1815 */       float f7 = this.izadd * f6 + this.zleft;
/*      */ 
/* 1817 */       j += paramInt1;
/* 1818 */       k += paramInt1;
/*      */ 
/* 1820 */       for (; j < k; ++j)
/*      */       {
/*      */         try {
/* 1823 */           if (f7 <= this.m_zbuffer[j])
/*      */           {
/*      */             int i5;
/* 1827 */             if (this.m_bilinear) {
/* 1828 */               i6 = (i1 >> 16) * this.TEX_WIDTH + (l >> 16);
/* 1829 */               i7 = l & (char)-1;
/* 1830 */               i5 = this.m_texture[i6] & 0xFF;
/* 1831 */               i8 = this.m_texture[(i6 + 1)] & 0xFF;
/* 1832 */               i6 += this.TEX_WIDTH;
/* 1833 */               i9 = this.m_texture[i6] & 0xFF;
/* 1834 */               i10 = this.m_texture[(i6 + 1)] & 0xFF;
/* 1835 */               i5 += ((i8 - i5) * i7 >> 16);
/* 1836 */               i9 += ((i10 - i9) * i7 >> 16);
/* 1837 */               i5 += ((i9 - i5) * (i1 & (char)-1) >> 16);
/*      */             } else {
/* 1839 */               i5 = this.m_texture[((i1 >> 16) * this.TEX_WIDTH + (l >> 16))] & 0xFF;
/*      */             }
/*      */ 
/* 1843 */             int i6 = i2 & 0xFF0000;
/* 1844 */             int i7 = i3 >> 8 & 0xFF00;
/* 1845 */             int i8 = i4 >> 16;
/*      */ 
/* 1848 */             int i9 = this.m_pixels[j];
/* 1849 */             int i10 = i9 & 0xFF0000;
/* 1850 */             int i11 = i9 & 0xFF00;
/* 1851 */             i9 &= 255;
/* 1852 */             this.m_pixels[j] = (i10 + ((i6 - i10) * i5 >> 8) & 0xFF0000 | i11 + ((i7 - i11) * i5 >> 8) & 0xFF00 | i9 + ((i8 - i9) * i5 >> 8) & 0xFF);
/*      */ 
/* 1855 */             this.m_stencil[j] = i;
/*      */           }
/*      */ 
/*      */         }
/*      */         catch (Exception localException)
/*      */         {
/*      */         }
/*      */ 
/* 1863 */         l += this.iuadd;
/* 1864 */         i1 += this.ivadd;
/* 1865 */         i2 += this.iradd;
/* 1866 */         i3 += this.igadd;
/* 1867 */         i4 += this.ibadd;
/* 1868 */         f7 += this.izadd;
/*      */       }
/*      */ 
/* 1871 */       paramInt1 += this.SCREEN_WIDTH;
/* 1872 */       this.xleft += paramFloat1;
/* 1873 */       this.xrght += paramFloat2;
/*      */ 
/* 1875 */       this.uleft += this.uleftadd;
/* 1876 */       this.vleft += this.vleftadd;
/* 1877 */       this.rleft += this.rleftadd;
/* 1878 */       this.gleft += this.gleftadd;
/* 1879 */       this.bleft += this.bleftadd;
/* 1880 */       this.zleft += this.zleftadd;
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void drawsegment_gouraud_texture8_alpha(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2)
/*      */   {
/* 1895 */     paramInt1 *= this.SCREEN_WIDTH;
/* 1896 */     paramInt2 *= this.SCREEN_WIDTH;
/* 1897 */     int i = this.m_index;
/*      */ 
/* 1899 */     float f1 = this.iuadd;
/* 1900 */     float f2 = this.ivadd;
/* 1901 */     float f3 = this.iradd;
/* 1902 */     float f4 = this.igadd;
/* 1903 */     float f5 = this.ibadd;
/* 1904 */     float f6 = this.iaadd;
/*      */ 
/* 1906 */     while (paramInt1 < paramInt2) {
/* 1907 */       int j = (int)(this.xleft + 0.5F);
/* 1908 */       if (j < 0)
/* 1909 */         j = 0;
/* 1910 */       int k = (int)(this.xrght + 0.5F);
/* 1911 */       if (k > this.SCREEN_WIDTH)
/* 1912 */         k = this.SCREEN_WIDTH;
/* 1913 */       float f7 = j + 0.5F - this.xleft;
/*      */ 
/* 1915 */       int l = (int)(f1 * f7 + this.uleft);
/* 1916 */       int i1 = (int)(f2 * f7 + this.vleft);
/* 1917 */       int i2 = (int)(f3 * f7 + this.rleft);
/* 1918 */       int i3 = (int)(f4 * f7 + this.gleft);
/* 1919 */       int i4 = (int)(f5 * f7 + this.bleft);
/* 1920 */       int i5 = (int)(f6 * f7 + this.aleft);
/* 1921 */       float f8 = this.izadd * f7 + this.zleft;
/*      */ 
/* 1923 */       j += paramInt1;
/* 1924 */       k += paramInt1;
/*      */ 
/* 1926 */       for (; j < k; ++j)
/*      */       {
/*      */         try {
/* 1929 */           if (f8 <= this.m_zbuffer[j])
/*      */           {
/* 1933 */             if (this.m_bilinear) {
/* 1934 */               i7 = (i1 >> 16) * this.TEX_WIDTH + (l >> 16);
/* 1935 */               i8 = l & (char)-1;
/* 1936 */               i6 = this.m_texture[i7] & 0xFF;
/* 1937 */               i9 = this.m_texture[(i7 + 1)] & 0xFF;
/* 1938 */               i7 += this.TEX_WIDTH;
/* 1939 */               i10 = this.m_texture[i7] & 0xFF;
/* 1940 */               i11 = this.m_texture[(i7 + 1)] & 0xFF;
/* 1941 */               i6 += ((i9 - i6) * i8 >> 16);
/* 1942 */               i10 += ((i11 - i10) * i8 >> 16);
/* 1943 */               i6 += ((i10 - i6) * (i1 & (char)-1) >> 16);
/*      */             } else {
/* 1945 */               i6 = this.m_texture[((i1 >> 16) * this.TEX_WIDTH + (l >> 16))] & 0xFF;
/*      */             }
/* 1947 */             int i6 = i6 * (i5 >> 16) >> 8;
/*      */ 
/* 1950 */             int i7 = i2 & 0xFF0000;
/* 1951 */             int i8 = i3 >> 8 & 0xFF00;
/* 1952 */             int i9 = i4 >> 16;
/*      */ 
/* 1955 */             int i10 = this.m_pixels[j];
/* 1956 */             int i11 = i10 & 0xFF0000;
/* 1957 */             int i12 = i10 & 0xFF00;
/* 1958 */             i10 &= 255;
/* 1959 */             this.m_pixels[j] = (i11 + ((i7 - i11) * i6 >> 8) & 0xFF0000 | i12 + ((i8 - i12) * i6 >> 8) & 0xFF00 | i10 + ((i9 - i10) * i6 >> 8) & 0xFF);
/*      */ 
/* 1962 */             this.m_stencil[j] = i;
/*      */           }
/*      */ 
/*      */         }
/*      */         catch (Exception localException)
/*      */         {
/*      */         }
/*      */ 
/* 1970 */         l += this.iuadd;
/* 1971 */         i1 += this.ivadd;
/* 1972 */         i2 += this.iradd;
/* 1973 */         i3 += this.igadd;
/* 1974 */         i4 += this.ibadd;
/* 1975 */         i5 += this.iaadd;
/* 1976 */         f8 += this.izadd;
/*      */       }
/*      */ 
/* 1979 */       paramInt1 += this.SCREEN_WIDTH;
/* 1980 */       this.xleft += paramFloat1;
/* 1981 */       this.xrght += paramFloat2;
/* 1982 */       this.uleft += this.uleftadd;
/* 1983 */       this.vleft += this.vleftadd;
/* 1984 */       this.rleft += this.rleftadd;
/* 1985 */       this.gleft += this.gleftadd;
/* 1986 */       this.bleft += this.bleftadd;
/* 1987 */       this.aleft += this.aleftadd;
/* 1988 */       this.zleft += this.zleftadd;
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void drawsegment_gouraud_texture24(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2)
/*      */   {
/* 2003 */     paramInt1 *= this.SCREEN_WIDTH;
/* 2004 */     paramInt2 *= this.SCREEN_WIDTH;
/* 2005 */     int i = this.m_index;
/*      */ 
/* 2007 */     float f1 = this.iuadd;
/* 2008 */     float f2 = this.ivadd;
/* 2009 */     float f3 = this.iradd;
/* 2010 */     float f4 = this.igadd;
/* 2011 */     float f5 = this.ibadd;
/*      */ 
/* 2013 */     while (paramInt1 < paramInt2) {
/* 2014 */       int j = (int)(this.xleft + 0.5F);
/* 2015 */       if (j < 0)
/* 2016 */         j = 0;
/* 2017 */       int k = (int)(this.xrght + 0.5F);
/* 2018 */       if (k > this.SCREEN_WIDTH)
/* 2019 */         k = this.SCREEN_WIDTH;
/* 2020 */       float f6 = j + 0.5F - this.xleft;
/*      */ 
/* 2022 */       int l = (int)(f1 * f6 + this.uleft);
/* 2023 */       int i1 = (int)(f2 * f6 + this.vleft);
/* 2024 */       int i2 = (int)(f3 * f6 + this.rleft);
/* 2025 */       int i3 = (int)(f4 * f6 + this.gleft);
/* 2026 */       int i4 = (int)(f5 * f6 + this.bleft);
/* 2027 */       float f7 = this.izadd * f6 + this.zleft;
/*      */ 
/* 2029 */       j += paramInt1;
/* 2030 */       k += paramInt1;
/*      */ 
/* 2032 */       for (; j < k; ++j)
/*      */       {
/*      */         try {
/* 2035 */           if (f7 <= this.m_zbuffer[j]) {
/* 2036 */             this.m_zbuffer[j] = f7;
/*      */             int i5;
/*      */             int i6;
/*      */             int i7;
/* 2042 */             if (this.m_bilinear) {
/* 2043 */               i8 = (i1 >> 16) * this.TEX_WIDTH + (l >> 16);
/* 2044 */               i9 = (l & (char)-1) >> 9;
/* 2045 */               i10 = (i1 & (char)-1) >> 9;
/*      */ 
/* 2048 */               int i11 = this.m_texture[i8];
/* 2049 */               int i12 = this.m_texture[(i8 + 1)];
/* 2050 */               i8 += this.TEX_WIDTH;
/* 2051 */               int i13 = this.m_texture[i8];
/* 2052 */               int i14 = this.m_texture[(i8 + 1)];
/*      */ 
/* 2055 */               int i15 = i11 & 0xFF0000;
/* 2056 */               int i16 = i13 & 0xFF0000;
/* 2057 */               int i17 = i15 + (((i12 & 0xFF0000) - i15) * i9 >> 7);
/* 2058 */               int i18 = i16 + (((i14 & 0xFF0000) - i16) * i9 >> 7);
/* 2059 */               i5 = i17 + ((i18 - i17) * i10 >> 7);
/*      */ 
/* 2062 */               i15 = i11 & 0xFF00;
/* 2063 */               i16 = i13 & 0xFF00;
/* 2064 */               i17 = i15 + (((i12 & 0xFF00) - i15) * i9 >> 7);
/* 2065 */               i18 = i16 + (((i14 & 0xFF00) - i16) * i9 >> 7);
/* 2066 */               i6 = i17 + ((i18 - i17) * i10 >> 7);
/*      */ 
/* 2069 */               i15 = i11 & 0xFF;
/* 2070 */               i16 = i13 & 0xFF;
/* 2071 */               i17 = i15 + (((i12 & 0xFF) - i15) * i9 >> 7);
/* 2072 */               i18 = i16 + (((i14 & 0xFF) - i16) * i9 >> 7);
/* 2073 */               i7 = i17 + ((i18 - i17) * i10 >> 7);
/*      */             }
/*      */             else {
/* 2076 */               i7 = this.m_texture[((i1 >> 16) * this.TEX_WIDTH + (l >> 16))];
/* 2077 */               i5 = i7 & 0xFF0000;
/* 2078 */               i6 = i7 & 0xFF00;
/* 2079 */               i7 &= 255;
/*      */             }
/*      */ 
/* 2083 */             int i8 = i2 >> 16;
/* 2084 */             int i9 = i3 >> 16;
/* 2085 */             int i10 = i4 >> 16;
/*      */ 
/* 2088 */             this.m_pixels[j] = ((i5 * i8 & 0xFF000000 | i6 * i9 & 0xFF0000 | i7 * i10) >> 8);
/* 2089 */             this.m_stencil[j] = i;
/*      */           }
/*      */         }
/*      */         catch (Exception localException)
/*      */         {
/*      */         }
/*      */ 
/* 2096 */         l += this.iuadd;
/* 2097 */         i1 += this.ivadd;
/* 2098 */         i2 += this.iradd;
/* 2099 */         i3 += this.igadd;
/* 2100 */         i4 += this.ibadd;
/* 2101 */         f7 += this.izadd;
/*      */       }
/*      */ 
/* 2104 */       paramInt1 += this.SCREEN_WIDTH;
/* 2105 */       this.xleft += paramFloat1;
/* 2106 */       this.xrght += paramFloat2;
/* 2107 */       this.uleft += this.uleftadd;
/* 2108 */       this.vleft += this.vleftadd;
/* 2109 */       this.rleft += this.rleftadd;
/* 2110 */       this.gleft += this.gleftadd;
/* 2111 */       this.bleft += this.bleftadd;
/* 2112 */       this.zleft += this.zleftadd;
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void drawsegment_gouraud_texture24_alpha(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2)
/*      */   {
/* 2127 */     paramInt1 *= this.SCREEN_WIDTH;
/* 2128 */     paramInt2 *= this.SCREEN_WIDTH;
/* 2129 */     int i = this.m_index;
/*      */ 
/* 2131 */     float f1 = this.iuadd;
/* 2132 */     float f2 = this.ivadd;
/* 2133 */     float f3 = this.iradd;
/* 2134 */     float f4 = this.igadd;
/* 2135 */     float f5 = this.ibadd;
/* 2136 */     float f6 = this.iaadd;
/*      */ 
/* 2138 */     while (paramInt1 < paramInt2) {
/* 2139 */       int j = (int)(this.xleft + 0.5F);
/* 2140 */       if (j < 0)
/* 2141 */         j = 0;
/* 2142 */       int k = (int)(this.xrght + 0.5F);
/* 2143 */       if (k > this.SCREEN_WIDTH)
/* 2144 */         k = this.SCREEN_WIDTH;
/* 2145 */       float f7 = j + 0.5F - this.xleft;
/*      */ 
/* 2147 */       int l = (int)(f1 * f7 + this.uleft);
/* 2148 */       int i1 = (int)(f2 * f7 + this.vleft);
/* 2149 */       int i2 = (int)(f3 * f7 + this.rleft);
/* 2150 */       int i3 = (int)(f4 * f7 + this.gleft);
/* 2151 */       int i4 = (int)(f5 * f7 + this.bleft);
/* 2152 */       int i5 = (int)(f6 * f7 + this.aleft);
/* 2153 */       float f8 = this.izadd * f7 + this.zleft;
/*      */ 
/* 2155 */       j += paramInt1;
/* 2156 */       k += paramInt1;
/*      */ 
/* 2158 */       for (; j < k; ++j)
/*      */       {
/*      */         try
/*      */         {
/* 2163 */           if (f8 <= this.m_zbuffer[j])
/*      */           {
/* 2167 */             int i6 = i5 >> 16;
/*      */ 
/* 2173 */             if (this.m_bilinear) {
/* 2174 */               i10 = (i1 >> 16) * this.TEX_WIDTH + (l >> 16);
/* 2175 */               i11 = (l & (char)-1) >> 9;
/* 2176 */               i12 = (i1 & (char)-1) >> 9;
/*      */ 
/* 2179 */               int i13 = this.m_texture[i10];
/* 2180 */               int i14 = this.m_texture[(i10 + 1)];
/* 2181 */               i10 += this.TEX_WIDTH;
/* 2182 */               int i15 = this.m_texture[i10];
/* 2183 */               int i16 = this.m_texture[(i10 + 1)];
/*      */ 
/* 2186 */               int i17 = i13 & 0xFF0000;
/* 2187 */               int i18 = i15 & 0xFF0000;
/* 2188 */               int i19 = i17 + (((i14 & 0xFF0000) - i17) * i11 >> 7);
/* 2189 */               int i20 = i18 + (((i16 & 0xFF0000) - i18) * i11 >> 7);
/* 2190 */               i7 = i19 + ((i20 - i19) * i12 >> 7) >> 16;
/*      */ 
/* 2193 */               i17 = i13 & 0xFF00;
/* 2194 */               i18 = i15 & 0xFF00;
/* 2195 */               i19 = i17 + (((i14 & 0xFF00) - i17) * i11 >> 7);
/* 2196 */               i20 = i18 + (((i16 & 0xFF00) - i18) * i11 >> 7);
/* 2197 */               i8 = i19 + ((i20 - i19) * i12 >> 7) >> 8;
/*      */ 
/* 2200 */               i17 = i13 & 0xFF;
/* 2201 */               i18 = i15 & 0xFF;
/* 2202 */               i19 = i17 + (((i14 & 0xFF) - i17) * i11 >> 7);
/* 2203 */               i20 = i18 + (((i16 & 0xFF) - i18) * i11 >> 7);
/* 2204 */               i9 = i19 + ((i20 - i19) * i12 >> 7);
/*      */             } else {
/* 2206 */               i9 = this.m_texture[((i1 >> 16) * this.TEX_WIDTH + (l >> 16))];
/* 2207 */               i7 = (i9 & 0xFF0000) >> 16;
/* 2208 */               i8 = (i9 & 0xFF00) >> 8;
/* 2209 */               i9 &= 255;
/*      */             }
/*      */ 
/* 2213 */             int i7 = i7 * i2 >>> 8;
/* 2214 */             int i8 = i8 * i3 >>> 16;
/* 2215 */             int i9 = i9 * i4 >>> 24;
/*      */ 
/* 2218 */             int i10 = this.m_pixels[j];
/* 2219 */             int i11 = i10 & 0xFF0000;
/* 2220 */             int i12 = i10 & 0xFF00;
/* 2221 */             i10 &= 255;
/*      */ 
/* 2224 */             this.m_pixels[j] = (i11 + ((i7 - i11) * i6 >> 8) & 0xFF0000 | i12 + ((i8 - i12) * i6 >> 8) & 0xFF00 | i10 + ((i9 - i10) * i6 >> 8) & 0xFF);
/* 2225 */             this.m_stencil[j] = i;
/*      */           }
/*      */         }
/*      */         catch (Exception localException)
/*      */         {
/*      */         }
/*      */ 
/* 2232 */         l += this.iuadd;
/* 2233 */         i1 += this.ivadd;
/* 2234 */         i2 += this.iradd;
/* 2235 */         i3 += this.igadd;
/* 2236 */         i4 += this.ibadd;
/* 2237 */         i5 += this.iaadd;
/* 2238 */         f8 += this.izadd;
/*      */       }
/*      */ 
/* 2241 */       paramInt1 += this.SCREEN_WIDTH;
/* 2242 */       this.xleft += paramFloat1;
/* 2243 */       this.xrght += paramFloat2;
/* 2244 */       this.uleft += this.uleftadd;
/* 2245 */       this.vleft += this.vleftadd;
/* 2246 */       this.rleft += this.rleftadd;
/* 2247 */       this.gleft += this.gleftadd;
/* 2248 */       this.bleft += this.bleftadd;
/* 2249 */       this.aleft += this.aleftadd;
/* 2250 */       this.zleft += this.zleftadd;
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void drawsegment_gouraud_texture32(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2)
/*      */   {
/* 2265 */     paramInt1 *= this.SCREEN_WIDTH;
/* 2266 */     paramInt2 *= this.SCREEN_WIDTH;
/* 2267 */     int i = this.m_index;
/*      */ 
/* 2269 */     float f1 = this.iuadd;
/* 2270 */     float f2 = this.ivadd;
/* 2271 */     float f3 = this.iradd;
/* 2272 */     float f4 = this.igadd;
/* 2273 */     float f5 = this.ibadd;
/*      */ 
/* 2275 */     while (paramInt1 < paramInt2) {
/* 2276 */       int j = (int)(this.xleft + 0.5F);
/* 2277 */       if (j < 0)
/* 2278 */         j = 0;
/* 2279 */       int k = (int)(this.xrght + 0.5F);
/* 2280 */       if (k > this.SCREEN_WIDTH)
/* 2281 */         k = this.SCREEN_WIDTH;
/* 2282 */       float f6 = j + 0.5F - this.xleft;
/*      */ 
/* 2284 */       int l = (int)(f1 * f6 + this.uleft);
/* 2285 */       int i1 = (int)(f2 * f6 + this.vleft);
/* 2286 */       int i2 = (int)(f3 * f6 + this.rleft);
/* 2287 */       int i3 = (int)(f4 * f6 + this.gleft);
/* 2288 */       int i4 = (int)(f5 * f6 + this.bleft);
/* 2289 */       float f7 = this.izadd * f6 + this.zleft;
/*      */ 
/* 2291 */       j += paramInt1;
/* 2292 */       k += paramInt1;
/*      */ 
/* 2294 */       for (; j < k; ++j)
/*      */       {
/*      */         try {
/* 2297 */           if (f7 <= this.m_zbuffer[j])
/*      */           {
/*      */             int i8;
/* 2305 */             if (this.m_bilinear) {
/* 2306 */               i9 = (i1 >> 16) * this.TEX_WIDTH + (l >> 16);
/* 2307 */               i10 = (l & (char)-1) >> 9;
/* 2308 */               i11 = (i1 & (char)-1) >> 9;
/*      */ 
/* 2311 */               int i12 = this.m_texture[i9];
/* 2312 */               int i13 = this.m_texture[(i9 + 1)];
/* 2313 */               i9 += this.TEX_WIDTH;
/* 2314 */               int i14 = this.m_texture[i9];
/* 2315 */               int i15 = this.m_texture[(i9 + 1)];
/*      */ 
/* 2318 */               int i16 = i12 & 0xFF0000;
/* 2319 */               int i17 = i14 & 0xFF0000;
/* 2320 */               int i18 = i16 + (((i13 & 0xFF0000) - i16) * i10 >> 7);
/* 2321 */               int i19 = i17 + (((i15 & 0xFF0000) - i17) * i10 >> 7);
/* 2322 */               i5 = i18 + ((i19 - i18) * i11 >> 7) >> 16;
/*      */ 
/* 2325 */               i16 = i12 & 0xFF00;
/* 2326 */               i17 = i14 & 0xFF00;
/* 2327 */               i18 = i16 + (((i13 & 0xFF00) - i16) * i10 >> 7);
/* 2328 */               i19 = i17 + (((i15 & 0xFF00) - i17) * i10 >> 7);
/* 2329 */               i6 = i18 + ((i19 - i18) * i11 >> 7) >> 8;
/*      */ 
/* 2332 */               i16 = i12 & 0xFF;
/* 2333 */               i17 = i14 & 0xFF;
/* 2334 */               i18 = i16 + (((i13 & 0xFF) - i16) * i10 >> 7);
/* 2335 */               i19 = i17 + (((i15 & 0xFF) - i17) * i10 >> 7);
/* 2336 */               i7 = i18 + ((i19 - i18) * i11 >> 7);
/*      */ 
/* 2339 */               i12 >>>= 24;
/* 2340 */               i14 >>>= 24;
/* 2341 */               i18 = i12 + (((i13 >>> 24) - i12) * i10 >> 7);
/* 2342 */               i19 = i14 + (((i15 >>> 24) - i14) * i10 >> 7);
/* 2343 */               i8 = i18 + ((i19 - i18) * i11 >> 7);
/*      */             }
/*      */             else {
/* 2346 */               i7 = this.m_texture[((i1 >> 16) * this.TEX_WIDTH + (l >> 16))];
/* 2347 */               i8 = i7 >>> 24;
/* 2348 */               i5 = (i7 & 0xFF0000) >> 16;
/* 2349 */               i6 = (i7 & 0xFF00) >> 8;
/* 2350 */               i7 &= 255;
/*      */             }
/*      */ 
/* 2354 */             int i5 = i5 * i2 >>> 8;
/* 2355 */             int i6 = i6 * i3 >>> 16;
/* 2356 */             int i7 = i7 * i4 >>> 24;
/*      */ 
/* 2359 */             int i9 = this.m_pixels[j];
/* 2360 */             int i10 = i9 & 0xFF0000;
/* 2361 */             int i11 = i9 & 0xFF00;
/* 2362 */             i9 &= 255;
/*      */ 
/* 2365 */             this.m_pixels[j] = (i10 + ((i5 - i10) * i8 >> 8) & 0xFF0000 | i11 + ((i6 - i11) * i8 >> 8) & 0xFF00 | i9 + ((i7 - i9) * i8 >> 8) & 0xFF);
/*      */           }
/*      */         }
/*      */         catch (Exception localException)
/*      */         {
/*      */         }
/*      */ 
/* 2372 */         l += this.iuadd;
/* 2373 */         i1 += this.ivadd;
/* 2374 */         i2 += this.iradd;
/* 2375 */         i3 += this.igadd;
/* 2376 */         i4 += this.ibadd;
/* 2377 */         f7 += this.izadd;
/*      */       }
/*      */ 
/* 2380 */       paramInt1 += this.SCREEN_WIDTH;
/* 2381 */       this.xleft += paramFloat1;
/* 2382 */       this.xrght += paramFloat2;
/* 2383 */       this.uleft += this.uleftadd;
/* 2384 */       this.vleft += this.vleftadd;
/* 2385 */       this.rleft += this.rleftadd;
/* 2386 */       this.gleft += this.gleftadd;
/* 2387 */       this.bleft += this.bleftadd;
/* 2388 */       this.zleft += this.zleftadd;
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void drawsegment_gouraud_texture32_alpha(float paramFloat1, float paramFloat2, int paramInt1, int paramInt2)
/*      */   {
/* 2403 */     paramInt1 *= this.SCREEN_WIDTH;
/* 2404 */     paramInt2 *= this.SCREEN_WIDTH;
/* 2405 */     int i = this.m_index;
/*      */ 
/* 2407 */     float f1 = this.iuadd;
/* 2408 */     float f2 = this.ivadd;
/* 2409 */     float f3 = this.iradd;
/* 2410 */     float f4 = this.igadd;
/* 2411 */     float f5 = this.ibadd;
/* 2412 */     float f6 = this.iaadd;
/*      */ 
/* 2414 */     while (paramInt1 < paramInt2) {
/* 2415 */       int j = (int)(this.xleft + 0.5F);
/* 2416 */       if (j < 0)
/* 2417 */         j = 0;
/* 2418 */       int k = (int)(this.xrght + 0.5F);
/* 2419 */       if (k > this.SCREEN_WIDTH)
/* 2420 */         k = this.SCREEN_WIDTH;
/* 2421 */       float f7 = j + 0.5F - this.xleft;
/*      */ 
/* 2423 */       int l = (int)(f1 * f7 + this.uleft);
/* 2424 */       int i1 = (int)(f2 * f7 + this.vleft);
/* 2425 */       int i2 = (int)(f3 * f7 + this.rleft);
/* 2426 */       int i3 = (int)(f4 * f7 + this.gleft);
/* 2427 */       int i4 = (int)(f5 * f7 + this.bleft);
/* 2428 */       int i5 = (int)(f6 * f7 + this.aleft);
/* 2429 */       float f8 = this.izadd * f7 + this.zleft;
/*      */ 
/* 2431 */       j += paramInt1;
/* 2432 */       k += paramInt1;
/*      */ 
/* 2434 */       for (; j < k; ++j)
/*      */       {
/*      */         try
/*      */         {
/* 2439 */           if (f8 <= this.m_zbuffer[j])
/*      */           {
/* 2443 */             int i6 = i5 >> 16;
/*      */ 
/* 2449 */             if (this.m_bilinear) {
/* 2450 */               i10 = (i1 >> 16) * this.TEX_WIDTH + (l >> 16);
/* 2451 */               i11 = (l & (char)-1) >> 9;
/* 2452 */               i12 = (i1 & (char)-1) >> 9;
/*      */ 
/* 2455 */               int i13 = this.m_texture[i10];
/* 2456 */               int i14 = this.m_texture[(i10 + 1)];
/* 2457 */               i10 += this.TEX_WIDTH;
/* 2458 */               int i15 = this.m_texture[i10];
/* 2459 */               int i16 = this.m_texture[(i10 + 1)];
/*      */ 
/* 2462 */               int i17 = i13 & 0xFF0000;
/* 2463 */               int i18 = i15 & 0xFF0000;
/* 2464 */               int i19 = i17 + (((i14 & 0xFF0000) - i17) * i11 >> 7);
/* 2465 */               int i20 = i18 + (((i16 & 0xFF0000) - i18) * i11 >> 7);
/* 2466 */               i7 = i19 + ((i20 - i19) * i12 >> 7) >> 16;
/*      */ 
/* 2469 */               i17 = i13 & 0xFF00;
/* 2470 */               i18 = i15 & 0xFF00;
/* 2471 */               i19 = i17 + (((i14 & 0xFF00) - i17) * i11 >> 7);
/* 2472 */               i20 = i18 + (((i16 & 0xFF00) - i18) * i11 >> 7);
/* 2473 */               i8 = i19 + ((i20 - i19) * i12 >> 7) >> 8;
/*      */ 
/* 2476 */               i17 = i13 & 0xFF;
/* 2477 */               i18 = i15 & 0xFF;
/* 2478 */               i19 = i17 + (((i14 & 0xFF) - i17) * i11 >> 7);
/* 2479 */               i20 = i18 + (((i16 & 0xFF) - i18) * i11 >> 7);
/* 2480 */               i9 = i19 + ((i20 - i19) * i12 >> 7);
/*      */ 
/* 2483 */               i13 >>>= 24;
/* 2484 */               i15 >>>= 24;
/* 2485 */               i19 = i13 + (((i14 >>> 24) - i13) * i11 >> 7);
/* 2486 */               i20 = i15 + (((i16 >>> 24) - i15) * i11 >> 7);
/* 2487 */               i6 = i6 * (i19 + ((i20 - i19) * i12 >> 7)) >> 8;
/*      */             } else {
/* 2489 */               i9 = this.m_texture[((i1 >> 16) * this.TEX_WIDTH + (l >> 16))];
/* 2490 */               i6 = i6 * (i9 >>> 24) >> 8;
/* 2491 */               i7 = (i9 & 0xFF0000) >> 16;
/* 2492 */               i8 = (i9 & 0xFF00) >> 8;
/* 2493 */               i9 &= 255;
/*      */             }
/*      */ 
/* 2497 */             int i7 = i7 * i2 >>> 8;
/* 2498 */             int i8 = i8 * i3 >>> 16;
/* 2499 */             int i9 = i9 * i4 >>> 24;
/*      */ 
/* 2502 */             int i10 = this.m_pixels[j];
/* 2503 */             int i11 = i10 & 0xFF0000;
/* 2504 */             int i12 = i10 & 0xFF00;
/* 2505 */             i10 &= 255;
/*      */ 
/* 2508 */             this.m_pixels[j] = (i11 + ((i7 - i11) * i6 >> 8) & 0xFF0000 | i12 + ((i8 - i12) * i6 >> 8) & 0xFF00 | i10 + ((i9 - i10) * i6 >> 8) & 0xFF);
/* 2509 */             this.m_stencil[j] = i;
/*      */           }
/*      */         }
/*      */         catch (Exception localException)
/*      */         {
/*      */         }
/*      */ 
/* 2516 */         l += this.iuadd;
/* 2517 */         i1 += this.ivadd;
/* 2518 */         i2 += this.iradd;
/* 2519 */         i3 += this.igadd;
/* 2520 */         i4 += this.ibadd;
/* 2521 */         i5 += this.iaadd;
/* 2522 */         f8 += this.izadd;
/*      */       }
/*      */ 
/* 2525 */       paramInt1 += this.SCREEN_WIDTH;
/* 2526 */       this.xleft += paramFloat1;
/* 2527 */       this.xrght += paramFloat2;
/* 2528 */       this.uleft += this.uleftadd;
/* 2529 */       this.vleft += this.vleftadd;
/* 2530 */       this.rleft += this.rleftadd;
/* 2531 */       this.gleft += this.gleftadd;
/* 2532 */       this.bleft += this.bleftadd;
/* 2533 */       this.aleft += this.aleftadd;
/* 2534 */       this.zleft += this.zleftadd;
/*      */     }
/*      */   }
/*      */ 
/*      */   public PTriangle(PGraphics3 paramPGraphics3)
/*      */   {
/*  204 */     this.x_array = new float[3];
/*  205 */     this.y_array = new float[3];
/*  206 */     this.z_array = new float[3];
/*  207 */     this.u_array = new float[3];
/*  208 */     this.v_array = new float[3];
/*  209 */     this.r_array = new float[3];
/*  210 */     this.g_array = new float[3];
/*  211 */     this.b_array = new float[3];
/*  212 */     this.a_array = new float[3];
/*      */ 
/*  214 */     this.parent = paramPGraphics3;
/*  215 */     reset();
/*      */   }
/*      */ }

/* Location:           /Users/mfeyereisen/Desktop/Sources 2/common/
 * Qualified Name:     processing.core.PTriangle
 * JD-Core Version:    0.5.3
 */