/*      */ package processing.core;
/*      */ 
/*      */ import java.awt.Color;
/*      */ import java.awt.Image;
/*      */ import java.awt.Toolkit;
/*      */ import java.awt.image.DirectColorModel;
/*      */ import java.awt.image.MemoryImageSource;
/*      */ import java.io.PrintStream;
/*      */ 
/*      */ public class PGraphics extends PImage
/*      */   implements PConstants
/*      */ {
/*      */   static final int MATRIX_STACK_DEPTH = 32;
/*      */   static final int DEFAULT_VERTICES = 512;
/*      */   static final int DEFAULT_SPLINE_VERTICES = 128;
/*  248 */   static final float[] sinLUT = new float[720];
/*  249 */   static final float[] cosLUT = new float[720];
/*      */   static final float SINCOS_PRECISION = 0.5F;
/*      */   static final int SINCOS_LENGTH = 720;
/*      */   public int width1;
/*      */   public int height1;
/*      */   public int pixelCount;
/*      */   DirectColorModel cm;
/*      */   MemoryImageSource mis;
/*      */   public Image image;
/*      */   protected boolean[] hints;
/*      */   public int colorMode;
/*      */   public float colorModeX;
/*      */   public float colorModeY;
/*      */   public float colorModeZ;
/*      */   public float colorModeA;
/*      */   boolean colorScale;
/*      */   boolean colorRgb255;
/*      */   public boolean tint;
/*      */   public int tintColor;
/*      */   boolean tintAlpha;
/*      */   float tintR;
/*      */   float tintG;
/*      */   float tintB;
/*      */   float tintA;
/*      */   int tintRi;
/*      */   int tintGi;
/*      */   int tintBi;
/*      */   int tintAi;
/*      */   public boolean fill;
/*      */   public int fillColor;
/*      */   boolean fillAlpha;
/*      */   float fillR;
/*      */   float fillG;
/*      */   float fillB;
/*      */   float fillA;
/*      */   int fillRi;
/*      */   int fillGi;
/*      */   int fillBi;
/*      */   int fillAi;
/*      */   public boolean stroke;
/*      */   public int strokeColor;
/*      */   boolean strokeAlpha;
/*      */   float strokeR;
/*      */   float strokeG;
/*      */   float strokeB;
/*      */   float strokeA;
/*      */   int strokeRi;
/*      */   int strokeGi;
/*      */   int strokeBi;
/*      */   int strokeAi;
/*      */   public int backgroundColor;
/*      */   float backgroundR;
/*      */   float backgroundG;
/*      */   float backgroundB;
/*      */   int backgroundRi;
/*      */   int backgroundGi;
/*      */   int backgroundBi;
/*      */   protected float calcR;
/*      */   protected float calcG;
/*      */   protected float calcB;
/*      */   protected float calcA;
/*      */   int calcRi;
/*      */   int calcGi;
/*      */   int calcBi;
/*      */   int calcAi;
/*      */   int calcColor;
/*      */   boolean calcAlpha;
/*      */   int cacheHsbKey;
/*      */   float[] cacheHsbValue;
/*      */   public float strokeWeight;
/*      */   public int strokeJoin;
/*      */   public int strokeCap;
/*      */   public float m00;
/*      */   public float m01;
/*      */   public float m02;
/*      */   public float m10;
/*      */   public float m11;
/*      */   public float m12;
/*      */   float[][] matrixStack;
/*      */   int matrixStackDepth;
/*      */   Path path;
/*      */   protected int shape;
/*      */   public float[][] vertices;
/*      */   int vertexCount;
/*      */   protected boolean bezier_inited;
/*      */   protected int bezier_detail;
/*      */   protected float[][] bezier_basis;
/*      */   protected PMatrix bezierBasis;
/*      */   protected float[][] bezier_forward;
/*      */   protected float[][] bezier_draw;
/*      */   protected boolean curve_inited;
/*      */   protected int curve_detail;
/*      */   protected float curve_tightness;
/*      */   protected float[][] curve_basis;
/*      */   protected float[][] curve_forward;
/*      */   protected float[][] curve_draw;
/*      */   protected PMatrix bezierBasisInverse;
/*      */   protected PMatrix curveToBezierMatrix;
/*      */   protected float[][] splineVertices;
/*      */   protected int splineVertexCount;
/*      */   public int rectMode;
/*      */   public int ellipseMode;
/*      */   public PFont textFont;
/*      */   public int textAlign;
/*      */   public int textMode;
/*      */   public float textSize;
/*      */   public float textLeading;
/*      */ 
/*      */   public void resize(int paramInt1, int paramInt2)
/*      */   {
/*  346 */     this.width = paramInt1;
/*  347 */     this.height = paramInt2;
/*  348 */     this.width1 = (this.width - 1);
/*  349 */     this.height1 = (this.height - 1);
/*      */ 
/*  351 */     allocate();
/*      */   }
/*      */ 
/*      */   public void requestDisplay(PApplet paramPApplet)
/*      */   {
/*  362 */     paramPApplet.display();
/*      */   }
/*      */ 
/*      */   protected void allocate()
/*      */   {
/*  368 */     this.pixelCount = (this.width * this.height);
/*  369 */     this.pixels = new int[this.pixelCount];
/*      */ 
/*  374 */     this.backgroundColor |= -16777216;
/*  375 */     for (int i = 0; i < this.pixelCount; ++i) this.pixels[i] = this.backgroundColor;
/*      */ 
/*  378 */     this.cm = new DirectColorModel(32, 16711680, 65280, 255);
/*  379 */     this.mis = new MemoryImageSource(this.width, this.height, this.pixels, 0, this.width);
/*  380 */     this.mis.setFullBufferUpdates(true);
/*  381 */     this.mis.setAnimated(true);
/*  382 */     this.image = Toolkit.getDefaultToolkit().createImage(this.mis);
/*      */   }
/*      */ 
/*      */   public void beginFrame()
/*      */   {
/*  397 */     resetMatrix();
/*      */ 
/*  400 */     this.vertexCount = 0;
/*      */   }
/*      */ 
/*      */   public void endFrame()
/*      */   {
/*  414 */     this.mis.newPixels(this.pixels, this.cm, 0, this.width);
/*      */   }
/*      */ 
/*      */   public void defaults()
/*      */   {
/*  423 */     colorMode(1, 255.0F);
/*  424 */     fill(255.0F);
/*  425 */     stroke(0);
/*      */ 
/*  427 */     strokeWeight(1.0F);
/*      */ 
/*  429 */     strokeCap(2);
/*  430 */     strokeJoin(8);
/*      */ 
/*  432 */     background(204);
/*      */ 
/*  435 */     this.shape = 0;
/*      */ 
/*  438 */     this.matrixStackDepth = 0;
/*      */ 
/*  440 */     rectMode(0);
/*  441 */     ellipseMode(3);
/*      */ 
/*  446 */     this.textFont = null;
/*  447 */     this.textSize = 12.0F;
/*  448 */     this.textLeading = 14.0F;
/*  449 */     this.textAlign = 37;
/*  450 */     this.textMode = 3;
/*      */   }
/*      */ 
/*      */   public void hint(int paramInt)
/*      */   {
/*  475 */     this.hints[paramInt] = true;
/*      */   }
/*      */ 
/*      */   public void unhint(int paramInt) {
/*  479 */     this.hints[paramInt] = false;
/*      */   }
/*      */ 
/*      */   public void beginShape()
/*      */   {
/*  491 */     beginShape(256);
/*      */   }
/*      */ 
/*      */   public void beginShape(int paramInt)
/*      */   {
/*  501 */     this.shape = paramInt;
/*      */ 
/*  505 */     this.vertexCount = 0;
/*      */ 
/*  507 */     this.splineVertexCount = 0;
/*      */   }
/*      */ 
/*      */   public void normal(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/*  517 */     depthError("normal");
/*      */   }
/*      */ 
/*      */   public void textureMode(int paramInt) {
/*  521 */     depthError("textureMode");
/*      */   }
/*      */ 
/*      */   public void texture(PImage paramPImage) {
/*  525 */     depthError("texture");
/*      */   }
/*      */ 
/*      */   public void vertex(float paramFloat1, float paramFloat2)
/*      */   {
/*  530 */     this.splineVertexCount = 0;
/*      */ 
/*  533 */     if (this.vertexCount == this.vertices.length) {
/*  534 */       float[][] arrayOfFloat = new float[this.vertexCount << 1][36];
/*  535 */       System.arraycopy(this.vertices, 0, arrayOfFloat, 0, this.vertexCount);
/*  536 */       this.vertices = arrayOfFloat;
/*      */     }
/*      */ 
/*  541 */     this.vertices[this.vertexCount][9] = paramFloat1;
/*  542 */     this.vertices[this.vertexCount][10] = paramFloat1;
/*  543 */     this.vertexCount += 1;
/*      */ 
/*  545 */     switch (this.shape)
/*      */     {
/*      */     case 16:
/*  548 */       point(paramFloat1, paramFloat2);
/*  549 */       break;
/*      */     case 32:
/*  552 */       if (this.vertexCount % 2 != 0) break label236;
/*  553 */       line(this.vertices[(this.vertexCount - 2)][9], this.vertices[(this.vertexCount - 2)][10], paramFloat1, paramFloat2);
/*      */ 
/*  556 */       break;
/*      */     case 33:
/*      */     case 34:
/*  560 */       if (this.vertexCount == 1) {
/*  561 */         this.path = new Path();
/*  562 */         this.path.moveTo(paramFloat1, paramFloat2); break label280:
/*      */       }
/*  564 */       this.path.lineTo(paramFloat1, paramFloat2);
/*      */ 
/*  566 */       break;
/*      */     case 64:
/*  569 */       if (this.vertexCount % 3 != 0) break label354;
/*  570 */       triangle(this.vertices[(this.vertexCount - 3)][9], this.vertices[(this.vertexCount - 3)][10], this.vertices[(this.vertexCount - 2)][9], this.vertices[(this.vertexCount - 2)][10], paramFloat1, paramFloat2);
/*      */ 
/*  576 */       break;
/*      */     case 65:
/*  579 */       if (this.vertexCount == 3) {
/*  580 */         triangle(this.vertices[0][9], this.vertices[0][10], this.vertices[1][9], this.vertices[1][10], paramFloat1, paramFloat2); break label543:
/*      */       }
/*      */ 
/*  583 */       if (this.vertexCount <= 3) break label543;
/*  584 */       this.path = new Path();
/*      */ 
/*  587 */       this.path.moveTo(this.vertices[(this.vertexCount - 2)][9], this.vertices[(this.vertexCount - 2)][10]);
/*      */ 
/*  589 */       this.path.lineTo(this.vertices[(this.vertexCount - 1)][9], this.vertices[(this.vertexCount - 1)][10]);
/*      */ 
/*  591 */       this.path.lineTo(this.vertices[(this.vertexCount - 3)][9], this.vertices[(this.vertexCount - 3)][10]);
/*      */ 
/*  593 */       draw_shape(this.path);
/*      */ 
/*  595 */       break;
/*      */     case 66:
/*  598 */       if (this.vertexCount == 3) {
/*  599 */         triangle(this.vertices[0][9], this.vertices[0][10], this.vertices[1][9], this.vertices[1][10], paramFloat1, paramFloat2); break label696:
/*      */       }
/*      */ 
/*  602 */       if (this.vertexCount <= 3) break label696;
/*  603 */       this.path = new Path();
/*      */ 
/*  606 */       this.path.moveTo(this.vertices[0][9], this.vertices[0][10]);
/*      */ 
/*  608 */       this.path.lineTo(this.vertices[(this.vertexCount - 2)][9], this.vertices[(this.vertexCount - 2)][10]);
/*      */ 
/*  610 */       this.path.lineTo(paramFloat1, paramFloat2);
/*  611 */       draw_shape(this.path);
/*      */ 
/*  613 */       break;
/*      */     case 128:
/*  616 */       if (this.vertexCount % 4 != 0) break label798;
/*  617 */       quad(this.vertices[(this.vertexCount - 4)][9], this.vertices[(this.vertexCount - 4)][10], this.vertices[(this.vertexCount - 3)][9], this.vertices[(this.vertexCount - 3)][10], this.vertices[(this.vertexCount - 2)][9], this.vertices[(this.vertexCount - 2)][10], paramFloat1, paramFloat2);
/*      */ 
/*  625 */       break;
/*      */     case 129:
/*  631 */       if (this.vertexCount == 4)
/*      */       {
/*  633 */         quad(this.vertices[0][9], this.vertices[0][10], this.vertices[2][9], this.vertices[2][10], paramFloat1, paramFloat2, this.vertices[1][9], this.vertices[1][10]); break label1014:
/*      */       }
/*      */ 
/*  638 */       if (this.vertexCount <= 4) break label1014;
/*  639 */       this.path = new Path();
/*      */ 
/*  642 */       this.path.moveTo(this.vertices[(this.vertexCount - 3)][9], this.vertices[(this.vertexCount - 3)][10]);
/*      */ 
/*  644 */       this.path.lineTo(this.vertices[(this.vertexCount - 1)][9], this.vertices[(this.vertexCount - 1)][10]);
/*      */ 
/*  646 */       this.path.lineTo(paramFloat1, paramFloat2);
/*  647 */       this.path.lineTo(this.vertices[(this.vertexCount - 2)][9], this.vertices[(this.vertexCount - 2)][10]);
/*      */ 
/*  649 */       draw_shape(this.path);
/*      */ 
/*  651 */       break;
/*      */     case 256:
/*  656 */       if (this.vertexCount == 1) {
/*  657 */         label236: label1014: this.path = new Path();
/*  658 */         label280: label354: this.path.moveTo(paramFloat1, paramFloat2); label798: label543: label696: break label1058:
/*      */       }
/*  660 */       this.path.lineTo(paramFloat1, paramFloat2);
/*      */     }
/*      */ 
/*  664 */     label1058:
/*      */   }
/*      */ 
/*      */   public void vertex(float paramFloat1, float paramFloat2, float paramFloat3) {
/*  668 */     depthErrorXYZ("vertex");
/*      */   }
/*      */ 
/*      */   public void vertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/*  673 */     throw new RuntimeException("vertex() with u, v coordinates can only be used with OPENGL or P3D");
/*      */   }
/*      */ 
/*      */   public void vertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5)
/*      */   {
/*  679 */     throw new RuntimeException("vertex() with u, v coordinates can only be used with OPENGL or P3D");
/*      */   }
/*      */ 
/*      */   public void bezierVertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/*      */   }
/*      */ 
/*      */   protected void bezier_vertex(float paramFloat1, float paramFloat2)
/*      */   {
/*  694 */     this.vertexCount = 0;
/*      */ 
/*  696 */     if (this.splineVertices == null) {
/*  697 */       this.splineVertices = new float[128][36];
/*      */     }
/*      */ 
/*  701 */     if (this.splineVertexCount == 128) {
/*  702 */       System.arraycopy(this.splineVertices[125], 0, this.splineVertices[0], 0, 36);
/*      */ 
/*  704 */       System.arraycopy(this.splineVertices[126], 0, this.splineVertices[1], 0, 36);
/*      */ 
/*  706 */       this.splineVertexCount = 3;
/*      */     }
/*  708 */     this.splineVertices[this.splineVertexCount][9] = paramFloat1;
/*  709 */     this.splineVertices[this.splineVertexCount][10] = paramFloat2;
/*  710 */     this.splineVertexCount += 1;
/*      */ 
/*  712 */     switch (this.shape)
/*      */     {
/*      */     case 33:
/*      */     case 34:
/*      */     case 256:
/*  716 */       if (this.splineVertexCount == 1) {
/*  717 */         this.path.moveTo(paramFloat1, paramFloat2); break label245:
/*      */       }
/*  719 */       if (this.splineVertexCount < 4) break label245;
/*  720 */       this.path.curveTo(this.splineVertices[(this.splineVertexCount - 3)][9], this.splineVertices[(this.splineVertexCount - 3)][10], this.splineVertices[(this.splineVertexCount - 2)][9], this.splineVertices[(this.splineVertexCount - 2)][10], paramFloat1, paramFloat2);
/*      */ 
/*  726 */       break;
/*      */     default:
/*  729 */       label245: throw new RuntimeException("bezierVertex() can only be used with LINE_LOOP and POLYGON shapes");
/*      */     }
/*      */   }
/*      */ 
/*      */   public void bezierVertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9)
/*      */   {
/*  738 */     depthErrorXYZ("bezierVertex");
/*      */   }
/*      */ 
/*      */   public void curveVertex(float paramFloat1, float paramFloat2)
/*      */   {
/*      */   }
/*      */ 
/*      */   public void curveVertex(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/*  755 */     depthErrorXYZ("curveVertex");
/*      */   }
/*      */ 
/*      */   public void endShape()
/*      */   {
/*  760 */     this.shape = 0;
/*      */ 
/*  762 */     switch (this.shape)
/*      */     {
/*      */     case 33:
/*  764 */       stroke_shape(this.path);
/*  765 */       break;
/*      */     case 34:
/*  768 */       this.path.closePath();
/*  769 */       stroke_shape(this.path);
/*  770 */       break;
/*      */     case 256:
/*  773 */       this.path.closePath();
/*  774 */       draw_shape(this.path);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void fill_shape(Path paramPath)
/*      */   {
/*      */   }
/*      */ 
/*      */   protected void stroke_shape(Path paramPath)
/*      */   {
/*      */   }
/*      */ 
/*      */   protected void draw_shape(Path paramPath)
/*      */   {
/*      */   }
/*      */ 
/*      */   public void point(float paramFloat1, float paramFloat2)
/*      */   {
/*      */   }
/*      */ 
/*      */   public void point(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/*  827 */     depthErrorXYZ("point");
/*      */   }
/*      */ 
/*      */   public void line(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/*      */   }
/*      */ 
/*      */   public void line(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/*  838 */     depthErrorXYZ("line");
/*      */   }
/*      */ 
/*      */   public void triangle(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/*      */   }
/*      */ 
/*      */   public void quad(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8)
/*      */   {
/*      */   }
/*      */ 
/*      */   public void rectMode(int paramInt)
/*      */   {
/*  861 */     this.rectMode = paramInt;
/*      */   }
/*      */ 
/*      */   public void rect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/*      */     float f1;
/*      */     float f2;
/*  867 */     switch (this.rectMode)
/*      */     {
/*      */     case 1:
/*  869 */       break;
/*      */     case 0:
/*  871 */       paramFloat3 += paramFloat1; paramFloat4 += paramFloat2;
/*  872 */       break;
/*      */     case 2:
/*  874 */       f1 = paramFloat3;
/*  875 */       f2 = paramFloat4;
/*  876 */       paramFloat3 = paramFloat1 + f1;
/*  877 */       paramFloat4 = paramFloat2 + f2;
/*  878 */       paramFloat1 -= f1;
/*  879 */       paramFloat2 -= f2;
/*  880 */       break;
/*      */     case 3:
/*  882 */       f1 = paramFloat3 / 2.0F;
/*  883 */       f2 = paramFloat4 / 2.0F;
/*  884 */       paramFloat3 = paramFloat1 + f1;
/*  885 */       paramFloat4 = paramFloat2 + f2;
/*  886 */       paramFloat1 -= f1;
/*  887 */       paramFloat2 -= f2;
/*      */     }
/*      */     float f3;
/*  890 */     if (paramFloat1 > paramFloat3) {
/*  891 */       f3 = paramFloat1; paramFloat1 = paramFloat3; paramFloat3 = f3;
/*      */     }
/*      */ 
/*  894 */     if (paramFloat2 > paramFloat4) {
/*  895 */       f3 = paramFloat2; paramFloat2 = paramFloat4; paramFloat4 = f3;
/*      */     }
/*      */ 
/*  898 */     rectImpl(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*      */   }
/*      */ 
/*      */   protected void rectImpl(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/*      */   }
/*      */ 
/*      */   public void ellipseMode(int paramInt)
/*      */   {
/*  914 */     this.ellipseMode = paramInt;
/*      */   }
/*      */ 
/*      */   public void ellipse(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/*  919 */     float f1 = paramFloat1;
/*  920 */     float f2 = paramFloat2;
/*  921 */     float f3 = paramFloat3;
/*  922 */     float f4 = paramFloat4;
/*      */ 
/*  924 */     if (this.ellipseMode == 1) {
/*  925 */       f3 = paramFloat3 - paramFloat1;
/*  926 */       f4 = paramFloat4 - paramFloat2;
/*      */     }
/*  928 */     else if (this.ellipseMode == 2) {
/*  929 */       f1 = paramFloat1 - paramFloat3;
/*  930 */       f2 = paramFloat2 - paramFloat4;
/*  931 */       f3 = paramFloat3 * 2.0F;
/*  932 */       f4 = paramFloat4 * 2.0F;
/*      */     }
/*  934 */     else if (this.ellipseMode == 3) {
/*  935 */       f1 = paramFloat1 - (paramFloat3 / 2.0F);
/*  936 */       f2 = paramFloat2 - (paramFloat4 / 2.0F);
/*      */     }
/*      */ 
/*  939 */     if (f3 < 0.0F) {
/*  940 */       f1 += f3;
/*  941 */       f3 = -f3;
/*      */     }
/*      */ 
/*  944 */     if (f4 < 0.0F) {
/*  945 */       f2 += f4;
/*  946 */       f4 = -f4;
/*      */     }
/*      */ 
/*  949 */     ellipseImpl(f1, f2, f3, f4);
/*      */   }
/*      */ 
/*      */   protected void ellipseImpl(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/*      */   }
/*      */ 
/*      */   public void arc(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/*  967 */     float f1 = paramFloat1;
/*  968 */     float f2 = paramFloat2;
/*  969 */     float f3 = paramFloat3;
/*  970 */     float f4 = paramFloat4;
/*      */ 
/*  972 */     if (this.ellipseMode == 1) {
/*  973 */       f3 = paramFloat3 - paramFloat1;
/*  974 */       f4 = paramFloat4 - paramFloat2;
/*      */     }
/*  976 */     else if (this.ellipseMode == 2) {
/*  977 */       f1 = paramFloat1 - paramFloat3;
/*  978 */       f2 = paramFloat2 - paramFloat4;
/*  979 */       f3 = paramFloat3 * 2.0F;
/*  980 */       f4 = paramFloat4 * 2.0F;
/*      */     }
/*  982 */     else if (this.ellipseMode == 3) {
/*  983 */       f1 = paramFloat1 - (paramFloat3 / 2.0F);
/*  984 */       f2 = paramFloat2 - (paramFloat4 / 2.0F);
/*      */     }
/*      */ 
/*  993 */     if ((Float.isInfinite(paramFloat5)) || (Float.isInfinite(paramFloat6))) return;
/*  994 */     for (; paramFloat6 < paramFloat5; paramFloat6 += 6.283186F);
/*  996 */     arcImpl(f1, f2, f3, f4, paramFloat5, paramFloat6);
/*      */   }
/*      */ 
/*      */   protected void arcImpl(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/*      */   }
/*      */ 
/*      */   public void box(float paramFloat)
/*      */   {
/* 1012 */     depthError("box");
/*      */   }
/*      */ 
/*      */   public void box(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 1016 */     depthError("box");
/*      */   }
/*      */ 
/*      */   public void sphereDetail(int paramInt) {
/* 1020 */     depthError("sphereDetail");
/*      */   }
/*      */ 
/*      */   public void sphere(float paramFloat) {
/* 1024 */     depthError("sphere");
/*      */   }
/*      */ 
/*      */   public float bezierPoint(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5)
/*      */   {
/* 1062 */     float f = 1.0F - paramFloat5;
/* 1063 */     return (paramFloat1 * f * f * f + 3 * paramFloat2 * paramFloat5 * f * f + 3 * paramFloat3 * paramFloat5 * paramFloat5 * f + paramFloat4 * paramFloat5 * paramFloat5 * paramFloat5);
/*      */   }
/*      */ 
/*      */   public float bezierTangent(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5)
/*      */   {
/* 1072 */     float f = 1.0F - paramFloat5;
/*      */ 
/* 1074 */     return (paramFloat1 * 3 * paramFloat5 * paramFloat5 + paramFloat2 * 3 * paramFloat5 * (2.0F - (3 * paramFloat5)) + paramFloat3 * 3 * (3 * paramFloat5 * paramFloat5 - (4 * paramFloat5) + 1.0F) + paramFloat4 * -3.0F * f * f);
/*      */   }
/*      */ 
/*      */   public void bezier(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8)
/*      */   {
/* 1108 */     beginShape(33);
/* 1109 */     vertex(paramFloat1, paramFloat2);
/* 1110 */     bezierVertex(paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8);
/* 1111 */     endShape();
/*      */   }
/*      */ 
/*      */   public void bezier(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12)
/*      */   {
/* 1119 */     depthErrorXYZ("bezier");
/*      */   }
/*      */ 
/*      */   protected void bezier_init()
/*      */   {
/* 1124 */     bezierDetail(this.bezier_detail);
/*      */   }
/*      */ 
/*      */   public void bezierDetail(int paramInt)
/*      */   {
/* 1129 */     if (this.bezier_forward == null) {
/* 1130 */       this.bezier_forward = new float[4][4];
/* 1131 */       this.bezier_draw = new float[4][4];
/*      */     }
/* 1133 */     this.bezier_detail = paramInt;
/* 1134 */     this.bezier_inited = true;
/*      */ 
/* 1137 */     setup_spline_forward(paramInt, this.bezier_forward);
/*      */ 
/* 1141 */     mult_spline_matrix(this.bezier_forward, this.bezier_basis, this.bezier_draw, 4);
/*      */   }
/*      */ 
/*      */   protected void curve_init()
/*      */   {
/* 1146 */     curve_mode(this.curve_detail, this.curve_tightness);
/*      */   }
/*      */ 
/*      */   public void curveDetail(int paramInt)
/*      */   {
/* 1151 */     curve_mode(paramInt, this.curve_tightness);
/*      */   }
/*      */ 
/*      */   public void curveTightness(float paramFloat)
/*      */   {
/* 1156 */     curve_mode(this.curve_detail, paramFloat);
/*      */   }
/*      */ 
/*      */   protected void curve_mode(int paramInt, float paramFloat)
/*      */   {
/* 1172 */     this.curve_detail = paramInt;
/*      */ 
/* 1176 */     if (this.curve_basis == null)
/*      */     {
/* 1178 */       this.curve_basis = new float[4][4];
/* 1179 */       this.curve_forward = new float[4][4];
/* 1180 */       this.curve_draw = new float[4][4];
/* 1181 */       this.curve_inited = true;
/*      */     }
/*      */ 
/* 1184 */     float[][] arrayOfFloat = this.curve_basis;
/*      */ 
/* 1186 */     arrayOfFloat[0][0] = (paramFloat - 1.0F); arrayOfFloat[0][1] = (paramFloat + 3); arrayOfFloat[0][2] = (-3.0F - paramFloat); arrayOfFloat[0][3] = (1.0F - paramFloat);
/* 1187 */     arrayOfFloat[1][0] = (2.0F * (1.0F - paramFloat)); arrayOfFloat[1][1] = (-5.0F - paramFloat); arrayOfFloat[1][2] = (2.0F * (paramFloat + 2.0F)); arrayOfFloat[1][3] = (paramFloat - 1.0F);
/* 1188 */     arrayOfFloat[2][0] = (paramFloat - 1.0F); arrayOfFloat[2][1] = 0.0F; arrayOfFloat[2][2] = (1.0F - paramFloat); arrayOfFloat[2][3] = 0.0F;
/* 1189 */     arrayOfFloat[3][0] = 0.0F; arrayOfFloat[3][1] = 2.0F; arrayOfFloat[3][2] = 0.0F; arrayOfFloat[3][3] = 0.0F;
/*      */ 
/* 1191 */     for (int i = 0; i < 4; ++i) {
/* 1192 */       for (int j = 0; j < 4; ++j) {
/* 1193 */         arrayOfFloat[i][j] /= 2.0F;
/*      */       }
/*      */     }
/* 1196 */     setup_spline_forward(paramInt, this.curve_forward);
/*      */ 
/* 1198 */     if (this.bezierBasisInverse == null) {
/* 1199 */       this.bezierBasisInverse = new PMatrix(this.bezierBasis).invert();
/*      */     }
/*      */ 
/* 1203 */     this.curveToBezierMatrix = new PMatrix(arrayOfFloat[0][0], arrayOfFloat[0][1], arrayOfFloat[0][2], arrayOfFloat[0][3], arrayOfFloat[1][0], arrayOfFloat[1][1], arrayOfFloat[1][2], arrayOfFloat[1][3], arrayOfFloat[2][0], arrayOfFloat[2][1], arrayOfFloat[2][2], arrayOfFloat[2][3], arrayOfFloat[3][0], arrayOfFloat[3][1], arrayOfFloat[3][2], arrayOfFloat[3][3]);
/*      */ 
/* 1207 */     this.curveToBezierMatrix.preApply(this.bezierBasisInverse);
/*      */ 
/* 1211 */     mult_spline_matrix(this.curve_forward, this.curve_basis, this.curve_draw, 4);
/*      */   }
/*      */ 
/*      */   public float curvePoint(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5)
/*      */   {
/* 1221 */     if (!(this.curve_inited)) curve_init();
/*      */ 
/* 1223 */     float f1 = paramFloat5 * paramFloat5;
/* 1224 */     float f2 = paramFloat5 * f1;
/* 1225 */     float[][] arrayOfFloat = this.curve_basis;
/*      */ 
/* 1228 */     return (paramFloat1 * (f2 * arrayOfFloat[0][0] + f1 * arrayOfFloat[1][0] + paramFloat5 * arrayOfFloat[2][0] + arrayOfFloat[3][0]) + paramFloat2 * (f2 * arrayOfFloat[0][1] + f1 * arrayOfFloat[1][1] + paramFloat5 * arrayOfFloat[2][1] + arrayOfFloat[3][1]) + paramFloat3 * (f2 * arrayOfFloat[0][2] + f1 * arrayOfFloat[1][2] + paramFloat5 * arrayOfFloat[2][2] + arrayOfFloat[3][2]) + paramFloat4 * (f2 * arrayOfFloat[0][3] + f1 * arrayOfFloat[1][3] + paramFloat5 * arrayOfFloat[2][3] + arrayOfFloat[3][3]));
/*      */   }
/*      */ 
/*      */   public float curveTangent(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5)
/*      */   {
/* 1237 */     System.err.println("curveTangent not yet implemented");
/* 1238 */     return 0.0F;
/*      */   }
/*      */ 
/*      */   public void curve(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8)
/*      */   {
/* 1262 */     beginShape(33);
/* 1263 */     curveVertex(paramFloat1, paramFloat2);
/* 1264 */     curveVertex(paramFloat3, paramFloat4);
/* 1265 */     curveVertex(paramFloat5, paramFloat6);
/* 1266 */     curveVertex(paramFloat7, paramFloat8);
/* 1267 */     endShape();
/*      */   }
/*      */ 
/*      */   public void curve(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12)
/*      */   {
/* 1275 */     depthErrorXYZ("curve");
/*      */   }
/*      */ 
/*      */   protected void setup_spline_forward(int paramInt, float[][] paramArrayOfFloat)
/*      */   {
/* 1288 */     float f1 = 1.0F / paramInt;
/* 1289 */     float f2 = f1 * f1;
/* 1290 */     float f3 = f2 * f1;
/*      */ 
/* 1292 */     paramArrayOfFloat[0][0] = 0.0F; paramArrayOfFloat[0][1] = 0.0F; paramArrayOfFloat[0][2] = 0.0F; paramArrayOfFloat[0][3] = 1.0F;
/* 1293 */     paramArrayOfFloat[1][0] = f3; paramArrayOfFloat[1][1] = f2; paramArrayOfFloat[1][2] = f1; paramArrayOfFloat[1][3] = 0.0F;
/* 1294 */     paramArrayOfFloat[2][0] = (6.0F * f3); paramArrayOfFloat[2][1] = (2.0F * f2); paramArrayOfFloat[2][2] = 0.0F; paramArrayOfFloat[2][3] = 0.0F;
/* 1295 */     paramArrayOfFloat[3][0] = (6.0F * f3); paramArrayOfFloat[3][1] = 0.0F; paramArrayOfFloat[3][2] = 0.0F; paramArrayOfFloat[3][3] = 0.0F;
/*      */   }
/*      */ 
/*      */   protected void mult_spline_matrix(float[][] paramArrayOfFloat1, float[][] paramArrayOfFloat2, float[][] paramArrayOfFloat3, int paramInt)
/*      */   {
/* 1304 */     for (int i = 0; i < 4; ++i) {
/* 1305 */       for (int j = 0; j < paramInt; ++j) {
/* 1306 */         paramArrayOfFloat3[i][j] = 0.0F;
/*      */       }
/*      */     }
/* 1309 */     for (i = 0; i < 4; ++i)
/* 1310 */       for (int k = 0; k < paramInt; ++k)
/* 1311 */         for (int l = 0; l < 4; ++l)
/* 1312 */           paramArrayOfFloat3[i][k] += paramArrayOfFloat1[i][l] * paramArrayOfFloat2[l][k];
/*      */   }
/*      */ 
/*      */   protected void spline2_segment(int paramInt1, int paramInt2, float[][] paramArrayOfFloat, int paramInt3)
/*      */   {
/* 1332 */     float f1 = this.splineVertices[paramInt1][9];
/* 1333 */     float f2 = this.splineVertices[paramInt1][10];
/*      */ 
/* 1335 */     float f3 = this.splineVertices[(paramInt1 + 1)][9];
/* 1336 */     float f4 = this.splineVertices[(paramInt1 + 1)][10];
/*      */ 
/* 1338 */     float f5 = this.splineVertices[(paramInt1 + 2)][9];
/* 1339 */     float f6 = this.splineVertices[(paramInt1 + 2)][10];
/*      */ 
/* 1341 */     float f7 = this.splineVertices[(paramInt1 + 3)][9];
/* 1342 */     float f8 = this.splineVertices[(paramInt1 + 3)][10];
/*      */ 
/* 1344 */     float f9 = this.splineVertices[paramInt2][9];
/* 1345 */     float f10 = this.splineVertices[paramInt2][10];
/*      */ 
/* 1347 */     float f11 = paramArrayOfFloat[1][0] * f1 + paramArrayOfFloat[1][1] * f3 + paramArrayOfFloat[1][2] * f5 + paramArrayOfFloat[1][3] * f7;
/* 1348 */     float f12 = paramArrayOfFloat[2][0] * f1 + paramArrayOfFloat[2][1] * f3 + paramArrayOfFloat[2][2] * f5 + paramArrayOfFloat[2][3] * f7;
/* 1349 */     float f13 = paramArrayOfFloat[3][0] * f1 + paramArrayOfFloat[3][1] * f3 + paramArrayOfFloat[3][2] * f5 + paramArrayOfFloat[3][3] * f7;
/*      */ 
/* 1351 */     float f14 = paramArrayOfFloat[1][0] * f2 + paramArrayOfFloat[1][1] * f4 + paramArrayOfFloat[1][2] * f6 + paramArrayOfFloat[1][3] * f8;
/* 1352 */     float f15 = paramArrayOfFloat[2][0] * f2 + paramArrayOfFloat[2][1] * f4 + paramArrayOfFloat[2][2] * f6 + paramArrayOfFloat[2][3] * f8;
/* 1353 */     float f16 = paramArrayOfFloat[3][0] * f2 + paramArrayOfFloat[3][1] * f4 + paramArrayOfFloat[3][2] * f6 + paramArrayOfFloat[3][3] * f8;
/*      */ 
/* 1356 */     int i = this.splineVertexCount;
/* 1357 */     vertex(f9, f10);
/* 1358 */     for (int j = 0; j < paramInt3; ++j) {
/* 1359 */       f9 += f11; f11 += f12; f12 += f13;
/* 1360 */       f10 += f14; f14 += f15; f15 += f16;
/* 1361 */       vertex(f9, f10);
/*      */     }
/* 1363 */     this.splineVertexCount = i;
/*      */   }
/*      */ 
/*      */   protected void spline3_segment(int paramInt1, int paramInt2, float[][] paramArrayOfFloat, int paramInt3)
/*      */   {
/* 1369 */     float f1 = this.splineVertices[paramInt1][9];
/* 1370 */     float f2 = this.splineVertices[paramInt1][10];
/* 1371 */     float f3 = this.splineVertices[paramInt1][11];
/*      */ 
/* 1373 */     float f4 = this.splineVertices[(paramInt1 + 1)][9];
/* 1374 */     float f5 = this.splineVertices[(paramInt1 + 1)][10];
/* 1375 */     float f6 = this.splineVertices[(paramInt1 + 1)][11];
/*      */ 
/* 1377 */     float f7 = this.splineVertices[(paramInt1 + 2)][9];
/* 1378 */     float f8 = this.splineVertices[(paramInt1 + 2)][10];
/* 1379 */     float f9 = this.splineVertices[(paramInt1 + 2)][11];
/*      */ 
/* 1381 */     float f10 = this.splineVertices[(paramInt1 + 3)][9];
/* 1382 */     float f11 = this.splineVertices[(paramInt1 + 3)][10];
/* 1383 */     float f12 = this.splineVertices[(paramInt1 + 3)][11];
/*      */ 
/* 1385 */     float f13 = this.splineVertices[paramInt2][9];
/* 1386 */     float f14 = this.splineVertices[paramInt2][10];
/* 1387 */     float f15 = this.splineVertices[paramInt2][11];
/*      */ 
/* 1389 */     float f16 = paramArrayOfFloat[1][0] * f1 + paramArrayOfFloat[1][1] * f4 + paramArrayOfFloat[1][2] * f7 + paramArrayOfFloat[1][3] * f10;
/* 1390 */     float f17 = paramArrayOfFloat[2][0] * f1 + paramArrayOfFloat[2][1] * f4 + paramArrayOfFloat[2][2] * f7 + paramArrayOfFloat[2][3] * f10;
/* 1391 */     float f18 = paramArrayOfFloat[3][0] * f1 + paramArrayOfFloat[3][1] * f4 + paramArrayOfFloat[3][2] * f7 + paramArrayOfFloat[3][3] * f10;
/*      */ 
/* 1393 */     float f19 = paramArrayOfFloat[1][0] * f2 + paramArrayOfFloat[1][1] * f5 + paramArrayOfFloat[1][2] * f8 + paramArrayOfFloat[1][3] * f11;
/* 1394 */     float f20 = paramArrayOfFloat[2][0] * f2 + paramArrayOfFloat[2][1] * f5 + paramArrayOfFloat[2][2] * f8 + paramArrayOfFloat[2][3] * f11;
/* 1395 */     float f21 = paramArrayOfFloat[3][0] * f2 + paramArrayOfFloat[3][1] * f5 + paramArrayOfFloat[3][2] * f8 + paramArrayOfFloat[3][3] * f11;
/*      */ 
/* 1397 */     float f22 = paramArrayOfFloat[1][0] * f3 + paramArrayOfFloat[1][1] * f6 + paramArrayOfFloat[1][2] * f9 + paramArrayOfFloat[1][3] * f12;
/* 1398 */     float f23 = paramArrayOfFloat[2][0] * f3 + paramArrayOfFloat[2][1] * f6 + paramArrayOfFloat[2][2] * f9 + paramArrayOfFloat[2][3] * f12;
/* 1399 */     float f24 = paramArrayOfFloat[3][0] * f3 + paramArrayOfFloat[3][1] * f6 + paramArrayOfFloat[3][2] * f9 + paramArrayOfFloat[3][3] * f12;
/*      */ 
/* 1402 */     int i = this.splineVertexCount;
/* 1403 */     vertex(f13, f14, f15);
/* 1404 */     for (int j = 0; j < paramInt3; ++j) {
/* 1405 */       f13 += f16; f16 += f17; f17 += f18;
/* 1406 */       f14 += f19; f19 += f20; f20 += f21;
/* 1407 */       f15 += f22; f22 += f23; f23 += f24;
/* 1408 */       vertex(f13, f14, f15);
/*      */     }
/* 1410 */     this.splineVertexCount = i;
/*      */   }
/*      */ 
/*      */   public void image(PImage paramPImage, float paramFloat1, float paramFloat2)
/*      */   {
/* 1421 */     imageImpl(paramPImage, paramFloat1, paramFloat2, paramFloat1 + paramPImage.width, paramFloat2 + paramPImage.height, 0, 0, paramPImage.width, paramPImage.height);
/*      */   }
/*      */ 
/*      */   public void image(PImage paramPImage, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 1429 */     image(paramPImage, paramFloat1, paramFloat2, paramFloat3, paramFloat4, 0, 0, paramPImage.width, paramPImage.height);
/*      */   }
/*      */ 
/*      */   public void image(PImage paramPImage, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*      */   {
/* 1440 */     if (this.imageMode == 0) {
/* 1441 */       if (paramFloat3 < 0.0F) {
/* 1442 */         paramFloat1 += paramFloat3; paramFloat3 = -paramFloat3;
/*      */       }
/* 1444 */       if (paramFloat4 < 0.0F) {
/* 1445 */         paramFloat2 += paramFloat4; paramFloat4 = -paramFloat4;
/*      */       }
/*      */ 
/* 1448 */       imageImpl(paramPImage, paramFloat1, paramFloat2, paramFloat1 + paramFloat3, paramFloat2 + paramFloat4, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */     }
/* 1452 */     else if (this.imageMode == 1)
/*      */     {
/*      */       float f;
/* 1453 */       if (paramFloat3 < paramFloat1) {
/* 1454 */         f = paramFloat1; paramFloat1 = paramFloat3; paramFloat3 = f;
/*      */       }
/* 1456 */       if (paramFloat4 < paramFloat2) {
/* 1457 */         f = paramFloat2; paramFloat2 = paramFloat4; paramFloat4 = f;
/*      */       }
/*      */ 
/* 1460 */       imageImpl(paramPImage, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void imageImpl(PImage paramPImage, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*      */   {
/* 1475 */     System.err.println("unimplemented imageImpl() in PGraphics");
/*      */   }
/*      */ 
/*      */   public void textFont(PFont paramPFont, float paramFloat)
/*      */   {
/* 1489 */     textFont(paramPFont);
/* 1490 */     textSize(paramFloat);
/*      */   }
/*      */ 
/*      */   public void textFont(PFont paramPFont)
/*      */   {
/* 1500 */     if (paramPFont != null) {
/* 1501 */       this.textFont = paramPFont;
/* 1502 */       textSize(this.textFont.size);
/*      */     }
/*      */     else {
/* 1505 */       throw new RuntimeException("a null PFont was passed to textFont()");
/*      */     }
/*      */   }
/*      */ 
/*      */   public void textSize(float paramFloat)
/*      */   {
/* 1514 */     if (this.textFont != null) {
/* 1515 */       if ((this.textMode == 128) && (paramFloat != this.textFont.size))
/*      */       {
/* 1517 */         throw new RuntimeException("can't use textSize() with textMode(SCREEN)");
/*      */       }
/*      */ 
/* 1520 */       this.textSize = paramFloat;
/* 1521 */       this.textLeading = (this.textSize * (this.textFont.ascent() + this.textFont.descent()) * 1.275F);
/*      */     }
/*      */     else
/*      */     {
/* 1525 */       throw new RuntimeException("use textFont() before textSize()");
/*      */     }
/*      */   }
/*      */ 
/*      */   public void textLeading(float paramFloat)
/*      */   {
/* 1534 */     this.textLeading = paramFloat;
/*      */   }
/*      */ 
/*      */   public void textAlign(int paramInt)
/*      */   {
/* 1542 */     this.textAlign = paramInt;
/*      */   }
/*      */ 
/*      */   public void textMode(int paramInt)
/*      */   {
/* 1554 */     if ((paramInt != 128) && (paramInt != 3)) {
/* 1555 */       throw new RuntimeException("Only textMode(SCREEN) or textMode(MODEL) can be used. Maybe you meant textAlign()?");
/*      */     }
/*      */ 
/* 1559 */     if (this.textFont != null) {
/* 1560 */       this.textMode = paramInt;
/*      */ 
/* 1564 */       if (this.textMode == 128)
/* 1565 */         textSize(this.textFont.size);
/*      */     }
/*      */     else
/*      */     {
/* 1569 */       throw new RuntimeException("use textFont() before textMode()");
/*      */     }
/*      */   }
/*      */ 
/*      */   public float textAscent()
/*      */   {
/* 1575 */     if (this.textFont != null) {
/* 1576 */       return (this.textFont.ascent() * this.textSize);
/*      */     }
/*      */ 
/* 1579 */     throw new RuntimeException("use textFont() before textAscent()");
/*      */   }
/*      */ 
/*      */   public float textDescent()
/*      */   {
/* 1585 */     if (this.textFont != null) {
/* 1586 */       return (this.textFont.descent() * this.textSize);
/*      */     }
/*      */ 
/* 1589 */     throw new RuntimeException("use textFont() before textDescent()");
/*      */   }
/*      */ 
/*      */   public float textWidth(char paramChar)
/*      */   {
/* 1595 */     if (this.textFont != null) {
/* 1596 */       return (this.textFont.width(paramChar) * this.textSize);
/*      */     }
/*      */ 
/* 1599 */     throw new RuntimeException("use textFont() before textWidth()");
/*      */   }
/*      */ 
/*      */   public float textWidth(String paramString)
/*      */   {
/* 1609 */     if (this.textFont != null) {
/* 1610 */       return (this.textFont.width(paramString) * this.textSize);
/*      */     }
/*      */ 
/* 1613 */     throw new RuntimeException("use textFont() before textWidth()");
/*      */   }
/*      */ 
/*      */   public void text(char paramChar, float paramFloat1, float paramFloat2)
/*      */   {
/* 1619 */     text(paramChar, paramFloat1, paramFloat2, 0.0F);
/*      */   }
/*      */ 
/*      */   public void text(char paramChar, float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 1629 */     if ((paramFloat3 != 0.0F) && (this.textMode == 128)) {
/* 1630 */       String str = "textMode(SCREEN) cannot have a z coordinate";
/* 1631 */       throw new RuntimeException(str);
/*      */     }
/*      */ 
/* 1636 */     if (this.textFont != null) {
/* 1637 */       if (this.textMode == 128) loadPixels();
/* 1638 */       this.textFont.text(paramChar, paramFloat1, paramFloat2, paramFloat3, this);
/* 1639 */       if (this.textMode == 128) updatePixels();
/*      */     }
/*      */     else {
/* 1642 */       throw new RuntimeException("use textFont() before text()");
/*      */     }
/*      */   }
/*      */ 
/*      */   public void text(String paramString, float paramFloat1, float paramFloat2)
/*      */   {
/* 1648 */     text(paramString, paramFloat1, paramFloat2, 0.0F);
/*      */   }
/*      */ 
/*      */   public void text(String paramString, float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 1663 */     if ((paramFloat3 != 0.0F) && (this.textMode == 128)) {
/* 1664 */       String str = "textMode(SCREEN) cannot have a z coordinate";
/* 1665 */       throw new RuntimeException(str);
/*      */     }
/*      */ 
/* 1670 */     if (this.textFont != null) {
/* 1671 */       if (this.textMode == 128) loadPixels();
/* 1672 */       this.textFont.text(paramString, paramFloat1, paramFloat2, paramFloat3, this);
/* 1673 */       if (this.textMode == 128) updatePixels();
/*      */     }
/*      */     else {
/* 1676 */       throw new RuntimeException("use textFont() before text()");
/*      */     }
/*      */   }
/*      */ 
/*      */   public void text(String paramString, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 1695 */     text(paramString, paramFloat1, paramFloat2, paramFloat3, paramFloat4, 0.0F);
/*      */   }
/*      */ 
/*      */   public void text(String paramString, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5)
/*      */   {
/* 1700 */     if (this.textFont != null)
/*      */     {
/*      */       float f1;
/*      */       float f2;
/* 1702 */       switch (this.rectMode)
/*      */       {
/*      */       case 0:
/* 1704 */         paramFloat3 += paramFloat1; paramFloat4 += paramFloat2;
/* 1705 */         break;
/*      */       case 2:
/* 1707 */         f1 = paramFloat3;
/* 1708 */         f2 = paramFloat4;
/* 1709 */         paramFloat3 = paramFloat1 + f1;
/* 1710 */         paramFloat4 = paramFloat2 + f2;
/* 1711 */         paramFloat1 -= f1;
/* 1712 */         paramFloat2 -= f2;
/* 1713 */         break;
/*      */       case 3:
/* 1715 */         f1 = paramFloat3 / 2.0F;
/* 1716 */         f2 = paramFloat4 / 2.0F;
/* 1717 */         paramFloat3 = paramFloat1 + f1;
/* 1718 */         paramFloat4 = paramFloat2 + f2;
/* 1719 */         paramFloat1 -= f1;
/* 1720 */         paramFloat2 -= f2;
/*      */       case 1:
/*      */       }
/*      */       float f3;
/* 1722 */       if (paramFloat3 < paramFloat1) {
/* 1723 */         f3 = paramFloat1; paramFloat1 = paramFloat3; paramFloat3 = f3;
/*      */       }
/* 1725 */       if (paramFloat4 < paramFloat2) {
/* 1726 */         f3 = paramFloat2; paramFloat2 = paramFloat4; paramFloat4 = f3;
/*      */       }
/* 1728 */       if (this.textMode == 128) loadPixels();
/* 1729 */       this.textFont.text(paramString, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, this);
/* 1730 */       if (this.textMode == 128) updatePixels();
/*      */     }
/*      */     else {
/* 1733 */       throw new RuntimeException("use textFont() before text()");
/*      */     }
/*      */   }
/*      */ 
/*      */   public void text(int paramInt, float paramFloat1, float paramFloat2)
/*      */   {
/* 1739 */     text(String.valueOf(paramInt), paramFloat1, paramFloat2);
/*      */   }
/*      */ 
/*      */   public void text(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 1744 */     text(String.valueOf(paramInt), paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public void text(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 1756 */     text(PApplet.nfs(paramFloat1, 0, 3), paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public void text(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/*      */   }
/*      */ 
/*      */   protected void textImpl(char paramChar, float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 1768 */     int i = this.textFont.index(paramChar);
/* 1769 */     if (i == -1) return;
/*      */ 
/* 1771 */     PImage localPImage = this.textFont.images[i];
/*      */ 
/* 1773 */     if (this.textMode == 3) {
/* 1774 */       float f1 = this.textFont.height[i] / this.textFont.fheight;
/* 1775 */       float f2 = this.textFont.width[i] / this.textFont.fwidth;
/* 1776 */       float f3 = this.textFont.leftExtent[i] / this.textFont.fwidth;
/* 1777 */       float f4 = this.textFont.topExtent[i] / this.textFont.fheight;
/*      */ 
/* 1779 */       float f5 = paramFloat1 + f3 * this.textSize;
/* 1780 */       float f6 = paramFloat2 - (f4 * this.textSize);
/* 1781 */       float f7 = f5 + f2 * this.textSize;
/* 1782 */       float f8 = f6 + f1 * this.textSize;
/*      */ 
/* 1784 */       textImplObject(localPImage, f5, f6, paramFloat3, f7, f8, paramFloat3, this.textFont.width[i], this.textFont.height[i]);
/*      */     }
/* 1788 */     else if (this.textMode == 128) {
/* 1789 */       int j = (int)paramFloat1 + this.textFont.leftExtent[i];
/* 1790 */       int k = (int)paramFloat2 - this.textFont.topExtent[i];
/*      */ 
/* 1792 */       int l = this.textFont.width[i];
/* 1793 */       int i1 = this.textFont.height[i];
/*      */ 
/* 1795 */       textImplScreen(localPImage, j, k, l, i1);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void textImplObject(PImage paramPImage, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, int paramInt1, int paramInt2)
/*      */   {
/* 1804 */     boolean bool1 = this.tint;
/* 1805 */     int i = this.tintColor;
/* 1806 */     float f1 = this.tintR;
/* 1807 */     float f2 = this.tintG;
/* 1808 */     float f3 = this.tintB;
/* 1809 */     float f4 = this.tintA;
/* 1810 */     boolean bool2 = this.tintAlpha;
/*      */ 
/* 1812 */     this.tint = true;
/* 1813 */     this.tintColor = this.fillColor;
/* 1814 */     this.tintR = this.fillR;
/* 1815 */     this.tintG = this.fillG;
/* 1816 */     this.tintB = this.fillB;
/* 1817 */     this.tintA = this.fillA;
/* 1818 */     this.tintAlpha = this.fillAlpha;
/*      */ 
/* 1820 */     imageImpl(paramPImage, paramFloat1, paramFloat2, paramFloat4, paramFloat5, 0, 0, paramInt1, paramInt2);
/*      */ 
/* 1822 */     this.tint = bool1;
/* 1823 */     this.tintColor = i;
/* 1824 */     this.tintR = f1;
/* 1825 */     this.tintG = f2;
/* 1826 */     this.tintB = f3;
/* 1827 */     this.tintA = f4;
/* 1828 */     this.tintAlpha = bool2;
/*      */   }
/*      */ 
/*      */   protected void textImplScreen(PImage paramPImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*      */   {
/* 1844 */     int i = 0;
/* 1845 */     int j = 0;
/*      */ 
/* 1847 */     if ((paramInt1 >= this.width) || (paramInt2 >= this.height) || (paramInt1 + paramInt3 < 0) || (paramInt2 + paramInt4 < 0)) {
/* 1848 */       return;
/*      */     }
/* 1850 */     if (paramInt1 < 0) {
/* 1851 */       i -= paramInt1;
/* 1852 */       paramInt3 += paramInt1;
/* 1853 */       paramInt1 = 0;
/*      */     }
/* 1855 */     if (paramInt2 < 0) {
/* 1856 */       j -= paramInt2;
/* 1857 */       paramInt4 += paramInt2;
/* 1858 */       paramInt2 = 0;
/*      */     }
/* 1860 */     if (paramInt1 + paramInt3 > this.width) {
/* 1861 */       paramInt3 -= paramInt1 + paramInt3 - this.width;
/*      */     }
/* 1863 */     if (paramInt2 + paramInt4 > this.height) {
/* 1864 */       paramInt4 -= paramInt2 + paramInt4 - this.height;
/*      */     }
/*      */ 
/* 1867 */     int k = this.fillRi;
/* 1868 */     int l = this.fillGi;
/* 1869 */     int i1 = this.fillBi;
/* 1870 */     int i2 = this.fillAi;
/*      */ 
/* 1872 */     int[] arrayOfInt = paramPImage.pixels;
/*      */ 
/* 1875 */     for (int i3 = j; i3 < j + paramInt4; ++i3)
/* 1876 */       for (int i4 = i; i4 < i + paramInt3; ++i4) {
/* 1877 */         int i5 = i2 * arrayOfInt[(i3 * this.textFont.twidth + i4)] >> 8;
/* 1878 */         int i6 = i5 ^ 0xFF;
/*      */ 
/* 1880 */         int i7 = arrayOfInt[(i3 * paramPImage.width + i4)];
/* 1881 */         int i8 = this.pixels[((paramInt2 + i3 - j) * this.width + paramInt1 + i4 - i)];
/*      */ 
/* 1883 */         this.pixels[((paramInt2 + i3 - j) * this.width + paramInt1 + i4 - i)] = (0xFF000000 | (i5 * k + i6 * (i8 >> 16 & 0xFF) & 0xFF00) << 8 | i5 * l + i6 * (i8 >> 8 & 0xFF) & 0xFF00 | i5 * i1 + i6 * (i8 & 0xFF) >> 8);
/*      */       }
/*      */   }
/*      */ 
/*      */   public void translate(float paramFloat1, float paramFloat2)
/*      */   {
/* 1900 */     this.m02 += paramFloat1 * this.m00 + paramFloat2 * this.m01 + this.m02;
/* 1901 */     this.m12 += paramFloat1 * this.m10 + paramFloat2 * this.m11 + this.m12;
/*      */   }
/*      */ 
/*      */   public void translate(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 1906 */     depthErrorXYZ("translate");
/*      */   }
/*      */ 
/*      */   public void rotate(float paramFloat)
/*      */   {
/* 1917 */     float f1 = (float)Math.cos(paramFloat);
/* 1918 */     float f2 = (float)Math.sin(paramFloat);
/*      */ 
/* 1920 */     applyMatrix(f1, -f2, 0.0F, f2, f1, 0.0F);
/*      */   }
/*      */ 
/*      */   public void rotateX(float paramFloat)
/*      */   {
/* 1925 */     depthError("rotateX");
/*      */   }
/*      */ 
/*      */   public void rotateY(float paramFloat) {
/* 1929 */     depthError("rotateY");
/*      */   }
/*      */ 
/*      */   public void rotateZ(float paramFloat) {
/* 1933 */     depthError("rotateZ");
/*      */   }
/*      */ 
/*      */   public void rotate(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 1938 */     throw new RuntimeException("rotate(angle, x, y, z) can only be used with P3D or OPENGL");
/*      */   }
/*      */ 
/*      */   public void scale(float paramFloat)
/*      */   {
/* 1948 */     applyMatrix(paramFloat, 0.0F, 0.0F, 0.0F, paramFloat, 0.0F);
/*      */   }
/*      */ 
/*      */   public void scale(float paramFloat1, float paramFloat2)
/*      */   {
/* 1954 */     applyMatrix(paramFloat1, 0.0F, 0.0F, 0.0F, paramFloat2, 0.0F);
/*      */   }
/*      */ 
/*      */   public void scale(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 1960 */     depthErrorXYZ("scale");
/*      */   }
/*      */ 
/*      */   public void pushMatrix()
/*      */   {
/* 1971 */     if (this.matrixStackDepth + 1 == 32) {
/* 1972 */       throw new RuntimeException("too many calls to pushMatrix()");
/*      */     }
/* 1974 */     float[] arrayOfFloat = this.matrixStack[this.matrixStackDepth];
/* 1975 */     arrayOfFloat[0] = this.m00; arrayOfFloat[1] = this.m01; arrayOfFloat[2] = this.m02;
/* 1976 */     arrayOfFloat[3] = this.m10; arrayOfFloat[4] = this.m11; arrayOfFloat[5] = this.m12;
/* 1977 */     this.matrixStackDepth += 1;
/*      */   }
/*      */ 
/*      */   public void popMatrix()
/*      */   {
/* 1982 */     if (this.matrixStackDepth == 0) {
/* 1983 */       throw new RuntimeException("too many calls to popMatrix() (and not enough to pushMatrix)");
/*      */     }
/*      */ 
/* 1986 */     this.matrixStackDepth -= 1;
/* 1987 */     float[] arrayOfFloat = this.matrixStack[this.matrixStackDepth];
/* 1988 */     this.m00 = arrayOfFloat[0]; this.m01 = arrayOfFloat[1]; this.m02 = arrayOfFloat[2];
/* 1989 */     this.m10 = arrayOfFloat[3]; this.m11 = arrayOfFloat[4]; this.m12 = arrayOfFloat[5];
/*      */   }
/*      */ 
/*      */   public void resetMatrix()
/*      */   {
/* 1998 */     this.m00 = 1.0F; this.m01 = 0.0F; this.m02 = 0.0F;
/* 1999 */     this.m10 = 0.0F; this.m11 = 1.0F; this.m12 = 0.0F;
/*      */   }
/*      */ 
/*      */   public void applyMatrix(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/* 2009 */     float f1 = this.m00 * paramFloat1 + this.m01 * paramFloat4;
/* 2010 */     float f2 = this.m00 * paramFloat2 + this.m01 * paramFloat5;
/* 2011 */     float f3 = this.m00 * paramFloat3 + this.m01 * paramFloat6 + this.m02;
/*      */ 
/* 2013 */     float f4 = this.m10 * paramFloat1 + this.m11 * paramFloat4;
/* 2014 */     float f5 = this.m10 * paramFloat2 + this.m11 * paramFloat5;
/* 2015 */     float f6 = this.m10 * paramFloat3 + this.m11 * paramFloat6 + this.m12;
/*      */ 
/* 2017 */     this.m00 = f1; this.m01 = f2; this.m02 = f3;
/* 2018 */     this.m10 = f4; this.m11 = f5; this.m12 = f6;
/*      */   }
/*      */ 
/*      */   public void applyMatrix(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12, float paramFloat13, float paramFloat14, float paramFloat15, float paramFloat16)
/*      */   {
/* 2026 */     throw new RuntimeException("applyMatrix() with a 4x4 matrix can only be used with OPENGL or P3D");
/*      */   }
/*      */ 
/*      */   public void printMatrix()
/*      */   {
/* 2035 */     float f = Math.abs(this.m00);
/* 2036 */     if (Math.abs(this.m01) > f) f = Math.abs(this.m01);
/* 2037 */     if (Math.abs(this.m02) > f) f = Math.abs(this.m02);
/* 2038 */     if (Math.abs(this.m10) > f) f = Math.abs(this.m10);
/* 2039 */     if (Math.abs(this.m11) > f) f = Math.abs(this.m11);
/* 2040 */     if (Math.abs(this.m12) > f) f = Math.abs(this.m12);
/*      */ 
/* 2043 */     if ((Float.isNaN(f)) || (Float.isInfinite(f))) {
/* 2044 */       f = 1000000.0F;
/*      */     }
/*      */ 
/* 2047 */     int i = 1;
/* 2048 */     int j = (int)f;
/* 2049 */     for (; j /= 10 != 0; ++i);
/* 2051 */     System.out.println(PApplet.nfs(this.m00, i, 4) + ' ' + PApplet.nfs(this.m01, i, 4) + ' ' + PApplet.nfs(this.m02, i, 4));
/*      */ 
/* 2055 */     System.out.println(PApplet.nfs(this.m10, i, 4) + ' ' + PApplet.nfs(this.m11, i, 4) + ' ' + PApplet.nfs(this.m12, i, 4));
/*      */ 
/* 2059 */     System.out.println();
/*      */   }
/*      */ 
/*      */   public void cameraMode(int paramInt)
/*      */   {
/* 2070 */     depthError("cameraMode");
/*      */   }
/*      */ 
/*      */   public void beginCamera() {
/* 2074 */     depthError("beginCamera");
/*      */   }
/*      */ 
/*      */   public void endCamera() {
/* 2078 */     depthError("endCamera");
/*      */   }
/*      */ 
/*      */   public void camera() {
/* 2082 */     depthError("camera");
/*      */   }
/*      */ 
/*      */   public void camera(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9)
/*      */   {
/* 2088 */     depthError("camera");
/*      */   }
/*      */ 
/*      */   public void ortho() {
/* 2092 */     depthError("ortho");
/*      */   }
/*      */ 
/*      */   public void ortho(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/* 2098 */     depthError("ortho");
/*      */   }
/*      */ 
/*      */   public void perspective() {
/* 2102 */     depthError("perspective");
/*      */   }
/*      */ 
/*      */   public void perspective(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 2106 */     depthError("perspective");
/*      */   }
/*      */ 
/*      */   public void frustum(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/* 2111 */     depthError("frustum");
/*      */   }
/*      */ 
/*      */   public void printCamera() {
/* 2115 */     depthError("printCamera");
/*      */   }
/*      */ 
/*      */   public void printProjection() {
/* 2119 */     depthError("printCamera");
/*      */   }
/*      */ 
/*      */   public float screenX(float paramFloat1, float paramFloat2)
/*      */   {
/* 2135 */     return (this.m00 * paramFloat1 + this.m01 * paramFloat2 + this.m02);
/*      */   }
/*      */ 
/*      */   public float screenY(float paramFloat1, float paramFloat2)
/*      */   {
/* 2145 */     return (this.m10 * paramFloat1 + this.m11 * paramFloat2 + this.m12);
/*      */   }
/*      */ 
/*      */   public float screenX(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 2157 */     depthErrorXYZ("screenX");
/* 2158 */     return 0.0F;
/*      */   }
/*      */ 
/*      */   public float screenY(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 2170 */     depthErrorXYZ("screenY");
/* 2171 */     return 0.0F;
/*      */   }
/*      */ 
/*      */   public float screenZ(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 2187 */     depthErrorXYZ("screenZ");
/* 2188 */     return 0.0F;
/*      */   }
/*      */ 
/*      */   public float modelX(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 2202 */     depthError("modelX");
/* 2203 */     return 0.0F;
/*      */   }
/*      */ 
/*      */   public float modelY(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 2211 */     depthError("modelY");
/* 2212 */     return 0.0F;
/*      */   }
/*      */ 
/*      */   public float modelZ(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 2220 */     depthError("modelZ");
/* 2221 */     return 0.0F;
/*      */   }
/*      */ 
/*      */   public void colorMode(int paramInt)
/*      */   {
/* 2232 */     colorMode(paramInt, this.colorModeX, this.colorModeY, this.colorModeZ, this.colorModeA);
/*      */   }
/*      */ 
/*      */   public void colorMode(int paramInt, float paramFloat)
/*      */   {
/* 2237 */     colorMode(paramInt, paramFloat, paramFloat, paramFloat, paramFloat);
/*      */   }
/*      */ 
/*      */   public void colorMode(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 2252 */     colorMode(paramInt, paramFloat1, paramFloat2, paramFloat3, this.colorModeA);
/*      */   }
/*      */ 
/*      */   public void colorMode(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 2258 */     this.colorMode = paramInt;
/*      */ 
/* 2260 */     this.colorModeX = paramFloat1;
/* 2261 */     this.colorModeY = paramFloat2;
/* 2262 */     this.colorModeZ = paramFloat3;
/* 2263 */     this.colorModeA = paramFloat4;
/*      */ 
/* 2266 */     if ((paramFloat4 != 1.0F) || (paramFloat1 != paramFloat2) || (paramFloat2 != paramFloat3) || (paramFloat3 != paramFloat4)) 0; this.colorScale = true;
/*      */ 
/* 2271 */     if ((this.colorMode == 1) && (this.colorModeA == 255.0F) && (this.colorModeX == 255.0F) && (this.colorModeY == 255.0F) && (this.colorModeZ == 255.0F)) 0; this.colorRgb255 = true;
/*      */   }
/*      */ 
/*      */   protected void colorCalc(float paramFloat)
/*      */   {
/* 2281 */     colorCalc(paramFloat, this.colorModeA);
/*      */   }
/*      */ 
/*      */   protected void colorCalc(float paramFloat1, float paramFloat2)
/*      */   {
/* 2286 */     if (paramFloat1 > this.colorModeX) paramFloat1 = this.colorModeX;
/* 2287 */     if (paramFloat2 > this.colorModeA) paramFloat2 = this.colorModeA;
/*      */ 
/* 2289 */     if (paramFloat1 < 0.0F) paramFloat1 = 0.0F;
/* 2290 */     if (paramFloat2 < 0.0F) paramFloat2 = 0.0F;
/*      */ 
/* 2292 */     this.calcR = ((this.colorScale) ? paramFloat1 / this.colorModeX : paramFloat1);
/* 2293 */     this.calcG = this.calcR;
/* 2294 */     this.calcB = this.calcR;
/* 2295 */     this.calcA = ((this.colorScale) ? paramFloat2 / this.colorModeA : paramFloat2);
/*      */ 
/* 2297 */     this.calcRi = (int)(this.calcR * 255.0F); this.calcGi = (int)(this.calcG * 255.0F);
/* 2298 */     this.calcBi = (int)(this.calcB * 255.0F); this.calcAi = (int)(this.calcA * 255.0F);
/* 2299 */     this.calcColor = (this.calcAi << 24 | this.calcRi << 16 | this.calcGi << 8 | this.calcBi);
/* 2300 */     if (this.calcAi != 255) 0; this.calcAlpha = true;
/*      */   }
/*      */ 
/*      */   protected void colorCalc(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 2305 */     colorCalc(paramFloat1, paramFloat2, paramFloat3, this.colorModeA);
/*      */   }
/*      */ 
/*      */   protected void colorCalc(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 2310 */     if (paramFloat1 > this.colorModeX) paramFloat1 = this.colorModeX;
/* 2311 */     if (paramFloat2 > this.colorModeY) paramFloat2 = this.colorModeY;
/* 2312 */     if (paramFloat3 > this.colorModeZ) paramFloat3 = this.colorModeZ;
/* 2313 */     if (paramFloat4 > this.colorModeA) paramFloat4 = this.colorModeA;
/*      */ 
/* 2315 */     if (paramFloat1 < 0.0F) paramFloat1 = 0.0F;
/* 2316 */     if (paramFloat2 < 0.0F) paramFloat2 = 0.0F;
/* 2317 */     if (paramFloat3 < 0.0F) paramFloat3 = 0.0F;
/* 2318 */     if (paramFloat4 < 0.0F) paramFloat4 = 0.0F;
/*      */ 
/* 2320 */     switch (this.colorMode)
/*      */     {
/*      */     case 1:
/* 2322 */       if (this.colorScale) {
/* 2323 */         this.calcR = (paramFloat1 / this.colorModeX);
/* 2324 */         this.calcG = (paramFloat2 / this.colorModeY);
/* 2325 */         this.calcB = (paramFloat3 / this.colorModeZ);
/* 2326 */         this.calcA = (paramFloat4 / this.colorModeA);
/*      */       } else {
/* 2328 */         this.calcR = paramFloat1; this.calcG = paramFloat2; this.calcB = paramFloat3; this.calcA = paramFloat4;
/*      */       }
/* 2330 */       break;
/*      */     case 3:
/* 2333 */       paramFloat1 /= this.colorModeX;
/* 2334 */       paramFloat2 /= this.colorModeY;
/* 2335 */       paramFloat3 /= this.colorModeZ;
/*      */ 
/* 2337 */       this.calcA = ((this.colorScale) ? paramFloat4 / this.colorModeA : paramFloat4);
/*      */ 
/* 2339 */       if (paramFloat2 == 0.0F) {
/* 2340 */         this.calcR = (this.calcG = this.calcB = paramFloat3);
/*      */       }
/*      */       else {
/* 2343 */         float f1 = (paramFloat1 - (int)paramFloat1) * 6.0F;
/* 2344 */         float f2 = f1 - (int)f1;
/* 2345 */         float f3 = paramFloat3 * (1.0F - paramFloat2);
/* 2346 */         float f4 = paramFloat3 * (1.0F - (paramFloat2 * f2));
/* 2347 */         float f5 = paramFloat3 * (1.0F - (paramFloat2 * (1.0F - f2)));
/*      */ 
/* 2349 */         switch ((int)f1)
/*      */         {
/*      */         case 0:
/* 2350 */           this.calcR = paramFloat3; this.calcG = f5; this.calcB = f3; break;
/*      */         case 1:
/* 2351 */           this.calcR = f4; this.calcG = paramFloat3; this.calcB = f3; break;
/*      */         case 2:
/* 2352 */           this.calcR = f3; this.calcG = paramFloat3; this.calcB = f5; break;
/*      */         case 3:
/* 2353 */           this.calcR = f3; this.calcG = f4; this.calcB = paramFloat3; break;
/*      */         case 4:
/* 2354 */           this.calcR = f5; this.calcG = f3; this.calcB = paramFloat3; break;
/*      */         case 5:
/* 2355 */           this.calcR = paramFloat3; this.calcG = f3; this.calcB = f4;
/*      */         }
/*      */       }
/*      */     case 2:
/*      */     }
/* 2360 */     this.calcRi = (int)(255.0F * this.calcR); this.calcGi = (int)(255.0F * this.calcG);
/* 2361 */     this.calcBi = (int)(255.0F * this.calcB); this.calcAi = (int)(255.0F * this.calcA);
/* 2362 */     this.calcColor = (this.calcAi << 24 | this.calcRi << 16 | this.calcGi << 8 | this.calcBi);
/* 2363 */     if (this.calcAi != 255) 0; this.calcAlpha = true;
/*      */   }
/*      */ 
/*      */   protected void colorFrom(int paramInt)
/*      */   {
/* 2379 */     this.calcColor = paramInt;
/* 2380 */     this.calcAi = (paramInt >> 24 & 0xFF);
/* 2381 */     this.calcRi = (paramInt >> 16 & 0xFF);
/* 2382 */     this.calcGi = (paramInt >> 8 & 0xFF);
/* 2383 */     this.calcBi = (paramInt & 0xFF);
/* 2384 */     this.calcA = (this.calcAi / 255.0F);
/* 2385 */     this.calcR = (this.calcRi / 255.0F);
/* 2386 */     this.calcG = (this.calcGi / 255.0F);
/* 2387 */     this.calcB = (this.calcBi / 255.0F);
/* 2388 */     if (this.calcAi != 255) 0; this.calcAlpha = true;
/*      */   }
/*      */ 
/*      */   protected void colorTint()
/*      */   {
/* 2393 */     this.tint = true;
/* 2394 */     this.tintR = this.calcR;
/* 2395 */     this.tintG = this.calcG;
/* 2396 */     this.tintB = this.calcB;
/* 2397 */     this.tintA = this.calcA;
/* 2398 */     this.tintRi = this.calcRi;
/* 2399 */     this.tintGi = this.calcGi;
/* 2400 */     this.tintBi = this.calcBi;
/* 2401 */     this.tintAi = this.calcAi;
/* 2402 */     this.tintColor = this.calcColor;
/* 2403 */     this.tintAlpha = this.calcAlpha;
/*      */   }
/*      */ 
/*      */   protected void colorFill()
/*      */   {
/* 2408 */     this.fill = true;
/*      */ 
/* 2410 */     this.fillR = this.calcR;
/* 2411 */     this.fillG = this.calcG;
/* 2412 */     this.fillB = this.calcB;
/* 2413 */     this.fillA = this.calcA;
/* 2414 */     this.fillRi = this.calcRi;
/* 2415 */     this.fillGi = this.calcGi;
/* 2416 */     this.fillBi = this.calcBi;
/* 2417 */     this.fillAi = this.calcAi;
/* 2418 */     this.fillColor = this.calcColor;
/* 2419 */     this.fillAlpha = this.calcAlpha;
/*      */   }
/*      */ 
/*      */   protected void colorStroke()
/*      */   {
/* 2424 */     this.stroke = true;
/*      */ 
/* 2426 */     this.strokeR = this.calcR;
/* 2427 */     this.strokeG = this.calcG;
/* 2428 */     this.strokeB = this.calcB;
/* 2429 */     this.strokeA = this.calcA;
/* 2430 */     this.strokeRi = this.calcRi;
/* 2431 */     this.strokeGi = this.calcGi;
/* 2432 */     this.strokeBi = this.calcBi;
/* 2433 */     this.strokeAi = this.calcAi;
/* 2434 */     this.strokeColor = this.calcColor;
/* 2435 */     this.strokeAlpha = this.calcAlpha;
/*      */   }
/*      */ 
/*      */   protected void colorBackground()
/*      */   {
/* 2440 */     this.backgroundR = this.calcR;
/* 2441 */     this.backgroundG = this.calcG;
/* 2442 */     this.backgroundB = this.calcB;
/* 2443 */     this.backgroundRi = this.calcRi;
/* 2444 */     this.backgroundGi = this.calcGi;
/* 2445 */     this.backgroundBi = this.calcBi;
/* 2446 */     this.backgroundColor = this.calcColor;
/*      */   }
/*      */ 
/*      */   public void noTint()
/*      */   {
/* 2454 */     this.tint = false;
/*      */   }
/*      */ 
/*      */   public void tint(int paramInt)
/*      */   {
/* 2463 */     if (((paramInt & 0xFF000000) == 0) && (paramInt <= this.colorModeX)) {
/* 2464 */       tint(paramInt);
/*      */     }
/*      */     else {
/* 2467 */       colorFrom(paramInt);
/* 2468 */       colorTint();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void tint(float paramFloat) {
/* 2473 */     colorCalc(paramFloat);
/* 2474 */     colorTint();
/*      */   }
/*      */ 
/*      */   public void tint(float paramFloat1, float paramFloat2)
/*      */   {
/* 2479 */     colorCalc(paramFloat1, paramFloat2);
/* 2480 */     colorTint();
/*      */   }
/*      */ 
/*      */   public void tint(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 2485 */     colorCalc(paramFloat1, paramFloat2, paramFloat3);
/* 2486 */     colorTint();
/*      */   }
/*      */ 
/*      */   public void tint(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 2491 */     colorCalc(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/* 2492 */     colorTint();
/*      */   }
/*      */ 
/*      */   public void noFill()
/*      */   {
/* 2500 */     this.fill = false;
/*      */   }
/*      */ 
/*      */   public void fill(int paramInt)
/*      */   {
/* 2525 */     if (((paramInt & 0xFF000000) == 0) && (paramInt <= this.colorModeX)) {
/* 2526 */       fill(paramInt);
/*      */     }
/*      */     else {
/* 2529 */       colorFrom(paramInt);
/* 2530 */       colorFill();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void fill(float paramFloat) {
/* 2535 */     colorCalc(paramFloat);
/* 2536 */     colorFill();
/*      */   }
/*      */ 
/*      */   public void fill(float paramFloat1, float paramFloat2)
/*      */   {
/* 2541 */     colorCalc(paramFloat1, paramFloat2);
/* 2542 */     colorFill();
/*      */   }
/*      */ 
/*      */   public void fill(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 2547 */     colorCalc(paramFloat1, paramFloat2, paramFloat3);
/* 2548 */     colorFill();
/*      */   }
/*      */ 
/*      */   public void fill(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 2553 */     colorCalc(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/* 2554 */     colorFill();
/*      */   }
/*      */ 
/*      */   public void ambient(int paramInt)
/*      */   {
/* 2562 */     depthError("ambient");
/*      */   }
/*      */ 
/*      */   public void ambient(float paramFloat) {
/* 2566 */     depthError("ambient");
/*      */   }
/*      */ 
/*      */   public void ambient(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 2570 */     depthError("ambient");
/*      */   }
/*      */ 
/*      */   public void specular(int paramInt)
/*      */   {
/* 2578 */     depthError("specular");
/*      */   }
/*      */ 
/*      */   public void specular(float paramFloat) {
/* 2582 */     depthError("specular");
/*      */   }
/*      */ 
/*      */   public void specular(float paramFloat1, float paramFloat2) {
/* 2586 */     depthError("specular");
/*      */   }
/*      */ 
/*      */   public void specular(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 2590 */     depthError("specular");
/*      */   }
/*      */ 
/*      */   public void specular(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 2594 */     depthError("specular");
/*      */   }
/*      */ 
/*      */   public void shininess(float paramFloat) {
/* 2598 */     depthError("shininess");
/*      */   }
/*      */ 
/*      */   public void emissive(int paramInt)
/*      */   {
/* 2606 */     depthError("emissive");
/*      */   }
/*      */ 
/*      */   public void emissive(float paramFloat) {
/* 2610 */     depthError("emissive");
/*      */   }
/*      */ 
/*      */   public void emissive(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 2614 */     depthError("emissive");
/*      */   }
/*      */ 
/*      */   public void lights()
/*      */   {
/* 2625 */     depthError("lights");
/*      */   }
/*      */ 
/*      */   public void ambientLight(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 2629 */     depthError("ambientLight");
/*      */   }
/*      */ 
/*      */   public void ambientLight(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 2633 */     depthError("ambientLight");
/*      */   }
/*      */ 
/*      */   public void directionalLight(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/* 2638 */     depthError("directionalLight");
/*      */   }
/*      */ 
/*      */   public void pointLight(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/* 2643 */     depthError("pointLight");
/*      */   }
/*      */ 
/*      */   public void spotLight(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11)
/*      */   {
/* 2650 */     depthError("spotLight");
/*      */   }
/*      */ 
/*      */   public void lightFalloff(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 2654 */     depthError("lightFalloff");
/*      */   }
/*      */ 
/*      */   public void lightSpecular(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 2658 */     depthError("lightSpecular");
/*      */   }
/*      */ 
/*      */   public void strokeWeight(float paramFloat)
/*      */   {
/* 2667 */     this.strokeWeight = paramFloat;
/*      */   }
/*      */ 
/*      */   public void strokeJoin(int paramInt)
/*      */   {
/* 2672 */     this.strokeJoin = paramInt;
/*      */   }
/*      */ 
/*      */   public void strokeCap(int paramInt)
/*      */   {
/* 2677 */     this.strokeCap = paramInt;
/*      */   }
/*      */ 
/*      */   public void noStroke()
/*      */   {
/* 2682 */     this.stroke = false;
/*      */   }
/*      */ 
/*      */   public void stroke(int paramInt)
/*      */   {
/* 2691 */     if (((paramInt & 0xFF000000) == 0) && (paramInt <= this.colorModeX)) {
/* 2692 */       stroke(paramInt);
/*      */     }
/*      */     else {
/* 2695 */       colorFrom(paramInt);
/* 2696 */       colorStroke();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void stroke(float paramFloat)
/*      */   {
/* 2702 */     colorCalc(paramFloat);
/* 2703 */     colorStroke();
/*      */   }
/*      */ 
/*      */   public void stroke(float paramFloat1, float paramFloat2)
/*      */   {
/* 2708 */     colorCalc(paramFloat1, paramFloat2);
/* 2709 */     colorStroke();
/*      */   }
/*      */ 
/*      */   public void stroke(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 2714 */     colorCalc(paramFloat1, paramFloat2, paramFloat3);
/* 2715 */     colorStroke();
/*      */   }
/*      */ 
/*      */   public void stroke(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 2720 */     colorCalc(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/* 2721 */     colorStroke();
/*      */   }
/*      */ 
/*      */   public void background(int paramInt)
/*      */   {
/* 2737 */     if (((paramInt & 0xFF000000) == 0) && (paramInt <= this.colorModeX)) {
/* 2738 */       background(paramInt);
/*      */     }
/*      */     else {
/* 2741 */       colorFrom(paramInt);
/* 2742 */       colorBackground();
/*      */     }
/* 2744 */     clear();
/*      */   }
/*      */ 
/*      */   public void background(float paramFloat)
/*      */   {
/* 2753 */     colorCalc(paramFloat);
/* 2754 */     colorBackground();
/* 2755 */     clear();
/*      */   }
/*      */ 
/*      */   public void background(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 2764 */     colorCalc(paramFloat1, paramFloat2, paramFloat3);
/* 2765 */     colorBackground();
/* 2766 */     clear();
/*      */   }
/*      */ 
/*      */   public void background(PImage paramPImage)
/*      */   {
/* 2783 */     if ((paramPImage.width != this.width) || (paramPImage.height != this.height)) {
/* 2784 */       throw new RuntimeException("background image must be the same size as your application");
/*      */     }
/*      */ 
/* 2787 */     if ((paramPImage.format != 1) && (paramPImage.format != 2)) {
/* 2788 */       throw new RuntimeException("background images should be RGB or ARGB");
/*      */     }
/*      */ 
/* 2792 */     this.backgroundColor = 0;
/*      */ 
/* 2795 */     System.arraycopy(paramPImage.pixels, 0, this.pixels, 0, this.pixels.length);
/*      */   }
/*      */ 
/*      */   protected void clear()
/*      */   {
/* 2806 */     for (int i = 0; i < this.pixelCount; ++i)
/* 2807 */       this.pixels[i] = this.backgroundColor;
/*      */   }
/*      */ 
/*      */   protected void depthError(String paramString)
/*      */   {
/* 2819 */     throw new RuntimeException(paramString + "() can only be used with P3D or OPENGL.");
/*      */   }
/*      */ 
/*      */   protected void depthErrorXYZ(String paramString)
/*      */   {
/* 2824 */     throw new RuntimeException(paramString + "(x, y, z) can only be used with OPENGL or P3D, use " + paramString + "(x, y) instead.");
/*      */   }
/*      */ 
/*      */   public final int color(int paramInt)
/*      */   {
/* 2840 */     if (this.colorRgb255)
/*      */     {
/* 2842 */       if (paramInt > 255) paramInt = 255; else if (paramInt < 0) paramInt = 0;
/* 2843 */       return (0xFF000000 | paramInt << 16 | paramInt << 8 | paramInt);
/*      */     }
/* 2845 */     colorCalc(paramInt);
/* 2846 */     return this.calcColor;
/*      */   }
/*      */ 
/*      */   public final int color(float paramFloat) {
/* 2850 */     colorCalc(paramFloat);
/* 2851 */     return this.calcColor;
/*      */   }
/*      */ 
/*      */   public final int color(int paramInt1, int paramInt2)
/*      */   {
/* 2856 */     if (this.colorRgb255)
/*      */     {
/* 2858 */       if (paramInt1 > 255) paramInt1 = 255; else if (paramInt1 < 0) paramInt1 = 0;
/* 2859 */       if (paramInt2 > 255) paramInt2 = 255; else if (paramInt2 < 0) paramInt2 = 0;
/*      */ 
/* 2861 */       return ((paramInt2 & 0xFF) << 24 | paramInt1 << 16 | paramInt1 << 8 | paramInt1);
/*      */     }
/* 2863 */     colorCalc(paramInt1, paramInt2);
/* 2864 */     return this.calcColor;
/*      */   }
/*      */ 
/*      */   public final int color(float paramFloat1, float paramFloat2) {
/* 2868 */     colorCalc(paramFloat1, paramFloat2);
/* 2869 */     return this.calcColor;
/*      */   }
/*      */ 
/*      */   public final int color(int paramInt1, int paramInt2, int paramInt3)
/*      */   {
/* 2874 */     if (this.colorRgb255)
/*      */     {
/* 2876 */       if (paramInt1 > 255) paramInt1 = 255; else if (paramInt1 < 0) paramInt1 = 0;
/* 2877 */       if (paramInt2 > 255) paramInt2 = 255; else if (paramInt2 < 0) paramInt2 = 0;
/* 2878 */       if (paramInt3 > 255) paramInt3 = 255; else if (paramInt3 < 0) paramInt3 = 0;
/*      */ 
/* 2880 */       return (0xFF000000 | paramInt1 << 16 | paramInt2 << 8 | paramInt3);
/*      */     }
/* 2882 */     colorCalc(paramInt1, paramInt2, paramInt3);
/* 2883 */     return this.calcColor;
/*      */   }
/*      */ 
/*      */   public final int color(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 2887 */     colorCalc(paramFloat1, paramFloat2, paramFloat3);
/* 2888 */     return this.calcColor;
/*      */   }
/*      */ 
/*      */   public final int color(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*      */   {
/* 2893 */     if (this.colorRgb255)
/*      */     {
/* 2895 */       if (paramInt4 > 255) paramInt4 = 255; else if (paramInt4 < 0) paramInt4 = 0;
/* 2896 */       if (paramInt1 > 255) paramInt1 = 255; else if (paramInt1 < 0) paramInt1 = 0;
/* 2897 */       if (paramInt2 > 255) paramInt2 = 255; else if (paramInt2 < 0) paramInt2 = 0;
/* 2898 */       if (paramInt3 > 255) paramInt3 = 255; else if (paramInt3 < 0) paramInt3 = 0;
/*      */ 
/* 2900 */       return (paramInt4 << 24 | paramInt1 << 16 | paramInt2 << 8 | paramInt3);
/*      */     }
/* 2902 */     colorCalc(paramInt1, paramInt2, paramInt3, paramInt4);
/* 2903 */     return this.calcColor;
/*      */   }
/*      */ 
/*      */   public final int color(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 2907 */     colorCalc(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/* 2908 */     return this.calcColor;
/*      */   }
/*      */ 
/*      */   public final float alpha(int paramInt)
/*      */   {
/* 2913 */     float f = paramInt >> 24 & 0xFF;
/* 2914 */     if (this.colorModeA == 255.0F) return f;
/* 2915 */     return (f / 255.0F * this.colorModeA);
/*      */   }
/*      */ 
/*      */   public final float red(int paramInt) {
/* 2919 */     float f = paramInt >> 16 & 0xFF;
/* 2920 */     if (this.colorRgb255) return f;
/* 2921 */     return (f / 255.0F * this.colorModeX);
/*      */   }
/*      */ 
/*      */   public final float green(int paramInt) {
/* 2925 */     float f = paramInt >> 8 & 0xFF;
/* 2926 */     if (this.colorRgb255) return f;
/* 2927 */     return (f / 255.0F * this.colorModeY);
/*      */   }
/*      */ 
/*      */   public final float blue(int paramInt) {
/* 2931 */     float f = paramInt & 0xFF;
/* 2932 */     if (this.colorRgb255) return f;
/* 2933 */     return (f / 255.0F * this.colorModeZ);
/*      */   }
/*      */ 
/*      */   public final float hue(int paramInt)
/*      */   {
/* 2938 */     if (paramInt != this.cacheHsbKey) {
/* 2939 */       Color.RGBtoHSB(paramInt >> 16 & 0xFF, paramInt >> 8 & 0xFF, paramInt & 0xFF, this.cacheHsbValue);
/*      */ 
/* 2941 */       this.cacheHsbKey = paramInt;
/*      */     }
/* 2943 */     return (this.cacheHsbValue[0] * this.colorModeX);
/*      */   }
/*      */ 
/*      */   public final float saturation(int paramInt) {
/* 2947 */     if (paramInt != this.cacheHsbKey) {
/* 2948 */       Color.RGBtoHSB(paramInt >> 16 & 0xFF, paramInt >> 8 & 0xFF, paramInt & 0xFF, this.cacheHsbValue);
/*      */ 
/* 2950 */       this.cacheHsbKey = paramInt;
/*      */     }
/* 2952 */     return (this.cacheHsbValue[1] * this.colorModeY);
/*      */   }
/*      */ 
/*      */   public final float brightness(int paramInt) {
/* 2956 */     if (paramInt != this.cacheHsbKey) {
/* 2957 */       Color.RGBtoHSB(paramInt >> 16 & 0xFF, paramInt >> 8 & 0xFF, paramInt & 0xFF, this.cacheHsbValue);
/*      */ 
/* 2959 */       this.cacheHsbKey = paramInt;
/*      */     }
/* 2961 */     return (this.cacheHsbValue[2] * this.colorModeZ);
/*      */   }
/*      */ 
/*      */   public void mask(int[] paramArrayOfInt)
/*      */   {
/* 2997 */     super.mask(paramArrayOfInt);
/*      */   }
/*      */ 
/*      */   public void mask(PImage paramPImage)
/*      */   {
/* 3007 */     super.mask(paramPImage);
/*      */   }
/*      */ 
/*      */   private final void jdMethod_this()
/*      */   {
/*   62 */     this.hints = new boolean[8];
/*      */ 
/*  144 */     this.cacheHsbValue = new float[3];
/*      */ 
/*  169 */     this.matrixStack = new float[32][16];
/*      */ 
/*  187 */     this.vertices = new float[512][36];
/*      */ 
/*  193 */     this.bezier_inited = false;
/*  194 */     this.bezier_detail = 20;
/*      */ 
/*  196 */     this.bezier_basis = new float[][] { { -1.0F, 3, -3.0F, 1.0F }, { 3, -6.0F, 3 }, { -3.0F, 3 }, { 1.0F } };
/*      */ 
/*  203 */     this.bezierBasis = new PMatrix(-1.0F, 3, -3.0F, 1.0F, 3, -6.0F, 3, 0.0F, -3.0F, 3, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F);
/*      */ 
/*  214 */     this.curve_inited = false;
/*  215 */     this.curve_detail = 20;
/*      */ 
/*  217 */     this.curve_tightness = 0.0F;
/*      */   }
/*      */ 
/*      */   public PGraphics()
/*      */   {
/*  291 */     jdMethod_this();
/*      */   }
/*      */ 
/*      */   public PGraphics(int paramInt1, int paramInt2, PApplet paramPApplet)
/*      */   {
/*  325 */     jdMethod_this();
/*  326 */     if (paramPApplet != null) paramPApplet.addListeners();
/*      */ 
/*  332 */     resize(paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*  250 */     for (int i = 0; i < 720; ++i) {
/*  251 */       sinLUT[i] = (float)Math.sin(i * 0.01745329F * 0.5F);
/*  252 */       cosLUT[i] = (float)Math.cos(i * 0.01745329F * 0.5F);
/*      */     }
/*      */   }
/*      */ 
/*      */   class Path
/*      */   {
/*      */     public void moveTo(float paramFloat1, float paramFloat2)
/*      */     {
/*      */     }
/*      */ 
/*      */     public void lineTo(float paramFloat1, float paramFloat2)
/*      */     {
/*      */     }
/*      */ 
/*      */     public void curveTo(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */     {
/*      */     }
/*      */ 
/*      */     public void closePath()
/*      */     {
/*      */     }
/*      */   }
/*      */ }

/* Location:           /Users/mfeyereisen/Desktop/Sources 2/common/
 * Qualified Name:     processing.core.PGraphics
 * JD-Core Version:    0.5.3
 */