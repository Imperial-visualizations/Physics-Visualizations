/*      */ package processing.core;
/*      */ 
/*      */ import java.awt.BasicStroke;
/*      */ import java.awt.Color;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.Image;
/*      */ import java.awt.RenderingHints;
/*      */ import java.awt.Shape;
/*      */ import java.awt.geom.AffineTransform;
/*      */ import java.awt.geom.Arc2D.Float;
/*      */ import java.awt.geom.Ellipse2D.Float;
/*      */ import java.awt.geom.GeneralPath;
/*      */ import java.awt.geom.Line2D.Float;
/*      */ import java.awt.geom.Rectangle2D.Float;
/*      */ import java.awt.image.BufferedImage;
/*      */ 
/*      */ public class PGraphics2 extends PGraphics
/*      */ {
/*      */   public Graphics2D g2;
/*      */   GeneralPath gpath;
/*      */   int transformCount;
/*      */   AffineTransform[] transformStack;
/*      */   double[] transform;
/*      */   Line2D.Float line;
/*      */   Ellipse2D.Float ellipse;
/*      */   Rectangle2D.Float rect;
/*      */   Arc2D.Float arc;
/*      */   protected Color tintColorObject;
/*      */   protected Color fillColorObject;
/*      */   protected Color strokeColorObject;
/*      */   float[] curveX;
/*      */   float[] curveY;
/*      */ 
/*      */   public void resize(int paramInt1, int paramInt2)
/*      */   {
/*   94 */     this.width = paramInt1;
/*   95 */     this.height = paramInt2;
/*   96 */     this.width1 = (this.width - 1);
/*   97 */     this.height1 = (this.height - 1);
/*      */ 
/*   99 */     allocate();
/*      */ 
/*  102 */     background(this.backgroundColor);
/*      */   }
/*      */ 
/*      */   protected void allocate()
/*      */   {
/*  108 */     this.image = new BufferedImage(this.width, this.height, 2);
/*  109 */     this.g2 = ((Graphics2D)this.image.getGraphics());
/*      */   }
/*      */ 
/*      */   public void endFrame()
/*      */   {
/*      */   }
/*      */ 
/*      */   public void vertex(float paramFloat1, float paramFloat2)
/*      */   {
/*  133 */     this.splineVertexCount = 0;
/*      */ 
/*  136 */     if (this.vertexCount == this.vertices.length) {
/*  137 */       float[][] arrayOfFloat = new float[this.vertexCount << 1][36];
/*  138 */       System.arraycopy(this.vertices, 0, arrayOfFloat, 0, this.vertexCount);
/*  139 */       this.vertices = arrayOfFloat;
/*      */     }
/*      */ 
/*  144 */     this.vertices[this.vertexCount][9] = paramFloat1;
/*  145 */     this.vertices[this.vertexCount][10] = paramFloat2;
/*  146 */     this.vertexCount += 1;
/*      */ 
/*  148 */     switch (this.shape)
/*      */     {
/*      */     case 16:
/*  151 */       point(paramFloat1, paramFloat2);
/*  152 */       break;
/*      */     case 32:
/*  155 */       if (this.vertexCount % 2 != 0) break label236;
/*  156 */       line(this.vertices[(this.vertexCount - 2)][9], this.vertices[(this.vertexCount - 2)][10], paramFloat1, paramFloat2);
/*      */ 
/*  159 */       break;
/*      */     case 33:
/*      */     case 34:
/*  163 */       if (this.gpath == null) {
/*  164 */         this.gpath = new GeneralPath();
/*  165 */         this.gpath.moveTo(paramFloat1, paramFloat2); break label278:
/*      */       }
/*  167 */       this.gpath.lineTo(paramFloat1, paramFloat2);
/*      */ 
/*  169 */       break;
/*      */     case 64:
/*  172 */       if (this.vertexCount % 3 != 0) break label352;
/*  173 */       triangle(this.vertices[(this.vertexCount - 3)][9], this.vertices[(this.vertexCount - 3)][10], this.vertices[(this.vertexCount - 2)][9], this.vertices[(this.vertexCount - 2)][10], paramFloat1, paramFloat2);
/*      */ 
/*  179 */       break;
/*      */     case 65:
/*  182 */       if (this.vertexCount < 3) break label451;
/*  183 */       triangle(this.vertices[(this.vertexCount - 2)][9], this.vertices[(this.vertexCount - 2)][10], this.vertices[(this.vertexCount - 1)][9], this.vertices[(this.vertexCount - 1)][10], this.vertices[(this.vertexCount - 3)][9], this.vertices[(this.vertexCount - 3)][10]);
/*      */ 
/*  190 */       break;
/*      */     case 66:
/*  193 */       if (this.vertexCount == 3) {
/*  194 */         triangle(this.vertices[0][9], this.vertices[0][10], this.vertices[1][9], this.vertices[1][10], paramFloat1, paramFloat2); break label603:
/*      */       }
/*      */ 
/*  197 */       if (this.vertexCount <= 3) break label603;
/*  198 */       this.gpath = new GeneralPath();
/*      */ 
/*  201 */       this.gpath.moveTo(this.vertices[0][9], this.vertices[0][10]);
/*      */ 
/*  203 */       this.gpath.lineTo(this.vertices[(this.vertexCount - 2)][9], this.vertices[(this.vertexCount - 2)][10]);
/*      */ 
/*  205 */       this.gpath.lineTo(paramFloat1, paramFloat2);
/*  206 */       draw_shape(this.gpath);
/*      */ 
/*  208 */       break;
/*      */     case 128:
/*  211 */       if (this.vertexCount % 4 != 0) break label705;
/*  212 */       quad(this.vertices[(this.vertexCount - 4)][9], this.vertices[(this.vertexCount - 4)][10], this.vertices[(this.vertexCount - 3)][9], this.vertices[(this.vertexCount - 3)][10], this.vertices[(this.vertexCount - 2)][9], this.vertices[(this.vertexCount - 2)][10], paramFloat1, paramFloat2);
/*      */ 
/*  220 */       break;
/*      */     case 129:
/*  226 */       if ((this.vertexCount < 4) || (this.vertexCount % 2 != 0)) break label815;
/*  227 */       quad(this.vertices[(this.vertexCount - 4)][9], this.vertices[(this.vertexCount - 4)][10], this.vertices[(this.vertexCount - 2)][9], this.vertices[(this.vertexCount - 2)][10], paramFloat1, paramFloat2, this.vertices[(this.vertexCount - 3)][9], this.vertices[(this.vertexCount - 3)][10]);
/*      */ 
/*  235 */       break;
/*      */     case 256:
/*  238 */       if (this.gpath == null) {
/*  239 */         label236: this.gpath = new GeneralPath();
/*  240 */         label278: label352: this.gpath.moveTo(paramFloat1, paramFloat2); label815: label705: label451: label603: break label857:
/*      */       }
/*  242 */       this.gpath.lineTo(paramFloat1, paramFloat2);
/*      */     }
/*      */ 
/*  246 */     label857:
/*      */   }
/*      */ 
/*      */   public void bezierVertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/*  252 */     if (this.gpath == null) {
/*  253 */       throw new RuntimeException("Must call vertex() at least once before using bezierVertex()");
/*      */     }
/*      */ 
/*  257 */     switch (this.shape)
/*      */     {
/*      */     case 33:
/*      */     case 34:
/*      */     case 256:
/*  261 */       this.gpath.curveTo(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/*  262 */       break;
/*      */     default:
/*  265 */       throw new RuntimeException("bezierVertex() can only be used with LINE_STRIP, LINE_LOOP, or POLYGON");
/*      */     }
/*      */   }
/*      */ 
/*      */   public void curveVertex(float paramFloat1, float paramFloat2)
/*      */   {
/*  275 */     if ((this.shape != 34) && (this.shape != 33) && (this.shape != 256)) {
/*  276 */       throw new RuntimeException("curveVertex() can only be used with LINE_LOOP, LINE_STRIP, and POLYGON shapes");
/*      */     }
/*      */ 
/*  280 */     if (!(this.curve_inited)) curve_init();
/*  281 */     this.vertexCount = 0;
/*      */ 
/*  283 */     if (this.splineVertices == null) {
/*  284 */       this.splineVertices = new float[128][36];
/*      */     }
/*      */ 
/*  288 */     if (this.splineVertexCount == 128) {
/*  289 */       System.arraycopy(this.splineVertices[125], 0, this.splineVertices[0], 0, 36);
/*      */ 
/*  291 */       System.arraycopy(this.splineVertices[126], 0, this.splineVertices[1], 0, 36);
/*      */ 
/*  293 */       System.arraycopy(this.splineVertices[127], 0, this.splineVertices[2], 0, 36);
/*      */ 
/*  295 */       this.splineVertexCount = 3;
/*      */     }
/*      */ 
/*  300 */     if (this.splineVertexCount >= 3) {
/*  301 */       this.curveX[0] = this.splineVertices[(this.splineVertexCount - 3)][9];
/*  302 */       this.curveY[0] = this.splineVertices[(this.splineVertexCount - 3)][10];
/*      */ 
/*  304 */       this.curveX[1] = this.splineVertices[(this.splineVertexCount - 2)][9];
/*  305 */       this.curveY[1] = this.splineVertices[(this.splineVertexCount - 2)][10];
/*      */ 
/*  307 */       this.curveX[2] = this.splineVertices[(this.splineVertexCount - 1)][9];
/*  308 */       this.curveY[2] = this.splineVertices[(this.splineVertexCount - 1)][10];
/*      */ 
/*  310 */       this.curveX[3] = paramFloat1;
/*  311 */       this.curveY[3] = paramFloat2;
/*      */ 
/*  313 */       this.curveToBezierMatrix.mult(this.curveX, this.curveX);
/*  314 */       this.curveToBezierMatrix.mult(this.curveY, this.curveY);
/*      */ 
/*  318 */       if (this.gpath == null) {
/*  319 */         this.gpath = new GeneralPath();
/*  320 */         this.gpath.moveTo(this.curveX[0], this.curveY[0]);
/*      */       }
/*      */ 
/*  323 */       this.gpath.curveTo(this.curveX[1], this.curveY[1], this.curveX[2], this.curveY[2], this.curveX[3], this.curveY[3]);
/*      */     }
/*      */ 
/*  329 */     this.splineVertices[this.splineVertexCount][9] = paramFloat1;
/*  330 */     this.splineVertices[this.splineVertexCount][10] = paramFloat2;
/*  331 */     this.splineVertexCount += 1;
/*      */   }
/*      */ 
/*      */   public void beginShape(int paramInt)
/*      */   {
/*  336 */     super.beginShape(paramInt);
/*      */ 
/*  343 */     this.gpath = null;
/*      */   }
/*      */ 
/*      */   public void endShape()
/*      */   {
/*  348 */     if (this.gpath != null) {
/*  349 */       switch (this.shape)
/*      */       {
/*      */       case 33:
/*  351 */         stroke_shape(this.gpath);
/*  352 */         break;
/*      */       case 34:
/*  355 */         this.gpath.closePath();
/*  356 */         stroke_shape(this.gpath);
/*  357 */         break;
/*      */       case 256:
/*  360 */         this.gpath.closePath();
/*  361 */         draw_shape(this.gpath);
/*      */       }
/*      */     }
/*      */ 
/*  365 */     this.shape = 0;
/*      */   }
/*      */ 
/*      */   protected void fill_shape(Shape paramShape)
/*      */   {
/*  374 */     if (this.fill) {
/*  375 */       this.g2.setColor(this.fillColorObject);
/*  376 */       this.g2.fill(paramShape);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void stroke_shape(Shape paramShape) {
/*  381 */     if (this.stroke) {
/*  382 */       this.g2.setColor(this.strokeColorObject);
/*  383 */       this.g2.draw(paramShape);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void draw_shape(Shape paramShape) {
/*  388 */     if (this.fill) {
/*  389 */       this.g2.setColor(this.fillColorObject);
/*  390 */       this.g2.fill(paramShape);
/*      */     }
/*  392 */     if (this.stroke) {
/*  393 */       this.g2.setColor(this.strokeColorObject);
/*  394 */       this.g2.draw(paramShape);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void point(float paramFloat1, float paramFloat2)
/*      */   {
/*  403 */     line(paramFloat1, paramFloat2, paramFloat1, paramFloat2);
/*      */   }
/*      */ 
/*      */   public void line(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/*  410 */     this.line.setLine(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*  411 */     stroke_shape(this.line);
/*      */   }
/*      */ 
/*      */   public void triangle(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/*  417 */     this.gpath = new GeneralPath();
/*  418 */     this.gpath.moveTo(paramFloat1, paramFloat2);
/*  419 */     this.gpath.lineTo(paramFloat3, paramFloat4);
/*  420 */     this.gpath.lineTo(paramFloat5, paramFloat6);
/*  421 */     this.gpath.closePath();
/*      */ 
/*  423 */     draw_shape(this.gpath);
/*      */   }
/*      */ 
/*      */   public void quad(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8)
/*      */   {
/*  429 */     GeneralPath localGeneralPath = new GeneralPath();
/*  430 */     localGeneralPath.moveTo(paramFloat1, paramFloat2);
/*  431 */     localGeneralPath.lineTo(paramFloat3, paramFloat4);
/*  432 */     localGeneralPath.lineTo(paramFloat5, paramFloat6);
/*  433 */     localGeneralPath.lineTo(paramFloat7, paramFloat8);
/*  434 */     localGeneralPath.closePath();
/*      */ 
/*  436 */     draw_shape(localGeneralPath);
/*      */   }
/*      */ 
/*      */   protected void rectImpl(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/*  444 */     this.rect.setFrame(paramFloat1, paramFloat2, paramFloat3 - paramFloat1, paramFloat4 - paramFloat2);
/*  445 */     draw_shape(this.rect);
/*      */   }
/*      */ 
/*      */   protected void ellipseImpl(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/*  450 */     this.ellipse.setFrame(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*  451 */     draw_shape(this.ellipse);
/*      */   }
/*      */ 
/*      */   protected void arcImpl(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/*  460 */     if (paramFloat6 - paramFloat5 >= 6.283186F) {
/*  461 */       paramFloat5 = 0.0F;
/*  462 */       paramFloat6 = 360.0F;
/*      */     }
/*      */     else {
/*  465 */       paramFloat5 = -paramFloat5 * 57.295776F;
/*  466 */       paramFloat6 = -paramFloat6 * 57.295776F;
/*      */ 
/*  469 */       while (paramFloat5 < 0.0F) {
/*  470 */         paramFloat5 += 360.0F;
/*  471 */         paramFloat6 += 360.0F;
/*      */       }
/*  473 */       if (paramFloat5 > paramFloat6) {
/*  474 */         f = paramFloat5;
/*  475 */         paramFloat5 = paramFloat6;
/*  476 */         paramFloat6 = f;
/*      */       }
/*      */     }
/*  479 */     float f = paramFloat6 - paramFloat5;
/*      */ 
/*  482 */     if (this.fill)
/*      */     {
/*  484 */       this.arc.setArc(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, f, 2);
/*  485 */       fill_shape(this.arc);
/*      */     }
/*  487 */     if (!(this.stroke))
/*      */       return;
/*  489 */     this.arc.setArc(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, f, 0);
/*  490 */     stroke_shape(this.arc);
/*      */   }
/*      */ 
/*      */   public void bezierDetail(int paramInt)
/*      */   {
/*      */   }
/*      */ 
/*      */   public void curveDetail(int paramInt)
/*      */   {
/*      */   }
/*      */ 
/*      */   protected void imageImpl(PImage paramPImage, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*      */   {
/*  515 */     if (paramPImage.cache == null) {
/*  516 */       paramPImage.cache = new ImageCache(paramPImage);
/*  517 */       paramPImage.updatePixels();
/*      */     }
/*      */ 
/*  520 */     ImageCache localImageCache = (ImageCache)paramPImage.cache;
/*      */ 
/*  523 */     if (((this.tint) && (!(localImageCache.tinted))) || ((this.tint) && (localImageCache.tintedColor != this.tintColor)) || ((!(this.tint)) && (localImageCache.tinted)))
/*      */     {
/*  527 */       paramPImage.updatePixels();
/*      */     }
/*      */ 
/*  530 */     if (paramPImage.modified) {
/*  531 */       localImageCache.update();
/*  532 */       paramPImage.modified = false;
/*      */     }
/*      */ 
/*  536 */     this.g2.drawImage(((ImageCache)paramPImage.cache).image, (int)paramFloat1, (int)paramFloat2, (int)paramFloat3, (int)paramFloat4, paramInt1, paramInt2, paramInt3, paramInt4, null);
/*      */   }
/*      */ 
/*      */   public void translate(float paramFloat1, float paramFloat2)
/*      */   {
/*  660 */     this.g2.translate(paramFloat1, paramFloat2);
/*      */   }
/*      */ 
/*      */   public void rotate(float paramFloat)
/*      */   {
/*  665 */     this.g2.rotate(paramFloat);
/*      */   }
/*      */ 
/*      */   public void scale(float paramFloat)
/*      */   {
/*  670 */     this.g2.scale(paramFloat, paramFloat);
/*      */   }
/*      */ 
/*      */   public void scale(float paramFloat1, float paramFloat2)
/*      */   {
/*  675 */     this.g2.scale(paramFloat1, paramFloat2);
/*      */   }
/*      */ 
/*      */   public void pushMatrix()
/*      */   {
/*  683 */     if (this.transformCount == this.transformStack.length) {
/*  684 */       throw new RuntimeException("pushMatrix() cannot use push more than " + this.transformStack.length + " times");
/*      */     }
/*      */ 
/*  687 */     this.transformStack[this.transformCount] = this.g2.getTransform();
/*  688 */     this.transformCount += 1;
/*      */   }
/*      */ 
/*      */   public void popMatrix()
/*      */   {
/*  693 */     if (this.transformCount == 0) {
/*  694 */       throw new RuntimeException("missing a popMatrix() to go with that pushMatrix()");
/*      */     }
/*      */ 
/*  697 */     this.transformCount -= 1;
/*  698 */     this.g2.setTransform(this.transformStack[this.transformCount]);
/*      */   }
/*      */ 
/*      */   public void resetMatrix()
/*      */   {
/*  703 */     this.g2.setTransform(new AffineTransform());
/*      */   }
/*      */ 
/*      */   public void applyMatrix(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/*  709 */     this.g2.transform(new AffineTransform(paramFloat1, paramFloat4, paramFloat2, paramFloat5, paramFloat3, paramFloat6));
/*      */   }
/*      */ 
/*      */   public void printMatrix()
/*      */   {
/*  714 */     this.g2.getTransform().getMatrix(this.transform);
/*      */ 
/*  716 */     this.m00 = (float)this.transform[0];
/*  717 */     this.m01 = (float)this.transform[2];
/*  718 */     this.m02 = (float)this.transform[4];
/*      */ 
/*  720 */     this.m10 = (float)this.transform[1];
/*  721 */     this.m11 = (float)this.transform[3];
/*  722 */     this.m12 = (float)this.transform[5];
/*      */ 
/*  724 */     super.printMatrix();
/*      */   }
/*      */ 
/*      */   public float screenX(float paramFloat1, float paramFloat2)
/*      */   {
/*  729 */     this.g2.getTransform().getMatrix(this.transform);
/*      */ 
/*  731 */     return ((float)this.transform[0] * paramFloat1 + (float)this.transform[2] * paramFloat2 + (float)this.transform[4]);
/*      */   }
/*      */ 
/*      */   public float screenY(float paramFloat1, float paramFloat2)
/*      */   {
/*  736 */     this.g2.getTransform().getMatrix(this.transform);
/*  737 */     return ((float)this.transform[1] * paramFloat1 + (float)this.transform[3] * paramFloat2 + (float)this.transform[5]);
/*      */   }
/*      */ 
/*      */   protected void colorTint()
/*      */   {
/*  745 */     super.colorTint();
/*      */ 
/*  747 */     this.tintColorObject = new Color(this.tintColor, true);
/*      */   }
/*      */ 
/*      */   protected void colorFill() {
/*  751 */     super.colorFill();
/*  752 */     this.fillColorObject = new Color(this.fillColor, true);
/*      */   }
/*      */ 
/*      */   protected void colorStroke() {
/*  756 */     super.colorStroke();
/*  757 */     this.strokeColorObject = new Color(this.strokeColor, true);
/*      */   }
/*      */ 
/*      */   public void strokeWeight(float paramFloat)
/*      */   {
/*  765 */     super.strokeWeight(paramFloat);
/*  766 */     set_stroke();
/*      */   }
/*      */ 
/*      */   public void strokeJoin(int paramInt)
/*      */   {
/*  771 */     super.strokeJoin(paramInt);
/*  772 */     set_stroke();
/*      */   }
/*      */ 
/*      */   public void strokeCap(int paramInt)
/*      */   {
/*  777 */     super.strokeCap(paramInt);
/*  778 */     set_stroke();
/*      */   }
/*      */ 
/*      */   protected void set_stroke()
/*      */   {
/*  783 */     int i = 0;
/*  784 */     if (this.strokeCap == 2)
/*  785 */       i = 1;
/*  786 */     else if (this.strokeCap == 4) {
/*  787 */       i = 2;
/*      */     }
/*      */ 
/*  790 */     int j = 2;
/*  791 */     if (this.strokeJoin == 8)
/*  792 */       j = 0;
/*  793 */     else if (this.strokeJoin == 2) {
/*  794 */       j = 1;
/*      */     }
/*      */ 
/*  797 */     this.g2.setStroke(new BasicStroke(this.strokeWeight, i, j));
/*      */   }
/*      */ 
/*      */   public void background(PImage paramPImage)
/*      */   {
/*  805 */     if ((paramPImage.width != this.width) || (paramPImage.height != this.height)) {
/*  806 */       throw new RuntimeException("background image must be the same size as your application");
/*      */     }
/*      */ 
/*  809 */     if ((paramPImage.format != 1) && (paramPImage.format != 2)) {
/*  810 */       throw new RuntimeException("background images should be RGB or ARGB");
/*      */     }
/*      */ 
/*  813 */     set(0, 0, paramPImage);
/*      */   }
/*      */ 
/*      */   public void clear()
/*      */   {
/*  818 */     this.g2.setColor(new Color(this.backgroundColor));
/*  819 */     this.g2.fillRect(0, 0, this.width, this.height);
/*      */   }
/*      */ 
/*      */   public void smooth()
/*      */   {
/*  830 */     this.g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*      */   }
/*      */ 
/*      */   public void noSmooth()
/*      */   {
/*  836 */     this.g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
/*      */   }
/*      */ 
/*      */   public void loadPixels()
/*      */   {
/*  845 */     if ((this.pixels == null) || (this.pixels.length != this.width * this.height)) {
/*  846 */       this.pixels = new int[this.width * this.height];
/*      */     }
/*  848 */     ((BufferedImage)this.image).getRGB(0, 0, this.width, this.height, this.pixels, 0, this.width);
/*      */   }
/*      */ 
/*      */   public void updatePixels()
/*      */   {
/*  859 */     updatePixels(0, 0, this.width, this.height);
/*      */   }
/*      */ 
/*      */   public void updatePixels(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*      */   {
/*  870 */     ((BufferedImage)this.image).setRGB(paramInt1, paramInt2, (this.imageMode == 0) ? paramInt3 : paramInt3 - paramInt1, (this.imageMode == 0) ? paramInt4 : paramInt4 - paramInt2, this.pixels, 0, this.width);
/*      */   }
/*      */ 
/*      */   public int get(int paramInt1, int paramInt2)
/*      */   {
/*  881 */     if ((paramInt1 < 0) || (paramInt2 < 0) || (paramInt1 >= this.width) || (paramInt2 >= this.height)) return 0;
/*  882 */     return ((BufferedImage)this.image).getRGB(paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */   public PImage get(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*      */   {
/*  887 */     if (this.imageMode == 1)
/*      */     {
/*  889 */       paramInt3 -= paramInt1;
/*  890 */       paramInt4 -= paramInt1;
/*      */     }
/*      */ 
/*  893 */     if (paramInt1 < 0) {
/*  894 */       paramInt3 += paramInt1;
/*  895 */       paramInt1 = 0;
/*      */     }
/*  897 */     if (paramInt2 < 0) {
/*  898 */       paramInt4 += paramInt2;
/*  899 */       paramInt2 = 0;
/*      */     }
/*      */ 
/*  902 */     if (paramInt1 + paramInt3 > this.width) paramInt3 = this.width - paramInt1;
/*  903 */     if (paramInt2 + paramInt4 > this.height) paramInt4 = this.height - paramInt2;
/*      */ 
/*  905 */     PImage localPImage = new PImage(paramInt3, paramInt4);
/*      */ 
/*  907 */     ((BufferedImage)this.image).getRGB(paramInt1, paramInt2, paramInt3, paramInt4, localPImage.pixels, 0, paramInt3);
/*  908 */     return localPImage;
/*      */   }
/*      */ 
/*      */   public PImage get()
/*      */   {
/*  916 */     PImage localPImage = new PImage(this.width, this.height);
/*  917 */     ((BufferedImage)this.image).getRGB(0, 0, this.width, this.height, localPImage.pixels, 0, this.width);
/*      */ 
/*  919 */     return localPImage;
/*      */   }
/*      */ 
/*      */   public void set(int paramInt1, int paramInt2, int paramInt3)
/*      */   {
/*  924 */     if ((paramInt1 < 0) || (paramInt2 < 0) || (paramInt1 >= this.width) || (paramInt2 >= this.height)) return;
/*  925 */     ((BufferedImage)this.image).setRGB(paramInt1, paramInt2, paramInt3);
/*      */   }
/*      */ 
/*      */   protected void setImpl(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, PImage paramPImage)
/*      */   {
/*  964 */     BufferedImage localBufferedImage = (BufferedImage)this.image;
/*  965 */     localBufferedImage.setRGB(paramInt1, paramInt2, paramInt5, paramInt6, paramPImage.pixels, paramInt4 * paramPImage.width + paramInt3, paramPImage.width);
/*      */   }
/*      */ 
/*      */   public void filter(int paramInt)
/*      */   {
/*  973 */     loadPixels();
/*  974 */     super.filter(paramInt);
/*  975 */     updatePixels();
/*      */   }
/*      */ 
/*      */   public void filter(int paramInt, float paramFloat)
/*      */   {
/*  980 */     loadPixels();
/*  981 */     super.filter(paramInt, paramFloat);
/*  982 */     updatePixels();
/*      */   }
/*      */ 
/*      */   public void copy(PImage paramPImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8)
/*      */   {
/*  991 */     loadPixels();
/*  992 */     super.copy(paramPImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8);
/*  993 */     updatePixels();
/*      */   }
/*      */ 
/*      */   public void blend(PImage paramPImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
/*      */   {
/*  998 */     loadPixels();
/*  999 */     super.blend(paramPImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/* 1000 */     updatePixels();
/*      */   }
/*      */ 
/*      */   public void blend(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
/*      */   {
/* 1005 */     loadPixels();
/* 1006 */     super.blend(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/* 1007 */     updatePixels();
/*      */   }
/*      */ 
/*      */   public void blend(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9)
/*      */   {
/* 1013 */     loadPixels();
/* 1014 */     super.blend(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9);
/* 1015 */     updatePixels();
/*      */   }
/*      */ 
/*      */   public void blend(PImage paramPImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9)
/*      */   {
/* 1021 */     loadPixels();
/* 1022 */     super.blend(paramPImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9);
/* 1023 */     updatePixels();
/*      */   }
/*      */ 
/*      */   public void save(String paramString)
/*      */   {
/* 1028 */     loadPixels();
/* 1029 */     super.save(paramString);
/*      */   }
/*      */ 
/*      */   private final void jdMethod_this()
/*      */   {
/*   41 */     this.transformStack = new AffineTransform[32];
/*      */ 
/*   43 */     this.transform = new double[6];
/*      */ 
/*   45 */     this.line = new Line2D.Float();
/*   46 */     this.ellipse = new Ellipse2D.Float();
/*   47 */     this.rect = new Rectangle2D.Float();
/*   48 */     this.arc = new Arc2D.Float();
/*      */ 
/*  271 */     this.curveX = new float[4];
/*  272 */     this.curveY = new float[4];
/*      */   }
/*      */ 
/*      */   public PGraphics2()
/*      */   {
/*   66 */     jdMethod_this();
/*      */   }
/*      */ 
/*      */   public PGraphics2(int paramInt1, int paramInt2, PApplet paramPApplet)
/*      */   {
/*   79 */     super(paramInt1, paramInt2, paramPApplet); jdMethod_this();
/*      */   }
/*      */ 
/*      */   class ImageCache
/*      */   {
/*      */     PImage source;
/*      */     boolean tinted;
/*      */     int tintedColor;
/*      */     int[] tintedPixels;
/*      */     BufferedImage image;
/*      */ 
/*      */     public void update()
/*      */     {
/*      */       int i;
/*      */       int j;
/*      */       int k;
/*  558 */       if ((this.source.format == 2) || (this.source.format == 1)) {
/*  559 */         if (PGraphics2.this.tint)
/*      */         {
/*  561 */           if (this.tintedPixels == null) {
/*  562 */             this.tintedPixels = new int[this.source.width * this.source.height];
/*      */           }
/*      */ 
/*  565 */           i = PGraphics2.this.tintColor;
/*  566 */           j = PGraphics2.this.tintColor >> 24 & 0xFF;
/*  567 */           k = PGraphics2.this.tintColor >> 16 & 0xFF;
/*  568 */           int l = PGraphics2.this.tintColor >> 8 & 0xFF;
/*  569 */           int i1 = PGraphics2.this.tintColor & 0xFF;
/*      */           int i2;
/*      */           int i3;
/*      */           int i4;
/*      */           int i5;
/*      */           int i6;
/*      */           int i7;
/*  575 */           if (this.source.format == 1) {
/*  576 */             i2 = j << 24;
/*      */ 
/*  578 */             for (i3 = 0; i3 < this.tintedPixels.length; ++i3) {
/*  579 */               i4 = this.source.pixels[i3];
/*  580 */               i5 = i4 >> 16 & 0xFF;
/*  581 */               i6 = i4 >> 8 & 0xFF;
/*  582 */               i7 = i4 & 0xFF;
/*      */ 
/*  584 */               this.tintedPixels[i3] = (i2 | (k * i5 & 0xFF00) << 8 | l * i6 & 0xFF00 | (i1 * i7 & 0xFF00) >> 8);
/*      */             }
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*  591 */             for (i2 = 0; i2 < this.tintedPixels.length; ++i2) {
/*  592 */               i3 = this.source.pixels[i2];
/*  593 */               i4 = i3 >> 24 & 0xFF;
/*  594 */               i5 = i3 >> 16 & 0xFF;
/*  595 */               i6 = i3 >> 8 & 0xFF;
/*  596 */               i7 = i3 & 0xFF;
/*      */ 
/*  598 */               this.tintedPixels[i2] = ((j * i4 & 0xFF00) << 16 | (k * i5 & 0xFF00) << 8 | l * i6 & 0xFF00 | (i1 * i7 & 0xFF00) >> 8);
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*  606 */           this.tinted = true;
/*  607 */           this.tintedColor = PGraphics2.this.tintColor;
/*      */ 
/*  610 */           this.image.setRGB(0, 0, this.source.width, this.source.height, this.tintedPixels, 0, this.source.width);
/*      */         }
/*      */         else
/*      */         {
/*  616 */           this.image.setRGB(0, 0, this.source.width, this.source.height, this.source.pixels, 0, this.source.width);
/*      */         }
/*      */ 
/*      */       }
/*  620 */       else if (this.source.format == 4) {
/*  621 */         if (this.tintedPixels == null) {
/*  622 */           this.tintedPixels = new int[this.source.width * this.source.height];
/*      */         }
/*      */ 
/*  625 */         i = PGraphics2.this.tintColor & 0xFFFFFF;
/*  626 */         if ((PGraphics2.this.tintColor >> 24 & 0xFF) >= 254)
/*      */         {
/*  629 */           for (j = 0; j < this.tintedPixels.length; ++j)
/*      */           {
/*  631 */             if (this.source.pixels[j] != 0) 0; this.tintedPixels[j] = (this.source.pixels[j] << 24 | i);
/*      */           }
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*  637 */           j = PGraphics2.this.tintColor >> 24 & 0xFF;
/*  638 */           for (k = 0; k < this.tintedPixels.length; ++k) {
/*  639 */             if (this.source.pixels[k] != 0) 0; this.tintedPixels[k] = ((j * this.source.pixels[k] & 0xFF00) << 16 | i);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  645 */         this.tinted = true;
/*  646 */         this.tintedColor = PGraphics2.this.tintColor;
/*      */ 
/*  649 */         this.image.setRGB(0, 0, this.source.width, this.source.height, this.tintedPixels, 0, this.source.width);
/*      */       }
/*      */     }
/*      */ 
/*      */     public ImageCache(PImage paramPImage)
/*      */     {
/*  550 */       this.source = paramPImage;
/*      */ 
/*  553 */       int i = 2;
/*  554 */       this.image = new BufferedImage(paramPImage.width, paramPImage.height, i);
/*      */     }
/*      */   }
/*      */ }

/* Location:           /Users/mfeyereisen/Desktop/Sources 2/common/
 * Qualified Name:     processing.core.PGraphics2
 * JD-Core Version:    0.5.3
 */