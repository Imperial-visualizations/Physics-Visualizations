/*     */ package processing.core;
/*     */ 
/*     */ public class PLine
/*     */   implements PConstants
/*     */ {
/*     */   static final int R_COLOR = 1;
/*     */   static final int R_ALPHA = 2;
/*     */   static final int R_SPATIAL = 8;
/*     */   static final int R_THICK = 4;
/*     */   static final int R_SMOOTH = 16;
/*     */   private int[] m_pixels;
/*     */   private float[] m_zbuffer;
/*     */   private int[] m_stencil;
/*     */   private int m_index;
/*     */   private int SCREEN_WIDTH;
/*     */   private int SCREEN_HEIGHT;
/*     */   private int SCREEN_WIDTH1;
/*     */   private int SCREEN_HEIGHT1;
/*     */   public boolean INTERPOLATE_RGB;
/*     */   public boolean INTERPOLATE_ALPHA;
/*     */   public boolean INTERPOLATE_Z;
/*     */   public boolean INTERPOLATE_THICK;
/*     */   private boolean SMOOTH;
/*     */   private boolean BLENDER;
/*     */   private int m_stroke;
/*     */   public int m_drawFlags;
/*     */   private float[] x_array;
/*     */   private float[] y_array;
/*     */   private float[] z_array;
/*     */   private float[] r_array;
/*     */   private float[] g_array;
/*     */   private float[] b_array;
/*     */   private float[] a_array;
/*     */   private int o0;
/*     */   private int o1;
/*     */   private float m_r0;
/*     */   private float m_g0;
/*     */   private float m_b0;
/*     */   private float m_a0;
/*     */   private float m_z0;
/*     */   private float dz;
/*     */   private float dr;
/*     */   private float dg;
/*     */   private float db;
/*     */   private float da;
/*     */   private PGraphics3 parent;
/*     */ 
/*     */   public void reset()
/*     */   {
/* 121 */     this.SCREEN_WIDTH = this.parent.width;
/* 122 */     this.SCREEN_HEIGHT = this.parent.height;
/* 123 */     this.SCREEN_WIDTH1 = (this.SCREEN_WIDTH - 1);
/* 124 */     this.SCREEN_HEIGHT1 = (this.SCREEN_HEIGHT - 1);
/*     */ 
/* 126 */     this.m_pixels = this.parent.pixels;
/* 127 */     this.m_stencil = this.parent.stencil;
/* 128 */     this.m_zbuffer = this.parent.zbuffer;
/*     */ 
/* 132 */     this.INTERPOLATE_RGB = false;
/* 133 */     this.INTERPOLATE_ALPHA = false;
/*     */ 
/* 135 */     this.m_drawFlags = 0;
/* 136 */     this.m_index = 0;
/* 137 */     this.BLENDER = false;
/*     */   }
/*     */ 
/*     */   public void setVertices(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*     */   {
/* 145 */     if ((paramFloat3 != paramFloat6) || (paramFloat3 != 0.0F) || (paramFloat6 != 0.0F) || (this.INTERPOLATE_Z)) {
/* 146 */       this.INTERPOLATE_Z = true;
/* 147 */       this.m_drawFlags |= 8;
/*     */     } else {
/* 149 */       this.INTERPOLATE_Z = false;
/* 150 */       this.m_drawFlags &= -9;
/*     */     }
/*     */ 
/* 153 */     this.z_array[0] = paramFloat3;
/* 154 */     this.z_array[1] = paramFloat6;
/*     */ 
/* 156 */     this.x_array[0] = paramFloat1;
/* 157 */     this.x_array[1] = paramFloat4;
/*     */ 
/* 159 */     this.y_array[0] = paramFloat2;
/* 160 */     this.y_array[1] = paramFloat5;
/*     */   }
/*     */ 
/*     */   public void setIntensities(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8)
/*     */   {
/* 165 */     this.a_array[0] = ((paramFloat4 * 253.0F + 1.0F) * 65536.0F);
/* 166 */     this.a_array[1] = ((paramFloat8 * 253.0F + 1.0F) * 65536.0F);
/*     */ 
/* 169 */     if ((paramFloat4 != 1.0F) || (paramFloat8 != 1.0F)) {
/* 170 */       this.INTERPOLATE_ALPHA = true;
/* 171 */       this.m_drawFlags |= 2;
/*     */     } else {
/* 173 */       this.INTERPOLATE_ALPHA = false;
/* 174 */       this.m_drawFlags &= -3;
/*     */     }
/*     */ 
/* 178 */     this.r_array[0] = ((paramFloat1 * 253.0F + 1.0F) * 65536.0F);
/* 179 */     this.r_array[1] = ((paramFloat5 * 253.0F + 1.0F) * 65536.0F);
/*     */ 
/* 181 */     this.g_array[0] = ((paramFloat2 * 253.0F + 1.0F) * 65536.0F);
/* 182 */     this.g_array[1] = ((paramFloat6 * 253.0F + 1.0F) * 65536.0F);
/*     */ 
/* 184 */     this.b_array[0] = ((paramFloat3 * 253.0F + 1.0F) * 65536.0F);
/* 185 */     this.b_array[1] = ((paramFloat7 * 253.0F + 1.0F) * 65536.0F);
/*     */ 
/* 188 */     if (paramFloat1 != paramFloat5) {
/* 189 */       this.INTERPOLATE_RGB = true;
/* 190 */       this.m_drawFlags |= 1;
/*     */     }
/* 192 */     else if (paramFloat2 != paramFloat6) {
/* 193 */       this.INTERPOLATE_RGB = true;
/* 194 */       this.m_drawFlags |= 1;
/*     */     }
/* 196 */     else if (paramFloat3 != paramFloat7) {
/* 197 */       this.INTERPOLATE_RGB = true;
/* 198 */       this.m_drawFlags |= 1;
/*     */     }
/*     */     else
/*     */     {
/* 202 */       this.m_stroke = (0xFF000000 | (int)(255.0F * paramFloat1) << 16 | (int)(255.0F * paramFloat2) << 8 | (int)(255.0F * paramFloat3));
/*     */ 
/* 204 */       this.INTERPOLATE_RGB = false;
/* 205 */       this.m_drawFlags &= -2;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setIndex(int paramInt)
/*     */   {
/* 211 */     this.m_index = paramInt;
/* 212 */     this.BLENDER = false;
/* 213 */     if (this.m_index != -1)
/* 214 */       this.BLENDER = true;
/*     */     else
/* 216 */       this.m_index = 0;
/*     */   }
/*     */ 
/*     */   public void draw()
/*     */   {
/* 225 */     boolean bool1 = true;
/*     */ 
/* 227 */     if (this.parent.smooth) {
/* 228 */       this.SMOOTH = true;
/* 229 */       this.m_drawFlags |= 16;
/*     */     }
/*     */     else {
/* 232 */       this.SMOOTH = false;
/* 233 */       this.m_drawFlags &= -17;
/*     */     }
/*     */ 
/* 237 */     if (this.parent.hints[6] != 0) {
/* 238 */       float f1 = -this.SCREEN_WIDTH;
/* 239 */       float f3 = -this.SCREEN_HEIGHT;
/* 240 */       float f5 = this.SCREEN_WIDTH * 2;
/* 241 */       float f6 = this.SCREEN_HEIGHT * 2;
/* 242 */       if ((this.x_array[1] < f1) || (this.x_array[1] > f5) || (this.x_array[0] < f1) || (this.x_array[0] > f5) || (this.y_array[1] < f3) || (this.y_array[1] > f6) || (this.y_array[0] < f3) || (this.y_array[0] > f6))
/*     */       {
/* 250 */         return;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 256 */     bool1 = lineClipping();
/* 257 */     if (!(bool1)) {
/* 258 */       return;
/*     */     }
/*     */ 
/* 268 */     boolean bool2 = false;
/*     */     float f7;
/* 278 */     if (this.x_array[1] < this.x_array[0])
/*     */     {
/* 281 */       f7 = this.x_array[1]; this.x_array[1] = this.x_array[0]; this.x_array[0] = f7;
/* 282 */       f7 = this.y_array[1]; this.y_array[1] = this.y_array[0]; this.y_array[0] = f7;
/* 283 */       f7 = this.z_array[1]; this.z_array[1] = this.z_array[0]; this.z_array[0] = f7;
/*     */ 
/* 285 */       f7 = this.r_array[1]; this.r_array[1] = this.r_array[0]; this.r_array[0] = f7;
/* 286 */       f7 = this.g_array[1]; this.g_array[1] = this.g_array[0]; this.g_array[0] = f7;
/* 287 */       f7 = this.b_array[1]; this.b_array[1] = this.b_array[0]; this.b_array[0] = f7;
/* 288 */       f7 = this.a_array[1]; this.a_array[1] = this.a_array[0]; this.a_array[0] = f7;
/*     */     }
/*     */ 
/* 293 */     float f4 = (int)this.x_array[1] - (int)this.x_array[0];
/* 294 */     float f2 = (int)this.y_array[1] - (int)this.y_array[0];
/*     */ 
/* 296 */     if (Math.abs(f2) > Math.abs(f4)) {
/* 297 */       f7 = f2;
/* 298 */       f2 = f4;
/* 299 */       f4 = f7;
/* 300 */       bool2 = true;
/*     */     }
/*     */     int i;
/*     */     int j;
/*     */     int k;
/* 305 */     if (f4 < 0)
/*     */     {
/* 307 */       this.o0 = 1;
/* 308 */       this.o1 = 0;
/*     */ 
/* 310 */       i = (int)this.x_array[1];
/* 311 */       j = (int)this.y_array[1];
/*     */ 
/* 313 */       k = -f4;
/*     */     }
/*     */     else {
/* 316 */       this.o0 = 0;
/* 317 */       this.o1 = 1;
/*     */ 
/* 319 */       i = (int)this.x_array[0];
/* 320 */       j = (int)this.y_array[0];
/*     */ 
/* 322 */       k = f4;
/*     */     }
/*     */     int l;
/* 326 */     if (k == 0)
/* 327 */       l = 0;
/*     */     else {
/* 329 */       l = (f2 << 16) / f4;
/*     */     }
/*     */ 
/* 332 */     this.m_r0 = this.r_array[this.o0];
/* 333 */     this.m_g0 = this.g_array[this.o0];
/* 334 */     this.m_b0 = this.b_array[this.o0];
/*     */ 
/* 336 */     if (this.INTERPOLATE_RGB) {
/* 337 */       this.dr = ((this.r_array[this.o1] - this.r_array[this.o0]) / k);
/* 338 */       this.dg = ((this.g_array[this.o1] - this.g_array[this.o0]) / k);
/* 339 */       this.db = ((this.b_array[this.o1] - this.b_array[this.o0]) / k);
/*     */     } else {
/* 341 */       this.dr = 0.0F;
/* 342 */       this.dg = 0.0F;
/* 343 */       this.db = 0.0F;
/*     */     }
/*     */ 
/* 346 */     this.m_a0 = this.a_array[this.o0];
/*     */ 
/* 348 */     if (this.INTERPOLATE_ALPHA)
/* 349 */       this.da = ((this.a_array[this.o1] - this.a_array[this.o0]) / k);
/*     */     else {
/* 351 */       this.da = 0.0F;
/*     */     }
/*     */ 
/* 354 */     this.m_z0 = this.z_array[this.o0];
/*     */ 
/* 357 */     if (this.INTERPOLATE_Z)
/* 358 */       this.dz = ((this.z_array[this.o1] - this.z_array[this.o0]) / k);
/*     */     else {
/* 360 */       this.dz = 0.0F;
/*     */     }
/*     */ 
/* 364 */     if (k == 0) {
/* 365 */       if (this.INTERPOLATE_ALPHA)
/* 366 */         drawPoint_alpha(i, j);
/*     */       else {
/* 368 */         drawPoint(i, j);
/*     */       }
/* 370 */       return;
/*     */     }
/*     */ 
/* 387 */     if (this.SMOOTH) {
/* 388 */       drawLine_smooth(i, j, l, k, bool2);
/*     */     }
/* 391 */     else if (this.m_drawFlags == 0) {
/* 392 */       drawLine_plain(i, j, l, k, bool2);
/*     */     }
/* 394 */     else if (this.m_drawFlags == 2) {
/* 395 */       drawLine_plain_alpha(i, j, l, k, bool2);
/*     */     }
/* 397 */     else if (this.m_drawFlags == 1) {
/* 398 */       drawLine_color(i, j, l, k, bool2);
/*     */     }
/* 400 */     else if (this.m_drawFlags == 3) {
/* 401 */       drawLine_color_alpha(i, j, l, k, bool2);
/*     */     }
/* 403 */     else if (this.m_drawFlags == 8) {
/* 404 */       drawLine_plain_spatial(i, j, l, k, bool2);
/*     */     }
/* 406 */     else if (this.m_drawFlags == 10) {
/* 407 */       drawLine_plain_alpha_spatial(i, j, l, k, bool2);
/*     */     }
/* 409 */     else if (this.m_drawFlags == 9) {
/* 410 */       drawLine_color_spatial(i, j, l, k, bool2);
/*     */     }
/* 412 */     else if (this.m_drawFlags == 11)
/* 413 */       drawLine_color_alpha_spatial(i, j, l, k, bool2);
/*     */   }
/*     */ 
/*     */   public boolean lineClipping()
/*     */   {
/* 422 */     int i = lineClipCode(this.x_array[0], this.y_array[0]);
/* 423 */     int j = lineClipCode(this.x_array[1], this.y_array[1]);
/* 424 */     int k = i | j;
/*     */ 
/* 426 */     if ((i & j) != 0)
/*     */     {
/* 428 */       return false;
/*     */     }
/* 430 */     if (k != 0)
/*     */     {
/* 433 */       float f1 = 0.0F; float f2 = 1.0F; float f3 = 0.0F;
/*     */ 
/* 435 */       for (int l = 0; l < 4; ++l) {
/* 436 */         if ((k >> l) % 2 == 1) {
/* 437 */           f3 = lineSlope(this.x_array[0], this.y_array[0], this.x_array[1], this.y_array[1], l + 1);
/* 438 */           if ((i >> l) % 2 == 1)
/* 439 */             f1 = (f3 > f1) ? f3 : f1;
/*     */           else {
/* 441 */             f2 = (f3 < f2) ? f3 : f2;
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 446 */       if (f1 > f2) {
/* 447 */         return false;
/*     */       }
/* 449 */       float f4 = this.x_array[0];
/* 450 */       float f5 = this.y_array[0];
/*     */ 
/* 452 */       this.x_array[0] = (f4 + f1 * (this.x_array[1] - f4));
/* 453 */       this.y_array[0] = (f5 + f1 * (this.y_array[1] - f5));
/* 454 */       this.x_array[1] = (f4 + f2 * (this.x_array[1] - f4));
/* 455 */       this.y_array[1] = (f5 + f2 * (this.y_array[1] - f5));
/*     */       float f6;
/* 458 */       if (this.INTERPOLATE_RGB) {
/* 459 */         f6 = this.r_array[0];
/* 460 */         this.r_array[0] = (f6 + f1 * (this.r_array[1] - f6));
/* 461 */         this.r_array[1] = (f6 + f2 * (this.r_array[1] - f6));
/* 462 */         f6 = this.g_array[0];
/* 463 */         this.g_array[0] = (f6 + f1 * (this.g_array[1] - f6));
/* 464 */         this.g_array[1] = (f6 + f2 * (this.g_array[1] - f6));
/* 465 */         f6 = this.b_array[0];
/* 466 */         this.b_array[0] = (f6 + f1 * (this.b_array[1] - f6));
/* 467 */         this.b_array[1] = (f6 + f2 * (this.b_array[1] - f6));
/*     */       }
/*     */ 
/* 470 */       if (this.INTERPOLATE_ALPHA) {
/* 471 */         f6 = this.a_array[0];
/* 472 */         this.a_array[0] = (f6 + f1 * (this.a_array[1] - f6));
/* 473 */         this.a_array[1] = (f6 + f2 * (this.a_array[1] - f6));
/*     */       }
/*     */     }
/*     */ 
/* 477 */     return true;
/*     */   }
/*     */ 
/*     */   private final int lineClipCode(float paramFloat1, float paramFloat2)
/*     */   {
/* 482 */     int i = 0;
/* 483 */     int j = 0;
/* 484 */     int k = this.SCREEN_WIDTH1;
/* 485 */     int l = this.SCREEN_HEIGHT1;
/*     */ 
/* 487 */     if (paramFloat1 > k) 0; return (((paramFloat2 < j) ? 8 : 0) | ((paramFloat2 > l) ? 4 : 0) | ((paramFloat1 < i) ? 2 : 0) | 0x1);
/*     */   }
/*     */ 
/*     */   private final float lineSlope(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt)
/*     */   {
/* 493 */     int i = 0;
/* 494 */     int j = 0;
/* 495 */     int k = this.SCREEN_WIDTH1;
/* 496 */     int l = this.SCREEN_HEIGHT1;
/*     */ 
/* 498 */     switch (paramInt)
/*     */     {
/*     */     case 4:
/* 499 */       return ((j - paramFloat2) / (paramFloat4 - paramFloat2));
/*     */     case 3:
/* 500 */       return ((l - paramFloat2) / (paramFloat4 - paramFloat2));
/*     */     case 2:
/* 501 */       return ((i - paramFloat1) / (paramFloat3 - paramFloat1));
/*     */     case 1:
/* 502 */       return ((k - paramFloat1) / (paramFloat3 - paramFloat1));
/*     */     }
/* 504 */     return (-1.0F);
/*     */   }
/*     */ 
/*     */   private final void drawPoint(int paramInt1, int paramInt2)
/*     */   {
/* 509 */     float f = this.m_z0;
/* 510 */     int i = paramInt2 * this.SCREEN_WIDTH + paramInt1;
/*     */ 
/* 512 */     if (f <= this.m_zbuffer[i]) {
/* 513 */       this.m_pixels[i] = this.m_stroke;
/* 514 */       this.m_zbuffer[i] = f;
/*     */     }
/*     */   }
/*     */ 
/*     */   private final void drawPoint_alpha(int paramInt1, int paramInt2)
/*     */   {
/* 520 */     int i = (int)this.a_array[0];
/* 521 */     int j = this.m_stroke & 0xFF0000;
/* 522 */     int k = this.m_stroke & 0xFF00;
/* 523 */     int l = this.m_stroke & 0xFF;
/* 524 */     float f = this.m_z0;
/* 525 */     int i1 = paramInt2 * this.SCREEN_WIDTH + paramInt1;
/*     */ 
/* 527 */     if (f <= this.m_zbuffer[i1]) {
/* 528 */       int i2 = i >> 16;
/* 529 */       int i3 = this.m_pixels[i1];
/* 530 */       int i4 = i3 & 0xFF00;
/* 531 */       int i5 = i3 & 0xFF;
/* 532 */       i3 &= 16711680;
/*     */ 
/* 534 */       i3 += ((j - i3) * i2 >> 8);
/* 535 */       i4 += ((k - i4) * i2 >> 8);
/* 536 */       i5 += ((l - i5) * i2 >> 8);
/*     */ 
/* 538 */       this.m_pixels[i1] = (0xFF000000 | i3 & 0xFF0000 | i4 & 0xFF00 | i5 & 0xFF);
/*     */     }
/*     */   }
/*     */ 
/*     */   private final void drawLine_plain(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean)
/*     */   {
/* 555 */     int i = 0;
/*     */     int j;
/* 557 */     if (paramBoolean)
/*     */     {
/* 559 */       paramInt4 += paramInt2;
/* 560 */       for (j = 32768 + (paramInt1 << 16); paramInt2 <= paramInt4; ++paramInt2) {
/* 561 */         i = paramInt2 * this.SCREEN_WIDTH + (j >> 16);
/* 562 */         this.m_pixels[i] = this.m_stroke;
/* 563 */         this.m_zbuffer[i] = this.m_z0;
/* 564 */         j += paramInt3;
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 569 */       paramInt4 += paramInt1;
/* 570 */       for (j = 32768 + (paramInt2 << 16); paramInt1 <= paramInt4; ++paramInt1) {
/* 571 */         i = (j >> 16) * this.SCREEN_WIDTH + paramInt1;
/* 572 */         this.m_pixels[i] = this.m_stroke;
/* 573 */         this.m_zbuffer[i] = this.m_z0;
/* 574 */         j += paramInt3;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private final void drawLine_plain_alpha(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean)
/*     */   {
/* 582 */     int i = 0;
/*     */ 
/* 584 */     int j = this.m_stroke & 0xFF0000;
/* 585 */     int k = this.m_stroke & 0xFF00;
/* 586 */     int l = this.m_stroke & 0xFF;
/*     */ 
/* 588 */     int i1 = (int)this.m_a0;
/*     */     int i2;
/*     */     int i3;
/*     */     int i4;
/*     */     int i5;
/*     */     int i6;
/* 590 */     if (paramBoolean) {
/* 591 */       paramInt4 += paramInt2;
/* 592 */       for (i2 = 32768 + (paramInt1 << 16); paramInt2 <= paramInt4; ++paramInt2) {
/* 593 */         i = paramInt2 * this.SCREEN_WIDTH + (i2 >> 16);
/*     */ 
/* 595 */         i3 = i1 >> 16;
/* 596 */         i4 = this.m_pixels[i];
/* 597 */         i5 = i4 & 0xFF00;
/* 598 */         i6 = i4 & 0xFF;
/* 599 */         i4 &= 16711680;
/* 600 */         i4 += ((j - i4) * i3 >> 8);
/* 601 */         i5 += ((k - i5) * i3 >> 8);
/* 602 */         i6 += ((l - i6) * i3 >> 8);
/*     */ 
/* 604 */         this.m_pixels[i] = (0xFF000000 | i4 & 0xFF0000 | i5 & 0xFF00 | i6 & 0xFF);
/*     */ 
/* 606 */         this.m_zbuffer[i] = this.m_z0;
/*     */ 
/* 608 */         i1 = (int)(i1 + this.da);
/* 609 */         i2 += paramInt3;
/*     */       }
/*     */     }
/*     */     else {
/* 613 */       paramInt4 += paramInt1;
/* 614 */       for (i2 = 32768 + (paramInt2 << 16); paramInt1 <= paramInt4; ++paramInt1) {
/* 615 */         i = (i2 >> 16) * this.SCREEN_WIDTH + paramInt1;
/*     */ 
/* 617 */         i3 = i1 >> 16;
/* 618 */         i4 = this.m_pixels[i];
/* 619 */         i5 = i4 & 0xFF00;
/* 620 */         i6 = i4 & 0xFF;
/* 621 */         i4 &= 16711680;
/* 622 */         i4 += ((j - i4) * i3 >> 8);
/* 623 */         i5 += ((k - i5) * i3 >> 8);
/* 624 */         i6 += ((l - i6) * i3 >> 8);
/*     */ 
/* 626 */         this.m_pixels[i] = (0xFF000000 | i4 & 0xFF0000 | i5 & 0xFF00 | i6 & 0xFF);
/*     */ 
/* 628 */         this.m_zbuffer[i] = this.m_z0;
/*     */ 
/* 630 */         i1 = (int)(i1 + this.da);
/* 631 */         i2 += paramInt3;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private final void drawLine_color(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean)
/*     */   {
/* 639 */     int i = 0;
/*     */ 
/* 641 */     int j = (int)this.m_r0;
/* 642 */     int k = (int)this.m_g0;
/* 643 */     int l = (int)this.m_b0;
/*     */     int i1;
/* 645 */     if (paramBoolean) {
/* 646 */       paramInt4 += paramInt2;
/* 647 */       for (i1 = 32768 + (paramInt1 << 16); paramInt2 <= paramInt4; ++paramInt2) {
/* 648 */         i = paramInt2 * this.SCREEN_WIDTH + (i1 >> 16);
/* 649 */         this.m_pixels[i] = (0xFF000000 | j & 0xFF0000 | k >> 8 & 0xFF00 | l >> 16);
/*     */ 
/* 651 */         this.m_zbuffer[i] = this.m_z0;
/* 652 */         j = (int)(j + this.dr);
/* 653 */         k = (int)(k + this.dg);
/* 654 */         l = (int)(l + this.db);
/* 655 */         i1 += paramInt3;
/*     */       }
/*     */     }
/*     */     else {
/* 659 */       paramInt4 += paramInt1;
/* 660 */       for (i1 = 32768 + (paramInt2 << 16); paramInt1 <= paramInt4; ++paramInt1) {
/* 661 */         i = (i1 >> 16) * this.SCREEN_WIDTH + paramInt1;
/* 662 */         this.m_pixels[i] = (0xFF000000 | j & 0xFF0000 | k >> 8 & 0xFF00 | l >> 16);
/*     */ 
/* 664 */         this.m_zbuffer[i] = this.m_z0;
/* 665 */         j = (int)(j + this.dr);
/* 666 */         k = (int)(k + this.dg);
/* 667 */         l = (int)(l + this.db);
/* 668 */         i1 += paramInt3;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private final void drawLine_color_alpha(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean)
/*     */   {
/* 676 */     int i = 0;
/*     */ 
/* 678 */     int j = (int)this.m_r0;
/* 679 */     int k = (int)this.m_g0;
/* 680 */     int l = (int)this.m_b0;
/* 681 */     int i1 = (int)this.m_a0;
/*     */     int i2;
/*     */     int i3;
/*     */     int i4;
/*     */     int i5;
/*     */     int i6;
/*     */     int i7;
/*     */     int i8;
/*     */     int i9;
/* 683 */     if (paramBoolean) {
/* 684 */       paramInt4 += paramInt2;
/* 685 */       for (i2 = 32768 + (paramInt1 << 16); paramInt2 <= paramInt4; ++paramInt2) {
/* 686 */         i = paramInt2 * this.SCREEN_WIDTH + (i2 >> 16);
/*     */ 
/* 688 */         i3 = j & 0xFF0000;
/* 689 */         i4 = k >> 8 & 0xFF00;
/* 690 */         i5 = l >> 16;
/*     */ 
/* 692 */         i6 = this.m_pixels[i];
/* 693 */         i7 = i6 & 0xFF00;
/* 694 */         i8 = i6 & 0xFF;
/* 695 */         i6 &= 16711680;
/*     */ 
/* 697 */         i9 = i1 >> 16;
/*     */ 
/* 699 */         i6 += ((i3 - i6) * i9 >> 8);
/* 700 */         i7 += ((i4 - i7) * i9 >> 8);
/* 701 */         i8 += ((i5 - i8) * i9 >> 8);
/*     */ 
/* 703 */         this.m_pixels[i] = (0xFF000000 | i6 & 0xFF0000 | i7 & 0xFF00 | i8 & 0xFF);
/*     */ 
/* 705 */         this.m_zbuffer[i] = this.m_z0;
/*     */ 
/* 707 */         j = (int)(j + this.dr);
/* 708 */         k = (int)(k + this.dg);
/* 709 */         l = (int)(l + this.db);
/* 710 */         i1 = (int)(i1 + this.da);
/* 711 */         i2 += paramInt3;
/*     */       }
/*     */     }
/*     */     else {
/* 715 */       paramInt4 += paramInt1;
/* 716 */       for (i2 = 32768 + (paramInt2 << 16); paramInt1 <= paramInt4; ++paramInt1) {
/* 717 */         i = (i2 >> 16) * this.SCREEN_WIDTH + paramInt1;
/*     */ 
/* 719 */         i3 = j & 0xFF0000;
/* 720 */         i4 = k >> 8 & 0xFF00;
/* 721 */         i5 = l >> 16;
/*     */ 
/* 723 */         i6 = this.m_pixels[i];
/* 724 */         i7 = i6 & 0xFF00;
/* 725 */         i8 = i6 & 0xFF;
/* 726 */         i6 &= 16711680;
/*     */ 
/* 728 */         i9 = i1 >> 16;
/*     */ 
/* 730 */         i6 += ((i3 - i6) * i9 >> 8);
/* 731 */         i7 += ((i4 - i7) * i9 >> 8);
/* 732 */         i8 += ((i5 - i8) * i9 >> 8);
/*     */ 
/* 734 */         this.m_pixels[i] = (0xFF000000 | i6 & 0xFF0000 | i7 & 0xFF00 | i8 & 0xFF);
/*     */ 
/* 736 */         this.m_zbuffer[i] = this.m_z0;
/*     */ 
/* 738 */         j = (int)(j + this.dr);
/* 739 */         k = (int)(k + this.dg);
/* 740 */         l = (int)(l + this.db);
/* 741 */         i1 = (int)(i1 + this.da);
/* 742 */         i2 += paramInt3;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private final void drawLine_plain_spatial(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean)
/*     */   {
/* 750 */     int i = 0;
/* 751 */     float f = this.m_z0;
/*     */     int j;
/* 753 */     if (paramBoolean) {
/* 754 */       paramInt4 += paramInt2;
/* 755 */       for (j = 32768 + (paramInt1 << 16); paramInt2 <= paramInt4; ++paramInt2) {
/* 756 */         i = paramInt2 * this.SCREEN_WIDTH + (j >> 16);
/* 757 */         if (f <= this.m_zbuffer[i]) {
/* 758 */           this.m_pixels[i] = this.m_stroke;
/* 759 */           this.m_zbuffer[i] = f;
/*     */         }
/* 761 */         f += this.dz;
/* 762 */         j += paramInt3;
/*     */       }
/*     */     }
/*     */     else {
/* 766 */       paramInt4 += paramInt1;
/* 767 */       for (j = 32768 + (paramInt2 << 16); paramInt1 <= paramInt4; ++paramInt1) {
/* 768 */         i = (j >> 16) * this.SCREEN_WIDTH + paramInt1;
/* 769 */         if (f <= this.m_zbuffer[i]) {
/* 770 */           this.m_pixels[i] = this.m_stroke;
/* 771 */           this.m_zbuffer[i] = f;
/*     */         }
/* 773 */         f += this.dz;
/* 774 */         j += paramInt3;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private final void drawLine_plain_alpha_spatial(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean)
/*     */   {
/* 782 */     int i = 0;
/* 783 */     float f = this.m_z0;
/*     */ 
/* 785 */     int j = this.m_stroke & 0xFF0000;
/* 786 */     int k = this.m_stroke & 0xFF00;
/* 787 */     int l = this.m_stroke & 0xFF;
/*     */ 
/* 789 */     int i1 = (int)this.m_a0;
/*     */     int i2;
/*     */     int i3;
/*     */     int i4;
/*     */     int i5;
/*     */     int i6;
/* 791 */     if (paramBoolean) {
/* 792 */       paramInt4 += paramInt2;
/* 793 */       for (i2 = 32768 + (paramInt1 << 16); paramInt2 <= paramInt4; ++paramInt2) {
/* 794 */         i = paramInt2 * this.SCREEN_WIDTH + (i2 >> 16);
/*     */ 
/* 796 */         if (f <= this.m_zbuffer[i]) {
/* 797 */           i3 = i1 >> 16;
/* 798 */           i4 = this.m_pixels[i];
/* 799 */           i5 = i4 & 0xFF00;
/* 800 */           i6 = i4 & 0xFF;
/* 801 */           i4 &= 16711680;
/* 802 */           i4 += ((j - i4) * i3 >> 8);
/* 803 */           i5 += ((k - i5) * i3 >> 8);
/* 804 */           i6 += ((l - i6) * i3 >> 8);
/*     */ 
/* 806 */           this.m_pixels[i] = (0xFF000000 | i4 & 0xFF0000 | i5 & 0xFF00 | i6 & 0xFF);
/*     */         }
/*     */ 
/* 810 */         f += this.dz;
/* 811 */         i1 = (int)(i1 + this.da);
/* 812 */         i2 += paramInt3;
/*     */       }
/*     */     }
/*     */     else {
/* 816 */       paramInt4 += paramInt1;
/* 817 */       for (i2 = 32768 + (paramInt2 << 16); paramInt1 <= paramInt4; ++paramInt1) {
/* 818 */         i = (i2 >> 16) * this.SCREEN_WIDTH + paramInt1;
/*     */ 
/* 820 */         if (f <= this.m_zbuffer[i]) {
/* 821 */           i3 = i1 >> 16;
/* 822 */           i4 = this.m_pixels[i];
/* 823 */           i5 = i4 & 0xFF00;
/* 824 */           i6 = i4 & 0xFF;
/* 825 */           i4 &= 16711680;
/* 826 */           i4 += ((j - i4) * i3 >> 8);
/* 827 */           i5 += ((k - i5) * i3 >> 8);
/* 828 */           i6 += ((l - i6) * i3 >> 8);
/*     */ 
/* 830 */           this.m_pixels[i] = (0xFF000000 | i4 & 0xFF0000 | i5 & 0xFF00 | i6 & 0xFF);
/*     */         }
/*     */ 
/* 834 */         f += this.dz;
/* 835 */         i1 = (int)(i1 + this.da);
/* 836 */         i2 += paramInt3;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private final void drawLine_color_spatial(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean)
/*     */   {
/* 844 */     int i = 0;
/* 845 */     float f = this.m_z0;
/*     */ 
/* 847 */     int j = (int)this.m_r0;
/* 848 */     int k = (int)this.m_g0;
/* 849 */     int l = (int)this.m_b0;
/*     */     int i1;
/* 851 */     if (paramBoolean) {
/* 852 */       paramInt4 += paramInt2;
/* 853 */       for (i1 = 32768 + (paramInt1 << 16); paramInt2 <= paramInt4; ++paramInt2) {
/* 854 */         i = paramInt2 * this.SCREEN_WIDTH + (i1 >> 16);
/*     */ 
/* 856 */         if (f <= this.m_zbuffer[i]) {
/* 857 */           this.m_pixels[i] = (0xFF000000 | j & 0xFF0000 | k >> 8 & 0xFF00 | l >> 16);
/*     */ 
/* 859 */           this.m_zbuffer[i] = f;
/*     */         }
/* 861 */         f += this.dz;
/* 862 */         j = (int)(j + this.dr);
/* 863 */         k = (int)(k + this.dg);
/* 864 */         l = (int)(l + this.db);
/* 865 */         label314: i1 += paramInt3;
/*     */       }
/*     */     } else {
/* 868 */       paramInt4 += paramInt1;
/* 869 */       i1 = 32768 + (paramInt2 << 16); break label314:
/*     */       while (true) { i = (i1 >> 16) * this.SCREEN_WIDTH + paramInt1;
/* 871 */         if (f <= this.m_zbuffer[i]) {
/* 872 */           this.m_pixels[i] = (0xFF000000 | j & 0xFF0000 | k >> 8 & 0xFF00 | l >> 16);
/*     */ 
/* 874 */           this.m_zbuffer[i] = f;
/*     */         }
/* 876 */         f += this.dz;
/* 877 */         j = (int)(j + this.dr);
/* 878 */         k = (int)(k + this.dg);
/* 879 */         l = (int)(l + this.db);
/* 880 */         i1 += paramInt3;
/*     */ 
/* 869 */         ++paramInt1; if (paramInt1 > paramInt4)
/*     */         {
/* 882 */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private final void drawLine_color_alpha_spatial(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) {
/* 889 */     int i = 0;
/* 890 */     float f = this.m_z0;
/*     */ 
/* 892 */     int j = (int)this.m_r0;
/* 893 */     int k = (int)this.m_g0;
/* 894 */     int l = (int)this.m_b0;
/* 895 */     int i1 = (int)this.m_a0;
/*     */     int i2;
/*     */     int i3;
/*     */     int i4;
/*     */     int i5;
/*     */     int i6;
/*     */     int i7;
/*     */     int i8;
/*     */     int i9;
/* 897 */     if (paramBoolean) {
/* 898 */       paramInt4 += paramInt2;
/* 899 */       for (i2 = 32768 + (paramInt1 << 16); paramInt2 <= paramInt4; ++paramInt2) {
/* 900 */         i = paramInt2 * this.SCREEN_WIDTH + (i2 >> 16);
/*     */ 
/* 902 */         if (f <= this.m_zbuffer[i]) {
/* 903 */           i3 = j & 0xFF0000;
/* 904 */           i4 = k >> 8 & 0xFF00;
/* 905 */           i5 = l >> 16;
/*     */ 
/* 907 */           i6 = this.m_pixels[i];
/* 908 */           i7 = i6 & 0xFF00;
/* 909 */           i8 = i6 & 0xFF;
/* 910 */           i6 &= 16711680;
/*     */ 
/* 912 */           i9 = i1 >> 16;
/*     */ 
/* 914 */           i6 += ((i3 - i6) * i9 >> 8);
/* 915 */           i7 += ((i4 - i7) * i9 >> 8);
/* 916 */           i8 += ((i5 - i8) * i9 >> 8);
/*     */ 
/* 918 */           this.m_pixels[i] = (0xFF000000 | i6 & 0xFF0000 | i7 & 0xFF00 | i8 & 0xFF);
/*     */ 
/* 920 */           this.m_zbuffer[i] = f;
/*     */         }
/* 922 */         f += this.dz;
/* 923 */         j = (int)(j + this.dr);
/* 924 */         k = (int)(k + this.dg);
/* 925 */         l = (int)(l + this.db);
/* 926 */         i1 = (int)(i1 + this.da);
/* 927 */         i2 += paramInt3;
/*     */       }
/*     */     }
/*     */     else {
/* 931 */       paramInt4 += paramInt1;
/* 932 */       for (i2 = 32768 + (paramInt2 << 16); paramInt1 <= paramInt4; ++paramInt1) {
/* 933 */         i = (i2 >> 16) * this.SCREEN_WIDTH + paramInt1;
/*     */ 
/* 935 */         if (f <= this.m_zbuffer[i]) {
/* 936 */           i3 = j & 0xFF0000;
/* 937 */           i4 = k >> 8 & 0xFF00;
/* 938 */           i5 = l >> 16;
/*     */ 
/* 940 */           i6 = this.m_pixels[i];
/* 941 */           i7 = i6 & 0xFF00;
/* 942 */           i8 = i6 & 0xFF;
/* 943 */           i6 &= 16711680;
/*     */ 
/* 945 */           i9 = i1 >> 16;
/*     */ 
/* 947 */           i6 += ((i3 - i6) * i9 >> 8);
/* 948 */           i7 += ((i4 - i7) * i9 >> 8);
/* 949 */           i8 += ((i5 - i8) * i9 >> 8);
/*     */ 
/* 951 */           this.m_pixels[i] = (0xFF000000 | i6 & 0xFF0000 | i7 & 0xFF00 | i8 & 0xFF);
/*     */ 
/* 953 */           this.m_zbuffer[i] = f;
/*     */         }
/* 955 */         f += this.dz;
/* 956 */         j = (int)(j + this.dr);
/* 957 */         k = (int)(k + this.dg);
/* 958 */         l = (int)(l + this.db);
/* 959 */         i1 = (int)(i1 + this.da);
/* 960 */         i2 += paramInt3;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   void drawLine_smooth(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean)
/*     */   {
/* 969 */     int k = 0;
/*     */ 
/* 973 */     float f = this.m_z0;
/*     */ 
/* 975 */     int i2 = (int)this.m_r0;
/* 976 */     int i3 = (int)this.m_g0;
/* 977 */     int i4 = (int)this.m_b0;
/* 978 */     int i5 = (int)this.m_a0;
/*     */     int i;
/*     */     int j;
/*     */     int i1;
/*     */     int i6;
/*     */     int i7;
/*     */     int i8;
/*     */     int i9;
/*     */     int i10;
/*     */     int i11;
/*     */     int i12;
/*     */     int l;
/* 980 */     if (paramBoolean) {
/* 981 */       i = paramInt1 << 16;
/* 982 */       j = paramInt2 << 16;
/*     */ 
/* 984 */       i1 = paramInt4 + paramInt2;
/*     */ 
/* 986 */       while (j >> 16 < i1)
/*     */       {
/* 988 */         k = (j >> 16) * this.SCREEN_WIDTH + (i >> 16);
/*     */ 
/* 990 */         i6 = i2 & 0xFF0000;
/* 991 */         i7 = i3 >> 8 & 0xFF00;
/* 992 */         i8 = i4 >> 16;
/*     */ 
/* 994 */         if (f <= this.m_zbuffer[k]) {
/* 995 */           i9 = ((i ^ 0xFFFFFFFF) >> 8 & 0xFF) * (i5 >> 16) >> 8;
/*     */ 
/* 997 */           i10 = this.m_pixels[k];
/* 998 */           i11 = i10 & 0xFF00;
/* 999 */           i12 = i10 & 0xFF;
/* 1000 */           i10 &= 16711680;
/*     */ 
/* 1002 */           i10 += ((i6 - i10) * i9 >> 8);
/* 1003 */           i11 += ((i7 - i11) * i9 >> 8);
/* 1004 */           i12 += ((i8 - i12) * i9 >> 8);
/*     */ 
/* 1006 */           this.m_pixels[k] = (0xFF000000 | i10 & 0xFF0000 | i11 & 0xFF00 | i12 & 0xFF);
/*     */ 
/* 1008 */           this.m_zbuffer[k] = f;
/*     */         }
/*     */ 
/* 1014 */         l = (i >> 16) + 1;
/* 1015 */         if (l >= this.SCREEN_WIDTH) {
/* 1016 */           i += paramInt3;
/* 1017 */           j += 65536;
/*     */         }
/*     */         else
/*     */         {
/* 1021 */           k = (j >> 16) * this.SCREEN_WIDTH + l;
/*     */ 
/* 1023 */           if (f <= this.m_zbuffer[k]) {
/* 1024 */             i9 = (i >> 8 & 0xFF) * (i5 >> 16) >> 8;
/*     */ 
/* 1026 */             i10 = this.m_pixels[k];
/* 1027 */             i11 = i10 & 0xFF00;
/* 1028 */             i12 = i10 & 0xFF;
/* 1029 */             i10 &= 16711680;
/*     */ 
/* 1031 */             i10 += ((i6 - i10) * i9 >> 8);
/* 1032 */             i11 += ((i7 - i11) * i9 >> 8);
/* 1033 */             i12 += ((i8 - i12) * i9 >> 8);
/*     */ 
/* 1035 */             this.m_pixels[k] = (0xFF000000 | i10 & 0xFF0000 | i11 & 0xFF00 | i12 & 0xFF);
/*     */ 
/* 1037 */             this.m_zbuffer[k] = f;
/*     */           }
/*     */ 
/* 1040 */           i += paramInt3;
/* 1041 */           j += 65536;
/*     */ 
/* 1043 */           f += this.dz;
/* 1044 */           i2 = (int)(i2 + this.dr);
/* 1045 */           i3 = (int)(i3 + this.dg);
/* 1046 */           i4 = (int)(i4 + this.db);
/* 1047 */           i5 = (int)(i5 + this.da);
/*     */         }
/*     */       }
/*     */     } else {
/* 1051 */       i = paramInt1 << 16;
/* 1052 */       j = paramInt2 << 16;
/* 1053 */       i1 = paramInt4 + paramInt1;
/*     */ 
/* 1055 */       while (i >> 16 < i1) {
/* 1056 */         k = (j >> 16) * this.SCREEN_WIDTH + (i >> 16);
/*     */ 
/* 1058 */         i6 = i2 & 0xFF0000;
/* 1059 */         i7 = i3 >> 8 & 0xFF00;
/* 1060 */         i8 = i4 >> 16;
/*     */ 
/* 1062 */         if (f <= this.m_zbuffer[k]) {
/* 1063 */           i9 = ((j ^ 0xFFFFFFFF) >> 8 & 0xFF) * (i5 >> 16) >> 8;
/*     */ 
/* 1065 */           i10 = this.m_pixels[k];
/* 1066 */           i11 = i10 & 0xFF00;
/* 1067 */           i12 = i10 & 0xFF;
/* 1068 */           i10 &= 16711680;
/*     */ 
/* 1070 */           i10 += ((i6 - i10) * i9 >> 8);
/* 1071 */           i11 += ((i7 - i11) * i9 >> 8);
/* 1072 */           i12 += ((i8 - i12) * i9 >> 8);
/*     */ 
/* 1074 */           this.m_pixels[k] = (0xFF000000 | i10 & 0xFF0000 | i11 & 0xFF00 | i12 & 0xFF);
/*     */ 
/* 1076 */           this.m_zbuffer[k] = f;
/*     */         }
/*     */ 
/* 1080 */         l = (j >> 16) + 1;
/* 1081 */         if (l >= this.SCREEN_HEIGHT) {
/* 1082 */           i += 65536;
/* 1083 */           j += paramInt3;
/*     */         }
/*     */         else
/*     */         {
/* 1087 */           k = l * this.SCREEN_WIDTH + (i >> 16);
/*     */ 
/* 1089 */           if (f <= this.m_zbuffer[k]) {
/* 1090 */             i9 = (j >> 8 & 0xFF) * (i5 >> 16) >> 8;
/*     */ 
/* 1092 */             i10 = this.m_pixels[k];
/* 1093 */             i11 = i10 & 0xFF00;
/* 1094 */             i12 = i10 & 0xFF;
/* 1095 */             i10 &= 16711680;
/*     */ 
/* 1097 */             i10 += ((i6 - i10) * i9 >> 8);
/* 1098 */             i11 += ((i7 - i11) * i9 >> 8);
/* 1099 */             i12 += ((i8 - i12) * i9 >> 8);
/*     */ 
/* 1101 */             this.m_pixels[k] = (0xFF000000 | i10 & 0xFF0000 | i11 & 0xFF00 | i12 & 0xFF);
/*     */ 
/* 1103 */             this.m_zbuffer[k] = f;
/*     */           }
/*     */ 
/* 1106 */           i += 65536;
/* 1107 */           j += paramInt3;
/*     */ 
/* 1109 */           f += this.dz;
/* 1110 */           i2 = (int)(i2 + this.dr);
/* 1111 */           i3 = (int)(i3 + this.dg);
/* 1112 */           i4 = (int)(i4 + this.db);
/* 1113 */           i5 = (int)(i5 + this.da);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public PLine(PGraphics3 paramPGraphics3)
/*     */   {
/* 105 */     this.INTERPOLATE_Z = false;
/*     */ 
/* 107 */     this.x_array = new float[2];
/* 108 */     this.y_array = new float[2];
/* 109 */     this.z_array = new float[2];
/* 110 */     this.r_array = new float[2];
/* 111 */     this.g_array = new float[2];
/* 112 */     this.b_array = new float[2];
/* 113 */     this.a_array = new float[2];
/*     */ 
/* 115 */     this.parent = paramPGraphics3;
/*     */   }
/*     */ }

/* Location:           /Users/mfeyereisen/Desktop/Sources 2/common/
 * Qualified Name:     processing.core.PLine
 * JD-Core Version:    0.5.3
 */