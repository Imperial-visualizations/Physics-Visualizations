/*      */ package processing.core;
/*      */ 
/*      */ import F;
/*      */ import java.awt.Toolkit;
/*      */ import java.awt.image.DirectColorModel;
/*      */ import java.awt.image.MemoryImageSource;
/*      */ 
/*      */ public class PGraphics3 extends PGraphics
/*      */ {
/*      */   static final int LIGHT_AMBIENT_R = 0;
/*      */   static final int LIGHT_AMBIENT_G = 1;
/*      */   static final int LIGHT_AMBIENT_B = 2;
/*      */   static final int LIGHT_DIFFUSE_R = 3;
/*      */   static final int LIGHT_DIFFUSE_G = 4;
/*      */   static final int LIGHT_DIFFUSE_B = 5;
/*      */   static final int LIGHT_SPECULAR_R = 6;
/*      */   static final int LIGHT_SPECULAR_G = 7;
/*      */   static final int LIGHT_SPECULAR_B = 8;
/*      */   static final int LIGHT_COLOR_COUNT = 9;
/*      */   protected static final int MAX_LIGHTS = 8;
/*      */   static final int DEFAULT_LINES = 512;
/*      */   static final int DEFAULT_TRIANGLES = 256;
/*      */   static final int DEFAULT_TEXTURES = 3;
/*      */   public PMatrix modelview;
/*      */   public PMatrix modelviewInv;
/*      */   public PMatrix camera;
/*      */   public PMatrix cameraInv;
/*      */   boolean useBackfaceCulling;
/*      */   public float ambientR;
/*      */   public float ambientG;
/*      */   public float ambientB;
/*      */   public int ambientRi;
/*      */   public int ambientGi;
/*      */   public int ambientBi;
/*      */   public float specularR;
/*      */   public float specularG;
/*      */   public float specularB;
/*      */   public float specularA;
/*      */   public int specularRi;
/*      */   public int specularGi;
/*      */   public int specularBi;
/*      */   public int specularAi;
/*      */   public float emissiveR;
/*      */   public float emissiveG;
/*      */   public float emissiveB;
/*      */   public int emissiveRi;
/*      */   public int emissiveGi;
/*      */   public int emissiveBi;
/*      */   public float shininess;
/*      */   private boolean lightingDependsOnVertexPosition;
/*      */   public float[] tempLightingContribution;
/*      */   public float[] worldNormal;
/*      */   public float cameraFOV;
/*      */   public float cameraX;
/*      */   public float cameraY;
/*      */   public float cameraZ;
/*      */   public float cameraNear;
/*      */   public float cameraFar;
/*      */   public float cameraAspect;
/*      */   public boolean manipulatingCamera;
/*      */   public PMatrix projection;
/*      */   public PMatrix forwardTransform;
/*      */   public PMatrix reverseTransform;
/*      */   public int[] stencil;
/*      */   public float[] zbuffer;
/*      */   public int lightCount;
/*      */   public int[] lights;
/*      */   public float[] lightsX;
/*      */   public float[] lightsY;
/*      */   public float[] lightsZ;
/*      */   public float[] lightsNX;
/*      */   public float[] lightsNY;
/*      */   public float[] lightsNZ;
/*      */   public float[] lightsFalloffConstant;
/*      */   public float[] lightsFalloffLinear;
/*      */   public float[] lightsFalloffQuadratic;
/*      */   public float[] lightsSpotAngle;
/*      */   public float[] lightsSpotAngleCos;
/*      */   public float[] lightsSpotConcentration;
/*      */   public float[] lightsDiffuseR;
/*      */   public float[] lightsDiffuseG;
/*      */   public float[] lightsDiffuseB;
/*      */   public float[] lightsSpecularR;
/*      */   public float[] lightsSpecularG;
/*      */   public float[] lightsSpecularB;
/*      */   public float lightSpecularR;
/*      */   public float lightSpecularG;
/*      */   public float lightSpecularB;
/*      */   public float lightFalloffConstant;
/*      */   public float lightFalloffLinear;
/*      */   public float lightFalloffQuadratic;
/*      */   protected int vertex_start;
/*      */   protected int vertex_end;
/*      */   protected int vertex_end_including_clip_verts;
/*      */   int[] vertex_order;
/*      */   public int pathCount;
/*      */   public int[] pathOffset;
/*      */   public int[] pathLength;
/*      */   PLine line;
/*      */   public int[][] lines;
/*      */   public int lineCount;
/*      */   PTriangle triangle;
/*      */   public int[][] triangles;
/*      */   public float[][][] triangleColors;
/*      */   public int triangleCount;
/*      */   int shape_index;
/*      */   public int textureMode;
/*      */   public float textureU;
/*      */   public float textureV;
/*      */   public PImage textureImage;
/*      */   protected PImage[] textures;
/*      */   int texture_index;
/*      */   public float normalX;
/*      */   public float normalY;
/*      */   public float normalZ;
/*      */   public int normalMode;
/*      */   public int normalCount;
/*      */   public int sphereDetail;
/*      */   float[] sphereX;
/*      */   float[] sphereY;
/*      */   float[] sphereZ;
/*      */ 
/*      */   public void resize(int paramInt1, int paramInt2)
/*      */   {
/*  302 */     this.width = paramInt1;
/*  303 */     this.height = paramInt2;
/*  304 */     this.width1 = (this.width - 1);
/*  305 */     this.height1 = (this.height - 1);
/*      */ 
/*  307 */     allocate();
/*      */ 
/*  313 */     this.cameraFOV = 1.047198F;
/*  314 */     this.cameraX = (this.width / 2.0F);
/*  315 */     this.cameraY = (this.height / 2.0F);
/*      */ 
/*  317 */     this.cameraZ = (this.cameraY / tan(this.cameraFOV / 2.0F));
/*  318 */     this.cameraNear = (this.cameraZ / 10.0F);
/*  319 */     this.cameraFar = (this.cameraZ * 10.0F);
/*      */ 
/*  321 */     this.cameraAspect = (this.width / this.height);
/*      */ 
/*  326 */     this.lightsX = new float[8];
/*  327 */     this.lightsY = new float[8];
/*  328 */     this.lightsZ = new float[8];
/*  329 */     this.lightsDiffuseR = new float[8];
/*  330 */     this.lightsDiffuseG = new float[8];
/*  331 */     this.lightsDiffuseB = new float[8];
/*  332 */     this.lightsSpecularR = new float[8];
/*  333 */     this.lightsSpecularG = new float[8];
/*  334 */     this.lightsSpecularB = new float[8];
/*  335 */     this.lights = new int[8];
/*  336 */     this.lightsNX = new float[8];
/*  337 */     this.lightsNY = new float[8];
/*  338 */     this.lightsNZ = new float[8];
/*  339 */     this.lightsFalloffConstant = new float[8];
/*  340 */     this.lightsFalloffLinear = new float[8];
/*  341 */     this.lightsFalloffQuadratic = new float[8];
/*  342 */     this.lightsSpotAngle = new float[8];
/*  343 */     this.lightsSpotAngleCos = new float[8];
/*  344 */     this.lightsSpotConcentration = new float[8];
/*      */ 
/*  352 */     this.projection = new PMatrix();
/*      */ 
/*  354 */     this.modelview = new PMatrix(32);
/*  355 */     this.modelviewInv = new PMatrix(32);
/*  356 */     this.forwardTransform = this.modelview;
/*  357 */     this.reverseTransform = this.modelviewInv;
/*      */ 
/*  359 */     this.camera = new PMatrix();
/*  360 */     this.cameraInv = new PMatrix();
/*      */ 
/*  363 */     camera();
/*      */ 
/*  368 */     perspective();
/*      */   }
/*      */ 
/*      */   protected void allocate()
/*      */   {
/*  373 */     this.pixelCount = (this.width * this.height);
/*  374 */     this.pixels = new int[this.pixelCount];
/*      */ 
/*  379 */     this.backgroundColor |= -16777216;
/*  380 */     for (int i = 0; i < this.pixelCount; ++i) this.pixels[i] = this.backgroundColor;
/*      */ 
/*  383 */     this.cm = new DirectColorModel(32, 16711680, 65280, 255);
/*  384 */     this.mis = new MemoryImageSource(this.width, this.height, this.pixels, 0, this.width);
/*  385 */     this.mis.setFullBufferUpdates(true);
/*  386 */     this.mis.setAnimated(true);
/*  387 */     this.image = Toolkit.getDefaultToolkit().createImage(this.mis);
/*      */ 
/*  389 */     this.zbuffer = new float[this.pixelCount];
/*  390 */     this.stencil = new int[this.pixelCount];
/*      */ 
/*  392 */     this.line = new PLine(this);
/*  393 */     this.triangle = new PTriangle(this);
/*      */   }
/*      */ 
/*      */   public void beginFrame()
/*      */   {
/*  398 */     super.beginFrame();
/*      */ 
/*  400 */     this.modelview.set(this.camera);
/*  401 */     this.modelviewInv.set(this.cameraInv);
/*      */ 
/*  404 */     this.lightCount = 0;
/*  405 */     this.lightingDependsOnVertexPosition = false;
/*  406 */     lightFalloff(1.0F, 0.0F, 0.0F);
/*  407 */     lightSpecular(0.0F, 0.0F, 0.0F);
/*      */ 
/*  410 */     this.lineCount = 0;
/*  411 */     if (this.line != null) this.line.reset();
/*  412 */     this.pathCount = 0;
/*      */ 
/*  415 */     this.triangleCount = 0;
/*  416 */     if (this.triangle != null) this.triangle.reset();
/*      */ 
/*  418 */     this.vertex_start = 0;
/*      */ 
/*  422 */     this.texture_index = 0;
/*      */ 
/*  424 */     normal(0.0F, 0.0F, 1.0F);
/*      */   }
/*      */ 
/*      */   public void endFrame()
/*      */   {
/*  432 */     if (this.hints[7] != 0) {
/*  433 */       if (this.triangleCount > 0) {
/*  434 */         depth_sort_triangles();
/*  435 */         render_triangles();
/*      */       }
/*  437 */       if (this.lineCount > 0) {
/*  438 */         depth_sort_lines();
/*  439 */         render_lines();
/*      */       }
/*      */     }
/*      */ 
/*  443 */     super.endFrame();
/*      */   }
/*      */ 
/*      */   public void defaults()
/*      */   {
/*  448 */     super.defaults();
/*      */ 
/*  450 */     this.manipulatingCamera = false;
/*  451 */     this.forwardTransform = this.modelview;
/*  452 */     this.reverseTransform = this.modelviewInv;
/*      */ 
/*  454 */     perspective();
/*      */ 
/*  457 */     textureMode(2);
/*      */ 
/*  459 */     emissive(0.0F);
/*  460 */     specular(0.5F);
/*  461 */     shininess(1.0F);
/*      */   }
/*      */ 
/*      */   public void beginShape(int paramInt)
/*      */   {
/*  470 */     this.shape = paramInt;
/*      */ 
/*  472 */     this.shape_index += 1;
/*  473 */     if (this.shape_index == -1) {
/*  474 */       this.shape_index = 0;
/*      */     }
/*      */ 
/*  477 */     if (this.hints[7] != 0)
/*      */     {
/*  480 */       this.vertex_start = this.vertexCount;
/*  481 */       this.vertex_end = 0;
/*      */     }
/*      */     else
/*      */     {
/*  486 */       this.vertexCount = 0;
/*  487 */       if (this.line != null) this.line.reset();
/*  488 */       this.lineCount = 0;
/*  489 */       this.pathCount = 0;
/*  490 */       if (this.triangle != null) this.triangle.reset();
/*  491 */       this.triangleCount = 0;
/*      */     }
/*  493 */     this.textureImage = null;
/*      */ 
/*  495 */     this.splineVertexCount = 0;
/*  496 */     this.normalMode = 0;
/*  497 */     this.normalCount = 0;
/*      */   }
/*      */ 
/*      */   public void normal(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/*  518 */     this.normalX = paramFloat1;
/*  519 */     this.normalY = paramFloat2;
/*  520 */     this.normalZ = paramFloat3;
/*      */ 
/*  524 */     if (this.shape != 0) {
/*  525 */       if (this.normalCount == 0) {
/*  526 */         for (int i = this.vertex_start; i < this.vertexCount; ++i) {
/*  527 */           this.vertices[i][17] = this.normalX;
/*  528 */           this.vertices[i][18] = this.normalY;
/*  529 */           this.vertices[i][19] = this.normalZ;
/*      */         }
/*      */       }
/*      */ 
/*  533 */       this.normalCount += 1;
/*  534 */       if (this.normalCount == 1)
/*      */       {
/*  536 */         this.normalMode = 1;
/*      */       }
/*      */       else
/*      */       {
/*  540 */         this.normalMode = 2;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void textureMode(int paramInt)
/*      */   {
/*  551 */     this.textureMode = paramInt;
/*      */   }
/*      */ 
/*      */   public void texture(PImage paramPImage)
/*      */   {
/*  562 */     this.textureImage = paramPImage;
/*      */ 
/*  564 */     if (this.texture_index == this.textures.length - 1) {
/*  565 */       PImage[] arrayOfPImage = new PImage[this.texture_index << 1];
/*  566 */       System.arraycopy(this.textures, 0, arrayOfPImage, 0, this.texture_index);
/*  567 */       this.textures = arrayOfPImage;
/*      */     }
/*      */ 
/*  571 */     if (this.textures[0] != null) {
/*  572 */       this.texture_index += 1;
/*      */     }
/*      */ 
/*  575 */     this.textures[this.texture_index] = paramPImage;
/*      */   }
/*      */ 
/*      */   public void vertex(float paramFloat1, float paramFloat2)
/*      */   {
/*  580 */     setup_vertex(paramFloat1, paramFloat2, 0.0F);
/*      */   }
/*      */ 
/*      */   public void vertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/*  585 */     texture_vertex(paramFloat3, paramFloat4);
/*  586 */     setup_vertex(paramFloat1, paramFloat2, 0.0F);
/*      */   }
/*      */ 
/*      */   public void vertex(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/*  591 */     setup_vertex(paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public void vertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5)
/*      */   {
/*  597 */     texture_vertex(paramFloat4, paramFloat5);
/*  598 */     setup_vertex(paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   protected void setup_vertex(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/*  603 */     if (this.vertexCount == this.vertices.length) {
/*  604 */       localObject = new float[this.vertexCount << 1][36];
/*  605 */       System.arraycopy(this.vertices, 0, localObject, 0, this.vertexCount);
/*  606 */       this.vertices = ((F)localObject);
/*      */     }
/*      */ 
/*  609 */     Object localObject = this.vertices[(this.vertexCount++)];
/*      */ 
/*  616 */     this.splineVertexCount = 0;
/*      */ 
/*  618 */     localObject[9] = paramFloat1;
/*  619 */     localObject[10] = paramFloat2;
/*  620 */     localObject[11] = paramFloat3;
/*      */ 
/*  622 */     if (this.fill) {
/*  623 */       localObject[3] = this.fillR;
/*  624 */       localObject[4] = this.fillG;
/*  625 */       localObject[5] = this.fillB;
/*  626 */       localObject[6] = this.fillA;
/*      */ 
/*  628 */       localObject[24] = this.ambientR;
/*  629 */       localObject[25] = this.ambientG;
/*  630 */       localObject[26] = this.ambientB;
/*      */ 
/*  632 */       localObject[27] = this.specularR;
/*  633 */       localObject[28] = this.specularG;
/*  634 */       localObject[29] = this.specularB;
/*  635 */       localObject[30] = this.specularA;
/*      */ 
/*  637 */       localObject[31] = this.shininess;
/*      */ 
/*  639 */       localObject[32] = this.emissiveR;
/*  640 */       localObject[33] = this.emissiveG;
/*  641 */       localObject[34] = this.emissiveB;
/*      */     }
/*      */ 
/*  644 */     if (this.stroke) {
/*  645 */       localObject[12] = this.strokeR;
/*  646 */       localObject[13] = this.strokeG;
/*  647 */       localObject[14] = this.strokeB;
/*  648 */       localObject[15] = this.strokeA;
/*  649 */       localObject[16] = this.strokeWeight;
/*      */     }
/*      */ 
/*  652 */     if (this.textureImage != null) {
/*  653 */       localObject[7] = this.textureU;
/*  654 */       localObject[8] = this.textureV;
/*      */     }
/*      */ 
/*  657 */     localObject[17] = this.normalX;
/*  658 */     localObject[18] = this.normalY;
/*  659 */     localObject[19] = this.normalZ;
/*      */ 
/*  661 */     localObject[35] = 0.0F;
/*      */   }
/*      */ 
/*      */   protected void texture_vertex(float paramFloat1, float paramFloat2)
/*      */   {
/*  675 */     if (this.textureImage == null) {
/*  676 */       throw new RuntimeException("need to set an image with texture() before using u and v coordinates");
/*      */     }
/*      */ 
/*  679 */     if (this.textureMode == 2) {
/*  680 */       paramFloat1 /= this.textureImage.width;
/*  681 */       paramFloat2 /= this.textureImage.height;
/*      */     }
/*      */ 
/*  684 */     this.textureU = paramFloat1;
/*  685 */     this.textureV = paramFloat2;
/*      */ 
/*  687 */     if (this.textureU < 0.0F) this.textureU = 0.0F;
/*  688 */     else if (this.textureU > 1.0F) this.textureU = 1.0F;
/*      */ 
/*  690 */     if (this.textureV < 0.0F) { this.textureV = 0.0F; } else {
/*  691 */       if (this.textureV <= 1.0F) return; this.textureV = 1.0F;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void spline_vertex(float paramFloat1, float paramFloat2, float paramFloat3, boolean paramBoolean)
/*      */   {
/*  698 */     if (this.splineVertices == null) {
/*  699 */       this.splineVertices = new float[128][36];
/*      */     }
/*      */ 
/*  703 */     if (this.splineVertexCount == 128) {
/*  704 */       System.arraycopy(this.splineVertices[125], 0, this.splineVertices[0], 0, 36);
/*      */ 
/*  706 */       System.arraycopy(this.splineVertices[126], 0, this.splineVertices[1], 0, 36);
/*      */ 
/*  708 */       System.arraycopy(this.splineVertices[127], 0, this.splineVertices[2], 0, 36);
/*      */ 
/*  710 */       this.splineVertexCount = 3;
/*      */     }
/*      */ 
/*  713 */     float[] arrayOfFloat = this.splineVertices[this.splineVertexCount];
/*      */ 
/*  715 */     arrayOfFloat[9] = paramFloat1;
/*  716 */     arrayOfFloat[10] = paramFloat2;
/*  717 */     arrayOfFloat[11] = paramFloat3;
/*      */ 
/*  719 */     if (this.fill) {
/*  720 */       arrayOfFloat[3] = this.fillR;
/*  721 */       arrayOfFloat[4] = this.fillG;
/*  722 */       arrayOfFloat[5] = this.fillB;
/*  723 */       arrayOfFloat[6] = this.fillA;
/*      */     }
/*      */ 
/*  726 */     if (this.stroke) {
/*  727 */       arrayOfFloat[12] = this.strokeR;
/*  728 */       arrayOfFloat[13] = this.strokeG;
/*  729 */       arrayOfFloat[14] = this.strokeB;
/*  730 */       arrayOfFloat[15] = this.strokeA;
/*  731 */       arrayOfFloat[16] = this.strokeWeight;
/*      */     }
/*      */ 
/*  734 */     if (this.textureImage != null) {
/*  735 */       arrayOfFloat[7] = this.textureU;
/*  736 */       arrayOfFloat[8] = this.textureV;
/*      */     }
/*      */ 
/*  739 */     arrayOfFloat[17] = this.normalX;
/*  740 */     arrayOfFloat[18] = this.normalY;
/*  741 */     arrayOfFloat[19] = this.normalZ;
/*      */ 
/*  743 */     this.splineVertexCount += 1;
/*      */ 
/*  746 */     if (this.splineVertexCount > 3)
/*  747 */       if (paramBoolean) {
/*  748 */         if (this.splineVertexCount % 4 == 0) {
/*  749 */           if (!(this.bezier_inited)) bezier_init();
/*  750 */           spline3_segment(this.splineVertexCount - 4, this.splineVertexCount - 4, this.bezier_draw, this.bezier_detail);
/*      */         }
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  756 */         if (!(this.curve_inited)) curve_init();
/*  757 */         spline3_segment(this.splineVertexCount - 4, this.splineVertexCount - 3, this.curve_draw, this.curve_detail);
/*      */       }
/*      */   }
/*      */ 
/*      */   public void bezierVertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/*  772 */     bezierVertex(paramFloat1, paramFloat2, 0.0F, paramFloat3, paramFloat4, 0.0F, paramFloat5, paramFloat6, 0.0F);
/*      */   }
/*      */ 
/*      */   public void bezierVertex(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9)
/*      */   {
/*      */     float[] arrayOfFloat;
/*  782 */     if (this.splineVertexCount > 0) {
/*  783 */       arrayOfFloat = this.splineVertices[(this.splineVertexCount - 1)];
/*  784 */       spline_vertex(arrayOfFloat[9], arrayOfFloat[10], arrayOfFloat[11], true);
/*      */     }
/*  786 */     else if (this.vertexCount > 0)
/*      */     {
/*  788 */       arrayOfFloat = this.vertices[(this.vertexCount - 1)];
/*  789 */       spline_vertex(arrayOfFloat[9], arrayOfFloat[10], arrayOfFloat[11], true);
/*      */     }
/*      */     else {
/*  792 */       throw new RuntimeException("A call to vertex() must be used before bezierVertex()");
/*      */     }
/*      */ 
/*  795 */     spline_vertex(paramFloat1, paramFloat2, paramFloat3, true);
/*  796 */     spline_vertex(paramFloat4, paramFloat5, paramFloat6, true);
/*  797 */     spline_vertex(paramFloat7, paramFloat8, paramFloat9, true);
/*      */   }
/*      */ 
/*      */   public void curveVertex(float paramFloat1, float paramFloat2)
/*      */   {
/*  805 */     spline_vertex(paramFloat1, paramFloat2, 0.0F, false);
/*      */   }
/*      */ 
/*      */   public void curveVertex(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/*  812 */     spline_vertex(paramFloat1, paramFloat2, paramFloat3, false);
/*      */   }
/*      */ 
/*      */   public void endShape()
/*      */   {
/*  817 */     this.vertex_end = this.vertexCount;
/*  818 */     this.vertex_end_including_clip_verts = this.vertex_end;
/*      */ 
/*  822 */     if (this.vertexCount == 0) {
/*  823 */       this.shape = 0;
/*  824 */       return;
/*      */     }
/*      */ 
/*  833 */     for (int i = this.vertex_start; i < this.vertex_end; ++i) {
/*  834 */       float[] arrayOfFloat1 = this.vertices[i];
/*      */ 
/*  836 */       arrayOfFloat1[20] = (this.modelview.m00 * arrayOfFloat1[9] + this.modelview.m01 * arrayOfFloat1[10] + this.modelview.m02 * arrayOfFloat1[11] + this.modelview.m03);
/*      */ 
/*  839 */       arrayOfFloat1[21] = (this.modelview.m10 * arrayOfFloat1[9] + this.modelview.m11 * arrayOfFloat1[10] + this.modelview.m12 * arrayOfFloat1[11] + this.modelview.m13);
/*      */ 
/*  842 */       arrayOfFloat1[22] = (this.modelview.m20 * arrayOfFloat1[9] + this.modelview.m21 * arrayOfFloat1[10] + this.modelview.m22 * arrayOfFloat1[11] + this.modelview.m23);
/*      */ 
/*  845 */       arrayOfFloat1[23] = (this.modelview.m30 * arrayOfFloat1[9] + this.modelview.m31 * arrayOfFloat1[10] + this.modelview.m32 * arrayOfFloat1[11] + this.modelview.m33);
/*      */ 
/*  850 */       if ((arrayOfFloat1[23] != 0.0F) && (arrayOfFloat1[23] != 1.0F)) {
/*  851 */         arrayOfFloat1[20] /= arrayOfFloat1[23];
/*  852 */         arrayOfFloat1[21] /= arrayOfFloat1[23];
/*  853 */         arrayOfFloat1[22] /= arrayOfFloat1[23];
/*      */       }
/*  855 */       arrayOfFloat1[23] = 1.0F;
/*      */     }
/*      */ 
/*  861 */     i = 1;
/*  862 */     int j = 0;
/*  863 */     int k = 0;
/*      */ 
/*  865 */     if (this.stroke)
/*      */     {
/*      */       int i1;
/*  866 */       switch (this.shape)
/*      */       {
/*      */       case 16:
/*  870 */         j = this.vertex_end;
/*  871 */         for (l = this.vertex_start; l < j; ++l) {
/*  872 */           add_path();
/*  873 */           add_line(l, l);
/*      */         }
/*      */ 
/*  876 */         break;
/*      */       case 32:
/*      */       case 33:
/*      */       case 34:
/*  883 */         l = this.lineCount;
/*  884 */         j = this.vertex_end - 1;
/*  885 */         if (this.shape == 32) 0; i = 1 + 1;
/*      */ 
/*  888 */         if (this.shape != 32) add_path();
/*      */ 
/*  890 */         for (i1 = this.vertex_start; i1 < j; i1 += i)
/*      */         {
/*  892 */           if (this.shape == 32) add_path();
/*  893 */           add_line(i1, i1 + 1);
/*      */         }
/*      */ 
/*  897 */         if (this.shape == 34) {
/*  898 */           add_line(j, this.lines[l][1]);
/*      */         }
/*      */ 
/*  901 */         break;
/*      */       case 64:
/*  905 */         for (l = this.vertex_start; l < this.vertex_end - 2; l += 3) {
/*  906 */           add_path();
/*  907 */           k = l - this.vertex_start;
/*  908 */           add_line(l, l + 1);
/*  909 */           add_line(l + 1, l + 2);
/*  910 */           add_line(l + 2, l);
/*      */         }
/*      */ 
/*  913 */         break;
/*      */       case 65:
/*  918 */         j = this.vertex_end - 1;
/*      */ 
/*  920 */         add_path();
/*  921 */         for (l = this.vertex_start; l < j; ++l) {
/*  922 */           k = l - this.vertex_start;
/*  923 */           add_line(l, l + 1);
/*      */         }
/*      */ 
/*  927 */         j = this.vertex_end - 2;
/*  928 */         for (l = this.vertex_start; l < j; ++l) {
/*  929 */           add_path();
/*  930 */           add_line(l, l + 2);
/*      */         }
/*      */ 
/*  933 */         break;
/*      */       case 66:
/*  939 */         for (l = this.vertex_start + 1; l < this.vertex_end; ++l) {
/*  940 */           add_path();
/*  941 */           add_line(this.vertex_start, l);
/*      */         }
/*      */ 
/*  945 */         add_path();
/*  946 */         for (l = this.vertex_start + 1; l < this.vertex_end - 1; ++l) {
/*  947 */           add_line(l, l + 1);
/*      */         }
/*      */ 
/*  950 */         add_line(this.vertex_end - 1, this.vertex_start + 1);
/*      */ 
/*  952 */         break;
/*      */       case 128:
/*  956 */         for (l = this.vertex_start; l < this.vertex_end; l += 4) {
/*  957 */           add_path();
/*  958 */           k = l - this.vertex_start;
/*  959 */           add_line(l, l + 1);
/*  960 */           add_line(l + 1, l + 2);
/*  961 */           add_line(l + 2, l + 3);
/*  962 */           add_line(l + 3, l);
/*      */         }
/*      */ 
/*  965 */         break;
/*      */       case 129:
/*  969 */         for (l = this.vertex_start; l < this.vertex_end - 3; l += 2) {
/*  970 */           add_path();
/*  971 */           add_line(l, l + 2);
/*  972 */           add_line(l + 2, l + 3);
/*  973 */           add_line(l + 3, l + 1);
/*  974 */           add_line(l + 1, l);
/*      */         }
/*      */ 
/*  996 */         break;
/*      */       case 256:
/* 1003 */         l = this.lineCount;
/* 1004 */         j = this.vertex_end - 1;
/*      */ 
/* 1006 */         add_path();
/* 1007 */         for (i1 = this.vertex_start; i1 < j; ++i1) {
/* 1008 */           add_line(i1, i1 + 1);
/*      */         }
/*      */ 
/* 1011 */         add_line(j, this.lines[l][1]);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1020 */     if (this.fill) {
/* 1021 */       switch (this.shape)
/*      */       {
/*      */       case 66:
/* 1024 */         j = this.vertex_end - 1;
/* 1025 */         for (l = this.vertex_start + 1; l < j; ++l) {
/* 1026 */           add_triangle(this.vertex_start, l, l + 1);
/*      */         }
/*      */ 
/* 1029 */         break;
/*      */       case 64:
/*      */       case 65:
/* 1034 */         j = this.vertex_end - 2;
/* 1035 */         i = (this.shape == 64) ? 3 : 1;
/* 1036 */         for (l = this.vertex_start; l < j; l += i)
/*      */         {
/* 1039 */           if (l % 2 == 0)
/* 1040 */             add_triangle(l, l + 2, l + 1);
/*      */           else {
/* 1042 */             add_triangle(l, l + 1, l + 2);
/*      */           }
/*      */         }
/*      */ 
/* 1046 */         break;
/*      */       case 128:
/* 1050 */         j = this.vertexCount - 3;
/* 1051 */         for (l = this.vertex_start; l < j; l += 4)
/*      */         {
/* 1053 */           add_triangle(l, l + 1, l + 2);
/*      */ 
/* 1055 */           add_triangle(l, l + 2, l + 3);
/*      */         }
/*      */ 
/* 1058 */         break;
/*      */       case 129:
/* 1062 */         j = this.vertexCount - 3;
/* 1063 */         for (l = this.vertex_start; l < j; l += 2)
/*      */         {
/* 1065 */           add_triangle(l, l + 2, l + 1);
/*      */ 
/* 1067 */           add_triangle(l + 2, l + 3, l + 1);
/*      */         }
/*      */ 
/* 1070 */         break;
/*      */       case 256:
/* 1076 */         triangulate_polygon();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1086 */     if ((this.lightCount > 0) && (this.fill)) {
/* 1087 */       handle_lighting();
/*      */     }
/*      */     else {
/* 1090 */       handle_no_lighting();
/*      */     }
/*      */ 
/* 1098 */     for (int l = this.vertex_start; l < this.vertex_end_including_clip_verts; ++l) {
/* 1099 */       float[] arrayOfFloat2 = this.vertices[l];
/*      */ 
/* 1101 */       float f1 = this.projection.m00 * arrayOfFloat2[20] + this.projection.m01 * arrayOfFloat2[21] + this.projection.m02 * arrayOfFloat2[22] + this.projection.m03 * arrayOfFloat2[23];
/*      */ 
/* 1104 */       float f2 = this.projection.m10 * arrayOfFloat2[20] + this.projection.m11 * arrayOfFloat2[21] + this.projection.m12 * arrayOfFloat2[22] + this.projection.m13 * arrayOfFloat2[23];
/*      */ 
/* 1107 */       float f3 = this.projection.m20 * arrayOfFloat2[20] + this.projection.m21 * arrayOfFloat2[21] + this.projection.m22 * arrayOfFloat2[22] + this.projection.m23 * arrayOfFloat2[23];
/*      */ 
/* 1110 */       float f4 = this.projection.m30 * arrayOfFloat2[20] + this.projection.m31 * arrayOfFloat2[21] + this.projection.m32 * arrayOfFloat2[22] + this.projection.m33 * arrayOfFloat2[23];
/*      */ 
/* 1114 */       if ((f4 != 0.0F) && (f4 != 1.0F)) {
/* 1115 */         f1 /= f4; f2 /= f4; f3 /= f4;
/*      */       }
/*      */ 
/* 1118 */       arrayOfFloat2[0] = (this.width * (1.0F + f1) / 2.0F);
/* 1119 */       arrayOfFloat2[1] = (this.height * (1.0F + f2) / 2.0F);
/* 1120 */       arrayOfFloat2[2] = ((f3 + 1.0F) / 2.0F);
/*      */     }
/*      */ 
/* 1128 */     if (this.hints[7] == 0) {
/* 1129 */       if (this.fill) render_triangles();
/* 1130 */       if (this.stroke) render_lines();
/*      */     }
/*      */ 
/* 1133 */     this.shape = 0;
/*      */   }
/*      */ 
/*      */   protected final void add_path()
/*      */   {
/* 1138 */     if (this.pathCount == this.pathOffset.length) {
/* 1139 */       int[] arrayOfInt1 = new int[this.pathCount << 1];
/* 1140 */       System.arraycopy(this.pathOffset, 0, arrayOfInt1, 0, this.pathCount);
/* 1141 */       this.pathOffset = arrayOfInt1;
/* 1142 */       int[] arrayOfInt2 = new int[this.pathCount << 1];
/* 1143 */       System.arraycopy(this.pathLength, 0, arrayOfInt2, 0, this.pathCount);
/* 1144 */       this.pathLength = arrayOfInt2;
/*      */     }
/* 1146 */     this.pathOffset[this.pathCount] = this.lineCount;
/* 1147 */     this.pathLength[this.pathCount] = 0;
/* 1148 */     this.pathCount += 1;
/*      */   }
/*      */ 
/*      */   protected void add_line(int paramInt1, int paramInt2) {
/* 1152 */     add_line_with_clip(paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */   protected final void add_line_with_clip(int paramInt1, int paramInt2) {
/* 1156 */     float f1 = this.vertices[paramInt1][22];
/* 1157 */     float f2 = this.vertices[paramInt2][22];
/* 1158 */     if (f1 > this.cameraNear) {
/* 1159 */       if (f2 > this.cameraNear) {
/* 1160 */         return;
/*      */       }
/* 1162 */       i = interpolate_clip_vertex(paramInt1, paramInt2);
/* 1163 */       add_line_no_clip(i, paramInt2);
/* 1164 */       return;
/*      */     }
/*      */ 
/* 1167 */     if (f2 <= this.cameraNear) {
/* 1168 */       add_line_no_clip(paramInt1, paramInt2);
/* 1169 */       return;
/*      */     }
/* 1171 */     int i = interpolate_clip_vertex(paramInt1, paramInt2);
/* 1172 */     add_line_no_clip(paramInt1, i);
/*      */   }
/*      */ 
/*      */   protected final void add_line_no_clip(int paramInt1, int paramInt2)
/*      */   {
/* 1178 */     if (this.lineCount == this.lines.length) {
/* 1179 */       int[][] arrayOfInt = new int[this.lineCount << 1][5];
/* 1180 */       System.arraycopy(this.lines, 0, arrayOfInt, 0, this.lineCount);
/* 1181 */       this.lines = arrayOfInt;
/*      */     }
/*      */ 
/* 1184 */     this.lines[this.lineCount][1] = paramInt1;
/* 1185 */     this.lines[this.lineCount][2] = paramInt2;
/* 1186 */     this.lines[this.lineCount][0] = -1;
/*      */ 
/* 1188 */     this.lines[this.lineCount][3] = (this.strokeCap | this.strokeJoin);
/* 1189 */     this.lines[this.lineCount][4] = (int)(this.strokeWeight + 0.5F);
/* 1190 */     this.lineCount += 1;
/*      */ 
/* 1193 */     this.pathLength[(this.pathCount - 1)] += 1;
/*      */   }
/*      */ 
/*      */   protected void add_triangle(int paramInt1, int paramInt2, int paramInt3) {
/* 1197 */     add_triangle_with_clip(paramInt1, paramInt2, paramInt3);
/*      */   }
/*      */ 
/*      */   protected final void add_triangle_with_clip(int paramInt1, int paramInt2, int paramInt3)
/*      */   {
/* 1202 */     int i = 0;
/* 1203 */     int j = 0;
/* 1204 */     int k = 0;
/* 1205 */     int l = 0;
/*      */ 
/* 1207 */     this.cameraNear = -8.0F;
/* 1208 */     if (this.vertices[paramInt1][22] > this.cameraNear) {
/* 1209 */       i = 1;
/* 1210 */       ++l;
/*      */     }
/* 1212 */     if (this.vertices[paramInt2][22] > this.cameraNear) {
/* 1213 */       j = 1;
/* 1214 */       ++l;
/*      */     }
/* 1216 */     if (this.vertices[paramInt3][22] > this.cameraNear) {
/* 1217 */       k = 1;
/* 1218 */       ++l;
/*      */     }
/* 1220 */     if (l == 0) {
/* 1221 */       add_triangle_no_clip(paramInt1, paramInt2, paramInt3);
/* 1222 */       return;
/*      */     }
/* 1224 */     if (l == 3)
/* 1225 */       return;
/*      */     int i1;
/*      */     int i2;
/*      */     int i3;
/* 1232 */     if (l == 2)
/*      */     {
/* 1236 */       if (i == 0) {
/* 1237 */         i1 = paramInt1;
/* 1238 */         i2 = paramInt2;
/* 1239 */         i3 = paramInt3;
/*      */       }
/* 1241 */       else if (j == 0) {
/* 1242 */         i1 = paramInt2;
/* 1243 */         i2 = paramInt1;
/* 1244 */         i3 = paramInt3;
/*      */       }
/*      */       else {
/* 1247 */         i1 = paramInt3;
/* 1248 */         i2 = paramInt2;
/* 1249 */         i3 = paramInt1;
/*      */       }
/*      */ 
/* 1252 */       i4 = interpolate_clip_vertex(i1, i2);
/* 1253 */       i5 = interpolate_clip_vertex(i1, i3);
/* 1254 */       add_triangle_no_clip(i1, i4, i5);
/* 1255 */       return;
/*      */     }
/*      */ 
/* 1266 */     if (i != 0)
/*      */     {
/* 1268 */       i1 = paramInt3;
/* 1269 */       i2 = paramInt2;
/* 1270 */       i3 = paramInt1;
/*      */     }
/* 1272 */     else if (j != 0)
/*      */     {
/* 1274 */       i1 = paramInt1;
/* 1275 */       i2 = paramInt3;
/* 1276 */       i3 = paramInt2;
/*      */     }
/*      */     else
/*      */     {
/* 1280 */       i1 = paramInt1;
/* 1281 */       i2 = paramInt2;
/* 1282 */       i3 = paramInt3;
/*      */     }
/*      */ 
/* 1285 */     int i4 = interpolate_clip_vertex(i1, i3);
/* 1286 */     int i5 = interpolate_clip_vertex(i2, i3);
/* 1287 */     add_triangle_no_clip(i1, i4, i2);
/*      */ 
/* 1291 */     add_triangle_no_clip(i2, i4, i5);
/*      */   }
/*      */ 
/*      */   private final int interpolate_clip_vertex(int paramInt1, int paramInt2)
/*      */   {
/*      */     float[] arrayOfFloat1;
/*      */     float[] arrayOfFloat2;
/* 1300 */     if (this.vertices[paramInt1][22] < this.vertices[paramInt2][22]) {
/* 1301 */       arrayOfFloat1 = this.vertices[paramInt2];
/* 1302 */       arrayOfFloat2 = this.vertices[paramInt1];
/*      */     }
/*      */     else {
/* 1305 */       arrayOfFloat1 = this.vertices[paramInt1];
/* 1306 */       arrayOfFloat2 = this.vertices[paramInt2];
/*      */     }
/* 1308 */     float f1 = arrayOfFloat1[22];
/* 1309 */     float f2 = arrayOfFloat2[22];
/*      */ 
/* 1311 */     float f3 = f1 - f2;
/*      */ 
/* 1313 */     if (f3 == 0.0F) {
/* 1314 */       return paramInt1;
/*      */     }
/*      */ 
/* 1318 */     float f4 = (this.cameraNear - f2) / f3;
/* 1319 */     float f5 = 1.0F - f4;
/*      */ 
/* 1324 */     vertex(f4 * arrayOfFloat1[9] + f5 * arrayOfFloat2[9], f4 * arrayOfFloat1[10] + f5 * arrayOfFloat2[10], f4 * arrayOfFloat1[11] + f5 * arrayOfFloat2[11]);
/* 1325 */     int i = this.vertexCount - 1;
/* 1326 */     this.vertex_end_including_clip_verts += 1;
/* 1327 */     float[] arrayOfFloat3 = this.vertices[i];
/*      */ 
/* 1329 */     arrayOfFloat3[0] = (f4 * arrayOfFloat1[0] + f5 * arrayOfFloat2[0]);
/* 1330 */     arrayOfFloat3[1] = (f4 * arrayOfFloat1[1] + f5 * arrayOfFloat2[1]);
/* 1331 */     arrayOfFloat3[2] = (f4 * arrayOfFloat1[2] + f5 * arrayOfFloat2[2]);
/*      */ 
/* 1333 */     arrayOfFloat3[20] = (f4 * arrayOfFloat1[20] + f5 * arrayOfFloat2[20]);
/* 1334 */     arrayOfFloat3[21] = (f4 * arrayOfFloat1[21] + f5 * arrayOfFloat2[21]);
/* 1335 */     arrayOfFloat3[22] = (f4 * arrayOfFloat1[22] + f5 * arrayOfFloat2[22]);
/* 1336 */     arrayOfFloat3[23] = (f4 * arrayOfFloat1[23] + f5 * arrayOfFloat2[23]);
/*      */ 
/* 1338 */     arrayOfFloat3[3] = (f4 * arrayOfFloat1[3] + f5 * arrayOfFloat2[3]);
/* 1339 */     arrayOfFloat3[4] = (f4 * arrayOfFloat1[4] + f5 * arrayOfFloat2[4]);
/* 1340 */     arrayOfFloat3[5] = (f4 * arrayOfFloat1[5] + f5 * arrayOfFloat2[5]);
/* 1341 */     arrayOfFloat3[6] = (f4 * arrayOfFloat1[6] + f5 * arrayOfFloat2[6]);
/*      */ 
/* 1343 */     arrayOfFloat3[7] = (f4 * arrayOfFloat1[7] + f5 * arrayOfFloat2[7]);
/* 1344 */     arrayOfFloat3[8] = (f4 * arrayOfFloat1[8] + f5 * arrayOfFloat2[8]);
/*      */ 
/* 1346 */     arrayOfFloat3[12] = (f4 * arrayOfFloat1[12] + f5 * arrayOfFloat2[12]);
/* 1347 */     arrayOfFloat3[13] = (f4 * arrayOfFloat1[13] + f5 * arrayOfFloat2[13]);
/* 1348 */     arrayOfFloat3[14] = (f4 * arrayOfFloat1[14] + f5 * arrayOfFloat2[14]);
/* 1349 */     arrayOfFloat3[15] = (f4 * arrayOfFloat1[15] + f5 * arrayOfFloat2[15]);
/*      */ 
/* 1351 */     arrayOfFloat3[17] = (f4 * arrayOfFloat1[17] + f5 * arrayOfFloat2[17]);
/* 1352 */     arrayOfFloat3[18] = (f4 * arrayOfFloat1[18] + f5 * arrayOfFloat2[18]);
/* 1353 */     arrayOfFloat3[19] = (f4 * arrayOfFloat1[19] + f5 * arrayOfFloat2[19]);
/*      */ 
/* 1355 */     arrayOfFloat3[16] = (f4 * arrayOfFloat1[16] + f5 * arrayOfFloat2[16]);
/*      */ 
/* 1357 */     arrayOfFloat3[24] = (f4 * arrayOfFloat1[24] + f5 * arrayOfFloat2[24]);
/* 1358 */     arrayOfFloat3[25] = (f4 * arrayOfFloat1[25] + f5 * arrayOfFloat2[25]);
/* 1359 */     arrayOfFloat3[26] = (f4 * arrayOfFloat1[26] + f5 * arrayOfFloat2[26]);
/*      */ 
/* 1361 */     arrayOfFloat3[27] = (f4 * arrayOfFloat1[27] + f5 * arrayOfFloat2[27]);
/* 1362 */     arrayOfFloat3[28] = (f4 * arrayOfFloat1[28] + f5 * arrayOfFloat2[28]);
/* 1363 */     arrayOfFloat3[29] = (f4 * arrayOfFloat1[29] + f5 * arrayOfFloat2[29]);
/* 1364 */     arrayOfFloat3[30] = (f4 * arrayOfFloat1[30] + f5 * arrayOfFloat2[30]);
/*      */ 
/* 1366 */     arrayOfFloat3[32] = (f4 * arrayOfFloat1[32] + f5 * arrayOfFloat2[32]);
/* 1367 */     arrayOfFloat3[33] = (f4 * arrayOfFloat1[33] + f5 * arrayOfFloat2[33]);
/* 1368 */     arrayOfFloat3[34] = (f4 * arrayOfFloat1[34] + f5 * arrayOfFloat2[34]);
/*      */ 
/* 1370 */     arrayOfFloat3[31] = (f4 * arrayOfFloat1[31] + f5 * arrayOfFloat2[31]);
/*      */ 
/* 1372 */     arrayOfFloat3[35] = 0.0F;
/*      */ 
/* 1374 */     return i;
/*      */   }
/*      */ 
/*      */   protected final void add_triangle_no_clip(int paramInt1, int paramInt2, int paramInt3)
/*      */   {
/* 1379 */     if (this.triangleCount == this.triangles.length) {
/* 1380 */       int[][] arrayOfInt = new int[this.triangleCount << 1][5];
/* 1381 */       System.arraycopy(this.triangles, 0, arrayOfInt, 0, this.triangleCount);
/* 1382 */       this.triangles = arrayOfInt;
/*      */ 
/* 1384 */       float[][][] arrayOfFloat = new float[this.triangleCount << 1][3][8];
/* 1385 */       System.arraycopy(this.triangleColors, 0, arrayOfFloat, 0, this.triangleCount);
/* 1386 */       this.triangleColors = arrayOfFloat;
/*      */     }
/* 1388 */     this.triangles[this.triangleCount][1] = paramInt1;
/* 1389 */     this.triangles[this.triangleCount][2] = paramInt2;
/* 1390 */     this.triangles[this.triangleCount][3] = paramInt3;
/*      */ 
/* 1392 */     if (this.textureImage == null)
/* 1393 */       this.triangles[this.triangleCount][4] = -1;
/*      */     else {
/* 1395 */       this.triangles[this.triangleCount][4] = this.texture_index;
/*      */     }
/*      */ 
/* 1398 */     this.triangles[this.triangleCount][0] = this.shape_index;
/* 1399 */     this.triangleCount += 1;
/*      */   }
/*      */ 
/*      */   protected void depth_sort_triangles()
/*      */   {
/*      */   }
/*      */ 
/*      */   protected void render_triangles()
/*      */   {
/* 1412 */     for (int i = 0; i < this.triangleCount; ++i) {
/* 1413 */       float[] arrayOfFloat1 = this.vertices[this.triangles[i][1]];
/* 1414 */       float[] arrayOfFloat2 = this.vertices[this.triangles[i][2]];
/* 1415 */       float[] arrayOfFloat3 = this.vertices[this.triangles[i][3]];
/* 1416 */       int j = this.triangles[i][4];
/* 1417 */       int k = this.triangles[i][0];
/*      */ 
/* 1419 */       this.triangle.reset();
/*      */ 
/* 1423 */       float f1 = min(1.0F, this.triangleColors[i][0][0] + this.triangleColors[i][0][4]);
/*      */ 
/* 1425 */       float f2 = min(1.0F, this.triangleColors[i][0][1] + this.triangleColors[i][0][5]);
/*      */ 
/* 1427 */       float f3 = min(1.0F, this.triangleColors[i][0][2] + this.triangleColors[i][0][6]);
/*      */ 
/* 1429 */       float f4 = min(1.0F, this.triangleColors[i][1][0] + this.triangleColors[i][1][4]);
/*      */ 
/* 1431 */       float f5 = min(1.0F, this.triangleColors[i][1][1] + this.triangleColors[i][1][5]);
/*      */ 
/* 1433 */       float f6 = min(1.0F, this.triangleColors[i][1][2] + this.triangleColors[i][1][6]);
/*      */ 
/* 1435 */       float f7 = min(1.0F, this.triangleColors[i][2][0] + this.triangleColors[i][2][4]);
/*      */ 
/* 1437 */       float f8 = min(1.0F, this.triangleColors[i][2][1] + this.triangleColors[i][2][5]);
/*      */ 
/* 1439 */       float f9 = min(1.0F, this.triangleColors[i][2][2] + this.triangleColors[i][2][6]);
/*      */ 
/* 1442 */       if ((j > -1) && (this.textures[j] != null)) {
/* 1443 */         this.triangle.setTexture(this.textures[j]);
/* 1444 */         this.triangle.setUV(arrayOfFloat1[7], arrayOfFloat1[8], arrayOfFloat2[7], arrayOfFloat2[8], arrayOfFloat3[7], arrayOfFloat3[8]);
/*      */       }
/*      */ 
/* 1447 */       this.triangle.setIntensities(f1, f2, f3, arrayOfFloat1[6], f4, f5, f6, arrayOfFloat2[6], f7, f8, f9, arrayOfFloat3[6]);
/*      */ 
/* 1451 */       this.triangle.setVertices(arrayOfFloat1[0], arrayOfFloat1[1], arrayOfFloat1[2], arrayOfFloat2[0], arrayOfFloat2[1], arrayOfFloat2[2], arrayOfFloat3[0], arrayOfFloat3[1], arrayOfFloat3[2]);
/*      */ 
/* 1455 */       this.triangle.setIndex(k);
/* 1456 */       this.triangle.render();
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void depth_sort_lines()
/*      */   {
/*      */   }
/*      */ 
/*      */   protected void render_lines()
/*      */   {
/* 1466 */     for (int i = 0; i < this.lineCount; ++i) {
/* 1467 */       float[] arrayOfFloat1 = this.vertices[this.lines[i][1]];
/* 1468 */       float[] arrayOfFloat2 = this.vertices[this.lines[i][2]];
/* 1469 */       int j = this.lines[i][0];
/*      */ 
/* 1471 */       this.line.reset();
/*      */ 
/* 1473 */       this.line.setIntensities(arrayOfFloat1[12], arrayOfFloat1[13], arrayOfFloat1[14], arrayOfFloat1[15], arrayOfFloat2[12], arrayOfFloat2[13], arrayOfFloat2[14], arrayOfFloat2[15]);
/*      */ 
/* 1476 */       this.line.setVertices(arrayOfFloat1[0], arrayOfFloat1[1], arrayOfFloat1[2], arrayOfFloat2[0], arrayOfFloat2[1], arrayOfFloat2[2]);
/*      */ 
/* 1479 */       this.line.setIndex(j);
/* 1480 */       this.line.draw();
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void triangulate_polygon()
/*      */   {
/* 1492 */     float f1 = 0.0F;
/* 1493 */     int i = this.vertex_end - 1; for (int j = this.vertex_start; j < this.vertex_end; i = j++) {
/* 1494 */       f1 += this.vertices[j][9] * this.vertices[i][10] - (this.vertices[i][9] * this.vertices[j][10]);
/*      */     }
/*      */ 
/* 1501 */     i = 0;
/*      */ 
/* 1503 */     if (f1 > 0.0F)
/* 1504 */       for (j = this.vertex_start; j < this.vertex_end; ++j) {
/* 1505 */         i = j - this.vertex_start;
/* 1506 */         this.vertex_order[i] = j;
/*      */       }
/*      */     else {
/* 1509 */       for (j = this.vertex_start; j < this.vertex_end; ++j) {
/* 1510 */         i = j - this.vertex_start;
/* 1511 */         this.vertex_order[i] = (this.vertex_end - 1 - i);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1516 */     j = this.vertex_end - this.vertex_start;
/* 1517 */     int k = 2 * j;
/*      */ 
/* 1519 */     int l = 0; for (int i1 = j - 1; j > 2; ) {
/* 1520 */       int i2 = 1;
/*      */ 
/* 1523 */       if (k-- <= 0)
/*      */       {
/*      */         return;
/*      */       }
/*      */ 
/* 1528 */       int i3 = i1; if (j <= i3) i3 = 0;
/* 1529 */       i1 = i3 + 1; if (j <= i1) i1 = 0;
/* 1530 */       int i4 = i1 + 1; if (j <= i4) i4 = 0;
/*      */ 
/* 1535 */       float f2 = -this.vertices[this.vertex_order[i3]][9];
/* 1536 */       float f3 = this.vertices[this.vertex_order[i3]][10];
/* 1537 */       float f4 = -this.vertices[this.vertex_order[i1]][9];
/* 1538 */       float f5 = this.vertices[this.vertex_order[i1]][10];
/* 1539 */       float f6 = -this.vertices[this.vertex_order[i4]][9];
/* 1540 */       float f7 = this.vertices[this.vertex_order[i4]][10];
/*      */ 
/* 1543 */       if (1.0E-04F > (f4 - f2) * (f7 - f3) - ((f5 - f3) * (f6 - f2))) {
/*      */         continue;
/*      */       }
/*      */ 
/* 1547 */       for (int i5 = 0; i5 < j; ++i5)
/*      */       {
/* 1551 */         if ((i5 == i3) || (i5 == i1) || (i5 == i4))
/*      */         {
/*      */           continue;
/*      */         }
/*      */ 
/* 1557 */         float f8 = -this.vertices[this.vertex_order[i5]][9];
/* 1558 */         float f9 = this.vertices[this.vertex_order[i5]][10];
/*      */ 
/* 1560 */         float f10 = f6 - f4; float f11 = f7 - f5;
/* 1561 */         float f12 = f2 - f6; float f13 = f3 - f7;
/* 1562 */         float f14 = f4 - f2; float f15 = f5 - f3;
/* 1563 */         float f16 = f8 - f2; float f17 = f9 - f3;
/* 1564 */         float f18 = f8 - f4; float f19 = f9 - f5;
/* 1565 */         float f20 = f8 - f6; float f21 = f9 - f7;
/*      */ 
/* 1567 */         float f22 = f10 * f19 - (f11 * f18);
/* 1568 */         float f23 = f14 * f17 - (f15 * f16);
/* 1569 */         float f24 = f12 * f21 - (f13 * f20);
/*      */ 
/* 1571 */         if ((f22 >= 0.0F) && (f24 >= 0.0F) && (f23 >= 0.0F)) {
/* 1572 */           i2 = 0;
/*      */         }
/*      */       }
/*      */ 
/* 1576 */       if (i2 != 0) {
/* 1577 */         add_triangle(this.vertex_order[i3], this.vertex_order[i1], this.vertex_order[i4]);
/*      */ 
/* 1579 */         ++l;
/*      */ 
/* 1582 */         i5 = i1; for (int i6 = i1 + 1; i6 < j; ++i6) {
/* 1583 */           this.vertex_order[i5] = this.vertex_order[i6];
/*      */ 
/* 1582 */           ++i5;
/*      */         }
/*      */ 
/* 1585 */         --j;
/*      */ 
/* 1588 */         k = 2 * j;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void toWorldNormal(float paramFloat1, float paramFloat2, float paramFloat3, float[] paramArrayOfFloat)
/*      */   {
/* 1595 */     paramArrayOfFloat[0] = (this.modelviewInv.m00 * paramFloat1 + this.modelviewInv.m10 * paramFloat2 + this.modelviewInv.m20 * paramFloat3 + this.modelviewInv.m30);
/*      */ 
/* 1598 */     paramArrayOfFloat[1] = (this.modelviewInv.m01 * paramFloat1 + this.modelviewInv.m11 * paramFloat2 + this.modelviewInv.m21 * paramFloat3 + this.modelviewInv.m31);
/*      */ 
/* 1601 */     paramArrayOfFloat[2] = (this.modelviewInv.m02 * paramFloat1 + this.modelviewInv.m12 * paramFloat2 + this.modelviewInv.m22 * paramFloat3 + this.modelviewInv.m32);
/*      */ 
/* 1604 */     paramArrayOfFloat[3] = (this.modelviewInv.m03 * paramFloat1 + this.modelviewInv.m13 * paramFloat2 + this.modelviewInv.m23 * paramFloat3 + this.modelviewInv.m33);
/*      */ 
/* 1608 */     if ((paramArrayOfFloat[3] != 0.0F) && (paramArrayOfFloat[3] != 1.0F))
/*      */     {
/* 1610 */       paramArrayOfFloat[0] /= paramArrayOfFloat[3]; paramArrayOfFloat[1] /= paramArrayOfFloat[3]; paramArrayOfFloat[2] /= paramArrayOfFloat[3];
/*      */     }
/* 1612 */     paramArrayOfFloat[3] = 1.0F;
/*      */ 
/* 1614 */     float f = mag(paramArrayOfFloat[0], paramArrayOfFloat[1], paramArrayOfFloat[2]);
/* 1615 */     if ((f != 0.0F) && (f != 1.0F)) {
/* 1616 */       paramArrayOfFloat[0] /= f; paramArrayOfFloat[1] /= f; paramArrayOfFloat[2] /= f;
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void calc_lighting_contribution(int paramInt, float[] paramArrayOfFloat)
/*      */   {
/* 1623 */     calc_lighting_contribution(paramInt, paramArrayOfFloat, false);
/*      */   }
/*      */ 
/*      */   private final void calc_lighting_contribution(int paramInt, float[] paramArrayOfFloat, boolean paramBoolean)
/*      */   {
/* 1629 */     float[] arrayOfFloat = this.vertices[paramInt];
/*      */ 
/* 1631 */     float f1 = arrayOfFloat[27];
/* 1632 */     float f2 = arrayOfFloat[28];
/* 1633 */     float f3 = arrayOfFloat[29];
/*      */ 
/* 1635 */     float f4 = arrayOfFloat[20];
/* 1636 */     float f5 = arrayOfFloat[21];
/* 1637 */     float f6 = arrayOfFloat[22];
/* 1638 */     float f7 = arrayOfFloat[31];
/*      */     float f8;
/*      */     float f9;
/*      */     float f10;
/* 1643 */     if (!(paramBoolean)) {
/* 1644 */       toWorldNormal(arrayOfFloat[17], arrayOfFloat[18], arrayOfFloat[19], this.worldNormal);
/* 1645 */       f8 = this.worldNormal[0];
/* 1646 */       f9 = this.worldNormal[1];
/* 1647 */       f10 = this.worldNormal[2];
/*      */     }
/*      */     else {
/* 1650 */       f8 = arrayOfFloat[17];
/* 1651 */       f9 = arrayOfFloat[18];
/* 1652 */       f10 = arrayOfFloat[19];
/*      */     }
/*      */ 
/* 1659 */     float f11 = dot(f8, f9, f10, -f4, -f5, -f6);
/*      */ 
/* 1663 */     if (f11 < 0.0F) {
/* 1664 */       f8 = -f8;
/* 1665 */       f9 = -f9;
/* 1666 */       f10 = -f10;
/*      */     }
/*      */ 
/* 1670 */     paramArrayOfFloat[0] = 0.0F;
/* 1671 */     paramArrayOfFloat[1] = 0.0F;
/* 1672 */     paramArrayOfFloat[2] = 0.0F;
/*      */ 
/* 1674 */     paramArrayOfFloat[3] = 0.0F;
/* 1675 */     paramArrayOfFloat[4] = 0.0F;
/* 1676 */     paramArrayOfFloat[5] = 0.0F;
/*      */ 
/* 1678 */     paramArrayOfFloat[6] = 0.0F;
/* 1679 */     paramArrayOfFloat[7] = 0.0F;
/* 1680 */     paramArrayOfFloat[8] = 0.0F;
/*      */ 
/* 1684 */     for (int i = 0; i < this.lightCount; ++i)
/*      */     {
/* 1686 */       float f12 = this.lightsFalloffConstant[i];
/* 1687 */       float f13 = 1.0F;
/*      */       float f14;
/* 1689 */       if (this.lights[i] == 0) {
/* 1690 */         if ((this.lightsFalloffQuadratic[i] != 0.0F) || (this.lightsFalloffLinear[i] != 0.0F))
/*      */         {
/* 1692 */           f14 = mag(this.lightsX[i] - f4, this.lightsY[i] - f5, this.lightsZ[i] - f6);
/* 1693 */           f12 += this.lightsFalloffQuadratic[i] * f14 + this.lightsFalloffLinear[i] * sqrt(f14);
/*      */         }
/*      */ 
/* 1696 */         if (f12 == 0.0F)
/* 1697 */           f12 = 1.0F;
/* 1698 */         paramArrayOfFloat[0] += this.lightsDiffuseR[i] / f12;
/* 1699 */         paramArrayOfFloat[1] += this.lightsDiffuseG[i] / f12;
/* 1700 */         paramArrayOfFloat[2] += this.lightsDiffuseB[i] / f12;
/*      */       }
/*      */       else
/*      */       {
/* 1706 */         float f17 = 0.0F;
/* 1707 */         float f18 = 0.0F;
/*      */         float f15;
/*      */         float f16;
/* 1709 */         if (this.lights[i] == 1) {
/* 1710 */           f14 = -this.lightsNX[i];
/* 1711 */           f15 = -this.lightsNY[i];
/* 1712 */           f16 = -this.lightsNZ[i];
/* 1713 */           f12 = 1.0F;
/* 1714 */           f18 = f8 * f14 + f9 * f15 + f10 * f16;
/*      */ 
/* 1716 */           if (f18 <= 0.0F)
/*      */             continue;
/*      */         }
/*      */         else {
/* 1720 */           f14 = this.lightsX[i] - f4;
/* 1721 */           f15 = this.lightsY[i] - f5;
/* 1722 */           f16 = this.lightsZ[i] - f6;
/*      */ 
/* 1724 */           f19 = mag(f14, f15, f16);
/* 1725 */           if (f19 != 0.0F) {
/* 1726 */             f14 /= f19;
/* 1727 */             f15 /= f19;
/* 1728 */             f16 /= f19;
/*      */           }
/* 1730 */           f18 = f8 * f14 + f9 * f15 + f10 * f16;
/*      */ 
/* 1732 */           if (f18 <= 0.0F) {
/*      */             continue;
/*      */           }
/*      */ 
/* 1736 */           if (this.lights[i] == 3) {
/* 1737 */             f17 = -(this.lightsNX[i] * f14 + this.lightsNY[i] * f15 + this.lightsNZ[i] * f16);
/*      */ 
/* 1740 */             if (f17 <= this.lightsSpotAngleCos[i]) {
/*      */               continue;
/*      */             }
/* 1743 */             f13 = pow(f17, this.lightsSpotConcentration[i]);
/*      */           }
/*      */ 
/* 1746 */           if ((this.lightsFalloffQuadratic[i] != 0.0F) || (this.lightsFalloffLinear[i] != 0.0F))
/*      */           {
/* 1748 */             f12 += this.lightsFalloffQuadratic[i] * f19 + this.lightsFalloffLinear[i] * sqrt(f19);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1756 */         if (f12 == 0.0F)
/* 1757 */           f12 = 1.0F;
/* 1758 */         float f19 = f18 * f13 / f12;
/* 1759 */         paramArrayOfFloat[3] += this.lightsDiffuseR[i] * f19;
/* 1760 */         paramArrayOfFloat[4] += this.lightsDiffuseG[i] * f19;
/* 1761 */         paramArrayOfFloat[5] += this.lightsDiffuseB[i] * f19;
/*      */ 
/* 1766 */         if (((f1 <= 0.0F) && (f2 <= 0.0F) && (f3 <= 0.0F)) || ((this.lightsSpecularR[i] <= 0.0F) && (this.lightsSpecularG[i] <= 0.0F) && (this.lightsSpecularB[i] <= 0.0F)))
/*      */         {
/*      */           continue;
/*      */         }
/*      */ 
/* 1771 */         float f20 = mag(f4, f5, f6);
/* 1772 */         if (f20 != 0.0F) {
/* 1773 */           f4 /= f20;
/* 1774 */           f5 /= f20;
/* 1775 */           f6 /= f20;
/*      */         }
/* 1777 */         float f21 = f14 - f4;
/* 1778 */         float f22 = f15 - f5;
/* 1779 */         float f23 = f16 - f6;
/* 1780 */         f20 = mag(f21, f22, f23);
/* 1781 */         if (f20 != 0.0F) {
/* 1782 */           f21 /= f20;
/* 1783 */           f22 /= f20;
/* 1784 */           f23 /= f20;
/*      */         }
/* 1786 */         float f24 = f21 * f8 + f22 * f9 + f23 * f10;
/*      */ 
/* 1788 */         if (f24 > 0.0F) {
/* 1789 */           f24 = pow(f24, f7);
/* 1790 */           f19 = f24 * f13 / f12;
/* 1791 */           paramArrayOfFloat[6] += this.lightsSpecularR[i] * f19;
/* 1792 */           paramArrayOfFloat[7] += this.lightsSpecularG[i] * f19;
/* 1793 */           paramArrayOfFloat[8] += this.lightsSpecularB[i] * f19;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void apply_lighting_contribution(int paramInt, float[] paramArrayOfFloat)
/*      */   {
/* 1814 */     float[] arrayOfFloat = this.vertices[paramInt];
/*      */ 
/* 1816 */     arrayOfFloat[3] = min(1.0F, arrayOfFloat[32] + arrayOfFloat[24] * paramArrayOfFloat[0] + arrayOfFloat[3] * paramArrayOfFloat[3]);
/*      */ 
/* 1818 */     arrayOfFloat[4] = min(1.0F, arrayOfFloat[33] + arrayOfFloat[25] * paramArrayOfFloat[1] + arrayOfFloat[4] * paramArrayOfFloat[4]);
/*      */ 
/* 1820 */     arrayOfFloat[5] = min(1.0F, arrayOfFloat[34] + arrayOfFloat[26] * paramArrayOfFloat[0] + arrayOfFloat[5] * paramArrayOfFloat[5]);
/*      */ 
/* 1822 */     arrayOfFloat[6] = min(1.0F, arrayOfFloat[6]);
/*      */ 
/* 1824 */     arrayOfFloat[27] = min(1.0F, arrayOfFloat[27] * paramArrayOfFloat[6]);
/* 1825 */     arrayOfFloat[28] = min(1.0F, arrayOfFloat[28] * paramArrayOfFloat[7]);
/* 1826 */     arrayOfFloat[29] = min(1.0F, arrayOfFloat[29] * paramArrayOfFloat[8]);
/* 1827 */     arrayOfFloat[30] = min(1.0F, arrayOfFloat[30]);
/*      */ 
/* 1829 */     arrayOfFloat[35] = 1.0F;
/*      */   }
/*      */ 
/*      */   private final void light_vertex_always(int paramInt, float[] paramArrayOfFloat)
/*      */   {
/* 1834 */     calc_lighting_contribution(paramInt, paramArrayOfFloat);
/* 1835 */     apply_lighting_contribution(paramInt, paramArrayOfFloat);
/*      */   }
/*      */ 
/*      */   private final void light_vertex_if_not_already_lit(int paramInt, float[] paramArrayOfFloat)
/*      */   {
/* 1841 */     if (this.vertices[paramInt][35] == 0.0F)
/* 1842 */       light_vertex_always(paramInt, paramArrayOfFloat);
/*      */   }
/*      */ 
/*      */   private final void copy_prelit_vertex_color_to_triangle(int paramInt1, int paramInt2, int paramInt3)
/*      */   {
/* 1849 */     float[] arrayOfFloat1 = this.triangleColors[paramInt1][paramInt3];
/* 1850 */     float[] arrayOfFloat2 = this.vertices[paramInt2];
/*      */ 
/* 1852 */     arrayOfFloat1[0] = arrayOfFloat2[3];
/* 1853 */     arrayOfFloat1[1] = arrayOfFloat2[4];
/* 1854 */     arrayOfFloat1[2] = arrayOfFloat2[5];
/* 1855 */     arrayOfFloat1[3] = arrayOfFloat2[6];
/* 1856 */     arrayOfFloat1[4] = arrayOfFloat2[27];
/* 1857 */     arrayOfFloat1[5] = arrayOfFloat2[28];
/* 1858 */     arrayOfFloat1[6] = arrayOfFloat2[29];
/* 1859 */     arrayOfFloat1[7] = arrayOfFloat2[30];
/*      */   }
/*      */ 
/*      */   private final void copy_vertex_color_to_triangle(int paramInt1, int paramInt2, int paramInt3, float[] paramArrayOfFloat)
/*      */   {
/* 1866 */     float[] arrayOfFloat1 = this.triangleColors[paramInt1][paramInt3];
/* 1867 */     float[] arrayOfFloat2 = this.vertices[paramInt2];
/*      */ 
/* 1869 */     arrayOfFloat1[0] = min(1.0F, arrayOfFloat2[32] + arrayOfFloat2[24] * paramArrayOfFloat[0] + arrayOfFloat2[3] * paramArrayOfFloat[3]);
/*      */ 
/* 1872 */     arrayOfFloat1[1] = min(1.0F, arrayOfFloat2[33] + arrayOfFloat2[25] * paramArrayOfFloat[1] + arrayOfFloat2[4] * paramArrayOfFloat[4]);
/*      */ 
/* 1875 */     arrayOfFloat1[2] = min(1.0F, arrayOfFloat2[34] + arrayOfFloat2[26] * paramArrayOfFloat[0] + arrayOfFloat2[5] * paramArrayOfFloat[5]);
/*      */ 
/* 1878 */     arrayOfFloat1[3] = min(1.0F, arrayOfFloat2[6]);
/*      */ 
/* 1880 */     arrayOfFloat1[4] = min(1.0F, arrayOfFloat2[27] * paramArrayOfFloat[6]);
/*      */ 
/* 1882 */     arrayOfFloat1[5] = min(1.0F, arrayOfFloat2[28] * paramArrayOfFloat[7]);
/*      */ 
/* 1884 */     arrayOfFloat1[6] = min(1.0F, arrayOfFloat2[29] * paramArrayOfFloat[8]);
/*      */ 
/* 1886 */     arrayOfFloat1[7] = min(1.0F, arrayOfFloat2[30]);
/*      */   }
/*      */ 
/*      */   private final void light_triangle(int paramInt, float[] paramArrayOfFloat)
/*      */   {
/* 1891 */     int i = this.triangles[paramInt][1];
/* 1892 */     copy_vertex_color_to_triangle(paramInt, i, 0, paramArrayOfFloat);
/* 1893 */     i = this.triangles[paramInt][2];
/* 1894 */     copy_vertex_color_to_triangle(paramInt, i, 1, paramArrayOfFloat);
/* 1895 */     i = this.triangles[paramInt][3];
/* 1896 */     copy_vertex_color_to_triangle(paramInt, i, 2, paramArrayOfFloat);
/*      */   }
/*      */ 
/*      */   private final void crossProduct(float[] paramArrayOfFloat1, float[] paramArrayOfFloat2, float[] paramArrayOfFloat3)
/*      */   {
/* 1901 */     paramArrayOfFloat3[0] = (paramArrayOfFloat1[1] * paramArrayOfFloat2[2] - (paramArrayOfFloat1[2] * paramArrayOfFloat2[1]));
/* 1902 */     paramArrayOfFloat3[1] = (paramArrayOfFloat1[2] * paramArrayOfFloat2[0] - (paramArrayOfFloat1[0] * paramArrayOfFloat2[2]));
/* 1903 */     paramArrayOfFloat3[2] = (paramArrayOfFloat1[0] * paramArrayOfFloat2[1] - (paramArrayOfFloat1[1] * paramArrayOfFloat2[0]));
/*      */   }
/*      */ 
/*      */   private final void light_triangle(int paramInt)
/*      */   {
/*      */     int i;
/* 1929 */     if (this.normalMode == 2) {
/* 1930 */       i = this.triangles[paramInt][1];
/* 1931 */       light_vertex_if_not_already_lit(i, this.tempLightingContribution);
/* 1932 */       copy_prelit_vertex_color_to_triangle(paramInt, i, 0);
/*      */ 
/* 1934 */       i = this.triangles[paramInt][2];
/* 1935 */       light_vertex_if_not_already_lit(i, this.tempLightingContribution);
/* 1936 */       copy_prelit_vertex_color_to_triangle(paramInt, i, 1);
/*      */ 
/* 1938 */       i = this.triangles[paramInt][3];
/* 1939 */       light_vertex_if_not_already_lit(i, this.tempLightingContribution);
/* 1940 */       copy_prelit_vertex_color_to_triangle(paramInt, i, 2);
/*      */     }
/*      */     else
/*      */     {
/*      */       int j;
/*      */       int k;
/*      */       float[] arrayOfFloat1;
/*      */       float[] arrayOfFloat2;
/*      */       float[] arrayOfFloat3;
/*      */       float f;
/* 1948 */       if (!(this.lightingDependsOnVertexPosition)) {
/* 1949 */         i = this.triangles[paramInt][1];
/* 1950 */         j = this.triangles[paramInt][2];
/* 1951 */         k = this.triangles[paramInt][3];
/* 1952 */         arrayOfFloat1 = new float[] { this.vertices[j][20] - this.vertices[i][20], this.vertices[j][21] - this.vertices[i][21], this.vertices[j][22] - this.vertices[i][22] };
/*      */ 
/* 1955 */         arrayOfFloat2 = new float[] { this.vertices[k][20] - this.vertices[i][20], this.vertices[k][21] - this.vertices[i][21], this.vertices[k][22] - this.vertices[i][22] };
/*      */ 
/* 1958 */         arrayOfFloat3 = new float[3];
/* 1959 */         crossProduct(arrayOfFloat1, arrayOfFloat2, arrayOfFloat3);
/* 1960 */         f = mag(arrayOfFloat3[0], arrayOfFloat3[1], arrayOfFloat3[2]);
/* 1961 */         if ((f != 0.0F) && (f != 1.0F)) {
/* 1962 */           arrayOfFloat3[0] /= f; arrayOfFloat3[1] /= f; arrayOfFloat3[2] /= f;
/*      */         }
/* 1964 */         this.vertices[i][17] = arrayOfFloat3[0];
/* 1965 */         this.vertices[i][18] = arrayOfFloat3[1];
/* 1966 */         this.vertices[i][19] = arrayOfFloat3[2];
/*      */ 
/* 1969 */         calc_lighting_contribution(i, this.tempLightingContribution, true);
/* 1970 */         copy_vertex_color_to_triangle(paramInt, i, 0, this.tempLightingContribution);
/* 1971 */         copy_vertex_color_to_triangle(paramInt, j, 1, this.tempLightingContribution);
/* 1972 */         copy_vertex_color_to_triangle(paramInt, k, 2, this.tempLightingContribution);
/*      */       }
/* 1977 */       else if (this.normalMode == 1) {
/* 1978 */         i = this.triangles[paramInt][1];
/* 1979 */         this.vertices[i][17] = this.vertices[this.vertex_start][17];
/* 1980 */         this.vertices[i][18] = this.vertices[this.vertex_start][18];
/* 1981 */         this.vertices[i][19] = this.vertices[this.vertex_start][19];
/* 1982 */         calc_lighting_contribution(i, this.tempLightingContribution);
/* 1983 */         copy_vertex_color_to_triangle(paramInt, i, 0, this.tempLightingContribution);
/*      */ 
/* 1985 */         i = this.triangles[paramInt][2];
/* 1986 */         this.vertices[i][17] = this.vertices[this.vertex_start][17];
/* 1987 */         this.vertices[i][18] = this.vertices[this.vertex_start][18];
/* 1988 */         this.vertices[i][19] = this.vertices[this.vertex_start][19];
/* 1989 */         calc_lighting_contribution(i, this.tempLightingContribution);
/* 1990 */         copy_vertex_color_to_triangle(paramInt, i, 1, this.tempLightingContribution);
/*      */ 
/* 1992 */         i = this.triangles[paramInt][3];
/* 1993 */         this.vertices[i][17] = this.vertices[this.vertex_start][17];
/* 1994 */         this.vertices[i][18] = this.vertices[this.vertex_start][18];
/* 1995 */         this.vertices[i][19] = this.vertices[this.vertex_start][19];
/* 1996 */         calc_lighting_contribution(i, this.tempLightingContribution);
/* 1997 */         copy_vertex_color_to_triangle(paramInt, i, 2, this.tempLightingContribution);
/*      */       }
/*      */       else
/*      */       {
/* 2002 */         i = this.triangles[paramInt][1];
/* 2003 */         j = this.triangles[paramInt][2];
/* 2004 */         k = this.triangles[paramInt][3];
/* 2005 */         arrayOfFloat1 = new float[] { this.vertices[j][20] - this.vertices[i][20], this.vertices[j][21] - this.vertices[i][21], this.vertices[j][22] - this.vertices[i][22] };
/*      */ 
/* 2008 */         arrayOfFloat2 = new float[] { this.vertices[k][20] - this.vertices[i][20], this.vertices[k][21] - this.vertices[i][21], this.vertices[k][22] - this.vertices[i][22] };
/*      */ 
/* 2011 */         arrayOfFloat3 = new float[3];
/* 2012 */         crossProduct(arrayOfFloat1, arrayOfFloat2, arrayOfFloat3);
/* 2013 */         f = mag(arrayOfFloat3[0], arrayOfFloat3[1], arrayOfFloat3[2]);
/* 2014 */         if ((f != 0.0F) && (f != 1.0F)) {
/* 2015 */           arrayOfFloat3[0] /= f; arrayOfFloat3[1] /= f; arrayOfFloat3[2] /= f;
/*      */         }
/* 2017 */         this.vertices[i][17] = arrayOfFloat3[0];
/* 2018 */         this.vertices[i][18] = arrayOfFloat3[1];
/* 2019 */         this.vertices[i][19] = arrayOfFloat3[2];
/*      */ 
/* 2021 */         calc_lighting_contribution(i, this.tempLightingContribution, true);
/* 2022 */         copy_vertex_color_to_triangle(paramInt, i, 0, this.tempLightingContribution);
/*      */ 
/* 2024 */         this.vertices[j][17] = arrayOfFloat3[0];
/* 2025 */         this.vertices[j][18] = arrayOfFloat3[1];
/* 2026 */         this.vertices[j][19] = arrayOfFloat3[2];
/*      */ 
/* 2028 */         calc_lighting_contribution(j, this.tempLightingContribution, true);
/* 2029 */         copy_vertex_color_to_triangle(paramInt, j, 1, this.tempLightingContribution);
/*      */ 
/* 2031 */         this.vertices[k][17] = arrayOfFloat3[0];
/* 2032 */         this.vertices[k][18] = arrayOfFloat3[1];
/* 2033 */         this.vertices[k][19] = arrayOfFloat3[2];
/*      */ 
/* 2035 */         calc_lighting_contribution(k, this.tempLightingContribution, true);
/* 2036 */         copy_vertex_color_to_triangle(paramInt, k, 2, this.tempLightingContribution);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void handle_lighting()
/*      */   {
/*      */     int i;
/* 2046 */     if ((!(this.lightingDependsOnVertexPosition)) && (this.normalMode == 1)) {
/* 2047 */       calc_lighting_contribution(this.vertex_start, this.tempLightingContribution);
/* 2048 */       for (i = 0; i < this.triangleCount; ++i) {
/* 2049 */         light_triangle(i, this.tempLightingContribution);
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 2054 */       for (i = 0; i < this.triangleCount; ++i)
/* 2055 */         light_triangle(i);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void handle_no_lighting()
/*      */   {
/* 2062 */     for (int j = 0; j < this.triangleCount; ++j) {
/* 2063 */       int i = this.triangles[j][1];
/* 2064 */       copy_prelit_vertex_color_to_triangle(j, i, 0);
/* 2065 */       i = this.triangles[j][2];
/* 2066 */       copy_prelit_vertex_color_to_triangle(j, i, 1);
/* 2067 */       i = this.triangles[j][3];
/* 2068 */       copy_prelit_vertex_color_to_triangle(j, i, 2);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void point(float paramFloat1, float paramFloat2)
/*      */   {
/* 2078 */     point(paramFloat1, paramFloat2, 0.0F);
/*      */   }
/*      */ 
/*      */   public void point(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 2090 */     beginShape(32);
/* 2091 */     vertex(paramFloat1, paramFloat2, paramFloat3);
/* 2092 */     vertex(paramFloat1 + 1.0E-04F, paramFloat2 + 1.0E-04F, paramFloat3);
/* 2093 */     endShape();
/*      */   }
/*      */ 
/*      */   public void line(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 2121 */     line(paramFloat1, paramFloat2, 0.0F, paramFloat3, paramFloat4, 0.0F);
/*      */   }
/*      */ 
/*      */   public void line(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/* 2127 */     beginShape(32);
/* 2128 */     vertex(paramFloat1, paramFloat2, paramFloat3);
/* 2129 */     vertex(paramFloat4, paramFloat5, paramFloat6);
/* 2130 */     endShape();
/*      */   }
/*      */ 
/*      */   public void triangle(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/* 2136 */     beginShape(64);
/* 2137 */     normal(0.0F, 0.0F, 1.0F);
/* 2138 */     vertex(paramFloat1, paramFloat2);
/* 2139 */     vertex(paramFloat3, paramFloat4);
/* 2140 */     vertex(paramFloat5, paramFloat6);
/* 2141 */     endShape();
/*      */   }
/*      */ 
/*      */   public void quad(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8)
/*      */   {
/* 2147 */     beginShape(128);
/* 2148 */     normal(0.0F, 0.0F, 1.0F);
/* 2149 */     vertex(paramFloat1, paramFloat2);
/* 2150 */     vertex(paramFloat3, paramFloat4);
/* 2151 */     vertex(paramFloat5, paramFloat6);
/* 2152 */     vertex(paramFloat7, paramFloat8);
/* 2153 */     endShape();
/*      */   }
/*      */ 
/*      */   protected void rectImpl(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 2164 */     quad(paramFloat1, paramFloat2, paramFloat3, paramFloat2, paramFloat3, paramFloat4, paramFloat1, paramFloat4);
/*      */   }
/*      */ 
/*      */   protected void ellipseImpl(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 2169 */     float f1 = paramFloat3 / 2.0F;
/* 2170 */     float f2 = paramFloat4 / 2.0F;
/*      */ 
/* 2172 */     float f3 = paramFloat1 + f1;
/* 2173 */     float f4 = paramFloat2 + f2;
/*      */ 
/* 2187 */     int i = (int)(4 + Math.sqrt(f1 + f2) * 3);
/*      */ 
/* 2190 */     float f5 = 720.0F / i;
/*      */ 
/* 2192 */     float f6 = 0.0F;
/*      */     boolean bool;
/*      */     int j;
/* 2203 */     if (this.fill) {
/* 2204 */       bool = this.stroke;
/* 2205 */       this.stroke = false;
/*      */ 
/* 2207 */       beginShape(66);
/* 2208 */       normal(0.0F, 0.0F, 1.0F);
/* 2209 */       vertex(f3, f4);
/* 2210 */       for (j = 0; j < i; ++j) {
/* 2211 */         vertex(f3 + cosLUT[(int)f6] * f1, f4 + sinLUT[(int)f6] * f2);
/*      */ 
/* 2213 */         f6 += f5;
/*      */       }
/*      */ 
/* 2216 */       vertex(f3 + cosLUT[0] * f1, f4 + sinLUT[0] * f2);
/*      */ 
/* 2218 */       endShape();
/*      */ 
/* 2220 */       this.stroke = bool;
/*      */     }
/*      */ 
/* 2223 */     if (this.stroke) {
/* 2224 */       bool = this.fill;
/* 2225 */       this.fill = false;
/*      */ 
/* 2227 */       f6 = 0.0F;
/* 2228 */       beginShape(34);
/* 2229 */       for (j = 0; j < i; ++j) {
/* 2230 */         vertex(f3 + cosLUT[(int)f6] * f1, f4 + sinLUT[(int)f6] * f2);
/*      */ 
/* 2232 */         f6 += f5;
/*      */       }
/* 2234 */       endShape();
/*      */ 
/* 2236 */       this.fill = bool;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void arcImpl(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/* 2249 */     float f1 = paramFloat3 / 2.0F;
/* 2250 */     float f2 = paramFloat4 / 2.0F;
/*      */ 
/* 2252 */     float f3 = paramFloat1 + f1;
/* 2253 */     float f4 = paramFloat2 + f2;
/*      */     int i1;
/* 2255 */     if (this.fill)
/*      */     {
/* 2257 */       bool = this.stroke;
/* 2258 */       this.stroke = false;
/*      */ 
/* 2260 */       i = (int)(0.5F + paramFloat5 / 6.283186F * 720.0F);
/* 2261 */       j = (int)(0.5F + paramFloat6 / 6.283186F * 720.0F);
/*      */ 
/* 2263 */       beginShape(66);
/* 2264 */       vertex(f3, f4);
/* 2265 */       k = 1;
/* 2266 */       for (l = i; l < j; l += k) {
/* 2267 */         i1 = l % 720;
/* 2268 */         vertex(f3 + cosLUT[i1] * f1, f4 + sinLUT[i1] * f2);
/*      */       }
/*      */ 
/* 2272 */       vertex(f3 + cosLUT[(j % 720)] * f1, f4 + sinLUT[(j % 720)] * f2);
/*      */ 
/* 2274 */       endShape();
/*      */ 
/* 2276 */       this.stroke = bool;
/*      */     }
/*      */ 
/* 2279 */     if (!(this.stroke)) {
/*      */       return;
/*      */     }
/*      */ 
/* 2283 */     boolean bool = this.fill;
/* 2284 */     this.fill = false;
/*      */ 
/* 2286 */     int i = (int)(0.5F + paramFloat5 / 6.283186F * 720.0F);
/* 2287 */     int j = (int)(0.5F + paramFloat6 / 6.283186F * 720.0F);
/*      */ 
/* 2289 */     beginShape(33);
/* 2290 */     int k = 1;
/* 2291 */     for (int l = i; l < j; l += k) {
/* 2292 */       i1 = l % 720;
/* 2293 */       vertex(f3 + cosLUT[i1] * f1, f4 + sinLUT[i1] * f2);
/*      */     }
/*      */ 
/* 2297 */     vertex(f3 + cosLUT[(j % 720)] * f1, f4 + sinLUT[(j % 720)] * f2);
/*      */ 
/* 2299 */     endShape();
/*      */ 
/* 2301 */     this.fill = bool;
/*      */   }
/*      */ 
/*      */   public void box(float paramFloat)
/*      */   {
/* 2313 */     box(paramFloat, paramFloat, paramFloat);
/*      */   }
/*      */ 
/*      */   public void box(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 2321 */     float f1 = -paramFloat1 / 2.0F; float f2 = paramFloat1 / 2.0F;
/* 2322 */     float f3 = -paramFloat2 / 2.0F; float f4 = paramFloat2 / 2.0F;
/* 2323 */     float f5 = -paramFloat3 / 2.0F; float f6 = paramFloat3 / 2.0F;
/*      */ 
/* 2325 */     if (this.triangle != null) {
/* 2326 */       this.triangle.setCulling(true);
/*      */     }
/*      */ 
/* 2329 */     beginShape(128);
/*      */ 
/* 2332 */     normal(0.0F, 0.0F, 1.0F);
/* 2333 */     vertex(f1, f3, f5);
/* 2334 */     vertex(f2, f3, f5);
/* 2335 */     vertex(f2, f4, f5);
/* 2336 */     vertex(f1, f4, f5);
/*      */ 
/* 2339 */     normal(1.0F, 0.0F, 0.0F);
/* 2340 */     vertex(f2, f3, f5);
/* 2341 */     vertex(f2, f3, f6);
/* 2342 */     vertex(f2, f4, f6);
/* 2343 */     vertex(f2, f4, f5);
/*      */ 
/* 2346 */     normal(0.0F, 0.0F, -1.0F);
/* 2347 */     vertex(f2, f3, f6);
/* 2348 */     vertex(f1, f3, f6);
/* 2349 */     vertex(f1, f4, f6);
/* 2350 */     vertex(f2, f4, f6);
/*      */ 
/* 2353 */     normal(-1.0F, 0.0F, 0.0F);
/* 2354 */     vertex(f1, f3, f6);
/* 2355 */     vertex(f1, f3, f5);
/* 2356 */     vertex(f1, f4, f5);
/* 2357 */     vertex(f1, f4, f6);
/*      */ 
/* 2360 */     normal(0.0F, 1.0F, 0.0F);
/* 2361 */     vertex(f1, f3, f6);
/* 2362 */     vertex(f2, f3, f6);
/* 2363 */     vertex(f2, f3, f5);
/* 2364 */     vertex(f1, f3, f5);
/*      */ 
/* 2367 */     normal(0.0F, -1.0F, 0.0F);
/* 2368 */     vertex(f1, f4, f5);
/* 2369 */     vertex(f2, f4, f5);
/* 2370 */     vertex(f2, f4, f6);
/* 2371 */     vertex(f1, f4, f6);
/*      */ 
/* 2373 */     endShape();
/*      */ 
/* 2375 */     if (this.triangle != null)
/* 2376 */       this.triangle.setCulling(false);
/*      */   }
/*      */ 
/*      */   public void sphereDetail(int paramInt)
/*      */   {
/* 2391 */     if (paramInt < 3) paramInt = 3;
/* 2392 */     if (paramInt == this.sphereDetail) return;
/*      */ 
/* 2394 */     float f1 = 720.0F / paramInt;
/* 2395 */     float[] arrayOfFloat1 = new float[paramInt];
/* 2396 */     float[] arrayOfFloat2 = new float[paramInt];
/*      */ 
/* 2398 */     for (int i = 0; i < paramInt; ++i) {
/* 2399 */       arrayOfFloat1[i] = cosLUT[((int)(i * f1) % 720)];
/* 2400 */       arrayOfFloat2[i] = sinLUT[((int)(i * f1) % 720)];
/*      */     }
/*      */ 
/* 2404 */     i = paramInt * (paramInt - 1) + 2;
/* 2405 */     int j = 0;
/*      */ 
/* 2408 */     this.sphereX = new float[i];
/* 2409 */     this.sphereY = new float[i];
/* 2410 */     this.sphereZ = new float[i];
/*      */ 
/* 2412 */     float f2 = 360.0F / paramInt;
/* 2413 */     float f3 = f2;
/*      */ 
/* 2416 */     for (int k = 1; k < paramInt; ++k) {
/* 2417 */       float f4 = sinLUT[((int)f3 % 720)];
/* 2418 */       float f5 = -cosLUT[((int)f3 % 720)];
/* 2419 */       for (int l = 0; l < paramInt; ++l) {
/* 2420 */         this.sphereX[j] = (arrayOfFloat1[l] * f4);
/* 2421 */         this.sphereY[j] = f5;
/* 2422 */         this.sphereZ[(j++)] = (arrayOfFloat2[l] * f4);
/*      */       }
/* 2424 */       f3 += f2;
/*      */     }
/* 2426 */     this.sphereDetail = paramInt;
/*      */   }
/*      */ 
/*      */   public void sphere(float paramFloat)
/*      */   {
/* 2451 */     float f1 = 0.0F;
/* 2452 */     float f2 = 0.0F;
/* 2453 */     float f3 = 0.0F;
/*      */ 
/* 2455 */     if (this.sphereDetail == 0) {
/* 2456 */       sphereDetail(30);
/*      */     }
/*      */ 
/* 2460 */     pushMatrix();
/* 2461 */     if ((f1 != 0.0F) && (f2 != 0.0F) && (f3 != 0.0F)) translate(f1, f2, f3);
/* 2462 */     scale(paramFloat);
/*      */ 
/* 2464 */     if (this.triangle != null) {
/* 2465 */       this.triangle.setCulling(true);
/*      */     }
/*      */ 
/* 2469 */     beginShape(65);
/* 2470 */     for (int l = 0; l < this.sphereDetail; ++l) {
/* 2471 */       normal(0.0F, -1.0F, 0.0F);
/* 2472 */       vertex(0.0F, -1.0F, 0.0F);
/* 2473 */       normal(this.sphereX[l], this.sphereY[l], this.sphereZ[l]);
/* 2474 */       vertex(this.sphereX[l], this.sphereY[l], this.sphereZ[l]);
/*      */     }
/*      */ 
/* 2477 */     vertex(0.0F, -1.0F, 0.0F);
/* 2478 */     normal(this.sphereX[0], this.sphereY[0], this.sphereZ[0]);
/* 2479 */     vertex(this.sphereX[0], this.sphereY[0], this.sphereZ[0]);
/* 2480 */     endShape();
/*      */ 
/* 2483 */     l = 0;
/*      */     int k;
/* 2484 */     for (int i1 = 2; i1 < this.sphereDetail; ++i1)
/*      */     {
/*      */       int j;
/* 2485 */       int i = j = l;
/* 2486 */       l += this.sphereDetail;
/* 2487 */       k = l;
/* 2488 */       beginShape(65);
/* 2489 */       for (int i2 = 0; i2 < this.sphereDetail; ++i2) {
/* 2490 */         normal(this.sphereX[i], this.sphereY[i], this.sphereZ[i]);
/* 2491 */         vertex(this.sphereX[i], this.sphereY[i], this.sphereZ[(i++)]);
/* 2492 */         normal(this.sphereX[k], this.sphereY[k], this.sphereZ[k]);
/* 2493 */         vertex(this.sphereX[k], this.sphereY[k], this.sphereZ[(k++)]);
/*      */       }
/*      */ 
/* 2496 */       i = j;
/* 2497 */       k = l;
/* 2498 */       normal(this.sphereX[i], this.sphereY[i], this.sphereZ[i]);
/* 2499 */       vertex(this.sphereX[i], this.sphereY[i], this.sphereZ[i]);
/* 2500 */       normal(this.sphereX[k], this.sphereY[k], this.sphereZ[k]);
/* 2501 */       vertex(this.sphereX[k], this.sphereY[k], this.sphereZ[k]);
/* 2502 */       endShape();
/*      */     }
/*      */ 
/* 2506 */     beginShape(65);
/* 2507 */     for (i1 = 0; i1 < this.sphereDetail; ++i1) {
/* 2508 */       k = l + i1;
/* 2509 */       normal(this.sphereX[k], this.sphereY[k], this.sphereZ[k]);
/* 2510 */       vertex(this.sphereX[k], this.sphereY[k], this.sphereZ[k]);
/* 2511 */       normal(0.0F, 1.0F, 0.0F);
/* 2512 */       vertex(0.0F, 1.0F, 0.0F);
/*      */     }
/* 2514 */     normal(this.sphereX[l], this.sphereY[l], this.sphereZ[l]);
/* 2515 */     vertex(this.sphereX[l], this.sphereY[l], this.sphereZ[l]);
/* 2516 */     normal(0.0F, 1.0F, 0.0F);
/* 2517 */     vertex(0.0F, 1.0F, 0.0F);
/* 2518 */     endShape();
/* 2519 */     popMatrix();
/*      */ 
/* 2521 */     if (this.triangle != null)
/* 2522 */       this.triangle.setCulling(false);
/*      */   }
/*      */ 
/*      */   public void bezier(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8)
/*      */   {
/* 2537 */     bezier(paramFloat1, paramFloat2, 0.0F, paramFloat3, paramFloat4, 0.0F, paramFloat5, paramFloat6, 0.0F, paramFloat7, paramFloat8, 0.0F);
/*      */   }
/*      */ 
/*      */   public void bezier(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12)
/*      */   {
/* 2548 */     beginShape(33);
/* 2549 */     vertex(paramFloat1, paramFloat2, paramFloat3);
/* 2550 */     bezierVertex(paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramFloat11, paramFloat12);
/*      */ 
/* 2553 */     endShape();
/*      */   }
/*      */ 
/*      */   public void curve(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8)
/*      */   {
/* 2561 */     curve(paramFloat1, paramFloat2, 0.0F, paramFloat3, paramFloat4, 0.0F, paramFloat5, paramFloat6, 0.0F, paramFloat7, paramFloat8, 0.0F);
/*      */   }
/*      */ 
/*      */   public void curve(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12)
/*      */   {
/* 2572 */     beginShape(33);
/* 2573 */     curveVertex(paramFloat1, paramFloat2, paramFloat3);
/* 2574 */     curveVertex(paramFloat4, paramFloat5, paramFloat6);
/* 2575 */     curveVertex(paramFloat7, paramFloat8, paramFloat9);
/* 2576 */     curveVertex(paramFloat10, paramFloat11, paramFloat12);
/* 2577 */     endShape();
/*      */   }
/*      */ 
/*      */   protected void imageImpl(PImage paramPImage, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
/*      */   {
/* 2591 */     boolean bool1 = this.stroke;
/* 2592 */     boolean bool2 = this.fill;
/* 2593 */     int i = this.textureMode;
/*      */ 
/* 2595 */     this.stroke = false;
/* 2596 */     this.fill = true;
/* 2597 */     this.textureMode = 2;
/*      */ 
/* 2599 */     float f1 = this.fillR;
/* 2600 */     float f2 = this.fillG;
/* 2601 */     float f3 = this.fillB;
/* 2602 */     float f4 = this.fillA;
/*      */ 
/* 2604 */     if (this.tint) {
/* 2605 */       this.fillR = this.tintR;
/* 2606 */       this.fillG = this.tintG;
/* 2607 */       this.fillB = this.tintB;
/* 2608 */       this.fillA = this.tintA;
/*      */     }
/*      */     else {
/* 2611 */       this.fillR = 1.0F;
/* 2612 */       this.fillG = 1.0F;
/* 2613 */       this.fillB = 1.0F;
/* 2614 */       this.fillA = 1.0F;
/*      */     }
/*      */ 
/* 2619 */     beginShape(128);
/* 2620 */     texture(paramPImage);
/* 2621 */     vertex(paramFloat1, paramFloat2, paramInt1, paramInt2);
/* 2622 */     vertex(paramFloat1, paramFloat4, paramInt1, paramInt4);
/* 2623 */     vertex(paramFloat3, paramFloat4, paramInt3, paramInt4);
/* 2624 */     vertex(paramFloat3, paramFloat2, paramInt3, paramInt2);
/* 2625 */     endShape();
/*      */ 
/* 2627 */     this.stroke = bool1;
/* 2628 */     this.fill = bool2;
/* 2629 */     this.textureMode = i;
/*      */ 
/* 2631 */     this.fillR = f1;
/* 2632 */     this.fillG = f2;
/* 2633 */     this.fillB = f3;
/* 2634 */     this.fillA = f4;
/*      */   }
/*      */ 
/*      */   public void translate(float paramFloat1, float paramFloat2)
/*      */   {
/* 2644 */     translate(paramFloat1, paramFloat2, 0.0F);
/*      */   }
/*      */ 
/*      */   public void translate(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 2649 */     this.forwardTransform.translate(paramFloat1, paramFloat2, paramFloat3);
/* 2650 */     this.reverseTransform.invTranslate(paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public void rotate(float paramFloat)
/*      */   {
/* 2661 */     rotateZ(paramFloat);
/*      */   }
/*      */ 
/*      */   public void rotateX(float paramFloat)
/*      */   {
/* 2669 */     this.forwardTransform.rotateX(paramFloat);
/* 2670 */     this.reverseTransform.invRotateX(paramFloat);
/*      */   }
/*      */ 
/*      */   public void rotateY(float paramFloat)
/*      */   {
/* 2675 */     this.forwardTransform.rotateY(paramFloat);
/* 2676 */     this.reverseTransform.invRotateY(paramFloat);
/*      */   }
/*      */ 
/*      */   public void rotateZ(float paramFloat)
/*      */   {
/* 2688 */     this.forwardTransform.rotateZ(paramFloat);
/* 2689 */     this.reverseTransform.invRotateZ(paramFloat);
/*      */   }
/*      */ 
/*      */   public void rotate(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 2699 */     this.forwardTransform.rotate(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/* 2700 */     this.reverseTransform.invRotate(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*      */   }
/*      */ 
/*      */   public void scale(float paramFloat)
/*      */   {
/* 2708 */     scale(paramFloat, paramFloat, paramFloat);
/*      */   }
/*      */ 
/*      */   public void scale(float paramFloat1, float paramFloat2)
/*      */   {
/* 2718 */     scale(paramFloat1, paramFloat2, 1.0F);
/*      */   }
/*      */ 
/*      */   public void scale(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 2726 */     this.forwardTransform.scale(paramFloat1, paramFloat2, paramFloat3);
/* 2727 */     this.reverseTransform.invScale(paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */   public void pushMatrix()
/*      */   {
/* 2738 */     if (!(this.modelview.push())) {
/* 2739 */       throw new RuntimeException("too many calls to pushMatrix()");
/*      */     }
/*      */ 
/* 2743 */     this.modelviewInv.push();
/*      */   }
/*      */ 
/*      */   public void popMatrix()
/*      */   {
/* 2748 */     if (!(this.modelview.pop())) {
/* 2749 */       throw new RuntimeException("too many calls to popMatrix() (and not enough to pushMatrix)");
/*      */     }
/*      */ 
/* 2754 */     this.modelviewInv.pop();
/*      */   }
/*      */ 
/*      */   public void resetMatrix()
/*      */   {
/* 2763 */     this.forwardTransform.reset();
/* 2764 */     this.reverseTransform.reset();
/*      */   }
/*      */ 
/*      */   public void applyMatrix(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12, float paramFloat13, float paramFloat14, float paramFloat15, float paramFloat16)
/*      */   {
/* 2778 */     this.forwardTransform.apply(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramFloat11, paramFloat12, paramFloat13, paramFloat14, paramFloat15, paramFloat16);
/*      */ 
/* 2783 */     this.reverseTransform.invApply(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramFloat11, paramFloat12, paramFloat13, paramFloat14, paramFloat15, paramFloat16);
/*      */   }
/*      */ 
/*      */   public void printMatrix()
/*      */   {
/* 2795 */     this.modelview.print();
/*      */   }
/*      */ 
/*      */   public void beginCamera()
/*      */   {
/* 2849 */     if (this.manipulatingCamera) {
/* 2850 */       throw new RuntimeException("cannot call beginCamera while already in camera manipulation mode");
/*      */     }
/*      */ 
/* 2853 */     this.manipulatingCamera = true;
/* 2854 */     this.forwardTransform = this.cameraInv;
/* 2855 */     this.reverseTransform = this.camera;
/*      */   }
/*      */ 
/*      */   public void endCamera()
/*      */   {
/* 2870 */     if (!(this.manipulatingCamera)) {
/* 2871 */       throw new RuntimeException("cannot call endCamera while not in camera manipulation mode");
/*      */     }
/*      */ 
/* 2875 */     this.modelview.set(this.camera);
/* 2876 */     this.modelviewInv.set(this.cameraInv);
/*      */ 
/* 2879 */     this.forwardTransform = this.modelview;
/* 2880 */     this.reverseTransform = this.modelviewInv;
/*      */ 
/* 2883 */     this.manipulatingCamera = false;
/*      */   }
/*      */ 
/*      */   public void camera()
/*      */   {
/* 2940 */     camera(this.cameraX, this.cameraY, this.cameraZ, this.cameraX, this.cameraY, 0.0F, 0.0F, 1.0F, 0.0F);
/*      */   }
/*      */ 
/*      */   public void camera(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9)
/*      */   {
/* 2999 */     float f1 = paramFloat1 - paramFloat4;
/* 3000 */     float f2 = paramFloat2 - paramFloat5;
/* 3001 */     float f3 = paramFloat3 - paramFloat6;
/* 3002 */     float f4 = sqrt(f1 * f1 + f2 * f2 + f3 * f3);
/*      */ 
/* 3004 */     if (f4 != 0.0F) {
/* 3005 */       f1 /= f4;
/* 3006 */       f2 /= f4;
/* 3007 */       f3 /= f4;
/*      */     }
/*      */ 
/* 3010 */     float f5 = paramFloat7;
/* 3011 */     float f6 = paramFloat8;
/* 3012 */     float f7 = paramFloat9;
/*      */ 
/* 3014 */     float f8 = f6 * f3 - (f7 * f2);
/* 3015 */     float f9 = -f5 * f3 + f7 * f1;
/* 3016 */     float f10 = f5 * f2 - (f6 * f1);
/*      */ 
/* 3018 */     f5 = f2 * f10 - (f3 * f9);
/* 3019 */     f6 = -f1 * f10 + f3 * f8;
/* 3020 */     f7 = f1 * f9 - (f2 * f8);
/*      */ 
/* 3022 */     f4 = sqrt(f8 * f8 + f9 * f9 + f10 * f10);
/* 3023 */     if (f4 != 0.0F) {
/* 3024 */       f8 /= f4;
/* 3025 */       f9 /= f4;
/* 3026 */       f10 /= f4;
/*      */     }
/*      */ 
/* 3029 */     f4 = sqrt(f5 * f5 + f6 * f6 + f7 * f7);
/* 3030 */     if (f4 != 0.0F) {
/* 3031 */       f5 /= f4;
/* 3032 */       f6 /= f4;
/* 3033 */       f7 /= f4;
/*      */     }
/*      */ 
/* 3038 */     this.camera.set(f8, f9, f10, 0.0F, f5, f6, f7, 0.0F, f1, f2, f3, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
/*      */ 
/* 3042 */     this.camera.translate(-paramFloat1, -paramFloat2, -paramFloat3);
/*      */ 
/* 3044 */     this.cameraInv.reset();
/* 3045 */     this.cameraInv.invApply(f8, f9, f10, 0.0F, f5, f6, f7, 0.0F, f1, f2, f3, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
/*      */ 
/* 3049 */     this.cameraInv.invTranslate(-paramFloat1, -paramFloat2, -paramFloat3);
/*      */ 
/* 3051 */     this.modelview.set(this.camera);
/* 3052 */     this.modelviewInv.set(this.cameraInv);
/*      */   }
/*      */ 
/*      */   public void printCamera()
/*      */   {
/* 3060 */     this.camera.print();
/*      */   }
/*      */ 
/*      */   public void ortho()
/*      */   {
/* 3069 */     ortho(0.0F, this.width, 0.0F, this.height, -10.0F, 10.0F);
/*      */   }
/*      */ 
/*      */   public void ortho(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/* 3081 */     float f1 = 2.0F / (paramFloat2 - paramFloat1);
/* 3082 */     float f2 = 2.0F / (paramFloat4 - paramFloat3);
/* 3083 */     float f3 = -2.0F / (paramFloat6 - paramFloat5);
/*      */ 
/* 3085 */     float f4 = -(paramFloat2 + paramFloat1) / (paramFloat2 - paramFloat1);
/* 3086 */     float f5 = -(paramFloat4 + paramFloat3) / (paramFloat4 - paramFloat3);
/* 3087 */     float f6 = -(paramFloat6 + paramFloat5) / (paramFloat6 - paramFloat5);
/*      */ 
/* 3089 */     this.projection.set(f1, 0.0F, 0.0F, f4, 0.0F, f2, 0.0F, f5, 0.0F, 0.0F, f3, f6, 0.0F, 0.0F, 0.0F, 1.0F);
/*      */   }
/*      */ 
/*      */   public void perspective()
/*      */   {
/* 3116 */     perspective(this.cameraFOV, this.cameraAspect, this.cameraNear, this.cameraFar);
/*      */   }
/*      */ 
/*      */   public void perspective(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 3125 */     float f1 = paramFloat3 * tan(paramFloat1 / 2.0F);
/* 3126 */     float f2 = -f1;
/*      */ 
/* 3128 */     float f3 = f2 * paramFloat2;
/* 3129 */     float f4 = f1 * paramFloat2;
/*      */ 
/* 3131 */     frustum(f3, f4, f2, f1, paramFloat3, paramFloat4);
/*      */   }
/*      */ 
/*      */   public void frustum(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/* 3144 */     this.projection.set(2.0F * paramFloat5 / (paramFloat2 - paramFloat1), 0.0F, (paramFloat2 + paramFloat1) / (paramFloat2 - paramFloat1), 0.0F, 0.0F, 2.0F * paramFloat5 / (paramFloat4 - paramFloat3), (paramFloat4 + paramFloat3) / (paramFloat4 - paramFloat3), 0.0F, 0.0F, 0.0F, -(paramFloat6 + paramFloat5) / (paramFloat6 - paramFloat5), -(2.0F * paramFloat6 * paramFloat5) / (paramFloat6 - paramFloat5), 0.0F, 0.0F, -1.0F, 0.0F);
/*      */   }
/*      */ 
/*      */   public void printProjection()
/*      */   {
/* 3155 */     this.projection.print();
/*      */   }
/*      */ 
/*      */   public float screenX(float paramFloat1, float paramFloat2)
/*      */   {
/* 3166 */     return screenX(paramFloat1, paramFloat2, 0.0F);
/*      */   }
/*      */ 
/*      */   public float screenY(float paramFloat1, float paramFloat2)
/*      */   {
/* 3171 */     return screenY(paramFloat1, paramFloat2, 0.0F);
/*      */   }
/*      */ 
/*      */   public float screenX(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 3176 */     float f1 = this.modelview.m00 * paramFloat1 + this.modelview.m01 * paramFloat2 + this.modelview.m02 * paramFloat3 + this.modelview.m03;
/*      */ 
/* 3178 */     float f2 = this.modelview.m10 * paramFloat1 + this.modelview.m11 * paramFloat2 + this.modelview.m12 * paramFloat3 + this.modelview.m13;
/*      */ 
/* 3180 */     float f3 = this.modelview.m20 * paramFloat1 + this.modelview.m21 * paramFloat2 + this.modelview.m22 * paramFloat3 + this.modelview.m23;
/*      */ 
/* 3182 */     float f4 = this.modelview.m30 * paramFloat1 + this.modelview.m31 * paramFloat2 + this.modelview.m32 * paramFloat3 + this.modelview.m33;
/*      */ 
/* 3185 */     float f5 = this.projection.m00 * f1 + this.projection.m01 * f2 + this.projection.m02 * f3 + this.projection.m03 * f4;
/*      */ 
/* 3188 */     float f6 = this.projection.m30 * f1 + this.projection.m31 * f2 + this.projection.m32 * f3 + this.projection.m33 * f4;
/*      */ 
/* 3192 */     if (f6 != 0.0F) f5 /= f6;
/* 3193 */     return (this.width * (1.0F + f5) / 2.0F);
/*      */   }
/*      */ 
/*      */   public float screenY(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 3198 */     float f1 = this.modelview.m00 * paramFloat1 + this.modelview.m01 * paramFloat2 + this.modelview.m02 * paramFloat3 + this.modelview.m03;
/*      */ 
/* 3200 */     float f2 = this.modelview.m10 * paramFloat1 + this.modelview.m11 * paramFloat2 + this.modelview.m12 * paramFloat3 + this.modelview.m13;
/*      */ 
/* 3202 */     float f3 = this.modelview.m20 * paramFloat1 + this.modelview.m21 * paramFloat2 + this.modelview.m22 * paramFloat3 + this.modelview.m23;
/*      */ 
/* 3204 */     float f4 = this.modelview.m30 * paramFloat1 + this.modelview.m31 * paramFloat2 + this.modelview.m32 * paramFloat3 + this.modelview.m33;
/*      */ 
/* 3207 */     float f5 = this.projection.m10 * f1 + this.projection.m11 * f2 + this.projection.m12 * f3 + this.projection.m13 * f4;
/*      */ 
/* 3210 */     float f6 = this.projection.m30 * f1 + this.projection.m31 * f2 + this.projection.m32 * f3 + this.projection.m33 * f4;
/*      */ 
/* 3214 */     if (f6 != 0.0F) f5 /= f6;
/* 3215 */     return (this.height * (1.0F + f5) / 2.0F);
/*      */   }
/*      */ 
/*      */   public float screenZ(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 3220 */     float f1 = this.modelview.m00 * paramFloat1 + this.modelview.m01 * paramFloat2 + this.modelview.m02 * paramFloat3 + this.modelview.m03;
/*      */ 
/* 3222 */     float f2 = this.modelview.m10 * paramFloat1 + this.modelview.m11 * paramFloat2 + this.modelview.m12 * paramFloat3 + this.modelview.m13;
/*      */ 
/* 3224 */     float f3 = this.modelview.m20 * paramFloat1 + this.modelview.m21 * paramFloat2 + this.modelview.m22 * paramFloat3 + this.modelview.m23;
/*      */ 
/* 3226 */     float f4 = this.modelview.m30 * paramFloat1 + this.modelview.m31 * paramFloat2 + this.modelview.m32 * paramFloat3 + this.modelview.m33;
/*      */ 
/* 3229 */     float f5 = this.projection.m20 * f1 + this.projection.m21 * f2 + this.projection.m22 * f3 + this.projection.m23 * f4;
/*      */ 
/* 3232 */     float f6 = this.projection.m30 * f1 + this.projection.m31 * f2 + this.projection.m32 * f3 + this.projection.m33 * f4;
/*      */ 
/* 3236 */     if (f6 != 0.0F) f5 /= f6;
/* 3237 */     return ((f5 + 1.0F) / 2.0F);
/*      */   }
/*      */ 
/*      */   public float modelX(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 3242 */     float f1 = this.modelview.m00 * paramFloat1 + this.modelview.m01 * paramFloat2 + this.modelview.m02 * paramFloat3 + this.modelview.m03;
/*      */ 
/* 3244 */     float f2 = this.modelview.m30 * paramFloat1 + this.modelview.m31 * paramFloat2 + this.modelview.m32 * paramFloat3 + this.modelview.m33;
/*      */ 
/* 3246 */     return ((f2 != 0.0F) ? f1 / f2 : f1);
/*      */   }
/*      */ 
/*      */   public float modelY(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 3251 */     float f1 = this.modelview.m10 * paramFloat1 + this.modelview.m11 * paramFloat2 + this.modelview.m12 * paramFloat3 + this.modelview.m13;
/*      */ 
/* 3253 */     float f2 = this.modelview.m30 * paramFloat1 + this.modelview.m31 * paramFloat2 + this.modelview.m32 * paramFloat3 + this.modelview.m33;
/*      */ 
/* 3255 */     return ((f2 != 0.0F) ? f1 / f2 : f1);
/*      */   }
/*      */ 
/*      */   public float modelZ(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 3260 */     float f1 = this.modelview.m20 * paramFloat1 + this.modelview.m21 * paramFloat2 + this.modelview.m22 * paramFloat3 + this.modelview.m23;
/*      */ 
/* 3262 */     float f2 = this.modelview.m30 * paramFloat1 + this.modelview.m31 * paramFloat2 + this.modelview.m32 * paramFloat3 + this.modelview.m33;
/*      */ 
/* 3264 */     return ((f2 != 0.0F) ? f1 / f2 : f1);
/*      */   }
/*      */ 
/*      */   public void background(PImage paramPImage)
/*      */   {
/* 3284 */     super.background(paramPImage);
/*      */ 
/* 3286 */     for (int i = 0; i < this.pixelCount; ++i) {
/* 3287 */       this.zbuffer[i] = 3.4028235E+38F;
/* 3288 */       this.stencil[i] = 0;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void clear()
/*      */   {
/* 3301 */     for (int i = 0; i < this.pixelCount; ++i) {
/* 3302 */       this.pixels[i] = this.backgroundColor;
/* 3303 */       this.zbuffer[i] = 3.4028235E+38F;
/* 3304 */       this.stencil[i] = 0;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void smooth()
/*      */   {
/* 3319 */     String str = "smooth() not available with P3D";
/* 3320 */     throw new RuntimeException(str);
/*      */   }
/*      */ 
/*      */   public void noSmooth()
/*      */   {
/* 3325 */     String str = "noSmooth() not available with P3D";
/* 3326 */     throw new RuntimeException(str);
/*      */   }
/*      */ 
/*      */   public void fill(int paramInt)
/*      */   {
/* 3334 */     super.fill(paramInt);
/* 3335 */     colorAmbient();
/*      */   }
/*      */ 
/*      */   public void fill(float paramFloat) {
/* 3339 */     super.fill(paramFloat);
/* 3340 */     colorAmbient();
/*      */   }
/*      */ 
/*      */   public void fill(float paramFloat1, float paramFloat2)
/*      */   {
/* 3345 */     super.fill(paramFloat1, paramFloat2);
/* 3346 */     colorAmbient();
/*      */   }
/*      */ 
/*      */   public void fill(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 3351 */     super.fill(paramFloat1, paramFloat2, paramFloat3);
/* 3352 */     colorAmbient();
/*      */   }
/*      */ 
/*      */   public void fill(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 3357 */     super.fill(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/* 3358 */     colorAmbient();
/*      */   }
/*      */ 
/*      */   public void ambient(int paramInt)
/*      */   {
/* 3366 */     if (((paramInt & 0xFF000000) == 0) && (paramInt <= this.colorModeX)) {
/* 3367 */       ambient(paramInt);
/*      */     }
/*      */     else {
/* 3370 */       colorFrom(paramInt);
/* 3371 */       colorAmbient();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void ambient(float paramFloat)
/*      */   {
/* 3377 */     colorCalc(paramFloat);
/* 3378 */     colorAmbient();
/*      */   }
/*      */ 
/*      */   public void ambient(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 3383 */     colorCalc(paramFloat1, paramFloat2, paramFloat3);
/* 3384 */     colorAmbient();
/*      */   }
/*      */ 
/*      */   private final void colorAmbient()
/*      */   {
/* 3389 */     this.ambientR = this.calcR;
/* 3390 */     this.ambientG = this.calcG;
/* 3391 */     this.ambientB = this.calcB;
/* 3392 */     this.ambientRi = this.calcRi;
/* 3393 */     this.ambientGi = this.calcGi;
/* 3394 */     this.ambientBi = this.calcBi;
/*      */   }
/*      */ 
/*      */   public void specular(int paramInt)
/*      */   {
/* 3402 */     if (((paramInt & 0xFF000000) == 0) && (paramInt <= this.colorModeX)) {
/* 3403 */       specular(paramInt);
/*      */     }
/*      */     else {
/* 3406 */       colorFrom(paramInt);
/* 3407 */       colorSpecular();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void specular(float paramFloat)
/*      */   {
/* 3413 */     colorCalc(paramFloat);
/* 3414 */     colorSpecular();
/*      */   }
/*      */ 
/*      */   public void specular(float paramFloat1, float paramFloat2)
/*      */   {
/* 3419 */     colorCalc(paramFloat1, paramFloat2);
/* 3420 */     colorSpecular();
/*      */   }
/*      */ 
/*      */   public void specular(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 3425 */     colorCalc(paramFloat1, paramFloat2, paramFloat3);
/* 3426 */     colorSpecular();
/*      */   }
/*      */ 
/*      */   public void specular(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*      */   {
/* 3431 */     colorCalc(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/* 3432 */     colorSpecular();
/*      */   }
/*      */ 
/*      */   protected void colorSpecular()
/*      */   {
/* 3437 */     this.specularR = this.calcR;
/* 3438 */     this.specularG = this.calcG;
/* 3439 */     this.specularB = this.calcB;
/* 3440 */     this.specularA = this.calcA;
/* 3441 */     this.specularRi = this.calcRi;
/* 3442 */     this.specularGi = this.calcGi;
/* 3443 */     this.specularBi = this.calcBi;
/* 3444 */     this.specularAi = this.calcAi;
/*      */   }
/*      */ 
/*      */   public void emissive(int paramInt)
/*      */   {
/* 3452 */     if (((paramInt & 0xFF000000) == 0) && (paramInt <= this.colorModeX)) {
/* 3453 */       emissive(paramInt);
/*      */     }
/*      */     else {
/* 3456 */       colorFrom(paramInt);
/* 3457 */       colorEmissive();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void emissive(float paramFloat)
/*      */   {
/* 3463 */     colorCalc(paramFloat);
/* 3464 */     colorEmissive();
/*      */   }
/*      */ 
/*      */   public void emissive(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 3469 */     colorCalc(paramFloat1, paramFloat2, paramFloat3);
/* 3470 */     colorEmissive();
/*      */   }
/*      */ 
/*      */   protected void colorEmissive()
/*      */   {
/* 3475 */     this.emissiveR = this.calcR;
/* 3476 */     this.emissiveG = this.calcG;
/* 3477 */     this.emissiveB = this.calcB;
/* 3478 */     this.emissiveRi = this.calcRi;
/* 3479 */     this.emissiveGi = this.calcGi;
/* 3480 */     this.emissiveBi = this.calcBi;
/*      */   }
/*      */ 
/*      */   public void shininess(float paramFloat)
/*      */   {
/* 3488 */     this.shininess = paramFloat;
/*      */   }
/*      */ 
/*      */   public void lights()
/*      */   {
/* 3621 */     int i = this.colorMode;
/* 3622 */     this.colorMode = 1;
/*      */ 
/* 3624 */     lightFalloff(1.0F, 0.0F, 0.0F);
/* 3625 */     lightSpecular(0.0F, 0.0F, 0.0F);
/*      */ 
/* 3627 */     ambientLight(this.colorModeX * 0.5F, this.colorModeY * 0.5F, this.colorModeZ * 0.5F);
/*      */ 
/* 3630 */     directionalLight(this.colorModeX * 0.5F, this.colorModeY * 0.5F, this.colorModeZ * 0.5F, 0.0F, 0.0F, -1.0F);
/*      */ 
/* 3635 */     this.colorMode = i;
/*      */ 
/* 3637 */     this.lightingDependsOnVertexPosition = false;
/*      */   }
/*      */ 
/*      */   public void ambientLight(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/* 3645 */     if (this.lightCount == 8) {
/* 3646 */       throw new RuntimeException("can only create 8 lights");
/*      */     }
/* 3648 */     colorCalc(paramFloat1, paramFloat2, paramFloat3);
/* 3649 */     this.lightsDiffuseR[this.lightCount] = this.calcR;
/* 3650 */     this.lightsDiffuseG[this.lightCount] = this.calcG;
/* 3651 */     this.lightsDiffuseB[this.lightCount] = this.calcB;
/*      */ 
/* 3653 */     this.lights[this.lightCount] = 0;
/* 3654 */     this.lightsFalloffConstant[this.lightCount] = this.lightFalloffConstant;
/* 3655 */     this.lightsFalloffLinear[this.lightCount] = this.lightFalloffLinear;
/* 3656 */     this.lightsFalloffQuadratic[this.lightCount] = this.lightFalloffQuadratic;
/* 3657 */     lightPosition(this.lightCount, paramFloat4, paramFloat5, paramFloat6);
/* 3658 */     this.lightCount += 1;
/*      */   }
/*      */ 
/*      */   public void ambientLight(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 3663 */     ambientLight(paramFloat1, paramFloat2, paramFloat3, 0.0F, 0.0F, 0.0F);
/*      */   }
/*      */ 
/*      */   public void directionalLight(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/* 3669 */     if (this.lightCount == 8) {
/* 3670 */       throw new RuntimeException("can only create 8 lights");
/*      */     }
/* 3672 */     colorCalc(paramFloat1, paramFloat2, paramFloat3);
/* 3673 */     this.lightsDiffuseR[this.lightCount] = this.calcR;
/* 3674 */     this.lightsDiffuseG[this.lightCount] = this.calcG;
/* 3675 */     this.lightsDiffuseB[this.lightCount] = this.calcB;
/*      */ 
/* 3678 */     this.lights[this.lightCount] = 1;
/* 3679 */     this.lightsFalloffConstant[this.lightCount] = this.lightFalloffConstant;
/* 3680 */     this.lightsFalloffLinear[this.lightCount] = this.lightFalloffLinear;
/* 3681 */     this.lightsFalloffQuadratic[this.lightCount] = this.lightFalloffQuadratic;
/* 3682 */     this.lightsSpecularR[this.lightCount] = this.lightSpecularR;
/* 3683 */     this.lightsSpecularG[this.lightCount] = this.lightSpecularG;
/* 3684 */     this.lightsSpecularB[this.lightCount] = this.lightSpecularB;
/* 3685 */     lightDirection(this.lightCount, paramFloat4, paramFloat5, paramFloat6);
/* 3686 */     this.lightCount += 1;
/*      */   }
/*      */ 
/*      */   public void pointLight(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/* 3693 */     if (this.lightCount == 8) {
/* 3694 */       throw new RuntimeException("can only create 8 lights");
/*      */     }
/* 3696 */     colorCalc(paramFloat1, paramFloat2, paramFloat3);
/* 3697 */     this.lightsDiffuseR[this.lightCount] = this.calcR;
/* 3698 */     this.lightsDiffuseG[this.lightCount] = this.calcG;
/* 3699 */     this.lightsDiffuseB[this.lightCount] = this.calcB;
/*      */ 
/* 3702 */     this.lights[this.lightCount] = 2;
/* 3703 */     this.lightsFalloffConstant[this.lightCount] = this.lightFalloffConstant;
/* 3704 */     this.lightsFalloffLinear[this.lightCount] = this.lightFalloffLinear;
/* 3705 */     this.lightsFalloffQuadratic[this.lightCount] = this.lightFalloffQuadratic;
/* 3706 */     this.lightsSpecularR[this.lightCount] = this.lightSpecularR;
/* 3707 */     this.lightsSpecularG[this.lightCount] = this.lightSpecularG;
/* 3708 */     this.lightsSpecularB[this.lightCount] = this.lightSpecularB;
/* 3709 */     lightPosition(this.lightCount, paramFloat4, paramFloat5, paramFloat6);
/* 3710 */     this.lightCount += 1;
/*      */ 
/* 3712 */     this.lightingDependsOnVertexPosition = true;
/*      */   }
/*      */ 
/*      */   public void spotLight(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11)
/*      */   {
/* 3721 */     if (this.lightCount == 8) {
/* 3722 */       throw new RuntimeException("can only create 8 lights");
/*      */     }
/* 3724 */     colorCalc(paramFloat1, paramFloat2, paramFloat3);
/* 3725 */     this.lightsDiffuseR[this.lightCount] = this.calcR;
/* 3726 */     this.lightsDiffuseG[this.lightCount] = this.calcG;
/* 3727 */     this.lightsDiffuseB[this.lightCount] = this.calcB;
/*      */ 
/* 3729 */     this.lights[this.lightCount] = 3;
/* 3730 */     this.lightsFalloffConstant[this.lightCount] = this.lightFalloffConstant;
/* 3731 */     this.lightsFalloffLinear[this.lightCount] = this.lightFalloffLinear;
/* 3732 */     this.lightsFalloffQuadratic[this.lightCount] = this.lightFalloffQuadratic;
/* 3733 */     this.lightsSpecularR[this.lightCount] = this.lightSpecularR;
/* 3734 */     this.lightsSpecularG[this.lightCount] = this.lightSpecularG;
/* 3735 */     this.lightsSpecularB[this.lightCount] = this.lightSpecularB;
/* 3736 */     lightPosition(this.lightCount, paramFloat4, paramFloat5, paramFloat6);
/* 3737 */     lightDirection(this.lightCount, paramFloat7, paramFloat8, paramFloat9);
/* 3738 */     this.lightsSpotAngle[this.lightCount] = paramFloat10;
/* 3739 */     this.lightsSpotAngleCos[this.lightCount] = max(0.0F, cos(paramFloat10));
/* 3740 */     this.lightsSpotConcentration[this.lightCount] = paramFloat11;
/* 3741 */     this.lightCount += 1;
/*      */ 
/* 3743 */     this.lightingDependsOnVertexPosition = true;
/*      */   }
/*      */ 
/*      */   public void lightFalloff(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 3752 */     this.lightFalloffConstant = paramFloat1;
/* 3753 */     this.lightFalloffLinear = paramFloat2;
/* 3754 */     this.lightFalloffQuadratic = paramFloat3;
/*      */ 
/* 3756 */     this.lightingDependsOnVertexPosition = true;
/*      */   }
/*      */ 
/*      */   public void lightSpecular(float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 3764 */     colorCalc(paramFloat1, paramFloat2, paramFloat3);
/* 3765 */     this.lightSpecularR = this.calcR;
/* 3766 */     this.lightSpecularG = this.calcG;
/* 3767 */     this.lightSpecularB = this.calcB;
/*      */ 
/* 3769 */     this.lightingDependsOnVertexPosition = true;
/*      */   }
/*      */ 
/*      */   protected void lightPosition(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 3778 */     this.lightsX[paramInt] = (this.modelview.m00 * paramFloat1 + this.modelview.m01 * paramFloat2 + this.modelview.m02 * paramFloat3 + this.modelview.m03);
/*      */ 
/* 3780 */     this.lightsY[paramInt] = (this.modelview.m10 * paramFloat1 + this.modelview.m11 * paramFloat2 + this.modelview.m12 * paramFloat3 + this.modelview.m13);
/*      */ 
/* 3782 */     this.lightsZ[paramInt] = (this.modelview.m20 * paramFloat1 + this.modelview.m21 * paramFloat2 + this.modelview.m22 * paramFloat3 + this.modelview.m23);
/*      */   }
/*      */ 
/*      */   protected void lightDirection(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3)
/*      */   {
/* 3793 */     this.lightsNX[paramInt] = (this.modelviewInv.m00 * paramFloat1 + this.modelviewInv.m10 * paramFloat2 + this.modelviewInv.m20 * paramFloat3 + this.modelviewInv.m30);
/*      */ 
/* 3796 */     this.lightsNY[paramInt] = (this.modelviewInv.m01 * paramFloat1 + this.modelviewInv.m11 * paramFloat2 + this.modelviewInv.m21 * paramFloat3 + this.modelviewInv.m31);
/*      */ 
/* 3799 */     this.lightsNZ[paramInt] = (this.modelviewInv.m02 * paramFloat1 + this.modelviewInv.m12 * paramFloat2 + this.modelviewInv.m22 * paramFloat3 + this.modelviewInv.m32);
/*      */ 
/* 3803 */     float f = mag(this.lightsNX[paramInt], this.lightsNY[paramInt], this.lightsNZ[paramInt]);
/* 3804 */     if ((f == 0.0F) || (f == 1.0F)) return;
/*      */ 
/* 3806 */     this.lightsNX[paramInt] /= f;
/* 3807 */     this.lightsNY[paramInt] /= f;
/* 3808 */     this.lightsNZ[paramInt] /= f;
/*      */   }
/*      */ 
/*      */   private final float mag(float paramFloat1, float paramFloat2)
/*      */   {
/* 3819 */     return (float)Math.sqrt(paramFloat1 * paramFloat1 + paramFloat2 * paramFloat2);
/*      */   }
/*      */ 
/*      */   private final float mag(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 3823 */     return (float)Math.sqrt(paramFloat1 * paramFloat1 + paramFloat2 * paramFloat2 + paramFloat3 * paramFloat3);
/*      */   }
/*      */ 
/*      */   private final float min(float paramFloat1, float paramFloat2) {
/* 3827 */     return ((paramFloat1 < paramFloat2) ? paramFloat1 : paramFloat2);
/*      */   }
/*      */ 
/*      */   private final float max(float paramFloat1, float paramFloat2) {
/* 3831 */     return ((paramFloat1 > paramFloat2) ? paramFloat1 : paramFloat2);
/*      */   }
/*      */ 
/*      */   private final float max(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 3835 */     return Math.max(paramFloat1, Math.max(paramFloat2, paramFloat3));
/*      */   }
/*      */ 
/*      */   private final float sq(float paramFloat) {
/* 3839 */     return (paramFloat * paramFloat);
/*      */   }
/*      */ 
/*      */   private final float sqrt(float paramFloat) {
/* 3843 */     return (float)Math.sqrt(paramFloat);
/*      */   }
/*      */ 
/*      */   private final float pow(float paramFloat1, float paramFloat2) {
/* 3847 */     return (float)Math.pow(paramFloat1, paramFloat2);
/*      */   }
/*      */ 
/*      */   private final float abs(float paramFloat) {
/* 3851 */     return ((paramFloat < 0.0F) ? -paramFloat : paramFloat);
/*      */   }
/*      */ 
/*      */   private final float sin(float paramFloat)
/*      */   {
/* 3856 */     return (float)Math.sin(paramFloat);
/*      */   }
/*      */ 
/*      */   private final float cos(float paramFloat)
/*      */   {
/* 3861 */     return (float)Math.cos(paramFloat);
/*      */   }
/*      */ 
/*      */   private final float tan(float paramFloat)
/*      */   {
/* 3866 */     return (float)Math.tan(paramFloat);
/*      */   }
/*      */ 
/*      */   private final float dot(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
/*      */   {
/* 3871 */     return (paramFloat1 * paramFloat4 + paramFloat2 * paramFloat5 + paramFloat3 * paramFloat6);
/*      */   }
/*      */ 
/*      */   private final void jdMethod_this()
/*      */   {
/*   56 */     this.useBackfaceCulling = false;
/*      */ 
/*   88 */     this.tempLightingContribution = new float[9];
/*   89 */     this.worldNormal = new float[4];
/*      */ 
/*  133 */     this.lightCount = 0;
/*      */ 
/*  189 */     this.vertex_order = new int[512];
/*      */ 
/*  194 */     this.pathOffset = new int[64];
/*  195 */     this.pathLength = new int[64];
/*      */ 
/*  202 */     this.lines = new int[512][5];
/*      */ 
/*  210 */     this.triangles = new int[256][5];
/*      */ 
/*  212 */     this.triangleColors = new float[256][3][8];
/*      */ 
/*  240 */     this.textures = new PImage[3];
/*      */ 
/*  256 */     this.sphereDetail = 0;
/*      */   }
/*      */ 
/*      */   public PGraphics3()
/*      */   {
/*  267 */     jdMethod_this();
/*  268 */     this.forwardTransform = this.modelview;
/*  269 */     this.reverseTransform = this.modelviewInv;
/*      */   }
/*      */ 
/*      */   public PGraphics3(int paramInt1, int paramInt2, PApplet paramPApplet)
/*      */   {
/*  284 */     super(paramInt1, paramInt2, paramPApplet); jdMethod_this();
/*  285 */     this.forwardTransform = this.modelview;
/*  286 */     this.reverseTransform = this.modelviewInv;
/*      */   }
/*      */ }

/* Location:           /Users/mfeyereisen/Desktop/Sources 2/common/
 * Qualified Name:     processing.core.PGraphics3
 * JD-Core Version:    0.5.3
 */