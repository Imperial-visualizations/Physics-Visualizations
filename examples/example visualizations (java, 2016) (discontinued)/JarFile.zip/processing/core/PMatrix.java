/*     */ package processing.core;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ public final class PMatrix
/*     */   implements PConstants
/*     */ {
/*     */   static final int DEFAULT_STACK_DEPTH = 0;
/*     */   public float m00;
/*     */   public float m01;
/*     */   public float m02;
/*     */   public float m03;
/*     */   public float m10;
/*     */   public float m11;
/*     */   public float m12;
/*     */   public float m13;
/*     */   public float m20;
/*     */   public float m21;
/*     */   public float m22;
/*     */   public float m23;
/*     */   public float m30;
/*     */   public float m31;
/*     */   public float m32;
/*     */   public float m33;
/*     */   int maxStackDepth;
/*     */   int stackPointer;
/*     */   float[][] stack;
/*     */ 
/*     */   public final void reset()
/*     */   {
/*  78 */     set(1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   public final void clearStack()
/*     */   {
/*  86 */     this.stackPointer = 0;
/*     */   }
/*     */ 
/*     */   public final boolean push()
/*     */   {
/*  91 */     if (this.stackPointer == this.maxStackDepth) return false;
/*     */ 
/*  93 */     this.stack[this.stackPointer][0] = this.m00;
/*  94 */     this.stack[this.stackPointer][1] = this.m01;
/*  95 */     this.stack[this.stackPointer][2] = this.m02;
/*  96 */     this.stack[this.stackPointer][3] = this.m03;
/*     */ 
/*  98 */     this.stack[this.stackPointer][4] = this.m10;
/*  99 */     this.stack[this.stackPointer][5] = this.m11;
/* 100 */     this.stack[this.stackPointer][6] = this.m12;
/* 101 */     this.stack[this.stackPointer][7] = this.m13;
/*     */ 
/* 103 */     this.stack[this.stackPointer][8] = this.m20;
/* 104 */     this.stack[this.stackPointer][9] = this.m21;
/* 105 */     this.stack[this.stackPointer][10] = this.m22;
/* 106 */     this.stack[this.stackPointer][11] = this.m23;
/*     */ 
/* 108 */     this.stack[this.stackPointer][12] = this.m30;
/* 109 */     this.stack[this.stackPointer][13] = this.m31;
/* 110 */     this.stack[this.stackPointer][14] = this.m32;
/* 111 */     this.stack[this.stackPointer][15] = this.m33;
/*     */ 
/* 113 */     this.stackPointer += 1;
/* 114 */     return true;
/*     */   }
/*     */ 
/*     */   public final boolean pop()
/*     */   {
/* 119 */     if (this.stackPointer == 0) return false;
/* 120 */     this.stackPointer -= 1;
/*     */ 
/* 122 */     this.m00 = this.stack[this.stackPointer][0];
/* 123 */     this.m01 = this.stack[this.stackPointer][1];
/* 124 */     this.m02 = this.stack[this.stackPointer][2];
/* 125 */     this.m03 = this.stack[this.stackPointer][3];
/*     */ 
/* 127 */     this.m10 = this.stack[this.stackPointer][4];
/* 128 */     this.m11 = this.stack[this.stackPointer][5];
/* 129 */     this.m12 = this.stack[this.stackPointer][6];
/* 130 */     this.m13 = this.stack[this.stackPointer][7];
/*     */ 
/* 132 */     this.m20 = this.stack[this.stackPointer][8];
/* 133 */     this.m21 = this.stack[this.stackPointer][9];
/* 134 */     this.m22 = this.stack[this.stackPointer][10];
/* 135 */     this.m23 = this.stack[this.stackPointer][11];
/*     */ 
/* 137 */     this.m30 = this.stack[this.stackPointer][12];
/* 138 */     this.m31 = this.stack[this.stackPointer][13];
/* 139 */     this.m32 = this.stack[this.stackPointer][14];
/* 140 */     this.m33 = this.stack[this.stackPointer][15];
/*     */ 
/* 142 */     return true;
/*     */   }
/*     */ 
/*     */   public final void set(PMatrix paramPMatrix)
/*     */   {
/* 147 */     set(paramPMatrix.m00, paramPMatrix.m01, paramPMatrix.m02, paramPMatrix.m03, paramPMatrix.m10, paramPMatrix.m11, paramPMatrix.m12, paramPMatrix.m13, paramPMatrix.m20, paramPMatrix.m21, paramPMatrix.m22, paramPMatrix.m23, paramPMatrix.m30, paramPMatrix.m31, paramPMatrix.m32, paramPMatrix.m33);
/*     */   }
/*     */ 
/*     */   public final void set(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12, float paramFloat13, float paramFloat14, float paramFloat15, float paramFloat16)
/*     */   {
/* 158 */     this.m00 = paramFloat1; this.m01 = paramFloat2; this.m02 = paramFloat3; this.m03 = paramFloat4;
/* 159 */     this.m10 = paramFloat5; this.m11 = paramFloat6; this.m12 = paramFloat7; this.m13 = paramFloat8;
/* 160 */     this.m20 = paramFloat9; this.m21 = paramFloat10; this.m22 = paramFloat11; this.m23 = paramFloat12;
/* 161 */     this.m30 = paramFloat13; this.m31 = paramFloat14; this.m32 = paramFloat15; this.m33 = paramFloat16;
/*     */   }
/*     */ 
/*     */   public final void translate(float paramFloat1, float paramFloat2)
/*     */   {
/* 166 */     translate(paramFloat1, paramFloat2, 0.0F);
/*     */   }
/*     */ 
/*     */   public final void invTranslate(float paramFloat1, float paramFloat2) {
/* 170 */     invTranslate(paramFloat1, paramFloat2, 0.0F);
/*     */   }
/*     */ 
/*     */   public final void translate(float paramFloat1, float paramFloat2, float paramFloat3)
/*     */   {
/* 175 */     this.m03 += paramFloat1 * this.m00 + paramFloat2 * this.m01 + paramFloat3 * this.m02;
/* 176 */     this.m13 += paramFloat1 * this.m10 + paramFloat2 * this.m11 + paramFloat3 * this.m12;
/* 177 */     this.m23 += paramFloat1 * this.m20 + paramFloat2 * this.m21 + paramFloat3 * this.m22;
/* 178 */     this.m33 += paramFloat1 * this.m30 + paramFloat2 * this.m31 + paramFloat3 * this.m32;
/*     */   }
/*     */ 
/*     */   public final void invTranslate(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 182 */     preApply(1.0F, 0.0F, 0.0F, -paramFloat1, 0.0F, 1.0F, 0.0F, -paramFloat2, 0.0F, 0.0F, 1.0F, -paramFloat3, 0.0F, 0.0F, 0.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   public final void rotateX(float paramFloat)
/*     */   {
/* 193 */     float f1 = cos(paramFloat);
/* 194 */     float f2 = sin(paramFloat);
/* 195 */     apply(1.0F, 0.0F, 0.0F, 0.0F, 0.0F, f1, -f2, 0.0F, 0.0F, f2, f1, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   public final void invRotateX(float paramFloat)
/*     */   {
/* 200 */     float f1 = cos(-paramFloat);
/* 201 */     float f2 = sin(-paramFloat);
/* 202 */     preApply(1.0F, 0.0F, 0.0F, 0.0F, 0.0F, f1, -f2, 0.0F, 0.0F, f2, f1, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   public final void rotateY(float paramFloat)
/*     */   {
/* 207 */     float f1 = cos(paramFloat);
/* 208 */     float f2 = sin(paramFloat);
/* 209 */     apply(f1, 0.0F, f2, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, -f2, 0.0F, f1, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   public final void invRotateY(float paramFloat)
/*     */   {
/* 214 */     float f1 = cos(-paramFloat);
/* 215 */     float f2 = sin(-paramFloat);
/* 216 */     preApply(f1, 0.0F, f2, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, -f2, 0.0F, f1, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   public final void rotate(float paramFloat)
/*     */   {
/* 225 */     rotateZ(paramFloat);
/*     */   }
/*     */ 
/*     */   public final void invRotate(float paramFloat)
/*     */   {
/* 230 */     invRotateZ(paramFloat);
/*     */   }
/*     */ 
/*     */   public final void rotateZ(float paramFloat)
/*     */   {
/* 235 */     float f1 = cos(paramFloat);
/* 236 */     float f2 = sin(paramFloat);
/* 237 */     apply(f1, -f2, 0.0F, 0.0F, f2, f1, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   public final void invRotateZ(float paramFloat)
/*     */   {
/* 242 */     float f1 = cos(-paramFloat);
/* 243 */     float f2 = sin(-paramFloat);
/* 244 */     preApply(f1, -f2, 0.0F, 0.0F, f2, f1, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   public final void rotate(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*     */   {
/* 254 */     float f1 = cos(paramFloat1);
/* 255 */     float f2 = sin(paramFloat1);
/* 256 */     float f3 = 1.0F - f1;
/*     */ 
/* 258 */     apply(f3 * paramFloat2 * paramFloat2 + f1, f3 * paramFloat2 * paramFloat3 - (f2 * paramFloat4), f3 * paramFloat2 * paramFloat4 + f2 * paramFloat3, 0.0F, f3 * paramFloat2 * paramFloat3 + f2 * paramFloat4, f3 * paramFloat3 * paramFloat3 + f1, f3 * paramFloat3 * paramFloat4 - (f2 * paramFloat2), 0.0F, f3 * paramFloat2 * paramFloat4 - (f2 * paramFloat3), f3 * paramFloat3 * paramFloat4 + f2 * paramFloat2, f3 * paramFloat4 * paramFloat4 + f1, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   public final void invRotate(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
/*     */   {
/* 268 */     float f1 = cos(-paramFloat1);
/* 269 */     float f2 = sin(-paramFloat1);
/* 270 */     float f3 = 1.0F - f1;
/*     */ 
/* 272 */     preApply(f3 * paramFloat2 * paramFloat2 + f1, f3 * paramFloat2 * paramFloat3 - (f2 * paramFloat4), f3 * paramFloat2 * paramFloat4 + f2 * paramFloat3, 0.0F, f3 * paramFloat2 * paramFloat3 + f2 * paramFloat4, f3 * paramFloat3 * paramFloat3 + f1, f3 * paramFloat3 * paramFloat4 - (f2 * paramFloat2), 0.0F, f3 * paramFloat2 * paramFloat4 - (f2 * paramFloat3), f3 * paramFloat3 * paramFloat4 + f2 * paramFloat2, f3 * paramFloat4 * paramFloat4 + f1, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   public final void scale(float paramFloat)
/*     */   {
/* 280 */     apply(paramFloat, 0.0F, 0.0F, 0.0F, 0.0F, paramFloat, 0.0F, 0.0F, 0.0F, 0.0F, paramFloat, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   public final void invScale(float paramFloat)
/*     */   {
/* 285 */     preApply(1.0F / paramFloat, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F / paramFloat, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F / paramFloat, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   public final void scale(float paramFloat1, float paramFloat2)
/*     */   {
/* 290 */     apply(paramFloat1, 0.0F, 0.0F, 0.0F, 0.0F, paramFloat2, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   public final void invScale(float paramFloat1, float paramFloat2)
/*     */   {
/* 295 */     preApply(1.0F / paramFloat1, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F / paramFloat2, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   public final void scale(float paramFloat1, float paramFloat2, float paramFloat3)
/*     */   {
/* 301 */     apply(paramFloat1, 0.0F, 0.0F, 0.0F, 0.0F, paramFloat2, 0.0F, 0.0F, 0.0F, 0.0F, paramFloat3, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   public final void invScale(float paramFloat1, float paramFloat2, float paramFloat3)
/*     */   {
/* 306 */     preApply(1.0F / paramFloat1, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F / paramFloat2, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F / paramFloat3, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   public final void transform(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12, float paramFloat13, float paramFloat14, float paramFloat15, float paramFloat16)
/*     */   {
/* 314 */     apply(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramFloat11, paramFloat12, paramFloat13, paramFloat14, paramFloat15, paramFloat16);
/*     */   }
/*     */ 
/*     */   public final void preApply(PMatrix paramPMatrix)
/*     */   {
/* 322 */     preApply(paramPMatrix.m00, paramPMatrix.m01, paramPMatrix.m02, paramPMatrix.m03, paramPMatrix.m10, paramPMatrix.m11, paramPMatrix.m12, paramPMatrix.m13, paramPMatrix.m20, paramPMatrix.m21, paramPMatrix.m22, paramPMatrix.m23, paramPMatrix.m30, paramPMatrix.m31, paramPMatrix.m32, paramPMatrix.m33);
/*     */   }
/*     */ 
/*     */   public final void preApply(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12, float paramFloat13, float paramFloat14, float paramFloat15, float paramFloat16)
/*     */   {
/* 335 */     float f1 = paramFloat1 * this.m00 + paramFloat2 * this.m10 + paramFloat3 * this.m20 + paramFloat4 * this.m30;
/* 336 */     float f2 = paramFloat1 * this.m01 + paramFloat2 * this.m11 + paramFloat3 * this.m21 + paramFloat4 * this.m31;
/* 337 */     float f3 = paramFloat1 * this.m02 + paramFloat2 * this.m12 + paramFloat3 * this.m22 + paramFloat4 * this.m32;
/* 338 */     float f4 = paramFloat1 * this.m03 + paramFloat2 * this.m13 + paramFloat3 * this.m23 + paramFloat4 * this.m33;
/*     */ 
/* 340 */     float f5 = paramFloat5 * this.m00 + paramFloat6 * this.m10 + paramFloat7 * this.m20 + paramFloat8 * this.m30;
/* 341 */     float f6 = paramFloat5 * this.m01 + paramFloat6 * this.m11 + paramFloat7 * this.m21 + paramFloat8 * this.m31;
/* 342 */     float f7 = paramFloat5 * this.m02 + paramFloat6 * this.m12 + paramFloat7 * this.m22 + paramFloat8 * this.m32;
/* 343 */     float f8 = paramFloat5 * this.m03 + paramFloat6 * this.m13 + paramFloat7 * this.m23 + paramFloat8 * this.m33;
/*     */ 
/* 345 */     float f9 = paramFloat9 * this.m00 + paramFloat10 * this.m10 + paramFloat11 * this.m20 + paramFloat12 * this.m30;
/* 346 */     float f10 = paramFloat9 * this.m01 + paramFloat10 * this.m11 + paramFloat11 * this.m21 + paramFloat12 * this.m31;
/* 347 */     float f11 = paramFloat9 * this.m02 + paramFloat10 * this.m12 + paramFloat11 * this.m22 + paramFloat12 * this.m32;
/* 348 */     float f12 = paramFloat9 * this.m03 + paramFloat10 * this.m13 + paramFloat11 * this.m23 + paramFloat12 * this.m33;
/*     */ 
/* 350 */     float f13 = paramFloat13 * this.m00 + paramFloat14 * this.m10 + paramFloat15 * this.m20 + paramFloat16 * this.m30;
/* 351 */     float f14 = paramFloat13 * this.m01 + paramFloat14 * this.m11 + paramFloat15 * this.m21 + paramFloat16 * this.m31;
/* 352 */     float f15 = paramFloat13 * this.m02 + paramFloat14 * this.m12 + paramFloat15 * this.m22 + paramFloat16 * this.m32;
/* 353 */     float f16 = paramFloat13 * this.m03 + paramFloat14 * this.m13 + paramFloat15 * this.m23 + paramFloat16 * this.m33;
/*     */ 
/* 355 */     this.m00 = f1; this.m01 = f2; this.m02 = f3; this.m03 = f4;
/* 356 */     this.m10 = f5; this.m11 = f6; this.m12 = f7; this.m13 = f8;
/* 357 */     this.m20 = f9; this.m21 = f10; this.m22 = f11; this.m23 = f12;
/* 358 */     this.m30 = f13; this.m31 = f14; this.m32 = f15; this.m33 = f16;
/*     */   }
/*     */ 
/*     */   public final boolean invApply(PMatrix paramPMatrix)
/*     */   {
/* 363 */     PMatrix localPMatrix1 = new PMatrix(paramPMatrix);
/* 364 */     PMatrix localPMatrix2 = localPMatrix1.invert();
/* 365 */     if (localPMatrix2 == null) return false;
/* 366 */     preApply(localPMatrix2);
/* 367 */     return true;
/*     */   }
/*     */ 
/*     */   public final boolean invApply(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12, float paramFloat13, float paramFloat14, float paramFloat15, float paramFloat16)
/*     */   {
/* 375 */     PMatrix localPMatrix1 = new PMatrix(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramFloat11, paramFloat12, paramFloat13, paramFloat14, paramFloat15, paramFloat16);
/*     */ 
/* 379 */     PMatrix localPMatrix2 = localPMatrix1.invert();
/* 380 */     if (localPMatrix2 == null) return false;
/* 381 */     preApply(localPMatrix2);
/* 382 */     return true;
/*     */   }
/*     */ 
/*     */   public final void apply(PMatrix paramPMatrix)
/*     */   {
/* 387 */     apply(paramPMatrix.m00, paramPMatrix.m01, paramPMatrix.m02, paramPMatrix.m03, paramPMatrix.m10, paramPMatrix.m11, paramPMatrix.m12, paramPMatrix.m13, paramPMatrix.m20, paramPMatrix.m21, paramPMatrix.m22, paramPMatrix.m23, paramPMatrix.m30, paramPMatrix.m31, paramPMatrix.m32, paramPMatrix.m33);
/*     */   }
/*     */ 
/*     */   public final void apply(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12, float paramFloat13, float paramFloat14, float paramFloat15, float paramFloat16)
/*     */   {
/* 399 */     float f1 = this.m00 * paramFloat1 + this.m01 * paramFloat5 + this.m02 * paramFloat9 + this.m03 * paramFloat13;
/* 400 */     float f2 = this.m00 * paramFloat2 + this.m01 * paramFloat6 + this.m02 * paramFloat10 + this.m03 * paramFloat14;
/* 401 */     float f3 = this.m00 * paramFloat3 + this.m01 * paramFloat7 + this.m02 * paramFloat11 + this.m03 * paramFloat15;
/* 402 */     float f4 = this.m00 * paramFloat4 + this.m01 * paramFloat8 + this.m02 * paramFloat12 + this.m03 * paramFloat16;
/*     */ 
/* 404 */     float f5 = this.m10 * paramFloat1 + this.m11 * paramFloat5 + this.m12 * paramFloat9 + this.m13 * paramFloat13;
/* 405 */     float f6 = this.m10 * paramFloat2 + this.m11 * paramFloat6 + this.m12 * paramFloat10 + this.m13 * paramFloat14;
/* 406 */     float f7 = this.m10 * paramFloat3 + this.m11 * paramFloat7 + this.m12 * paramFloat11 + this.m13 * paramFloat15;
/* 407 */     float f8 = this.m10 * paramFloat4 + this.m11 * paramFloat8 + this.m12 * paramFloat12 + this.m13 * paramFloat16;
/*     */ 
/* 409 */     float f9 = this.m20 * paramFloat1 + this.m21 * paramFloat5 + this.m22 * paramFloat9 + this.m23 * paramFloat13;
/* 410 */     float f10 = this.m20 * paramFloat2 + this.m21 * paramFloat6 + this.m22 * paramFloat10 + this.m23 * paramFloat14;
/* 411 */     float f11 = this.m20 * paramFloat3 + this.m21 * paramFloat7 + this.m22 * paramFloat11 + this.m23 * paramFloat15;
/* 412 */     float f12 = this.m20 * paramFloat4 + this.m21 * paramFloat8 + this.m22 * paramFloat12 + this.m23 * paramFloat16;
/*     */ 
/* 414 */     float f13 = this.m30 * paramFloat1 + this.m31 * paramFloat5 + this.m32 * paramFloat9 + this.m33 * paramFloat13;
/* 415 */     float f14 = this.m30 * paramFloat2 + this.m31 * paramFloat6 + this.m32 * paramFloat10 + this.m33 * paramFloat14;
/* 416 */     float f15 = this.m30 * paramFloat3 + this.m31 * paramFloat7 + this.m32 * paramFloat11 + this.m33 * paramFloat15;
/* 417 */     float f16 = this.m30 * paramFloat4 + this.m31 * paramFloat8 + this.m32 * paramFloat12 + this.m33 * paramFloat16;
/*     */ 
/* 419 */     this.m00 = f1; this.m01 = f2; this.m02 = f3; this.m03 = f4;
/* 420 */     this.m10 = f5; this.m11 = f6; this.m12 = f7; this.m13 = f8;
/* 421 */     this.m20 = f9; this.m21 = f10; this.m22 = f11; this.m23 = f12;
/* 422 */     this.m30 = f13; this.m31 = f14; this.m32 = f15; this.m33 = f16;
/*     */   }
/*     */ 
/*     */   public final void mult3(float[] paramArrayOfFloat1, float[] paramArrayOfFloat2)
/*     */   {
/* 428 */     float f1 = this.m00 * paramArrayOfFloat1[0] + this.m01 * paramArrayOfFloat1[1] + this.m02 * paramArrayOfFloat1[2] + this.m03;
/* 429 */     float f2 = this.m10 * paramArrayOfFloat1[0] + this.m11 * paramArrayOfFloat1[1] + this.m12 * paramArrayOfFloat1[2] + this.m13;
/* 430 */     float f3 = this.m20 * paramArrayOfFloat1[0] + this.m21 * paramArrayOfFloat1[1] + this.m22 * paramArrayOfFloat1[2] + this.m23;
/*     */ 
/* 432 */     paramArrayOfFloat2[0] = f1;
/* 433 */     paramArrayOfFloat2[1] = f2;
/* 434 */     paramArrayOfFloat2[2] = f3;
/*     */   }
/*     */ 
/*     */   public final void mult(float[] paramArrayOfFloat1, float[] paramArrayOfFloat2)
/*     */   {
/* 440 */     float f1 = this.m00 * paramArrayOfFloat1[0] + this.m01 * paramArrayOfFloat1[1] + this.m02 * paramArrayOfFloat1[2] + this.m03 * paramArrayOfFloat1[3];
/* 441 */     float f2 = this.m10 * paramArrayOfFloat1[0] + this.m11 * paramArrayOfFloat1[1] + this.m12 * paramArrayOfFloat1[2] + this.m13 * paramArrayOfFloat1[3];
/* 442 */     float f3 = this.m20 * paramArrayOfFloat1[0] + this.m21 * paramArrayOfFloat1[1] + this.m22 * paramArrayOfFloat1[2] + this.m23 * paramArrayOfFloat1[3];
/* 443 */     float f4 = this.m30 * paramArrayOfFloat1[0] + this.m31 * paramArrayOfFloat1[1] + this.m32 * paramArrayOfFloat1[2] + this.m33 * paramArrayOfFloat1[3];
/*     */ 
/* 445 */     paramArrayOfFloat2[0] = f1;
/* 446 */     paramArrayOfFloat2[1] = f2;
/* 447 */     paramArrayOfFloat2[2] = f3;
/* 448 */     paramArrayOfFloat2[3] = f4;
/*     */   }
/*     */ 
/*     */   public final float determinant()
/*     */   {
/* 456 */     float f = this.m00 * (this.m11 * this.m22 * this.m33 + this.m12 * this.m23 * this.m31 + this.m13 * this.m21 * this.m32 - (this.m13 * this.m22 * this.m31) - (this.m11 * this.m23 * this.m32) - (this.m12 * this.m21 * this.m33));
/*     */ 
/* 462 */     f -= this.m01 * (this.m10 * this.m22 * this.m33 + this.m12 * this.m23 * this.m30 + this.m13 * this.m20 * this.m32 - (this.m13 * this.m22 * this.m30) - (this.m10 * this.m23 * this.m32) - (this.m12 * this.m20 * this.m33));
/*     */ 
/* 467 */     f += this.m02 * (this.m10 * this.m21 * this.m33 + this.m11 * this.m23 * this.m30 + this.m13 * this.m20 * this.m31 - (this.m13 * this.m21 * this.m30) - (this.m10 * this.m23 * this.m31) - (this.m11 * this.m20 * this.m33));
/*     */ 
/* 472 */     f -= this.m03 * (this.m10 * this.m21 * this.m32 + this.m11 * this.m22 * this.m30 + this.m12 * this.m20 * this.m31 - (this.m12 * this.m21 * this.m30) - (this.m10 * this.m22 * this.m31) - (this.m11 * this.m20 * this.m32));
/*     */ 
/* 477 */     return f;
/*     */   }
/*     */ 
/*     */   private final float determinant3x3(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9)
/*     */   {
/* 488 */     return (paramFloat1 * (paramFloat5 * paramFloat9 - (paramFloat6 * paramFloat8)) + paramFloat2 * (paramFloat6 * paramFloat7 - (paramFloat4 * paramFloat9)) + paramFloat3 * (paramFloat4 * paramFloat8 - (paramFloat5 * paramFloat7)));
/*     */   }
/*     */ 
/*     */   public final PMatrix transpose()
/*     */   {
/* 496 */     float f = this.m01; this.m01 = this.m10; this.m10 = f;
/* 497 */     f = this.m02; this.m02 = this.m20; this.m20 = f;
/* 498 */     f = this.m03; this.m03 = this.m30; this.m30 = f;
/* 499 */     f = this.m12; this.m12 = this.m21; this.m21 = f;
/* 500 */     f = this.m13; this.m13 = this.m31; this.m31 = f;
/* 501 */     f = this.m23; this.m23 = this.m32; this.m32 = f;
/* 502 */     return this;
/*     */   }
/*     */ 
/*     */   public final PMatrix invert()
/*     */   {
/* 512 */     float f1 = determinant();
/*     */ 
/* 514 */     if (f1 != 0.0F)
/*     */     {
/* 519 */       float f2 = 1.0F / f1;
/*     */ 
/* 522 */       float f3 = determinant3x3(this.m11, this.m12, this.m13, this.m21, this.m22, this.m23, this.m31, this.m32, this.m33);
/* 523 */       float f4 = -determinant3x3(this.m10, this.m12, this.m13, this.m20, this.m22, this.m23, this.m30, this.m32, this.m33);
/* 524 */       float f5 = determinant3x3(this.m10, this.m11, this.m13, this.m20, this.m21, this.m23, this.m30, this.m31, this.m33);
/* 525 */       float f6 = -determinant3x3(this.m10, this.m11, this.m12, this.m20, this.m21, this.m22, this.m30, this.m31, this.m32);
/*     */ 
/* 528 */       float f7 = -determinant3x3(this.m01, this.m02, this.m03, this.m21, this.m22, this.m23, this.m31, this.m32, this.m33);
/* 529 */       float f8 = determinant3x3(this.m00, this.m02, this.m03, this.m20, this.m22, this.m23, this.m30, this.m32, this.m33);
/* 530 */       float f9 = -determinant3x3(this.m00, this.m01, this.m03, this.m20, this.m21, this.m23, this.m30, this.m31, this.m33);
/* 531 */       float f10 = determinant3x3(this.m00, this.m01, this.m02, this.m20, this.m21, this.m22, this.m30, this.m31, this.m32);
/*     */ 
/* 534 */       float f11 = determinant3x3(this.m01, this.m02, this.m03, this.m11, this.m12, this.m13, this.m31, this.m32, this.m33);
/* 535 */       float f12 = -determinant3x3(this.m00, this.m02, this.m03, this.m10, this.m12, this.m13, this.m30, this.m32, this.m33);
/* 536 */       float f13 = determinant3x3(this.m00, this.m01, this.m03, this.m10, this.m11, this.m13, this.m30, this.m31, this.m33);
/* 537 */       float f14 = -determinant3x3(this.m00, this.m01, this.m02, this.m10, this.m11, this.m12, this.m30, this.m31, this.m32);
/*     */ 
/* 540 */       float f15 = -determinant3x3(this.m01, this.m02, this.m03, this.m11, this.m12, this.m13, this.m21, this.m22, this.m23);
/* 541 */       float f16 = determinant3x3(this.m00, this.m02, this.m03, this.m10, this.m12, this.m13, this.m20, this.m22, this.m23);
/* 542 */       float f17 = -determinant3x3(this.m00, this.m01, this.m03, this.m10, this.m11, this.m13, this.m20, this.m21, this.m23);
/* 543 */       float f18 = determinant3x3(this.m00, this.m01, this.m02, this.m10, this.m11, this.m12, this.m20, this.m21, this.m22);
/*     */ 
/* 546 */       this.m00 = (f3 * f2);
/* 547 */       this.m11 = (f8 * f2);
/* 548 */       this.m22 = (f13 * f2);
/* 549 */       this.m33 = (f18 * f2);
/* 550 */       this.m01 = (f7 * f2);
/* 551 */       this.m10 = (f4 * f2);
/* 552 */       this.m20 = (f5 * f2);
/* 553 */       this.m02 = (f11 * f2);
/* 554 */       this.m12 = (f12 * f2);
/* 555 */       this.m21 = (f9 * f2);
/* 556 */       this.m03 = (f15 * f2);
/* 557 */       this.m30 = (f6 * f2);
/* 558 */       this.m13 = (f16 * f2);
/* 559 */       this.m31 = (f10 * f2);
/* 560 */       this.m32 = (f14 * f2);
/* 561 */       this.m23 = (f17 * f2);
/* 562 */       return this;
/*     */     }
/* 564 */     return null;
/*     */   }
/*     */ 
/*     */   public final void print()
/*     */   {
/* 572 */     int i = (int)Math.abs(max(max(max(max(abs(this.m00), abs(this.m01)), max(abs(this.m02), abs(this.m03))), max(max(abs(this.m10), abs(this.m11)), max(abs(this.m12), abs(this.m13)))), max(max(max(abs(this.m20), abs(this.m21)), max(abs(this.m22), abs(this.m23))), max(max(abs(this.m30), abs(this.m31)), max(abs(this.m32), abs(this.m33))))));
/*     */     int j;
/* 582 */     if ((Float.isNaN(i)) || (Float.isInfinite(i))) {
/* 583 */       j = 1000000;
/*     */     }
/*     */ 
/* 586 */     int k = 1;
/* 587 */     for (; j /= 10 != 0; ++k);
/* 589 */     System.out.println(PApplet.nfs(this.m00, k, 4) + ' ' + PApplet.nfs(this.m01, k, 4) + ' ' + PApplet.nfs(this.m02, k, 4) + ' ' + PApplet.nfs(this.m03, k, 4));
/*     */ 
/* 594 */     System.out.println(PApplet.nfs(this.m10, k, 4) + ' ' + PApplet.nfs(this.m11, k, 4) + ' ' + PApplet.nfs(this.m12, k, 4) + ' ' + PApplet.nfs(this.m13, k, 4));
/*     */ 
/* 599 */     System.out.println(PApplet.nfs(this.m20, k, 4) + ' ' + PApplet.nfs(this.m21, k, 4) + ' ' + PApplet.nfs(this.m22, k, 4) + ' ' + PApplet.nfs(this.m23, k, 4));
/*     */ 
/* 604 */     System.out.println(PApplet.nfs(this.m30, k, 4) + ' ' + PApplet.nfs(this.m31, k, 4) + ' ' + PApplet.nfs(this.m32, k, 4) + ' ' + PApplet.nfs(this.m33, k, 4));
/*     */ 
/* 609 */     System.out.println();
/*     */   }
/*     */ 
/*     */   private final float max(float paramFloat1, float paramFloat2)
/*     */   {
/* 617 */     return ((paramFloat1 > paramFloat2) ? paramFloat1 : paramFloat2);
/*     */   }
/*     */ 
/*     */   private final float abs(float paramFloat) {
/* 621 */     return ((paramFloat < 0.0F) ? -paramFloat : paramFloat);
/*     */   }
/*     */ 
/*     */   private final float sin(float paramFloat) {
/* 625 */     return (float)Math.sin(paramFloat);
/*     */   }
/*     */ 
/*     */   private final float cos(float paramFloat) {
/* 629 */     return (float)Math.cos(paramFloat);
/*     */   }
/*     */ 
/*     */   private final void jdMethod_this()
/*     */   {
/*  39 */     this.stackPointer = 0;
/*     */   }
/*     */ 
/*     */   public PMatrix() {
/*  43 */     jdMethod_this();
/*  44 */     set(1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
/*  45 */     this.maxStackDepth = 0;
/*     */   }
/*     */ 
/*     */   public PMatrix(int paramInt) {
/*  49 */     jdMethod_this();
/*  50 */     set(1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
/*  51 */     this.stack = new float[paramInt][16];
/*  52 */     this.maxStackDepth = paramInt;
/*     */   }
/*     */ 
/*     */   public PMatrix(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12, float paramFloat13, float paramFloat14, float paramFloat15, float paramFloat16)
/*     */   {
/*  59 */     jdMethod_this();
/*  60 */     set(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramFloat11, paramFloat12, paramFloat13, paramFloat14, paramFloat15, paramFloat16);
/*     */ 
/*  64 */     this.maxStackDepth = 0;
/*     */   }
/*     */ 
/*     */   public PMatrix(PMatrix paramPMatrix)
/*     */   {
/*  70 */     jdMethod_this();
/*  71 */     set(paramPMatrix);
/*  72 */     this.maxStackDepth = paramPMatrix.maxStackDepth;
/*  73 */     this.stack = new float[this.maxStackDepth][16];
/*     */   }
/*     */ }

/* Location:           /Users/mfeyereisen/Desktop/Sources 2/common/
 * Qualified Name:     processing.core.PMatrix
 * JD-Core Version:    0.5.3
 */